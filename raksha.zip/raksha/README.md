# Raksha

**One button. Total protection. Lifelong support.**

Raksha is a women's safety, legal aid and empowerment platform. It gives women one-tap emergency help and stays with them through the legal, emotional and financial journey that follows — from the first second of an emergency to evidence, complaint, legal help, counselling, financial support and independence.

> In immediate danger in India, call **112**. Women Helpline: **181**. Cyber crime: **1930**.

---

## 1. Project overview
A full-stack, production-oriented web application (React PWA + Node/Express + MongoDB + Socket.io) with role-based dashboards for women, emergency contacts, verified responders, lawyers, NGOs, counsellors, police officials, donors, lenders and administrators.

Everything that depends on an outside service (SMS, WhatsApp, email, 112/police, payments, streaming, malware scanning, object storage) sits behind a service layer that reports an honest status — `sent`, `simulated`, `not_configured`, `pending`, `confirmed` or `failed`. Raksha never claims police were contacted, an FIR was filed or a payment succeeded unless that was actually confirmed.

## 2. Features
| Area | What works |
|---|---|
| **SOS** | Press-and-hold (3 s) + cancellable countdown; parallel alerts to contacts (SMS/WhatsApp/email/in-app) with per-channel delivery status; nearby verified responders via geo query (approximate location until they accept); emergency-service workflow; live location; segmented audio/video evidence recording; SOS timeline; PIN-protected cancel/resolve; full activation/cancellation log; SMS fallback when offline; practice mode |
| **Live location** | Browser geolocation, Socket.io streaming, time-boxed sharing with timer, private tracking links for contacts without accounts, emergency location history, stop any time (except during an active SOS) |
| **Evidence Vault** | Photos, video, audio, documents, medical reports; magic-byte validation; size limits; ClamAV hook; SHA-256 fingerprint; AES-256-GCM encryption at rest; GPS + capture time; case linking; access history; integrity verification; protected ZIP package with manifest |
| **Rights Library** | Searchable, categorised, bookmarks; English + Hindi content (PWDVA 2005, Dowry Prohibition Act 1961, POSH Act 2013, divorce, maintenance, custody, police rights); regional-language-ready content model; disclaimer |
| **Lawyer & NGO matching** | Weighted, explainable scoring on case type, location, language, availability, budget and verification; profiles, badges, fees, pro bono, reviews; request → accept workflow |
| **Complaints** | Guided 3-step drafting → structured complaint → evidence with hashes → print/PDF or submission method → status tracking (draft → closed). Self-reported vs police-confirmed clearly labelled; online submission only through a configured integration |
| **Case management** | Case ID, team, evidence (consent-gated), complaints, documents, notes (shared / professional-only), hearings & important dates with reminders, visual timeline, reviews |
| **Government schemes** | Eligibility checker against admin-maintained official criteria (never invented), details/benefits/documents/official links, application tracker with document checklist |
| **Counselling** | Verified counsellors (emotional, legal, career & money), chat/call/video, free or paid, booking, confirmation, reminders, history |
| **Community** | Articles, survivor stories, discussions, questions, comments, reactions, anonymous posting, automatic (abuse + PII + self-harm) and manual moderation, reporting, blocking |
| **Financial help** | KYC-verified crowdfunding, Razorpay donations with server-side signature verification and receipts, demo gateway, registered-lender micro-loan marketplace (anonymised until acceptance), transparency page with live (non-demo) figures |
| **Chat & notifications** | Socket.io 1:1 chat only between connected people, read receipts, typing, evidence attachments, report/block; in-app + email/SMS/WhatsApp notifications; device notifications |
| **Admin** | Analytics (users, active SOS, SOS→contacts-alerted time, cases, professionals, donations, assistance, scheme applications), verification queue, users, SOS events (approximate), moderation, schemes editor, finance & disbursements, audit + evidence access logs, settings, integration status |
| **Privacy** | Consent controls, data-sharing settings, "who accessed my information", data export, account deletion, privacy policy & terms |
| **PWA** | Installable, offline emergency page (call 112, SMS your contacts with location), app shortcuts, mobile-first layout with a large SOS control |

## 3. Technology stack
- **Frontend:** React 18, Vite 5, TypeScript, Tailwind CSS 3, custom shadcn-style component kit, React Router 6, TanStack Query 5, Socket.io client, React-Leaflet (OpenStreetMap), Recharts, Sonner, lucide-react
- **Backend:** Node.js 20+, Express 4, TypeScript, Socket.io 4, Mongoose 8, Zod, JWT, bcrypt, Helmet, express-rate-limit, express-mongo-sanitize, sanitize-html, Multer, Archiver, Nodemailer, AWS S3 SDK
- **Database:** MongoDB 6+/Atlas
- **Testing:** Vitest, Supertest, mongodb-memory-server

## 4. Architecture
See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for diagrams and design decisions (SOS pipeline, location privacy, evidence integrity, authorization model, payments, scaling).

## 5. Folder structure
```
raksha/
├── backend/
│   ├── src/
│   │   ├── config/        env, db, roles
│   │   ├── controllers/   auth, users, contacts, sos, location, evidence, cases, complaints,
│   │   │                  professionals, schemes, appointments, community, finance, messages, admin
│   │   ├── routes/        one router per resource
│   │   ├── models/        30 Mongoose models (+ indexes)
│   │   ├── middleware/    auth, validation, security (rate limit, CSRF), upload, errors
│   │   ├── services/      sos, messaging, emergency, location, access, audit, storage, scanner,
│   │   │                  matching, schemeEligibility, complaintDraft, moderation, payments, notify, scheduler
│   │   ├── sockets/       Socket.io server (auth, location, SOS rooms, chat typing)
│   │   ├── validators/    shared zod schemas
│   │   ├── utils/         crypto, geo, file-type detection, http helpers, logger
│   │   ├── seed/          seed script
│   │   ├── app.ts / server.ts
│   └── tests/             Vitest + Supertest suites
├── frontend/
│   ├── public/            manifest, service worker, offline page, icons
│   └── src/
│       ├── api/           axios client (token refresh, error mapping)
│       ├── components/    ui kit, SOS button, map, timeline, brand
│       ├── contexts/      auth, socket, i18n
│       ├── hooks/         geolocation, segmented recorder
│       ├── i18n/          en, hi
│       ├── layouts/       app shell, public shell
│       ├── pages/         all user pages + dashboards/
│       ├── types/ utils/
├── database/seed/         schemes.json, rights.json (reference data)
├── docs/                  API.md, ARCHITECTURE.md, SETUP.md
├── docker-compose.yml, render.yaml, .env.example
```

## 6. Environment variables
All variables are documented in [`.env.example`](.env.example) / `backend/.env.example` and `frontend/.env.example`. Key ones:

`DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET, ENCRYPTION_KEY, APP_URL, CORS_ORIGINS, DEMO_MODE, MAPS_API_KEY, SMS_API_KEY, SMS_API_URL, WHATSAPP_API_KEY, WHATSAPP_PHONE_NUMBER_ID, SMTP_HOST, EMAIL_API_KEY, RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, RAZORPAY_WEBHOOK_SECRET, STORAGE_DRIVER, STORAGE_BUCKET, STORAGE_ACCESS_KEY, STORAGE_SECRET, CLAMAV_HOST, EMERGENCY_API_URL, POLICE_COMPLAINT_API_URL, STREAMING_SERVER_URL` · frontend: `VITE_API_URL`.

No API keys are hard-coded and none are ever sent to the frontend.

## 7. Local installation
```bash
npm install && npm run install:all
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

## 8. Database setup
Run MongoDB locally (`docker run -d -p 27017:27017 mongo:7`) or put an Atlas URI in `DATABASE_URL`. Indexes are created automatically.

## 9. Seed commands
```bash
npm run seed         # reference data + demo accounts (re-runnable)
npm run seed:fresh   # drop DB first (dev only)
```

## 10. Running the frontend
```bash
npm run dev:frontend   # http://localhost:5173
```

## 11. Running the backend
```bash
npm run dev:backend    # http://localhost:5000  (GET /api/health)
# or both at once:
npm run dev
```

## 12. Testing
```bash
npm test
```
The six critical guarantees are tested explicitly: unauthorised users cannot access evidence; cannot access another user's case; non-admins cannot verify professionals; payments cannot be marked successful from the frontend; demo SOS cannot contact real emergency services; sensitive location data is protected. Details in [docs/SETUP.md](docs/SETUP.md#5-tests).

## 13. Production deployment
Frontend → Vercel/Netlify (`frontend/vercel.json`, `frontend/netlify.toml`). Backend → Render (`render.yaml`), Railway or AWS (`backend/Dockerfile`). Database → MongoDB Atlas. Or everything with `docker compose up --build`. Full checklist: [docs/SETUP.md](docs/SETUP.md#6-production-configuration-checklist).

## 14. API documentation
[docs/API.md](docs/API.md) — every endpoint, auth requirement, payload, status codes and Socket.io events.

## 15. Security considerations
- Passwords: bcrypt (cost 12). Safety PIN: bcrypt. Refresh tokens: only SHA-256 hashes stored, rotated, reuse detection
- JWT access tokens kept in memory; refresh in `httpOnly`, `secure`, `SameSite` cookie; CSRF guard on cookie endpoints
- Helmet (strict CSP for the API, HSTS in production), CORS allow-list, rate limits (global, auth, OTP, SOS, upload)
- Zod validation + whitelisting on every input; `express-mongo-sanitize` against NoSQL injection; community content stripped of HTML (XSS)
- Uploads: memory-only, magic-byte type validation, size limits, ClamAV scanning hook, AES-256-GCM encryption at rest, never public URLs
- Field-level encryption for medical data
- Centralised authorization (`services/access.ts`), least privilege: admins see approximate location only and must justify evidence access
- Audit log of sensitive actions, visible to the data subject
- Stack traces never returned in production; structured logs without secrets or precise locations
- Data minimisation: location stored only during an active SOS or share

**Before going live:** commission an independent security review/penetration test, a DPDP Act 2023 compliance review, and agreements with any emergency/police integration partner.

## 16. Demo accounts
Password `RakshaDemo@2026` for all; Priya's safety PIN `2580`. Emails: `priya.demo`, `contact.demo`, `lawyer.demo`, `ngo.demo`, `counsellor.demo`, `responder.demo`, `police.demo`, `donor.demo`, `lender.demo`, `admin.demo` — all `@raksha.app`. One-click buttons appear on the login page when `DEMO_MODE=true`. Demo SOS, notifications and payments are simulated and clearly labelled.

## 17. External integrations
| Integration | How to enable | Without configuration |
|---|---|---|
| SMS | `SMS_API_URL`, `SMS_API_KEY` (adapt payload in `services/messaging.ts` to MSG91/Twilio/Gupshup etc.) | Status `not_configured` shown per contact |
| WhatsApp | `WHATSAPP_API_KEY`, `WHATSAPP_PHONE_NUMBER_ID` (Meta Cloud API; approved templates needed outside 24-h window) | `not_configured` |
| Email | `SMTP_*` | `not_configured`; dev shows codes on screen |
| Emergency services / 112 | `EMERGENCY_API_URL`, `EMERGENCY_API_KEY` — authorised partner only. Treated as confirmed only if the API says so | UI says "not configured — call 112" |
| Police complaints | `POLICE_COMPLAINT_API_URL`, `POLICE_COMPLAINT_API_KEY` | 503 with guidance to print / use state portal |
| Payments | `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` | Demo gateway in `DEMO_MODE`, otherwise payments disabled |
| Maps | OpenStreetMap by default; set `VITE_MAP_TILE_URL` for Mapbox/Google tiles | OSM tiles |
| Storage | `STORAGE_DRIVER=s3` + bucket vars (AWS S3 or any S3-compatible) | Encrypted local disk |
| Malware scan | `CLAMAV_HOST`, `CLAMAV_PORT` | Files marked `not_scanned` |
| Live streaming (RTMP) / WebRTC TURN | `STREAMING_SERVER_URL`, `WEBRTC_TURN_*` | UI states streaming is not configured; recordings still saved to the vault |

---

*Impact figures on the landing page (500+ verified professionals by Year 2, < 60 s SOS-to-contacts, 10,000+ women helped by Year 3) are planning targets from the pitch deck and are labelled as such — not achieved results.*
