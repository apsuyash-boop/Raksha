import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import compression from 'compression';
import morgan from 'morgan';
import mongoSanitize from 'express-mongo-sanitize';
import { env } from './config/env';
import { dbStatus } from './config/db';
import { apiLimiter } from './middleware/security';
import { errorHandler, notFound } from './middleware/error';
import { ok } from './utils/http';
import { providerStatus } from './services/messaging';

import authRoutes from './routes/auth.routes';
import userRoutes from './routes/users.routes';
import contactRoutes from './routes/contacts.routes';
import sosRoutes from './routes/sos.routes';
import locationRoutes from './routes/location.routes';
import evidenceRoutes from './routes/evidence.routes';
import caseRoutes from './routes/cases.routes';
import complaintRoutes from './routes/complaints.routes';
import appointmentRoutes from './routes/appointments.routes';
import communityRoutes from './routes/community.routes';
import adminRoutes from './routes/admin.routes';
import { counsellorsRouter, lawyersRouter, matchRouter, ngosRouter, partnerVerificationRouter, respondersRouter } from './routes/professionals.routes';
import { rightsRouter, schemesRouter } from './routes/schemes.routes';
import { campaignsRouter, donationsRouter, loansRouter, paymentsRouter, transparencyRouter } from './routes/finance.routes';
import { messagesRouter, notificationsRouter } from './routes/messages.routes';

const startedAt = new Date();

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');

  app.use(
    helmet({
      contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } },
      crossOriginResourcePolicy: { policy: 'same-site' },
      hsts: env.isProd ? { maxAge: 31536000, includeSubDomains: true, preload: true } : false,
    }),
  );
  app.use(
    cors({
      origin: (origin, cb) => {
        if (!origin || env.CORS_ORIGINS.includes(origin)) return cb(null, true);
        cb(null, false);
      },
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
      exposedHeaders: ['Content-Disposition', 'X-Evidence-SHA256', 'X-Integrity-Verified'],
      maxAge: 600,
    }),
  );
  app.use(compression());
  app.use(
    express.json({
      limit: '1mb',
      verify: (req: any, _res, buf) => {
        if (req.originalUrl?.startsWith('/api/payments/webhook')) req.rawBody = Buffer.from(buf);
      },
    }),
  );
  app.use(express.urlencoded({ extended: false, limit: '1mb' }));
  app.use(cookieParser());
  app.use(mongoSanitize({ replaceWith: '_' })); // strips $ and . operators from user input (NoSQL injection)
  if (!env.isTest) app.use(morgan(env.isProd ? 'combined' : 'dev', { skip: (req) => req.path === '/api/health' }));

  app.get('/api/health', (_req, res) => {
    const db = dbStatus();
    res.status(db === 'connected' ? 200 : 503).json({
      success: db === 'connected',
      message: db === 'connected' ? 'Raksha API healthy' : 'Database unavailable',
      data: { status: db === 'connected' ? 'ok' : 'degraded', database: db, uptimeSeconds: Math.round((Date.now() - startedAt.getTime()) / 1000), version: process.env.npm_package_version || '1.0.0', environment: env.NODE_ENV, demoMode: env.DEMO_MODE, time: new Date() },
    });
  });
  app.get('/api/config', (_req, res) => ok(res, { demoMode: env.DEMO_MODE, integrations: providerStatus(), mapsProvider: env.MAPS_PROVIDER, maxUploadMb: env.MAX_UPLOAD_MB, turn: env.WEBRTC_TURN_URL ? { urls: env.WEBRTC_TURN_URL } : null }));

  app.use('/api', apiLimiter);
  app.use('/api/auth', authRoutes);
  app.use('/api/users', userRoutes);
  app.use('/api/contacts', contactRoutes);
  app.use('/api/sos', sosRoutes);
  app.use('/api/location', locationRoutes);
  app.use('/api/evidence', evidenceRoutes);
  app.use('/api/cases', caseRoutes);
  app.use('/api/complaints', complaintRoutes);
  app.use('/api/lawyers', lawyersRouter);
  app.use('/api/ngos', ngosRouter);
  app.use('/api/counsellors', counsellorsRouter);
  app.use('/api/responders', respondersRouter);
  app.use('/api/verification', partnerVerificationRouter);
  app.use('/api/match', matchRouter);
  app.use('/api/schemes', schemesRouter);
  app.use('/api/rights', rightsRouter);
  app.use('/api/appointments', appointmentRoutes);
  app.use('/api/campaigns', campaignsRouter);
  app.use('/api/donations', donationsRouter);
  app.use('/api/payments', paymentsRouter);
  app.use('/api/loans', loansRouter);
  app.use('/api/transparency', transparencyRouter);
  app.use('/api/messages', messagesRouter);
  app.use('/api/notifications', notificationsRouter);
  app.use('/api/community', communityRoutes);
  app.use('/api/admin', adminRoutes);

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
