import dotenv from 'dotenv';
import path from 'path';
import crypto from 'crypto';

dotenv.config({ path: process.env.DOTENV_PATH || path.resolve(process.cwd(), '.env') });

const bool = (v: string | undefined, d = false) => (v === undefined || v === '' ? d : ['1', 'true', 'yes', 'on'].includes(v.toLowerCase()));
const num = (v: string | undefined, d: number) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));
const str = (v: string | undefined, d = '') => (v === undefined ? d : v);

const NODE_ENV = str(process.env.NODE_ENV, 'development');
const isProd = NODE_ENV === 'production';
const isTest = NODE_ENV === 'test';

function secret(name: string): string {
  const v = process.env[name];
  if (v && v.length >= 32) return v;
  if (isProd) throw new Error(`${name} must be set to a strong value (>= 32 chars) in production`);
  // Development/test only: ephemeral random secret so the app runs out of the box.
  return crypto.randomBytes(48).toString('hex');
}

export const env = {
  NODE_ENV,
  isProd,
  isTest,
  PORT: num(process.env.PORT, 5000),
  DATABASE_URL: str(process.env.DATABASE_URL, 'mongodb://127.0.0.1:27017/raksha'),
  APP_URL: str(process.env.APP_URL, 'http://localhost:5173'),
  API_URL: str(process.env.API_URL, 'http://localhost:5000'),
  CORS_ORIGINS: str(process.env.CORS_ORIGINS, 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),

  JWT_SECRET: secret('JWT_SECRET'),
  JWT_REFRESH_SECRET: secret('JWT_REFRESH_SECRET'),
  JWT_ACCESS_TTL: str(process.env.JWT_ACCESS_TTL, '15m'),
  REFRESH_TTL_DAYS: num(process.env.REFRESH_TTL_DAYS, 14),
  COOKIE_SECURE: bool(process.env.COOKIE_SECURE, isProd),
  COOKIE_SAMESITE: (str(process.env.COOKIE_SAMESITE, isProd ? 'none' : 'lax') as 'lax' | 'strict' | 'none'),

  // 32-byte key (hex, 64 chars) used for AES-256-GCM encryption of evidence and sensitive fields.
  ENCRYPTION_KEY: (() => {
    const v = process.env.ENCRYPTION_KEY;
    if (v && /^[0-9a-fA-F]{64}$/.test(v)) return Buffer.from(v, 'hex');
    if (isProd) throw new Error('ENCRYPTION_KEY must be a 64-char hex string in production');
    return crypto.createHash('sha256').update('raksha-dev-only-key-do-not-use-in-prod').digest();
  })(),

  DEMO_MODE: bool(process.env.DEMO_MODE, !isProd),

  // Maps
  MAPS_PROVIDER: str(process.env.MAPS_PROVIDER, 'osm'),
  MAPS_API_KEY: str(process.env.MAPS_API_KEY),

  // Messaging providers (blank = not configured)
  SMS_PROVIDER: str(process.env.SMS_PROVIDER),
  SMS_API_KEY: str(process.env.SMS_API_KEY),
  SMS_API_URL: str(process.env.SMS_API_URL),
  SMS_SENDER_ID: str(process.env.SMS_SENDER_ID, 'RAKSHA'),
  WHATSAPP_API_KEY: str(process.env.WHATSAPP_API_KEY),
  WHATSAPP_PHONE_NUMBER_ID: str(process.env.WHATSAPP_PHONE_NUMBER_ID),
  WHATSAPP_API_URL: str(process.env.WHATSAPP_API_URL, 'https://graph.facebook.com/v20.0'),
  EMAIL_API_KEY: str(process.env.EMAIL_API_KEY),
  SMTP_HOST: str(process.env.SMTP_HOST),
  SMTP_PORT: num(process.env.SMTP_PORT, 587),
  SMTP_USER: str(process.env.SMTP_USER),
  SMTP_PASS: str(process.env.SMTP_PASS),
  EMAIL_FROM: str(process.env.EMAIL_FROM, 'Raksha <no-reply@raksha.local>'),

  // Emergency services integration (police / 112). Blank = not configured.
  EMERGENCY_API_URL: str(process.env.EMERGENCY_API_URL),
  EMERGENCY_API_KEY: str(process.env.EMERGENCY_API_KEY),
  POLICE_COMPLAINT_API_URL: str(process.env.POLICE_COMPLAINT_API_URL),
  POLICE_COMPLAINT_API_KEY: str(process.env.POLICE_COMPLAINT_API_KEY),

  // Payments
  RAZORPAY_KEY_ID: str(process.env.RAZORPAY_KEY_ID),
  RAZORPAY_KEY_SECRET: str(process.env.RAZORPAY_KEY_SECRET),
  RAZORPAY_WEBHOOK_SECRET: str(process.env.RAZORPAY_WEBHOOK_SECRET),
  PLATFORM_FEE_PERCENT: num(process.env.PLATFORM_FEE_PERCENT, 0),

  // Storage
  STORAGE_DRIVER: str(process.env.STORAGE_DRIVER, 'local'), // local | s3
  STORAGE_LOCAL_DIR: str(process.env.STORAGE_LOCAL_DIR, path.resolve(process.cwd(), 'storage')),
  STORAGE_BUCKET: str(process.env.STORAGE_BUCKET),
  STORAGE_REGION: str(process.env.STORAGE_REGION, 'ap-south-1'),
  STORAGE_ENDPOINT: str(process.env.STORAGE_ENDPOINT),
  STORAGE_ACCESS_KEY: str(process.env.STORAGE_ACCESS_KEY),
  STORAGE_SECRET: str(process.env.STORAGE_SECRET),
  MAX_UPLOAD_MB: num(process.env.MAX_UPLOAD_MB, 50),

  // Malware scanning (ClamAV clamd). Blank = scanning not configured.
  CLAMAV_HOST: str(process.env.CLAMAV_HOST),
  CLAMAV_PORT: num(process.env.CLAMAV_PORT, 3310),

  // Streaming / video
  STREAMING_SERVER_URL: str(process.env.STREAMING_SERVER_URL),
  WEBRTC_TURN_URL: str(process.env.WEBRTC_TURN_URL),
  WEBRTC_TURN_USERNAME: str(process.env.WEBRTC_TURN_USERNAME),
  WEBRTC_TURN_CREDENTIAL: str(process.env.WEBRTC_TURN_CREDENTIAL),

  // SOS
  SOS_RESPONDER_RADIUS_KM: num(process.env.SOS_RESPONDER_RADIUS_KM, 3),
  SOS_MAX_RESPONDERS: num(process.env.SOS_MAX_RESPONDERS, 10),
};

export type Env = typeof env;
