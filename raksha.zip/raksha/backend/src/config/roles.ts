export const ROLES = [
  'user',
  'emergency_contact',
  'responder',
  'lawyer',
  'ngo',
  'counsellor',
  'police',
  'donor',
  'lender',
  'admin',
] as const;

export type Role = (typeof ROLES)[number];

/** Roles whose accounts must be verified by an administrator before acting as professionals. */
export const VERIFIED_ROLES: Role[] = ['responder', 'lawyer', 'ngo', 'counsellor', 'police', 'lender'];

/** Roles a person may self-select at registration. Admin is never self-assignable. */
export const SELF_REGISTER_ROLES: Role[] = ['user', 'emergency_contact', 'responder', 'lawyer', 'ngo', 'counsellor', 'police', 'donor', 'lender'];

export const CASE_TYPES = [
  'domestic_violence',
  'dowry',
  'harassment',
  'workplace_harassment',
  'divorce',
  'maintenance',
  'child_custody',
  'sexual_assault',
  'cyber_crime',
  'other',
] as const;
export type CaseType = (typeof CASE_TYPES)[number];

export const COMPLAINT_STATUSES = [
  'draft',
  'ready_for_submission',
  'submitted',
  'under_review',
  'registered',
  'investigation',
  'court_proceeding',
  'closed',
] as const;

export const LANGUAGES = ['en', 'hi', 'mr', 'bn', 'ta', 'te', 'kn', 'ml', 'gu', 'pa', 'or', 'ur'] as const;
