import { Request, Response } from 'express';
import { z } from 'zod';
import {
  Appointment, AuditLog, Campaign, Case, Comment, CommunityPost, Complaint, Counsellor, Donation, Evidence, Lawyer, NGO, Report,
  Responder, SchemeApplication, Session, Setting, SOSAlert, Transaction, User, Verification,
} from '../models';
import { AppError, escapeRegex, ok, paginate } from '../utils/http';
import { approximate } from '../utils/geo';
import { audit } from '../services/audit';
import { notify } from '../services/notify';
import { providerStatus } from '../services/messaging';
import { ROLES } from '../config/roles';

export const verificationDecisionSchema = z.object({ decision: z.enum(['approved', 'rejected', 'more_info']), note: z.string().max(1000).optional() });
export const userUpdateSchema = z.object({ status: z.enum(['active', 'suspended']).optional(), role: z.enum(ROLES).optional() });
export const moderationSchema = z.object({ action: z.enum(['publish', 'remove', 'feature', 'unfeature']), reason: z.string().max(500).optional() });
export const reportDecisionSchema = z.object({ status: z.enum(['actioned', 'dismissed']), resolution: z.string().max(1000).optional() });
export const settingSchema = z.object({ value: z.any(), description: z.string().max(300).optional() });

const PROFILE_MODEL: Record<string, any> = { lawyer: Lawyer, ngo: NGO, counsellor: Counsellor, responder: Responder };

export async function stats(_req: Request, res: Response) {
  const live = { isDemo: { $ne: true } };
  const [users, byRole, activeSos, sosTotal, cases, casesByStatus, profs, donations, assisted, schemeApps, pendingVer, openReports, pendingPosts, respTime] = await Promise.all([
    User.countDocuments({ status: { $ne: 'deleted' } }),
    User.aggregate([{ $match: { status: { $ne: 'deleted' } } }, { $group: { _id: '$role', count: { $sum: 1 } } }]),
    SOSAlert.countDocuments({ status: 'active' }),
    SOSAlert.countDocuments({}),
    Case.countDocuments({}),
    Case.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
    User.countDocuments({ role: { $in: ['lawyer', 'ngo', 'counsellor', 'responder'] }, verified: true, status: 'active' }),
    Transaction.aggregate([{ $match: { type: 'donation', status: 'captured' } }, { $group: { _id: '$isDemo', total: { $sum: '$amount' }, count: { $sum: 1 } } }]),
    Case.countDocuments({ status: { $in: ['resolved', 'closed'] }, $or: [{ lawyer: { $ne: null } }, { ngo: { $ne: null } }] }),
    SchemeApplication.countDocuments({}),
    Verification.countDocuments({ status: 'pending' }),
    Report.countDocuments({ status: 'open' }),
    CommunityPost.countDocuments({ status: 'pending_review' }),
    SOSAlert.aggregate([
      { $match: { contactsAlertedAt: { $ne: null }, ...live } },
      { $project: { ms: { $subtract: ['$contactsAlertedAt', '$createdAt'] } } },
      { $group: { _id: null, avg: { $avg: '$ms' }, max: { $max: '$ms' }, n: { $sum: 1 } } },
    ]),
  ]);
  const sosDaily = await SOSAlert.aggregate([
    { $match: { createdAt: { $gte: new Date(Date.now() - 30 * 86400000) } } },
    { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, total: { $sum: 1 }, demo: { $sum: { $cond: ['$isDemo', 1, 0] } } } },
    { $sort: { _id: 1 } },
  ]);
  return ok(res, {
    users,
    byRole,
    activeSos,
    sosTotal,
    avgContactAlertSeconds: respTime[0] ? Math.round(respTime[0].avg / 100) / 10 : null,
    responseSamples: respTime[0]?.n || 0,
    cases,
    casesByStatus,
    activeProfessionals: profs,
    donations: { live: donations.find((d) => !d._id) || { total: 0, count: 0 }, demo: donations.find((d) => d._id) || { total: 0, count: 0 } },
    successfulAssistance: assisted,
    schemeApplications: schemeApps,
    pendingVerifications: pendingVer,
    openReports,
    pendingPosts,
    sosDaily,
    integrations: providerStatus(),
  });
}

export async function users(req: Request, res: Response) {
  const { skip, limit } = paginate(req, 25, 100);
  const q: any = { status: { $ne: 'deleted' } };
  if (req.query.role) q.role = req.query.role;
  if (req.query.status) q.status = req.query.status;
  if (req.query.q) {
    const re = new RegExp(escapeRegex(String(req.query.q)), 'i');
    q.$or = [{ name: re }, { email: re }, { phone: re }];
  }
  const [items, total] = await Promise.all([User.find(q).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(), User.countDocuments(q)]);
  return ok(res, { items: items.map((u: any) => ({ ...u, passwordHash: undefined })), total });
}

export async function updateUser(req: Request, res: Response) {
  if (req.params.id === req.user!.id && req.body.status === 'suspended') throw AppError.badRequest('You cannot suspend yourself');
  const u = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!u) throw AppError.notFound();
  if (req.body.status === 'suspended') await Session.updateMany({ user: u._id }, { revokedAt: new Date() });
  await audit(req, 'admin.user_update', { targetType: 'User', targetId: u._id, subjectUser: u._id, meta: req.body });
  return ok(res, { user: u }, 'User updated');
}

export async function verifications(req: Request, res: Response) {
  const q: any = {};
  if (req.query.status) q.status = req.query.status;
  else q.status = { $in: ['pending', 'more_info'] };
  const items = await Verification.find(q).populate('user', 'name email phone role city state').populate('documents.evidence', 'evidenceId title kind').populate('campaign', 'title goalAmount').sort({ createdAt: 1 }).limit(200).lean<any[]>();
  // Attach professional profile for context.
  const out = await Promise.all(
    items.map(async (v) => ({ ...v, profile: PROFILE_MODEL[v.role] ? await PROFILE_MODEL[v.role].findOne({ user: v.user?._id }).select('+barCouncilId +registrationNumber +licenseNumber').lean() : null })),
  );
  return ok(res, { items: out });
}

/** Only administrators can verify professionals (enforced by route-level authorize('admin') + tests). */
export async function decideVerification(req: Request, res: Response) {
  const v = await Verification.findById(req.params.id);
  if (!v) throw AppError.notFound();
  v.status = req.body.decision;
  v.reviewer = req.user!.id;
  v.reviewNote = req.body.note;
  v.reviewedAt = new Date();
  await v.save();
  const approved = req.body.decision === 'approved';
  if (v.role === 'campaign_kyc') {
    if (v.campaign) await Campaign.updateOne({ _id: v.campaign }, approved ? { status: 'active', kycVerified: true, verifiedBy: req.user!.id } : req.body.decision === 'rejected' ? { status: 'rejected' } : {});
  } else {
    await User.updateOne({ _id: v.user }, { verified: approved });
    const M = PROFILE_MODEL[v.role];
    if (M) await M.updateOne({ user: v.user }, { verified: approved, verifiedAt: approved ? new Date() : undefined });
  }
  await notify(v.user, {
    type: 'verification',
    title: approved ? 'You are verified on Raksha' : req.body.decision === 'more_info' ? 'More information needed for verification' : 'Verification not approved',
    body: req.body.note,
    link: v.role === 'campaign_kyc' ? '/financial-help' : `/${v.role}/dashboard`,
    external: true,
  });
  await audit(req, 'admin.verification_decision', { targetType: 'Verification', targetId: v._id, subjectUser: v.user, meta: { decision: req.body.decision, role: v.role } });
  return ok(res, { verification: v }, `Verification ${req.body.decision}`);
}

export async function sosEvents(req: Request, res: Response) {
  const q: any = {};
  if (req.query.status) q.status = req.query.status;
  const items = await SOSAlert.find(q).sort({ createdAt: -1 }).limit(200).populate('user', 'name city').lean<any[]>();
  // Admins see approximate location only (least privilege).
  return ok(res, {
    items: items.map((a) => ({
      _id: a._id,
      user: a.user,
      status: a.status,
      isDemo: a.isDemo,
      createdAt: a.createdAt,
      contactsAlertedAt: a.contactsAlertedAt,
      alertSeconds: a.contactsAlertedAt ? Math.round((new Date(a.contactsAlertedAt).getTime() - new Date(a.createdAt).getTime()) / 100) / 10 : null,
      respondersNotified: (a.responders || []).length,
      respondersAccepted: (a.responders || []).filter((r: any) => ['accepted', 'arrived', 'completed'].includes(r.status)).length,
      emergencyService: a.emergencyService?.status,
      location: a.location?.coordinates?.length ? approximate(a.location.coordinates[1], a.location.coordinates[0]) : null,
      cancelledAt: a.cancelledAt,
      resolvedAt: a.resolvedAt,
    })),
  });
}

export async function evidenceAccessLog(req: Request, res: Response) {
  const logs = await AuditLog.find({ action: /^evidence\./ }).sort({ createdAt: -1 }).limit(300).populate('actor', 'name role').lean();
  return ok(res, { logs });
}

export async function auditLogs(req: Request, res: Response) {
  const { skip, limit } = paginate(req, 50, 200);
  const q: any = {};
  if (req.query.action) q.action = new RegExp(`^${escapeRegex(String(req.query.action))}`);
  const [items, total] = await Promise.all([AuditLog.find(q).sort({ createdAt: -1 }).skip(skip).limit(limit).populate('actor', 'name role').lean(), AuditLog.countDocuments(q)]);
  return ok(res, { items, total });
}

export async function complaints(_req: Request, res: Response) {
  const items = await Complaint.find().select('complaintNumber status submission firSource createdAt isDemo incident.type').sort({ createdAt: -1 }).limit(200).lean();
  return ok(res, { items });
}

export async function moderationQueue(_req: Request, res: Response) {
  const [posts, comments, reports] = await Promise.all([
    CommunityPost.find({ status: 'pending_review' }).sort({ createdAt: 1 }).limit(100).lean(),
    Comment.find({ status: 'pending_review' }).sort({ createdAt: 1 }).limit(100).lean(),
    Report.find({ status: 'open' }).populate('reporter', 'name').sort({ createdAt: 1 }).limit(200).lean(),
  ]);
  // Moderators see the content, not anonymous authors' identities.
  const strip = (x: any) => ({ ...x, author: x.anonymous ? undefined : x.author });
  return ok(res, { posts: posts.map(strip), comments: comments.map(strip), reports });
}

export async function moderatePost(req: Request, res: Response) {
  const p = await CommunityPost.findById(req.params.id);
  if (!p) throw AppError.notFound();
  const a = req.body.action;
  if (a === 'publish') p.status = 'published';
  if (a === 'remove') p.status = 'removed';
  if (a === 'feature') p.featured = true;
  if (a === 'unfeature') p.featured = false;
  p.moderation.reviewedBy = req.user!.id;
  p.moderation.reviewedAt = new Date();
  p.moderation.reason = req.body.reason;
  await p.save();
  if (a === 'remove' || a === 'publish') await notify(p.author, { type: 'moderation', title: a === 'publish' ? 'Your post is now live' : 'Your post was removed', body: req.body.reason, link: '/community' });
  await audit(req, `admin.post_${a}`, { targetType: 'CommunityPost', targetId: p._id });
  return ok(res, { post: { _id: p._id, status: p.status, featured: p.featured } }, 'Done');
}

export async function moderateComment(req: Request, res: Response) {
  const c = await Comment.findById(req.params.id);
  if (!c) throw AppError.notFound();
  const wasPublished = c.status === 'published';
  c.status = req.body.action === 'publish' ? 'published' : 'removed';
  await c.save();
  if (!wasPublished && c.status === 'published') await CommunityPost.updateOne({ _id: c.post }, { $inc: { commentsCount: 1 } });
  if (wasPublished && c.status === 'removed') await CommunityPost.updateOne({ _id: c.post }, { $inc: { commentsCount: -1 } });
  await audit(req, `admin.comment_${req.body.action}`, { targetType: 'Comment', targetId: c._id });
  return ok(res, {}, 'Done');
}

export async function decideReport(req: Request, res: Response) {
  const r = await Report.findByIdAndUpdate(req.params.id, { ...req.body, resolvedBy: req.user!.id }, { new: true });
  if (!r) throw AppError.notFound();
  await audit(req, 'admin.report_decision', { targetType: 'Report', targetId: r._id, meta: req.body });
  return ok(res, { report: r });
}

export async function finance(_req: Request, res: Response) {
  const [transactions, campaigns, donations] = await Promise.all([
    Transaction.find().sort({ createdAt: -1 }).limit(200).lean(),
    Campaign.find().sort({ createdAt: -1 }).limit(200).populate('beneficiary', 'name').lean(),
    Donation.find().sort({ createdAt: -1 }).limit(200).populate('campaign', 'title').lean(),
  ]);
  return ok(res, { transactions, campaigns, donations });
}

export async function listProfessionals(req: Request, res: Response) {
  const kind = String(req.params.kind);
  const M = PROFILE_MODEL[kind];
  if (!M) throw AppError.badRequest('Unknown professional type');
  const items = await M.find().populate('user', 'name email phone status verified').sort({ createdAt: -1 }).limit(300).lean();
  return ok(res, { items });
}

export async function appointments(_req: Request, res: Response) {
  const items = await Appointment.find().select('mode scheduledAt status free isDemo').sort({ scheduledAt: -1 }).limit(200).lean();
  return ok(res, { items });
}

export async function evidenceStats(_req: Request, res: Response) {
  const byKind = await Evidence.aggregate([{ $match: { deletedAt: null } }, { $group: { _id: '$kind', count: { $sum: 1 }, bytes: { $sum: '$size' } } }]);
  const scan = await Evidence.aggregate([{ $group: { _id: '$scanStatus', count: { $sum: 1 } } }]);
  return ok(res, { byKind, scan });
}

export async function settings(_req: Request, res: Response) {
  return ok(res, { settings: await Setting.find().lean(), integrations: providerStatus() });
}
export async function putSetting(req: Request, res: Response) {
  const s = await Setting.findOneAndUpdate({ key: req.params.key }, { value: req.body.value, description: req.body.description, updatedBy: req.user!.id }, { new: true, upsert: true });
  await audit(req, 'admin.setting_update', { targetType: 'Setting', targetId: s._id, meta: { key: req.params.key } });
  return ok(res, { setting: s }, 'Setting saved');
}
