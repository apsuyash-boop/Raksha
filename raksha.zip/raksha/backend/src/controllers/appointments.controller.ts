import { Request, Response } from 'express';
import { z } from 'zod';
import { Appointment, Counsellor } from '../models';
import { AppError, created, ok } from '../utils/http';
import { objectId } from '../validators/common';
import { notify } from '../services/notify';
import { audit } from '../services/audit';

export const createSchema = z.object({
  counsellorId: objectId,
  mode: z.enum(['chat', 'call', 'video']),
  scheduledAt: z.coerce.date().refine((d) => d.getTime() > Date.now() - 5 * 60 * 1000, 'Choose a future time'),
  topic: z.string().max(500).optional(),
});
export const statusSchema = z.object({
  action: z.enum(['confirm', 'decline', 'cancel', 'complete', 'reschedule']),
  scheduledAt: z.coerce.date().optional(),
  meetingUrl: z.string().url().max(300).optional(),
  notes: z.string().max(5000).optional(),
});

export async function create(req: Request, res: Response) {
  const c = await Counsellor.findOne({ _id: req.body.counsellorId, verified: true }).lean<any>();
  if (!c) throw AppError.badRequest('Counsellor not available');
  if (c.modes?.length && !c.modes.includes(req.body.mode)) throw AppError.badRequest(`This counsellor offers: ${c.modes.join(', ')}`);
  const clash = await Appointment.findOne({ counsellor: c._id, status: 'confirmed', scheduledAt: { $gt: new Date(req.body.scheduledAt.getTime() - 45 * 60000), $lt: new Date(req.body.scheduledAt.getTime() + 45 * 60000) } }).lean();
  if (clash) throw AppError.conflict('That time is already booked. Please choose another slot.');
  const a = await Appointment.create({
    user: req.user!.id,
    counsellor: c._id,
    counsellorUser: c.user,
    mode: req.body.mode,
    scheduledAt: req.body.scheduledAt,
    topic: req.body.topic,
    price: c.freeSessions ? 0 : c.price,
    free: !!c.freeSessions || !c.price,
    isDemo: req.user!.isDemo,
  });
  await notify(c.user, { type: 'appointment', title: 'New counselling request', body: `${req.body.mode} — ${req.body.scheduledAt.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}`, link: '/counsellor/dashboard', external: true });
  return created(res, { appointment: a }, 'Request sent to counsellor');
}

export async function mine(req: Request, res: Response) {
  const isCounsellor = req.user!.role === 'counsellor';
  const q = isCounsellor ? { counsellorUser: req.user!.id } : { user: req.user!.id };
  const appts = await Appointment.find(q)
    .populate(isCounsellor ? { path: 'user', select: 'name language' } : { path: 'counsellor', select: 'displayName category modes meetingUrl' })
    .sort({ scheduledAt: -1 })
    .limit(200)
    .lean();
  return ok(res, { appointments: appts });
}

export async function changeStatus(req: Request, res: Response) {
  const a = await Appointment.findById(req.params.id).select('+counsellorNotes');
  if (!a) throw AppError.notFound('Appointment not found');
  const me = req.user!.id;
  const isUser = String(a.user) === me;
  const isCounsellor = String(a.counsellorUser) === me;
  if (!isUser && !isCounsellor) throw AppError.forbidden();
  const { action } = req.body;

  if (['confirm', 'decline', 'complete'].includes(action) && !isCounsellor) throw AppError.forbidden('Only the counsellor can do this');
  if (action === 'confirm') {
    a.status = 'confirmed';
    if (req.body.meetingUrl) a.meetingUrl = req.body.meetingUrl;
    else if (a.mode === 'video') a.meetingUrl = (await Counsellor.findById(a.counsellor).select('meetingUrl').lean<any>())?.meetingUrl;
  }
  if (action === 'decline') a.status = 'declined';
  if (action === 'complete') {
    a.status = 'completed';
    if (req.body.notes) a.counsellorNotes = req.body.notes;
  }
  if (action === 'cancel') {
    a.status = 'cancelled';
    a.cancelledBy = me;
  }
  if (action === 'reschedule') {
    if (!req.body.scheduledAt) throw AppError.badRequest('New time required');
    a.scheduledAt = req.body.scheduledAt;
    a.status = isCounsellor ? 'confirmed' : 'requested';
    a.reminderSent = false;
  }
  await a.save();
  const other = isUser ? a.counsellorUser : a.user;
  await notify(other, { type: 'appointment', title: `Appointment ${a.status}`, body: a.scheduledAt.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }), link: isUser ? '/counsellor/dashboard' : '/counselling', external: action !== 'complete' });
  await audit(req, `appointment.${action}`, { targetType: 'Appointment', targetId: a._id, subjectUser: a.user });
  const json = a.toJSON();
  if (!isCounsellor) delete json.counsellorNotes;
  return ok(res, { appointment: json }, `Appointment ${a.status}`);
}
