import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { env } from '../config/env';
import { SELF_REGISTER_ROLES, VERIFIED_ROLES } from '../config/roles';
import { EmergencyContact, Otp, Session, User } from '../models';
import { signAccessToken } from '../middleware/auth';
import { AppError, ok, created } from '../utils/http';
import { encryptString, randomCode, randomToken, sha256 } from '../utils/crypto';
import { sendMessage } from '../services/messaging';
import { audit } from '../services/audit';
import { email, language, password, phone, pin } from '../validators/common';

const REFRESH_COOKIE = 'raksha_rt';
/** Used to keep login timing constant when the account does not exist. */
const DUMMY_HASH = bcrypt.hashSync('raksha-timing-dummy', 10);

/* ------------------------------ validators ------------------------------ */
export const registerSchema = z
  .object({
    name: z.string().trim().min(2).max(120),
    email: email.optional(),
    phone: phone.optional(),
    password,
    role: z.enum(SELF_REGISTER_ROLES as [string, ...string[]]).default('user'),
    age: z.coerce.number().int().min(13).max(120).optional(),
    state: z.string().trim().max(80).optional(),
    city: z.string().trim().max(80).optional(),
    language: language.default('en'),
    safetyPin: pin.optional(),
    emergencyContacts: z
      .array(z.object({ name: z.string().trim().min(1).max(120), phone: phone.optional(), email: email.optional(), relation: z.string().max(60).optional() }))
      .max(10)
      .optional(),
    medical: z
      .object({ bloodGroup: z.string().max(5).optional(), allergies: z.string().max(500).optional(), conditions: z.string().max(500).optional(), medications: z.string().max(500).optional(), notes: z.string().max(1000).optional() })
      .optional(),
    shareMedicalInfoInSOS: z.boolean().optional(),
    acceptTerms: z.literal(true, { errorMap: () => ({ message: 'Please accept the Terms and Privacy Policy' }) }),
  })
  .refine((d) => d.email || d.phone, { message: 'Provide an email or phone number', path: ['email'] });

export const loginSchema = z.object({ identifier: z.string().trim().min(3).max(200), password: z.string().min(1).max(128) });
export const forgotSchema = z.object({ identifier: z.string().trim().min(3).max(200) });
export const resetSchema = z.object({ token: z.string().min(20).max(200), password });
export const verifyRequestSchema = z.object({ channel: z.enum(['email', 'phone']) });
export const verifyConfirmSchema = z.object({ channel: z.enum(['email', 'phone']), code: z.string().regex(/^\d{6}$/) });
export const otpRequestSchema = z.object({ identifier: z.string().trim().min(3).max(200) });
export const otpVerifySchema = z.object({ identifier: z.string().trim().min(3).max(200), code: z.string().regex(/^\d{6}$/) });

/* -------------------------------- helpers ------------------------------- */
const identifierQuery = (id: string) => (id.includes('@') ? { email: id.toLowerCase() } : { phone: id.replace(/[\s-]/g, '') });

async function issueSession(req: Request, res: Response, user: any) {
  const raw = randomToken(48);
  const expiresAt = new Date(Date.now() + env.REFRESH_TTL_DAYS * 24 * 3600 * 1000);
  await Session.create({ user: user._id, tokenHash: sha256(raw), userAgent: req.headers['user-agent']?.slice(0, 200), ip: req.ip, expiresAt });
  res.cookie(REFRESH_COOKIE, raw, {
    httpOnly: true,
    secure: env.COOKIE_SECURE,
    sameSite: env.COOKIE_SAMESITE,
    path: '/api/auth',
    expires: expiresAt,
  });
  return { accessToken: signAccessToken(user), user: user.toJSON ? user.toJSON() : user };
}

async function issueOtp(target: string, purpose: 'verify_email' | 'verify_phone' | 'login', userId: any, demo: boolean) {
  const code = randomCode(6);
  await Otp.deleteMany({ target, purpose });
  await Otp.create({ target, purpose, codeHash: sha256(code), expiresAt: new Date(Date.now() + 10 * 60 * 1000), user: userId });
  const channel = target.includes('@') ? 'email' : 'sms';
  const r = await sendMessage(channel, target, `Your Raksha verification code is ${code}. It expires in 10 minutes. Never share it with anyone.`, { demo, subject: 'Your Raksha code' });
  // Development convenience ONLY: when no provider delivered the code, return it so local testing works.
  const devCode = !env.isProd && r.status !== 'sent' ? code : undefined;
  return { delivery: r.status, devCode };
}

async function consumeOtp(target: string, purpose: string, code: string) {
  const otp = await Otp.findOne({ target, purpose });
  if (!otp || otp.expiresAt < new Date()) throw AppError.badRequest('Code expired. Please request a new one.');
  if (otp.attempts >= 5) throw AppError.badRequest('Too many attempts. Please request a new code.');
  if (otp.codeHash !== sha256(code)) {
    otp.attempts += 1;
    await otp.save();
    throw AppError.badRequest('Incorrect code');
  }
  await otp.deleteOne();
  return otp;
}

/* ------------------------------- handlers ------------------------------- */
export async function register(req: Request, res: Response) {
  const b = req.body as z.infer<typeof registerSchema>;
  const exists = await User.findOne({ $or: [b.email ? { email: b.email } : null, b.phone ? { phone: b.phone } : null].filter(Boolean) as any[] }).lean();
  if (exists) throw AppError.conflict('An account with this email or phone already exists');

  const user = await User.create({
    name: b.name,
    email: b.email,
    phone: b.phone,
    passwordHash: await bcrypt.hash(b.password, 12),
    role: b.role,
    verified: !VERIFIED_ROLES.includes(b.role as any),
    age: b.age,
    state: b.state,
    city: b.city,
    language: b.language,
    safetyPinHash: b.safetyPin ? await bcrypt.hash(b.safetyPin, 10) : undefined,
    medicalEncrypted: b.medical ? encryptString(JSON.stringify(b.medical)) : undefined,
    privacy: { shareMedicalInfoInSOS: !!b.shareMedicalInfoInSOS },
    consents: [
      { key: 'terms_v1', granted: true },
      { key: 'privacy_v1', granted: true },
    ],
  });

  if (b.emergencyContacts?.length) {
    await EmergencyContact.insertMany(
      b.emergencyContacts.map((c, i) => ({ owner: user._id, name: c.name, phone: c.phone, email: c.email, relation: c.relation, priority: i + 1, channels: { sms: !!c.phone, whatsapp: false, email: !!c.email, app: true } })),
    );
  }

  const verification = await issueOtp(b.email || b.phone!, b.email ? 'verify_email' : 'verify_phone', user._id, false);
  await audit(req, 'auth.register', { actor: user._id, actorRole: user.role, targetType: 'User', targetId: user._id });
  const session = await issueSession(req, res, user);
  return created(res, { ...session, verification }, 'Account created');
}

export async function login(req: Request, res: Response) {
  const { identifier, password: pw } = req.body;
  const user = await User.findOne(identifierQuery(identifier)).select('+passwordHash');
  const okPw = user ? await bcrypt.compare(pw, user.passwordHash) : await bcrypt.compare(pw, DUMMY_HASH);
  if (!user || !okPw) throw AppError.unauthorized('Incorrect email/phone or password');
  if (user.status !== 'active') throw AppError.forbidden('This account is not active');
  user.lastLoginAt = new Date();
  await user.save();
  await audit(req, 'auth.login', { actor: user._id, actorRole: user.role });
  return ok(res, await issueSession(req, res, user), 'Logged in');
}

export async function refresh(req: Request, res: Response) {
  const raw = req.cookies?.[REFRESH_COOKIE];
  if (!raw) throw AppError.unauthorized('No session');
  const session = await Session.findOne({ tokenHash: sha256(raw) });
  if (!session || session.revokedAt || session.expiresAt < new Date()) {
    // Possible token reuse: revoke all sessions for safety.
    if (session?.revokedAt) await Session.updateMany({ user: session.user }, { revokedAt: new Date() });
    res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
    throw AppError.unauthorized('Session expired. Please log in again.');
  }
  const user = await User.findById(session.user);
  if (!user || user.status !== 'active') throw AppError.unauthorized('Account not active');
  session.revokedAt = new Date(); // rotation
  await session.save();
  return ok(res, await issueSession(req, res, user), 'Session refreshed');
}

export async function logout(req: Request, res: Response) {
  const raw = req.cookies?.[REFRESH_COOKIE];
  if (raw) await Session.updateOne({ tokenHash: sha256(raw) }, { revokedAt: new Date() });
  res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
  return ok(res, {}, 'Logged out');
}

export async function me(req: Request, res: Response) {
  const user = await User.findById(req.user!.id);
  if (!user) throw AppError.notFound();
  const contacts = await EmergencyContact.countDocuments({ owner: user._id });
  const hasPin = !!(await User.findById(user._id).select('+safetyPinHash').lean<any>())?.safetyPinHash;
  return ok(res, { user: user.toJSON(), emergencyContactsCount: contacts, hasSafetyPin: hasPin, demoMode: env.DEMO_MODE });
}

export async function forgotPassword(req: Request, res: Response) {
  const user = await User.findOne(identifierQuery(req.body.identifier));
  let devResetUrl: string | undefined;
  if (user && user.status === 'active') {
    const raw = randomToken(32);
    user.passwordReset = { tokenHash: sha256(raw), expiresAt: new Date(Date.now() + 30 * 60 * 1000) };
    await user.save();
    const url = `${env.APP_URL}/reset-password?token=${raw}`;
    const target = user.email || user.phone;
    const r = await sendMessage(user.email ? 'email' : 'sms', target, `Reset your Raksha password: ${url} (valid for 30 minutes). If you did not request this, ignore this message.`, { subject: 'Reset your Raksha password' });
    if (!env.isProd && r.status !== 'sent') devResetUrl = url;
    await audit(req, 'auth.forgot_password', { actor: user._id, actorRole: user.role });
  }
  // Same response whether or not the account exists (prevents account enumeration).
  return ok(res, { devResetUrl }, 'If an account exists, a reset link has been sent.');
}

export async function resetPassword(req: Request, res: Response) {
  const user = await User.findOne({ 'passwordReset.tokenHash': sha256(req.body.token), 'passwordReset.expiresAt': { $gt: new Date() } });
  if (!user) throw AppError.badRequest('This reset link is invalid or has expired');
  user.passwordHash = await bcrypt.hash(req.body.password, 12);
  user.passwordReset = undefined;
  await user.save();
  await Session.updateMany({ user: user._id, revokedAt: null }, { revokedAt: new Date() });
  await audit(req, 'auth.reset_password', { actor: user._id, actorRole: user.role });
  return ok(res, {}, 'Password updated. Please log in.');
}

export async function requestVerification(req: Request, res: Response) {
  const user = await User.findById(req.user!.id);
  const target = req.body.channel === 'email' ? user?.email : user?.phone;
  if (!target) throw AppError.badRequest(`No ${req.body.channel} on your account`);
  const r = await issueOtp(target, req.body.channel === 'email' ? 'verify_email' : 'verify_phone', user!._id, false);
  return ok(res, r, 'Verification code sent');
}

export async function confirmVerification(req: Request, res: Response) {
  const user = await User.findById(req.user!.id);
  const isEmail = req.body.channel === 'email';
  const target = isEmail ? user?.email : user?.phone;
  if (!target) throw AppError.badRequest('Nothing to verify');
  await consumeOtp(target, isEmail ? 'verify_email' : 'verify_phone', req.body.code);
  if (isEmail) user!.emailVerified = true;
  else user!.phoneVerified = true;
  await user!.save();
  return ok(res, { user: user!.toJSON() }, 'Verified');
}

export async function requestLoginOtp(req: Request, res: Response) {
  const user = await User.findOne(identifierQuery(req.body.identifier)).lean<any>();
  let devCode: string | undefined;
  if (user && user.status === 'active') {
    const target = req.body.identifier.includes('@') ? user.email : user.phone;
    devCode = (await issueOtp(target, 'login', user._id, false)).devCode;
  }
  return ok(res, { devCode }, 'If an account exists, a login code has been sent.');
}

export async function verifyLoginOtp(req: Request, res: Response) {
  const q = identifierQuery(req.body.identifier);
  const user = await User.findOne(q);
  if (!user) throw AppError.badRequest('Incorrect code');
  await consumeOtp((q as any).email || (q as any).phone, 'login', req.body.code);
  if (user.status !== 'active') throw AppError.forbidden('This account is not active');
  await audit(req, 'auth.login_otp', { actor: user._id, actorRole: user.role });
  return ok(res, await issueSession(req, res, user), 'Logged in');
}

export async function listSessions(req: Request, res: Response) {
  const sessions = await Session.find({ user: req.user!.id, revokedAt: null, expiresAt: { $gt: new Date() } })
    .select('userAgent ip createdAt lastUsedAt expiresAt')
    .sort({ createdAt: -1 })
    .lean();
  return ok(res, { sessions });
}

export async function revokeSession(req: Request, res: Response) {
  const r = await Session.updateOne({ _id: req.params.id, user: req.user!.id }, { revokedAt: new Date() });
  if (!r.matchedCount) throw AppError.notFound('Session not found');
  return ok(res, {}, 'Session revoked');
}

export async function revokeAllSessions(req: Request, res: Response) {
  await Session.updateMany({ user: req.user!.id, revokedAt: null }, { revokedAt: new Date() });
  res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
  return ok(res, {}, 'Signed out of all devices');
}

/** One-click login into seeded demo accounts. Only available when DEMO_MODE is on. */
export async function demoLogin(req: Request, res: Response) {
  if (!env.DEMO_MODE) throw AppError.notFound();
  const role = String(req.body.role || 'user');
  const user = await User.findOne({ isDemo: true, role, status: 'active' }).sort({ createdAt: 1 });
  if (!user) throw AppError.notFound('Demo account not found. Run `npm run seed` first.');
  await audit(req, 'auth.demo_login', { actor: user._id, actorRole: user.role });
  return ok(res, await issueSession(req, res, user), 'Logged in to demo account');
}
