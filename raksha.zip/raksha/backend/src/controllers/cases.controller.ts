import { Request, Response } from 'express';
import { z } from 'zod';
import { Case, Evidence, Lawyer, NGO, User } from '../models';
import { AppError, created, ok } from '../utils/http';
import { caseType, objectId } from '../validators/common';
import { caseAccess, professionalProfiles } from '../services/access';
import { caseNumber } from '../services/ids';
import { notify } from '../services/notify';
import { audit } from '../services/audit';

export const createSchema = z.object({
  type: caseType,
  title: z.string().trim().min(3).max(200),
  description: z.string().trim().max(5000).optional(),
  urgency: z.enum(['low', 'medium', 'high', 'emergency']).default('medium'),
  city: z.string().max(80).optional(),
  state: z.string().max(80).optional(),
  language: z.string().max(5).optional(),
  budget: z.enum(['free', 'low', 'standard', 'any']).default('any'),
  sosId: objectId.optional(),
});
export const updateSchema = z.object({
  title: z.string().trim().min(3).max(200).optional(),
  description: z.string().max(5000).optional(),
  urgency: z.enum(['low', 'medium', 'high', 'emergency']).optional(),
  status: z.enum(['open', 'seeking_help', 'in_progress', 'complaint_filed', 'in_court', 'resolved', 'closed']).optional(),
  consent: z.object({ shareEvidenceWithAssigned: z.boolean().optional(), shareContactWithAssigned: z.boolean().optional() }).optional(),
});
export const requestSchema = z.object({ providerType: z.enum(['lawyer', 'ngo']), providerId: objectId, service: z.string().max(100).optional(), message: z.string().max(1000).optional() });
export const respondSchema = z.object({ action: z.enum(['accept', 'reject']) });
export const noteSchema = z.object({ text: z.string().trim().min(1).max(5000), visibility: z.enum(['shared', 'professional_only']).default('shared') });
export const hearingSchema = z.object({ date: z.coerce.date(), court: z.string().max(200).optional(), purpose: z.string().max(200).optional() });
export const dateSchema = z.object({ date: z.coerce.date(), label: z.string().trim().min(1).max(200) });
export const documentSchema = z.object({ title: z.string().trim().min(1).max(200), body: z.string().max(30000).optional(), evidenceId: objectId.optional() });
export const reviewSchema = z.object({ target: z.enum(['lawyer', 'ngo']), rating: z.coerce.number().int().min(1).max(5), text: z.string().max(1000).optional() });

async function loadWithAccess(req: Request, allowRequested = false) {
  const c = await Case.findById(req.params.id);
  if (!c) throw AppError.notFound('Case not found');
  const access = await caseAccess(req.user!, c);
  if (!access || (access === 'requested' && !allowRequested)) {
    await audit(req, 'case.access_denied', { targetType: 'Case', targetId: c._id, subjectUser: c.user });
    throw AppError.forbidden('You do not have access to this case');
  }
  return { c, access };
}

function present(c: any, access: string, viewerId = '') {
  const json = c.toJSON ? c.toJSON() : c;
  if (access === 'owner' || access === 'admin') return { ...json, access };
  if (access === 'requested') {
    // Professionals deciding whether to accept see only the summary.
    return { _id: json._id, caseNumber: json.caseNumber, type: json.type, title: json.title, description: json.description, urgency: json.urgency, location: json.location, language: json.language, budget: json.budget, createdAt: json.createdAt, requests: (json.requests || []).filter((r: any) => String(r.providerUser) === viewerId), access };
  }
  // assigned professional
  return {
    ...json,
    evidence: json.consent?.shareEvidenceWithAssigned ? json.evidence : [],
    user: json.consent?.shareContactWithAssigned ? json.user : { _id: json.user?._id, name: json.user?.name },
    access,
  };
}

export async function createCase(req: Request, res: Response) {
  const b = req.body;
  const c = await Case.create({
    caseNumber: caseNumber(),
    user: req.user!.id,
    type: b.type,
    title: b.title,
    description: b.description,
    urgency: b.urgency,
    location: { city: b.city, state: b.state },
    language: b.language,
    budget: b.budget,
    sos: b.sosId ? [b.sosId] : [],
    isDemo: req.user!.isDemo,
    timeline: [{ label: 'Case created', by: req.user!.id }],
  });
  await audit(req, 'case.create', { targetType: 'Case', targetId: c._id, subjectUser: req.user!.id });
  return created(res, { case: c }, 'Case created');
}

export async function listCases(req: Request, res: Response) {
  const u = req.user!;
  if (u.role === 'lawyer' || u.role === 'ngo') {
    const p = await professionalProfiles(u.id);
    const pid = p.lawyer?._id || p.ngo?._id;
    const assignedQ = p.lawyer ? { lawyer: pid } : { ngo: pid };
    const [assigned, requests] = await Promise.all([
      pid ? Case.find(assignedQ).populate('user', 'name city').sort({ updatedAt: -1 }).lean() : [],
      Case.find({ requests: { $elemMatch: { providerUser: u.id, status: 'pending' } } })
        .select('caseNumber type title description urgency location language budget createdAt requests')
        .sort({ createdAt: -1 })
        .lean(),
    ]);
    return ok(res, { assigned, requests });
  }
  if (u.role === 'admin' && req.query.all === 'true') {
    const cases = await Case.find().select('caseNumber type title status urgency createdAt lawyer ngo isDemo').sort({ createdAt: -1 }).limit(200).lean();
    return ok(res, { cases });
  }
  const cases = await Case.find({ user: u.id }).populate('lawyer', 'displayName').populate('ngo', 'name').sort({ updatedAt: -1 }).lean();
  return ok(res, { cases });
}

export async function getCase(req: Request, res: Response) {
  const { c, access } = await loadWithAccess(req, true);
  await c.populate([
    { path: 'user', select: 'name phone email city state' },
    { path: 'lawyer', select: 'displayName user city feeType' },
    { path: 'ngo', select: 'name user city helpline' },
    { path: 'evidence', select: 'evidenceId title category kind size sha256 capturedAt uploadedAt' },
    { path: 'complaints', select: 'complaintNumber status firNumber firSource createdAt' },
    { path: 'notes.author', select: 'name role' },
    { path: 'timeline.by', select: 'name role' },
  ]);
  if (access !== 'owner') await audit(req, 'case.view', { targetType: 'Case', targetId: c._id, subjectUser: c.user._id, meta: { access } });
  const out: any = present(c, access, req.user!.id);
  if (access === 'owner') out.notes = (out.notes || []).filter((n: any) => n.visibility === 'shared' || String(n.author?._id) === req.user!.id);
  return ok(res, { case: out });
}

export async function updateCase(req: Request, res: Response) {
  const { c, access } = await loadWithAccess(req);
  const b = req.body;
  if (access === 'owner') {
    if (b.title) c.title = b.title;
    if (b.description !== undefined) c.description = b.description;
    if (b.urgency) c.urgency = b.urgency;
    if (b.consent) {
      Object.assign(c.consent, b.consent);
      c.timeline.push({ label: 'Consent settings updated', detail: JSON.stringify(b.consent), by: req.user!.id });
    }
  }
  if (b.status && b.status !== c.status) {
    c.status = b.status;
    if (['resolved', 'closed'].includes(b.status)) c.closedAt = new Date();
    c.timeline.push({ label: `Status changed to ${b.status.replace(/_/g, ' ')}`, by: req.user!.id });
    if (access !== 'owner') await notify(c.user, { type: 'case_update', title: `Case ${c.caseNumber} updated`, body: `Status: ${b.status.replace(/_/g, ' ')}`, link: `/cases/${c._id}` });
  }
  await c.save();
  await audit(req, 'case.update', { targetType: 'Case', targetId: c._id, subjectUser: c.user, meta: { fields: Object.keys(b) } });
  return ok(res, { case: c }, 'Case updated');
}

export async function requestAssistance(req: Request, res: Response) {
  const c = await Case.findOne({ _id: req.params.id, user: req.user!.id });
  if (!c) throw AppError.notFound('Case not found');
  const Model: any = req.body.providerType === 'lawyer' ? Lawyer : NGO;
  const provider = await Model.findOne({ _id: req.body.providerId, verified: true }).lean();
  if (!provider) throw AppError.badRequest('This professional is not available or not verified');
  if (c.requests.some((r: any) => String(r.provider) === String(provider._id) && r.status === 'pending')) throw AppError.conflict('You already sent a request to them');
  c.requests.push({
    providerType: req.body.providerType,
    provider: provider._id,
    providerModel: req.body.providerType === 'lawyer' ? 'Lawyer' : 'NGO',
    providerUser: provider.user,
    service: req.body.service,
    message: req.body.message,
  });
  if (c.status === 'open') c.status = 'seeking_help';
  c.timeline.push({ label: `Assistance requested from ${provider.displayName || provider.name}`, by: req.user!.id });
  await c.save();
  await notify(provider.user, { type: 'case_request', title: 'New case request', body: `${c.type.replace(/_/g, ' ')} — ${c.location?.city || ''}`, link: `/${req.body.providerType}/dashboard`, priority: c.urgency === 'emergency' ? 'high' : 'normal', external: true });
  return ok(res, { case: c }, 'Request sent');
}

export async function respondToRequest(req: Request, res: Response) {
  const c = await Case.findById(req.params.id);
  if (!c) throw AppError.notFound('Case not found');
  const r = c.requests.id(req.params.reqId);
  if (!r || String(r.providerUser) !== req.user!.id) throw AppError.forbidden('This request is not addressed to you');
  if (r.status !== 'pending') throw AppError.conflict('Request already handled');
  r.status = req.body.action === 'accept' ? 'accepted' : 'rejected';
  r.respondedAt = new Date();
  const p: any = r.providerType === 'lawyer' ? await Lawyer.findById(r.provider) : await NGO.findById(r.provider);
  const name = p?.displayName || p?.name || 'Professional';
  if (r.status === 'accepted') {
    if (r.providerType === 'lawyer') {
      c.lawyer = r.provider;
      await Lawyer.updateOne({ _id: r.provider }, { $inc: { activeCases: 1 } });
    } else c.ngo = r.provider;
    c.status = 'in_progress';
    c.timeline.push({ label: `${name} accepted your case`, by: req.user!.id });
  } else c.timeline.push({ label: `${name} could not take this case`, by: req.user!.id });
  await c.save();
  await notify(c.user, {
    type: r.status === 'accepted' ? 'case_accepted' : 'case_update',
    title: r.status === 'accepted' ? `${name} accepted your case` : `${name} declined your request`,
    body: r.status === 'accepted' ? 'You can now chat with them securely.' : 'Try another match — we will help you find someone.',
    link: `/cases/${c._id}`,
    external: true,
  });
  await audit(req, `case.request_${r.status}`, { targetType: 'Case', targetId: c._id, subjectUser: c.user });
  return ok(res, { case: c }, r.status === 'accepted' ? 'Case accepted' : 'Request declined');
}

export async function addNote(req: Request, res: Response) {
  const { c, access } = await loadWithAccess(req);
  const visibility = access === 'owner' ? 'shared' : req.body.visibility;
  c.notes.push({ author: req.user!.id, text: req.body.text, visibility, at: new Date() });
  await c.save();
  if (access !== 'owner' && visibility === 'shared') await notify(c.user, { type: 'case_update', title: 'New note on your case', body: req.body.text.slice(0, 80), link: `/cases/${c._id}` });
  return created(res, { notes: c.notes }, 'Note added');
}

export async function addHearing(req: Request, res: Response) {
  const { c } = await loadWithAccess(req);
  c.hearings.push({ ...req.body, reminderSent: false });
  c.timeline.push({ label: `Hearing scheduled: ${req.body.purpose || 'hearing'}`, detail: new Date(req.body.date).toISOString(), by: req.user!.id });
  if (c.status === 'in_progress' || c.status === 'complaint_filed') c.status = 'in_court';
  await c.save();
  await notify(c.user, { type: 'hearing_reminder', title: 'Court hearing scheduled', body: `${new Date(req.body.date).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} ${req.body.court || ''}`, link: `/cases/${c._id}` });
  return created(res, { hearings: c.hearings }, 'Hearing added');
}

export async function addDate(req: Request, res: Response) {
  const { c } = await loadWithAccess(req);
  c.importantDates.push(req.body);
  await c.save();
  return created(res, { importantDates: c.importantDates }, 'Date added');
}

export async function addDocument(req: Request, res: Response) {
  const { c, access } = await loadWithAccess(req);
  if (req.body.evidenceId) {
    const ev = await Evidence.findOne({ _id: req.body.evidenceId, owner: c.user }).select('_id').lean();
    if (!ev) throw AppError.badRequest('Evidence must belong to the case owner');
  }
  c.documents.push({ title: req.body.title, body: req.body.body, evidence: req.body.evidenceId, preparedBy: req.user!.id });
  c.timeline.push({ label: `Document prepared: ${req.body.title}`, by: req.user!.id });
  await c.save();
  if (access !== 'owner') await notify(c.user, { type: 'case_update', title: 'A document was prepared for your case', body: req.body.title, link: `/cases/${c._id}` });
  return created(res, { documents: c.documents }, 'Document saved');
}

export async function review(req: Request, res: Response) {
  const c = await Case.findOne({ _id: req.params.id, user: req.user!.id });
  if (!c) throw AppError.notFound('Case not found');
  const Model: any = req.body.target === 'lawyer' ? Lawyer : NGO;
  const pid = req.body.target === 'lawyer' ? c.lawyer : c.ngo;
  if (!pid) throw AppError.badRequest('No assigned professional to review');
  const p = await Model.findById(pid);
  p.reviews = (p.reviews || []).filter((r: any) => String(r.case) !== String(c._id));
  p.reviews.push({ user: req.user!.id, rating: req.body.rating, text: req.body.text, case: c._id });
  p.rating = Math.round((p.reviews.reduce((s: number, r: any) => s + r.rating, 0) / p.reviews.length) * 10) / 10;
  await p.save();
  return ok(res, { rating: p.rating }, 'Thank you for your review');
}

export async function caseParticipants(req: Request, res: Response) {
  const { c } = await loadWithAccess(req);
  const ids: any[] = [c.user];
  if (c.lawyer) ids.push((await Lawyer.findById(c.lawyer).select('user').lean<any>())?.user);
  if (c.ngo) ids.push((await NGO.findById(c.ngo).select('user').lean<any>())?.user);
  const users = await User.find({ _id: { $in: ids.filter(Boolean) } }).select('name role avatarColor').lean();
  return ok(res, { participants: users.filter((u: any) => String(u._id) !== req.user!.id) });
}
