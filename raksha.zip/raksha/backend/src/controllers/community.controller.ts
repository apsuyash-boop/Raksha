import { Request, Response } from 'express';
import { z } from 'zod';
import { Comment, CommunityPost, Report, User } from '../models';
import { AppError, created, escapeRegex, ok, paginate } from '../utils/http';
import { objectId } from '../validators/common';
import { autoModerate, cleanText } from '../services/moderation';
import { anonymousAlias } from '../services/ids';
import { audit } from '../services/audit';
import { notify } from '../services/notify';

export const postSchema = z.object({
  type: z.enum(['article', 'story', 'discussion', 'question']).default('discussion'),
  title: z.string().trim().min(5).max(200),
  body: z.string().trim().min(20).max(20000),
  tags: z.array(z.string().trim().max(30)).max(8).default([]),
  anonymous: z.boolean().default(false),
  language: z.string().max(5).default('en'),
});
export const commentSchema = z.object({ body: z.string().trim().min(2).max(4000), anonymous: z.boolean().default(false) });
export const reactSchema = z.object({ type: z.enum(['support', 'heart', 'strength']) });
export const reportSchema = z.object({
  targetType: z.enum(['post', 'comment', 'user', 'message', 'campaign', 'professional']),
  targetId: objectId,
  reason: z.enum(['harassment', 'hate', 'spam', 'fake_profile', 'privacy', 'self_harm', 'misinformation', 'fraud', 'other']),
  details: z.string().max(2000).optional(),
});

/** Never expose author identity for anonymous content. */
async function present(items: any[], viewerId?: string) {
  const authorIds = items.filter((p) => !p.anonymous).map((p) => p.author);
  const authors = await User.find({ _id: { $in: authorIds } }).select('name role verified avatarColor privacy.showInCommunityAs').lean<any[]>();
  return items.map((p) => {
    const { author, reactions, moderation, ...rest } = p;
    const a = authors.find((x) => String(x._id) === String(author));
    let display: any;
    if (p.anonymous || !a || a.privacy?.showInCommunityAs === 'anonymous') display = { name: p.alias || 'Anonymous', anonymous: true };
    else display = { name: a.privacy?.showInCommunityAs === 'name' ? a.name : String(a.name).split(' ')[0], role: a.role, verified: ['lawyer', 'ngo', 'counsellor'].includes(a.role) && a.verified, avatarColor: a.avatarColor, anonymous: false };
    void moderation;
    return { ...rest, author: display, isMine: viewerId ? String(author) === viewerId : false, myReaction: viewerId ? (reactions || []).find((r: any) => String(r.user) === viewerId)?.type : undefined };
  });
}

export async function list(req: Request, res: Response) {
  const { skip, limit } = paginate(req, 20, 50);
  const q: any = { status: 'published' };
  if (req.query.type) q.type = req.query.type;
  if (req.query.tag) q.tags = req.query.tag;
  if (req.query.q) {
    const re = new RegExp(escapeRegex(String(req.query.q)), 'i');
    q.$or = [{ title: re }, { body: re }, { tags: re }];
  }
  if (req.user) {
    const me = await User.findById(req.user.id).select('blockedUsers').lean<any>();
    if (me?.blockedUsers?.length) q.author = { $nin: me.blockedUsers };
  }
  const [items, total] = await Promise.all([CommunityPost.find(q).sort({ featured: -1, createdAt: -1 }).skip(skip).limit(limit).lean(), CommunityPost.countDocuments(q)]);
  return ok(res, { items: await present(items.map((p: any) => ({ ...p, body: p.body.slice(0, 400) })), req.user?.id), total });
}

export async function getOne(req: Request, res: Response) {
  const p = await CommunityPost.findById(req.params.id).lean<any>();
  if (!p || (p.status !== 'published' && String(p.author) !== req.user?.id && req.user?.role !== 'admin')) throw AppError.notFound('Post not found');
  const comments = await Comment.find({ post: p._id, status: 'published' }).sort({ createdAt: 1 }).lean();
  const [post] = await present([p], req.user?.id);
  return ok(res, { post, comments: await present(comments, req.user?.id) });
}

export async function mine(req: Request, res: Response) {
  const items = await CommunityPost.find({ author: req.user!.id }).sort({ createdAt: -1 }).lean();
  return ok(res, { items: await present(items, req.user!.id) });
}

export async function create(req: Request, res: Response) {
  const title = cleanText(req.body.title);
  const body = cleanText(req.body.body);
  const mod = await autoModerate(`${title}\n${body}`, { anonymous: req.body.anonymous });
  const p = await CommunityPost.create({
    author: req.user!.id,
    anonymous: req.body.anonymous,
    alias: req.body.anonymous ? anonymousAlias() : undefined,
    type: req.body.type,
    title,
    body,
    tags: req.body.tags.map((t: string) => cleanText(t).toLowerCase()),
    language: req.body.language,
    status: mod.status,
    moderation: { autoFlags: mod.flags },
    isDemo: req.user!.isDemo,
  });
  if (mod.flags.includes('self_harm_risk'))
    await notify(req.user!.id, { type: 'moderation', title: 'You are not alone', body: 'If you are thinking about harming yourself, please reach out. Call Tele-MANAS 14416 (24×7, free) or 112 in an emergency. Our counsellors are here too.', link: '/counselling', priority: 'high' });
  const [out] = await present([p.toObject()], req.user!.id);
  return created(res, { post: out }, mod.status === 'published' ? 'Posted' : 'Thank you — your post will appear after a quick review by our moderators');
}

export async function remove(req: Request, res: Response) {
  const p = await CommunityPost.findById(req.params.id);
  if (!p) throw AppError.notFound();
  if (String(p.author) !== req.user!.id && req.user!.role !== 'admin') throw AppError.forbidden();
  p.status = 'removed';
  await p.save();
  return ok(res, {}, 'Post removed');
}

export async function comment(req: Request, res: Response) {
  const p = await CommunityPost.findOne({ _id: req.params.id, status: 'published' });
  if (!p) throw AppError.notFound('Post not found');
  const body = cleanText(req.body.body);
  const mod = await autoModerate(body, { anonymous: req.body.anonymous });
  const c = await Comment.create({ post: p._id, author: req.user!.id, anonymous: req.body.anonymous, alias: req.body.anonymous ? anonymousAlias() : undefined, body, status: mod.status, autoFlags: mod.flags });
  if (mod.status === 'published') {
    p.commentsCount += 1;
    await p.save();
    if (String(p.author) !== req.user!.id) await notify(p.author, { type: 'message', title: 'New reply to your post', body: p.title, link: `/community/${p._id}` });
  }
  const [out] = await present([c.toObject()], req.user!.id);
  return created(res, { comment: out }, mod.status === 'published' ? 'Comment added' : 'Your comment will appear after review');
}

export async function react(req: Request, res: Response) {
  const p = await CommunityPost.findOne({ _id: req.params.id, status: 'published' });
  if (!p) throw AppError.notFound();
  const existing = p.reactions.find((r: any) => String(r.user) === req.user!.id);
  if (existing) {
    p.reactionCounts[existing.type] = Math.max(0, p.reactionCounts[existing.type] - 1);
    if (existing.type === req.body.type) {
      p.reactions = p.reactions.filter((r: any) => String(r.user) !== req.user!.id);
      await p.save();
      return ok(res, { reactionCounts: p.reactionCounts, myReaction: null });
    }
    existing.type = req.body.type;
  } else p.reactions.push({ user: req.user!.id, type: req.body.type });
  p.reactionCounts[req.body.type] += 1;
  await p.save();
  return ok(res, { reactionCounts: p.reactionCounts, myReaction: req.body.type });
}

export async function report(req: Request, res: Response) {
  const r = await Report.create({ ...req.body, reporter: req.user!.id });
  if (req.body.targetType === 'post') {
    const p = await CommunityPost.findByIdAndUpdate(req.body.targetId, { $inc: { reportsCount: 1 } }, { new: true });
    // Auto-hide after 3 independent reports pending manual review.
    if (p && p.reportsCount >= 3 && p.status === 'published') {
      p.status = 'pending_review';
      p.moderation.autoFlags = [...(p.moderation.autoFlags || []), 'multiple_reports'];
      await p.save();
    }
  }
  if (req.body.targetType === 'comment') await Comment.updateOne({ _id: req.body.targetId }, { status: 'pending_review' });
  await audit(req, 'report.create', { targetType: req.body.targetType, targetId: req.body.targetId });
  return created(res, { report: { id: r._id } }, 'Thank you. Our moderators will review this.');
}
