import { Request, Response } from 'express';
import { z } from 'zod';
import { Case, Complaint, Evidence, User } from '../models';
import { AppError, created, ok } from '../utils/http';
import { caseType, objectId } from '../validators/common';
import { buildComplaintDraft } from '../services/complaintDraft';
import { complaintNumber } from '../services/ids';
import { submitComplaintToPolice } from '../services/emergency';
import { caseAccess } from '../services/access';
import { notify } from '../services/notify';
import { audit } from '../services/audit';
import { COMPLAINT_STATUSES } from '../config/roles';

const incident = z.object({
  type: caseType,
  date: z.coerce.date().optional(),
  time: z.string().max(20).optional(),
  place: z.string().max(300).optional(),
  city: z.string().max(80).optional(),
  state: z.string().max(80).optional(),
  description: z.string().trim().min(20, 'Please describe what happened (at least a few sentences)').max(10000),
  accused: z.array(z.object({ name: z.string().max(120), relation: z.string().max(60).optional(), address: z.string().max(300).optional() })).max(10).optional(),
  witnesses: z.array(z.object({ name: z.string().max(120), contact: z.string().max(60).optional() })).max(10).optional(),
  injuries: z.string().max(1000).optional(),
  previousComplaints: z.string().max(1000).optional(),
});

export const createSchema = z.object({ caseId: objectId.optional(), incident, policeStation: z.string().max(200).optional(), evidenceIds: z.array(objectId).max(50).optional() });
export const updateSchema = z.object({ incident: incident.partial().optional(), policeStation: z.string().max(200).optional(), draftText: z.string().max(30000).optional(), evidenceIds: z.array(objectId).max(50).optional() });
export const submitSchema = z.object({ method: z.enum(['printed_in_person', 'online_portal_self', 'via_ngo', 'integration']) });
export const statusSchema = z.object({ status: z.enum(COMPLAINT_STATUSES), note: z.string().max(1000).optional(), firNumber: z.string().max(60).optional() });
export const shareSchema = z.object({ policeUserId: objectId });

const STATUS_LABEL: Record<string, string> = {
  draft: 'Draft',
  ready_for_submission: 'Ready for submission',
  submitted: 'Submitted',
  under_review: 'Under review',
  registered: 'FIR / complaint registered',
  investigation: 'Investigation',
  court_proceeding: 'Court proceeding',
  closed: 'Closed',
};

async function ownEvidence(userId: string, ids: string[] = []) {
  const ev = await Evidence.find({ _id: { $in: ids }, owner: userId, deletedAt: null }).select('evidenceId title category sha256 capturedAt').lean<any[]>();
  return ev;
}

async function load(req: Request) {
  const c = await Complaint.findById(req.params.id);
  if (!c) throw AppError.notFound('Complaint not found');
  const me = req.user!;
  let access: 'owner' | 'case' | 'police' | 'admin' | null = null;
  if (String(c.user) === me.id) access = 'owner';
  else if (me.role === 'admin') access = 'admin';
  else if (me.role === 'police' && me.verified && c.sharedWithPolice.some((p: any) => String(p) === me.id)) access = 'police';
  else if (c.case) {
    const cs = await Case.findById(c.case);
    if ((await caseAccess(me, cs)) === 'assigned') access = 'case';
  }
  if (!access) throw AppError.forbidden('You do not have access to this complaint');
  return { c, access };
}

async function regenerate(c: any, userId: string) {
  const u = await User.findById(userId).select('name age city state phone').lean<any>();
  const ev = await ownEvidence(userId, c.evidence.map(String));
  c.draftText = buildComplaintDraft({ complainant: u, incident: c.incident, policeStation: c.policeStation, evidence: ev });
}

export async function createComplaint(req: Request, res: Response) {
  if (req.body.caseId && !(await Case.exists({ _id: req.body.caseId, user: req.user!.id }))) throw AppError.forbidden('Case not found');
  const ev = await ownEvidence(req.user!.id, req.body.evidenceIds);
  const c = new Complaint({
    complaintNumber: complaintNumber(),
    user: req.user!.id,
    case: req.body.caseId,
    incident: req.body.incident,
    policeStation: req.body.policeStation,
    evidence: ev.map((e) => e._id),
    status: 'draft',
    statusHistory: [{ status: 'draft', note: 'Draft created', by: req.user!.id, source: 'user' }],
    isDemo: req.user!.isDemo,
  });
  await regenerate(c, req.user!.id);
  await c.save();
  if (req.body.caseId) await Case.updateOne({ _id: req.body.caseId }, { $addToSet: { complaints: c._id }, $push: { timeline: { label: 'Complaint draft created', by: req.user!.id } } });
  await audit(req, 'complaint.create', { targetType: 'Complaint', targetId: c._id, subjectUser: req.user!.id });
  return created(res, { complaint: c }, 'Complaint draft generated');
}

export async function list(req: Request, res: Response) {
  const complaints = await Complaint.find({ user: req.user!.id }).select('-draftText').sort({ updatedAt: -1 }).lean();
  return ok(res, { complaints });
}

export async function getOne(req: Request, res: Response) {
  const { c, access } = await load(req);
  await c.populate([
    { path: 'evidence', select: 'evidenceId title category kind sha256 capturedAt' },
    { path: 'statusHistory.by', select: 'name role' },
    { path: 'user', select: 'name city state' },
  ]);
  if (access !== 'owner') await audit(req, 'complaint.view', { targetType: 'Complaint', targetId: c._id, subjectUser: c.user._id, meta: { access } });
  return ok(res, { complaint: c, access, labels: STATUS_LABEL });
}

export async function update(req: Request, res: Response) {
  const { c, access } = await load(req);
  if (access !== 'owner') throw AppError.forbidden();
  if (!['draft', 'ready_for_submission'].includes(c.status)) throw AppError.conflict('A submitted complaint cannot be edited');
  if (req.body.incident) c.incident = { ...c.incident.toObject?.() ?? c.incident, ...req.body.incident };
  if (req.body.policeStation !== undefined) c.policeStation = req.body.policeStation;
  if (req.body.evidenceIds) c.evidence = (await ownEvidence(req.user!.id, req.body.evidenceIds)).map((e) => e._id);
  if (req.body.draftText !== undefined) c.draftText = req.body.draftText;
  else if (req.body.incident || req.body.evidenceIds || req.body.policeStation !== undefined) await regenerate(c, req.user!.id);
  await c.save();
  return ok(res, { complaint: c }, 'Saved');
}

export async function markReady(req: Request, res: Response) {
  const { c, access } = await load(req);
  if (access !== 'owner') throw AppError.forbidden();
  if (c.status !== 'draft') throw AppError.conflict('Already marked ready');
  c.status = 'ready_for_submission';
  c.statusHistory.push({ status: 'ready_for_submission', note: 'Reviewed and ready', by: req.user!.id, source: 'user' });
  await c.save();
  return ok(res, { complaint: c }, 'Marked ready for submission');
}

export async function submit(req: Request, res: Response) {
  const { c, access } = await load(req);
  if (access !== 'owner') throw AppError.forbidden();
  if (!['draft', 'ready_for_submission'].includes(c.status)) throw AppError.conflict('Already submitted');
  const method = req.body.method;
  if (method === 'integration') {
    const r = await submitComplaintToPolice({ complaintNumber: c.complaintNumber, text: c.draftText, isDemo: c.isDemo || req.user!.isDemo });
    if (r.status === 'not_configured') throw AppError.unavailable(r.message);
    if (r.status === 'failed') throw new AppError(502, r.message, 'INTEGRATION_FAILED');
    c.submission = { method: 'integration', confirmedByAuthority: r.status === 'confirmed', integrationRef: (r as any).reference, submittedAt: new Date() };
    c.status = 'submitted';
    c.statusHistory.push({ status: 'submitted', note: r.message, source: r.status === 'confirmed' ? 'integration' : 'system' });
  } else {
    c.submission = { method, confirmedByAuthority: false, submittedAt: new Date() };
    c.status = 'submitted';
    const how = method === 'printed_in_person' ? 'in person at the police station' : method === 'via_ngo' ? 'with help from an NGO volunteer' : 'on the state police citizen portal';
    c.statusHistory.push({ status: 'submitted', note: `Self-reported: submitted ${how}. Not confirmed by police.`, by: req.user!.id, source: 'user' });
  }
  await c.save();
  if (c.case) await Case.updateOne({ _id: c.case }, { status: 'complaint_filed', $push: { timeline: { label: 'Complaint submitted', detail: c.submission.confirmedByAuthority ? 'Confirmed by authority' : 'Self-reported', by: req.user!.id } } });
  await audit(req, 'complaint.submit', { targetType: 'Complaint', targetId: c._id, subjectUser: c.user, meta: { method, confirmed: c.submission.confirmedByAuthority } });
  return ok(res, { complaint: c }, c.submission.confirmedByAuthority ? 'Submitted and acknowledged' : 'Marked as submitted (self-reported)');
}

export async function updateStatus(req: Request, res: Response) {
  const { c, access } = await load(req);
  const { status, note, firNumber } = req.body;
  let source: string = 'user';
  if (access === 'police') source = 'police_official';
  else if (access === 'case') source = req.user!.role === 'lawyer' ? 'lawyer' : 'ngo';
  else if (access === 'admin') source = 'system';
  if (access === 'case' && !['under_review', 'investigation', 'court_proceeding', 'closed'].includes(status)) throw AppError.forbidden('You can only update investigation/court progress');

  c.status = status;
  if (status === 'registered' && firNumber) {
    c.firNumber = firNumber;
    c.firSource = access === 'police' ? 'police_official' : 'self_reported';
    if (access === 'police') c.submission.confirmedByAuthority = true;
  }
  c.statusHistory.push({ status, note: note || (status === 'registered' && access !== 'police' ? 'Self-reported by complainant' : undefined), by: req.user!.id, source });
  await c.save();
  if (String(c.user) !== req.user!.id)
    await notify(c.user, { type: 'complaint_update', title: `Complaint ${c.complaintNumber}: ${STATUS_LABEL[status]}`, body: note, link: `/complaints/${c._id}`, external: true });
  await audit(req, 'complaint.status', { targetType: 'Complaint', targetId: c._id, subjectUser: c.user, meta: { status, source } });
  return ok(res, { complaint: c }, 'Status updated');
}

export async function shareWithPolice(req: Request, res: Response) {
  const { c, access } = await load(req);
  if (access !== 'owner') throw AppError.forbidden();
  const officer = await User.findOne({ _id: req.body.policeUserId, role: 'police', verified: true, status: 'active' }).select('name').lean<any>();
  if (!officer) throw AppError.badRequest('Officer not found or not verified');
  if (!c.sharedWithPolice.some((p: any) => String(p) === req.body.policeUserId)) c.sharedWithPolice.push(officer._id);
  await c.save();
  await notify(officer._id, { type: 'complaint_update', title: 'A complaint was shared with you', body: c.complaintNumber, link: '/police/dashboard' });
  await audit(req, 'complaint.shared_with_police', { targetType: 'Complaint', targetId: c._id, subjectUser: c.user, meta: { officer: req.body.policeUserId } });
  return ok(res, {}, `Shared with ${officer.name}`);
}

export async function policeOfficers(req: Request, res: Response) {
  const q: any = { role: 'police', verified: true, status: 'active' };
  const officers = await User.find(q).select('name city state').limit(50).lean();
  return ok(res, { officers });
}

export async function policeInbox(req: Request, res: Response) {
  const complaints = await Complaint.find({ sharedWithPolice: req.user!.id }).populate('user', 'name city').sort({ updatedAt: -1 }).lean();
  return ok(res, { complaints });
}
