import { Request, Response } from 'express';
import { z } from 'zod';
import { EmergencyContact, SOSAlert, User } from '../models';
import { AppError, created, ok } from '../utils/http';
import { email, phone } from '../validators/common';
import { notify } from '../services/notify';
import { ownerView } from '../services/sos';

export const contactSchema = z
  .object({
    name: z.string().trim().min(1).max(120),
    relation: z.string().trim().max(60).optional(),
    phone: phone.optional(),
    email: email.optional(),
    channels: z.object({ sms: z.boolean(), whatsapp: z.boolean(), email: z.boolean(), app: z.boolean() }).partial().optional(),
    priority: z.coerce.number().int().min(1).max(10).optional(),
    canViewLiveLocation: z.boolean().optional(),
  })
  .refine((d) => d.phone || d.email, { message: 'Add a phone number or email', path: ['phone'] });

const MAX_CONTACTS = 10;

async function linkAccount(c: any) {
  // If the contact already has a Raksha account, link it so they get in-app alerts and live tracking.
  const or: any[] = [];
  if (c.phone) or.push({ phone: c.phone });
  if (c.email) or.push({ email: c.email });
  if (!or.length) return null;
  const u = await User.findOne({ $or: or, status: 'active' }).select('_id').lean<any>();
  return u?._id || null;
}

export async function list(req: Request, res: Response) {
  const contacts = await EmergencyContact.find({ owner: req.user!.id }).sort({ priority: 1, createdAt: 1 }).populate('linkedUser', 'name').lean();
  return ok(res, { contacts });
}

export async function create(req: Request, res: Response) {
  const count = await EmergencyContact.countDocuments({ owner: req.user!.id });
  if (count >= MAX_CONTACTS) throw AppError.badRequest(`You can add up to ${MAX_CONTACTS} emergency contacts`);
  const linkedUser = await linkAccount(req.body);
  const c = await EmergencyContact.create({ ...req.body, owner: req.user!.id, linkedUser, priority: req.body.priority ?? count + 1 });
  if (linkedUser && String(linkedUser) !== req.user!.id) {
    await notify(linkedUser, { type: 'emergency_contact', title: `${req.user!.name} added you as an emergency contact`, body: 'You will be alerted if she presses SOS.', link: '/guardian' });
  }
  return created(res, { contact: c }, 'Emergency contact added');
}

export async function update(req: Request, res: Response) {
  const c = await EmergencyContact.findOne({ _id: req.params.id, owner: req.user!.id });
  if (!c) throw AppError.notFound('Contact not found');
  Object.assign(c, req.body);
  c.linkedUser = await linkAccount(c);
  await c.save();
  return ok(res, { contact: c }, 'Contact updated');
}

export async function remove(req: Request, res: Response) {
  const r = await EmergencyContact.deleteOne({ _id: req.params.id, owner: req.user!.id });
  if (!r.deletedCount) throw AppError.notFound('Contact not found');
  return ok(res, {}, 'Contact removed');
}

/** For people who are emergency contacts: whom am I protecting, and are any of them in an active SOS? */
export async function protecting(req: Request, res: Response) {
  const links = await EmergencyContact.find({ linkedUser: req.user!.id }).populate('owner', 'name avatarColor city').lean<any[]>();
  const ownerIds = links.map((l) => l.owner?._id).filter(Boolean);
  const active = await SOSAlert.find({ user: { $in: ownerIds }, status: 'active' }).lean<any[]>();
  const recent = await SOSAlert.find({ user: { $in: ownerIds } }).sort({ createdAt: -1 }).limit(20).select('user status isDemo createdAt cancelledAt resolvedAt').lean();
  return ok(res, {
    people: links.map((l) => {
      const a = active.find((x) => String(x.user) === String(l.owner?._id));
      let view: any = null;
      if (a) {
        view = ownerView(a);
        delete view.contactDeliveries;
        delete view.responders;
        if (!l.canViewLiveLocation) delete view.location;
      }
      return { contactId: l._id, person: l.owner, canViewLiveLocation: l.canViewLiveLocation, activeSos: view };
    }),
    recent,
  });
}
