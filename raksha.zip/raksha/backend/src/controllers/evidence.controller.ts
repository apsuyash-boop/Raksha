import { Request, Response } from 'express';
import archiver from 'archiver';
import { z } from 'zod';
import { Case, Evidence, SOSAlert, User } from '../models';
import { AppError, created, ok, paginate } from '../utils/http';
import { detectFileType } from '../utils/fileType';
import { sha256 } from '../utils/crypto';
import { storage } from '../services/storage';
import { scanBuffer } from '../services/scanner';
import { evidenceAccess } from '../services/access';
import { evidenceId } from '../services/ids';
import { audit } from '../services/audit';
import { realtime } from '../services/realtime';
import { ownerView } from '../services/sos';
import { objectId } from '../validators/common';

export const uploadFieldsSchema = z.object({
  title: z.string().trim().max(200).optional(),
  description: z.string().trim().max(2000).optional(),
  category: z.enum(['photo', 'video', 'audio', 'document', 'medical_report', 'screenshot', 'complaint_document', 'sos_recording', 'other']).optional(),
  capturedAt: z.coerce.date().optional(),
  lat: z.coerce.number().min(-90).max(90).optional(),
  lng: z.coerce.number().min(-180).max(180).optional(),
  accuracy: z.coerce.number().min(0).optional(),
  sosId: objectId.optional(),
  caseId: objectId.optional(),
});
export const updateSchema = z.object({ title: z.string().max(200).optional(), description: z.string().max(2000).optional(), caseIds: z.array(objectId).max(20).optional() });
export const shareSchema = z.object({ userId: objectId });
export const packageSchema = z.object({ ids: z.array(objectId).min(1).max(100), reason: z.string().max(300).optional() });

const META_FIELDS = '-accessLog -sharedWith';

function logAccess(ev: any, req: Request, action: string, reason?: string) {
  ev.accessLog.push({ user: req.user!.id, role: req.user!.role, action, reason, ip: req.ip, at: new Date() });
}

async function authorize(req: Request, ev: any, action: string) {
  if (!ev || ev.deletedAt) throw AppError.notFound('Evidence not found');
  let reason = await evidenceAccess(req.user!, ev);
  if (!reason && req.user!.role === 'admin') {
    // Admin access to evidence is exceptional: requires a written justification and is visible to the owner.
    const justification = String(req.query.reason || req.body?.reason || '').trim();
    if (justification.length < 10) throw AppError.forbidden('Administrators must provide a justification (min 10 characters) to access evidence');
    reason = `admin: ${justification}`;
  }
  if (!reason) {
    await audit(req, 'evidence.access_denied', { targetType: 'Evidence', targetId: ev._id, subjectUser: ev.owner, meta: { action } });
    throw AppError.forbidden('You are not authorised to access this evidence');
  }
  return reason;
}

export async function uploadEvidence(req: Request, res: Response) {
  const files = (req.files as Express.Multer.File[]) || [];
  if (!files.length) throw AppError.badRequest('No file uploaded');
  const f = uploadFieldsSchema.parse(req.body);

  if (f.sosId && !(await SOSAlert.exists({ _id: f.sosId, user: req.user!.id }))) throw AppError.forbidden('SOS not found');
  if (f.caseId && !(await Case.exists({ _id: f.caseId, user: req.user!.id }))) throw AppError.forbidden('Case not found');

  const out: any[] = [];
  for (const file of files) {
    const type = detectFileType(file.buffer);
    if (!type) throw AppError.badRequest(`"${file.originalname}" is not a supported file type (images, video, audio, PDF or DOCX)`);
    const scan = await scanBuffer(file.buffer);
    if (scan.status === 'infected') {
      await audit(req, 'evidence.malware_blocked', { meta: { signature: scan.signature, name: file.originalname } });
      throw AppError.badRequest(`"${file.originalname}" failed the security scan and was rejected`);
    }
    const hash = sha256(file.buffer);
    const { key, driver } = await storage.putEncrypted(`evidence/${req.user!.id}`, file.buffer);
    const category = f.category || (f.sosId ? 'sos_recording' : type.kind === 'image' ? 'photo' : type.kind === 'document' ? 'document' : type.kind);
    const ev = await Evidence.create({
      evidenceId: evidenceId(),
      owner: req.user!.id,
      title: f.title || file.originalname.slice(0, 200),
      description: f.description,
      category,
      kind: type.kind,
      mimeType: type.mime,
      originalName: file.originalname.slice(0, 200),
      size: file.size,
      sha256: hash,
      storageKey: key,
      storageDriver: driver,
      capturedAt: f.capturedAt || new Date(),
      gps: f.lat != null && f.lng != null ? { lat: f.lat, lng: f.lng, accuracy: f.accuracy } : undefined,
      sos: f.sosId,
      cases: f.caseId ? [f.caseId] : [],
      scanStatus: scan.status,
      accessLog: [{ user: req.user!.id, role: req.user!.role, action: 'upload', ip: req.ip }],
    });
    if (f.sosId) {
      const alert = await SOSAlert.findById(f.sosId);
      if (alert) {
        alert.evidence.push(ev._id);
        alert.timeline.push({ step: 'note', label: `Evidence saved securely: ${type.kind} (${Math.round(file.size / 1024)} KB, SHA-256 ${hash.slice(0, 10)}…)`, at: new Date() });
        await alert.save();
        realtime.toUser(req.user!.id, 'sos:update', ownerView(alert));
      }
    }
    if (f.caseId) await Case.updateOne({ _id: f.caseId }, { $addToSet: { evidence: ev._id }, $push: { timeline: { label: 'Evidence added', detail: ev.title, by: req.user!.id } } });
    await audit(req, 'evidence.upload', { targetType: 'Evidence', targetId: ev._id, subjectUser: req.user!.id, meta: { sha256: hash, size: file.size } });
    const json = ev.toJSON();
    delete json.storageKey;
    delete json.storageDriver;
    delete json.accessLog;
    out.push(json);
  }
  return created(res, { items: out }, `${out.length} item(s) stored securely`);
}

export async function list(req: Request, res: Response) {
  const { skip, limit } = paginate(req, 50, 200);
  const q: any = { owner: req.user!.id, deletedAt: null };
  if (req.query.category) q.category = req.query.category;
  if (req.query.caseId) q.cases = req.query.caseId;
  if (req.query.sosId) q.sos = req.query.sosId;
  const [items, total] = await Promise.all([Evidence.find(q).select(META_FIELDS).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(), Evidence.countDocuments(q)]);
  return ok(res, { items, total });
}

export async function getOne(req: Request, res: Response) {
  const ev = await Evidence.findById(req.params.id);
  const reason = await authorize(req, ev, 'view_metadata');
  const isOwner = String(ev.owner) === req.user!.id;
  if (!isOwner) {
    logAccess(ev, req, 'view_metadata', reason);
    await ev.save();
    await audit(req, 'evidence.view_metadata', { targetType: 'Evidence', targetId: ev._id, subjectUser: ev.owner, meta: { reason } });
  }
  const json = ev.toJSON();
  delete json.storageKey;
  delete json.storageDriver;
  if (!isOwner) {
    delete json.accessLog;
    delete json.sharedWith;
  } else {
    await Evidence.populate(json, { path: 'accessLog.user sharedWith.user', select: 'name role' });
  }
  return ok(res, { item: json });
}

export async function download(req: Request, res: Response) {
  const ev = await Evidence.findById(req.params.id).select('+storageKey');
  const reason = await authorize(req, ev, 'download');
  const buf = await storage.getDecrypted(ev.storageKey);
  const integrityOk = sha256(buf) === ev.sha256;
  logAccess(ev, req, 'download', reason);
  await ev.save();
  await audit(req, 'evidence.download', { targetType: 'Evidence', targetId: ev._id, subjectUser: ev.owner, meta: { reason, integrityOk } });
  res.setHeader('Content-Type', ev.mimeType || 'application/octet-stream');
  res.setHeader('Content-Disposition', `${req.query.inline ? 'inline' : 'attachment'}; filename="${ev.evidenceId}.${(ev.originalName || '').split('.').pop() || 'bin'}"`);
  res.setHeader('X-Evidence-SHA256', ev.sha256);
  res.setHeader('X-Integrity-Verified', String(integrityOk));
  res.setHeader('Cache-Control', 'no-store');
  res.send(buf);
}

export async function verify(req: Request, res: Response) {
  const ev = await Evidence.findById(req.params.id).select('+storageKey');
  const reason = await authorize(req, ev, 'verify');
  const buf = await storage.getDecrypted(ev.storageKey);
  const computed = sha256(buf);
  const match = computed === ev.sha256;
  logAccess(ev, req, 'verify', reason);
  if (!match) ev.verificationStatus = 'disputed';
  await ev.save();
  return ok(res, { match, storedHash: ev.sha256, computedHash: computed, checkedAt: new Date() }, match ? 'Integrity verified — file is unchanged since upload' : 'WARNING: hash mismatch');
}

export async function update(req: Request, res: Response) {
  const ev = await Evidence.findOne({ _id: req.params.id, owner: req.user!.id, deletedAt: null });
  if (!ev) throw AppError.notFound('Evidence not found');
  if (req.body.title !== undefined) ev.title = req.body.title;
  if (req.body.description !== undefined) ev.description = req.body.description;
  if (req.body.caseIds) {
    const owned = await Case.find({ _id: { $in: req.body.caseIds }, user: req.user!.id }).select('_id').lean<any[]>();
    ev.cases = owned.map((c) => c._id);
    await Case.updateMany({ _id: { $in: ev.cases } }, { $addToSet: { evidence: ev._id } });
    await Case.updateMany({ user: req.user!.id, _id: { $nin: ev.cases } }, { $pull: { evidence: ev._id } });
  }
  await ev.save();
  return ok(res, { item: { ...ev.toJSON(), storageKey: undefined, accessLog: undefined } }, 'Updated');
}

export async function share(req: Request, res: Response) {
  const ev = await Evidence.findOne({ _id: req.params.id, owner: req.user!.id, deletedAt: null });
  if (!ev) throw AppError.notFound('Evidence not found');
  const target = await User.findById(req.body.userId).select('role verified').lean<any>();
  if (!target || !['lawyer', 'ngo', 'counsellor', 'police', 'admin'].includes(target.role) || !target.verified) throw AppError.badRequest('Evidence can only be shared with verified professionals');
  if (!ev.sharedWith.some((s: any) => String(s.user) === req.body.userId)) ev.sharedWith.push({ user: req.body.userId, grantedAt: new Date() });
  logAccess(ev, req, 'share', `shared with ${req.body.userId}`);
  await ev.save();
  await audit(req, 'evidence.share', { targetType: 'Evidence', targetId: ev._id, subjectUser: req.user!.id, meta: { with: req.body.userId } });
  return ok(res, {}, 'Access granted');
}

export async function revoke(req: Request, res: Response) {
  const ev = await Evidence.findOne({ _id: req.params.id, owner: req.user!.id });
  if (!ev) throw AppError.notFound('Evidence not found');
  ev.sharedWith = ev.sharedWith.filter((s: any) => String(s.user) !== req.params.userId);
  logAccess(ev, req, 'revoke', `revoked ${req.params.userId}`);
  await ev.save();
  await audit(req, 'evidence.revoke', { targetType: 'Evidence', targetId: ev._id, subjectUser: req.user!.id, meta: { from: req.params.userId } });
  return ok(res, {}, 'Access revoked');
}

export async function remove(req: Request, res: Response) {
  const ev = await Evidence.findOne({ _id: req.params.id, owner: req.user!.id, deletedAt: null }).select('+storageKey');
  if (!ev) throw AppError.notFound('Evidence not found');
  await storage.remove(ev.storageKey).catch(() => undefined);
  ev.deletedAt = new Date();
  logAccess(ev, req, 'delete');
  await ev.save();
  await Case.updateMany({ evidence: ev._id }, { $pull: { evidence: ev._id } });
  await audit(req, 'evidence.delete', { targetType: 'Evidence', targetId: ev._id, subjectUser: req.user!.id });
  return ok(res, {}, 'Evidence deleted permanently');
}

/** Protected evidence package: ZIP with original files + manifest.json (hashes, timestamps, GPS, chain of custody). */
export async function packageZip(req: Request, res: Response) {
  const items = await Evidence.find({ _id: { $in: req.body.ids }, deletedAt: null }).select('+storageKey');
  if (items.length !== req.body.ids.length) throw AppError.notFound('Some evidence items were not found');
  const reasons: string[] = [];
  for (const ev of items) reasons.push(await authorize(req, ev, 'package'));

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="raksha-evidence-${new Date().toISOString().slice(0, 10)}.zip"`);
  res.setHeader('Cache-Control', 'no-store');
  const zip = archiver('zip', { zlib: { level: 6 } });
  zip.on('error', (e) => res.destroy(e));
  zip.pipe(res);

  const manifest: any = { generatedAt: new Date().toISOString(), generatedBy: { id: req.user!.id, role: req.user!.role }, hashAlgorithm: 'SHA-256', items: [] as any[] };
  for (const ev of items) {
    const buf = await storage.getDecrypted(ev.storageKey);
    const ext = (ev.originalName || '').split('.').pop() || 'bin';
    const name = `${ev.evidenceId}.${ext}`;
    zip.append(buf, { name: `files/${name}` });
    manifest.items.push({
      file: `files/${name}`,
      evidenceId: ev.evidenceId,
      title: ev.title,
      category: ev.category,
      mimeType: ev.mimeType,
      size: ev.size,
      sha256: ev.sha256,
      integrityVerifiedAtExport: sha256(buf) === ev.sha256,
      capturedAt: ev.capturedAt,
      uploadedAt: ev.uploadedAt,
      gps: ev.gps,
      chainOfCustody: (ev.accessLog || []).map((a: any) => ({ user: String(a.user), role: a.role, action: a.action, at: a.at })),
    });
    logAccess(ev, req, 'package', reasons[0]);
    await ev.save();
    await audit(req, 'evidence.package', { targetType: 'Evidence', targetId: ev._id, subjectUser: ev.owner });
  }
  zip.append(JSON.stringify(manifest, null, 2), { name: 'manifest.json' });
  zip.append(
    'RAKSHA EVIDENCE PACKAGE\n\nEach file in /files is the original upload. manifest.json lists the SHA-256 fingerprint recorded at upload time.\nTo verify a file: `sha256sum files/<name>` (Linux/macOS) or `certutil -hashfile files\\<name> SHA256` (Windows) and compare with the manifest.\n',
    { name: 'README.txt' },
  );
  await zip.finalize();
}
