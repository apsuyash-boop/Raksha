import { Request, Response } from 'express';
import { z } from 'zod';
import { Campaign, Donation, LoanRequest, Transaction, User, Verification } from '../models';
import { AppError, created, ok, paginate } from '../utils/http';
import { email, objectId } from '../validators/common';
import { activeGateway, createOrder, feeFor, mockGatewayPay, verifyPaymentSignature, verifyWebhookSignature } from '../services/payments';
import { receiptNumber, slugify } from '../services/ids';
import { notify } from '../services/notify';
import { audit } from '../services/audit';
import { env } from '../config/env';
import { logger } from '../utils/logger';

/* -------------------------------- schemas -------------------------------- */
export const campaignSchema = z.object({
  title: z.string().trim().min(10).max(160),
  story: z.string().trim().min(100, 'Please share a little more (at least 100 characters)').max(6000),
  category: z.enum(['legal_fees', 'rent', 'shelter', 'medical', 'recovery', 'education', 'livelihood']),
  goalAmount: z.coerce.number().int().min(500).max(1000000),
  displayName: z.string().trim().max(60).default('A Raksha beneficiary'),
  city: z.string().max(80).optional(),
  state: z.string().max(80).optional(),
  caseId: objectId.optional(),
  payee: z.object({ type: z.enum(['lawyer', 'landlord', 'hospital', 'ngo', 'beneficiary']), name: z.string().max(120), reference: z.string().max(200).optional() }).optional(),
  endsAt: z.coerce.date().optional(),
});
export const orderSchema = z
  .object({
    campaignId: objectId.optional(),
    generalFund: z.boolean().optional(),
    amount: z.coerce.number().int().min(10).max(500000),
    anonymous: z.boolean().default(false),
    message: z.string().max(300).optional(),
    donorName: z.string().max(120).optional(),
    donorEmail: email.optional(),
  })
  .refine((d) => d.campaignId || d.generalFund, { message: 'Choose a campaign or the general fund' });
export const verifySchema = z.object({ orderId: z.string().min(5).max(100), paymentId: z.string().min(5).max(100), signature: z.string().min(10).max(200) });
export const utilizationSchema = z.object({ amount: z.coerce.number().min(1), purpose: z.string().max(300), paidTo: z.string().max(200) });
export const loanSchema = z.object({
  amount: z.coerce.number().int().min(1000).max(500000),
  purpose: z.enum(['rent_deposit', 'legal_fees', 'small_business', 'education', 'medical', 'relocation', 'other']),
  description: z.string().max(2000).optional(),
  tenureMonths: z.coerce.number().int().min(1).max(60),
  monthlyIncome: z.coerce.number().min(0).max(10000000).optional(),
  city: z.string().max(80).optional(),
  state: z.string().max(80).optional(),
  consentToShareWithLenders: z.literal(true, { errorMap: () => ({ message: 'Consent is needed to show your request to registered lending partners' }) }),
});
export const offerSchema = z.object({
  annualInterestRate: z.coerce.number().min(0).max(36),
  processingFee: z.coerce.number().min(0).max(10000).default(0),
  tenureMonths: z.coerce.number().int().min(1).max(60),
  terms: z.string().max(3000),
  regulatoryId: z.string().min(3).max(60),
});

const publicCampaign = (c: any) => ({
  _id: c._id,
  slug: c.slug,
  title: c.title,
  story: c.story,
  category: c.category,
  goalAmount: c.goalAmount,
  raisedAmount: c.raisedAmount,
  disbursedAmount: c.disbursedAmount,
  donorsCount: c.donorsCount,
  displayName: c.displayName,
  city: c.city,
  state: c.state,
  status: c.status,
  kycVerified: c.kycVerified,
  payeeType: c.payee?.type,
  utilization: (c.utilization || []).map((u: any) => ({ amount: u.amount, purpose: u.purpose, paidTo: u.paidTo, at: u.at })),
  endsAt: c.endsAt,
  createdAt: c.createdAt,
  isDemo: c.isDemo,
});

/* ------------------------------- campaigns ------------------------------- */
export async function listCampaigns(req: Request, res: Response) {
  const { skip, limit } = paginate(req, 12, 50);
  const q: any = { status: { $in: req.query.status === 'completed' ? ['completed'] : ['active'] } };
  if (req.query.category) q.category = req.query.category;
  const [items, total] = await Promise.all([Campaign.find(q).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(), Campaign.countDocuments(q)]);
  return ok(res, { items: items.map(publicCampaign), total });
}

export async function getCampaign(req: Request, res: Response) {
  const c = await Campaign.findOne({ slug: req.params.slug, status: { $in: ['active', 'completed', 'paused'] } }).lean();
  if (!c) throw AppError.notFound('Campaign not found');
  const recent = await Donation.find({ campaign: (c as any)._id, status: 'paid' }).sort({ createdAt: -1 }).limit(10).select('amount anonymous donorName message createdAt').lean<any[]>();
  return ok(res, { campaign: publicCampaign(c), recentDonations: recent.map((d) => ({ amount: d.amount, name: d.anonymous ? 'Anonymous' : d.donorName || 'Anonymous', message: d.message, at: d.createdAt })) });
}

export async function createCampaign(req: Request, res: Response) {
  const b = req.body;
  const c = await Campaign.create({ ...b, case: b.caseId, slug: slugify(b.title), beneficiary: req.user!.id, status: 'pending_verification', isDemo: req.user!.isDemo });
  await Verification.create({ user: req.user!.id, role: 'campaign_kyc', campaign: c._id, details: { title: c.title, goalAmount: c.goalAmount } });
  await audit(req, 'campaign.create', { targetType: 'Campaign', targetId: c._id });
  return created(res, { campaign: c }, 'Campaign submitted. It will go live after KYC verification.');
}

export async function myCampaigns(req: Request, res: Response) {
  return ok(res, { campaigns: await Campaign.find({ beneficiary: req.user!.id }).sort({ createdAt: -1 }).lean() });
}

export async function addUtilization(req: Request, res: Response) {
  const c = await Campaign.findById(req.params.id);
  if (!c) throw AppError.notFound();
  if (c.disbursedAmount + req.body.amount > c.raisedAmount) throw AppError.badRequest('Cannot disburse more than raised');
  const tx = await Transaction.create({ type: 'disbursement', provider: 'manual', amount: req.body.amount, status: 'completed', campaign: c._id, paidTo: req.body.paidTo, user: req.user!.id, isDemo: c.isDemo });
  c.utilization.push({ ...req.body, transaction: tx._id });
  c.disbursedAmount += req.body.amount;
  await c.save();
  await notify(c.beneficiary, { type: 'campaign', title: 'Funds disbursed', body: `₹${req.body.amount} paid to ${req.body.paidTo} for ${req.body.purpose}`, link: '/financial-help' });
  await audit(req, 'campaign.disbursement', { targetType: 'Campaign', targetId: c._id, meta: req.body });
  return ok(res, { campaign: c }, 'Disbursement recorded');
}

/* -------------------------------- payments ------------------------------- */
export async function paymentConfig(_req: Request, res: Response) {
  const g = activeGateway();
  return ok(res, { gateway: g, keyId: g === 'razorpay' ? env.RAZORPAY_KEY_ID : g === 'mock' ? 'mock' : null, platformFeePercent: env.PLATFORM_FEE_PERCENT, demo: g === 'mock' });
}

export async function createDonationOrder(req: Request, res: Response) {
  const b = req.body;
  let campaign: any = null;
  if (b.campaignId) {
    campaign = await Campaign.findOne({ _id: b.campaignId, status: 'active' });
    if (!campaign) throw AppError.badRequest('This campaign is not accepting donations');
  }
  const donor = req.user ? await User.findById(req.user.id).select('name email isDemo').lean<any>() : null;
  const donation = await Donation.create({
    donor: req.user?.id,
    donorName: b.donorName || donor?.name,
    donorEmail: b.donorEmail || donor?.email,
    anonymous: b.anonymous,
    campaign: campaign?._id,
    generalFund: !campaign,
    amount: b.amount,
    platformFee: feeFor(b.amount),
    message: b.message,
    status: 'created',
    isDemo: activeGateway() === 'mock',
  });
  const order = await createOrder(b.amount, `don_${donation._id}`, { donationId: String(donation._id) });
  const tx = await Transaction.create({ type: 'donation', provider: order.gateway, orderId: order.orderId, amount: b.amount, status: 'created', user: req.user?.id, campaign: campaign?._id, donation: donation._id, isDemo: order.gateway === 'mock' });
  donation.transaction = tx._id;
  await donation.save();
  return created(res, { donationId: donation._id, orderId: order.orderId, amount: order.amount, currency: order.currency, keyId: order.keyId, gateway: order.gateway, prefill: { name: donation.donorName, email: donation.donorEmail } });
}

/** Core of payment trust: success is ONLY recorded after server-side signature verification. */
async function settle(orderId: string, paymentId: string, signature: string, via: 'checkout' | 'webhook') {
  const tx = await Transaction.findOne({ orderId, type: 'donation' });
  if (!tx) throw AppError.notFound('Order not found');
  if (tx.status === 'captured') return { tx, already: true };
  const valid = via === 'webhook' || verifyPaymentSignature(tx.provider, orderId, paymentId, signature);
  if (!valid) {
    tx.status = 'failed';
    await tx.save();
    await Donation.updateOne({ _id: tx.donation }, { status: 'failed' });
    throw AppError.badRequest('Payment verification failed. If money was deducted, it will be refunded by the gateway.');
  }
  tx.status = 'captured';
  tx.paymentId = paymentId;
  tx.signatureVerified = via === 'checkout';
  tx.receiptNumber = receiptNumber();
  await tx.save();
  const donation = await Donation.findByIdAndUpdate(tx.donation, { status: 'paid', receiptNumber: tx.receiptNumber }, { new: true });
  if (donation?.platformFee) await Transaction.create({ type: 'platform_fee', provider: 'manual', amount: donation.platformFee, status: 'completed', donation: donation._id, campaign: donation.campaign, isDemo: tx.isDemo });
  if (donation?.campaign) {
    const c = await Campaign.findByIdAndUpdate(donation.campaign, { $inc: { raisedAmount: donation.amount - (donation.platformFee || 0), donorsCount: 1 } }, { new: true });
    if (c) {
      if (c.raisedAmount >= c.goalAmount && c.status === 'active') {
        c.status = 'completed';
        await c.save();
      }
      await notify(c.beneficiary, { type: 'donation', title: `You received ₹${donation.amount}`, body: donation.message || 'Someone supported your campaign.', link: '/financial-help' });
    }
  }
  if (donation?.donor) await notify(donation.donor, { type: 'donation', title: 'Thank you for your donation', body: `Receipt ${tx.receiptNumber}`, link: '/donate' });
  return { tx, donation, already: false };
}

export async function verifyDonation(req: Request, res: Response) {
  const { orderId, paymentId, signature } = req.body;
  const r = await settle(orderId, paymentId, signature, 'checkout');
  await audit(req, 'payment.verified', { targetType: 'Transaction', targetId: r.tx._id, meta: { orderId } });
  const d = r.donation || (await Donation.findById(r.tx.donation).lean());
  return ok(res, { receipt: receiptFor(d, r.tx) }, 'Payment verified. Thank you!');
}

export async function mockPay(req: Request, res: Response) {
  // Simulates the gateway's browser checkout in DEMO_MODE. The result must still pass /verify.
  return ok(res, mockGatewayPay(String(req.body.orderId || '')), 'Demo payment authorised (no real money moved)');
}

export async function webhook(req: Request, res: Response) {
  const raw: Buffer = (req as any).rawBody || Buffer.from(JSON.stringify(req.body));
  if (!verifyWebhookSignature(raw, String(req.headers['x-razorpay-signature'] || ''))) throw AppError.badRequest('Invalid webhook signature');
  const evt = req.body;
  if (evt?.event === 'payment.captured') {
    const p = evt.payload?.payment?.entity;
    if (p?.order_id) await settle(p.order_id, p.id, '', 'webhook').catch((e) => logger.warn('webhook settle', { err: e.message }));
  }
  return ok(res, {}, 'ok');
}

function receiptFor(d: any, tx: any) {
  return {
    receiptNumber: tx.receiptNumber,
    amount: d?.amount,
    platformFee: d?.platformFee || 0,
    currency: 'INR',
    paymentId: tx.paymentId,
    orderId: tx.orderId,
    gateway: tx.provider,
    isDemo: tx.isDemo,
    donorName: d?.anonymous ? 'Anonymous' : d?.donorName,
    date: tx.updatedAt,
    note: tx.isDemo ? 'DEMO RECEIPT — no real payment was made.' : 'Thank you for supporting women through Raksha.',
  };
}

export async function myDonations(req: Request, res: Response) {
  const items = await Donation.find({ donor: req.user!.id }).populate('campaign', 'title slug').sort({ createdAt: -1 }).lean();
  return ok(res, { items });
}

export async function getReceipt(req: Request, res: Response) {
  const d = await Donation.findOne({ _id: req.params.id, donor: req.user!.id, status: 'paid' }).lean<any>();
  if (!d) throw AppError.notFound('Receipt not found');
  const tx = await Transaction.findById(d.transaction).lean();
  return ok(res, { receipt: receiptFor(d, tx) });
}

/* --------------------------------- loans --------------------------------- */
export async function createLoan(req: Request, res: Response) {
  const l = await LoanRequest.create({ ...req.body, user: req.user!.id, isDemo: req.user!.isDemo });
  const lenders = await User.find({ role: 'lender', verified: true, status: 'active', isDemo: req.user!.isDemo }).select('_id').lean<any[]>();
  for (const x of lenders) await notify(x._id, { type: 'loan', title: 'New micro-loan request', body: `₹${l.amount} for ${l.purpose.replace(/_/g, ' ')}`, link: '/lender/dashboard' });
  return created(res, { loan: l }, 'Request shared with registered lending partners');
}

export async function myLoans(req: Request, res: Response) {
  return ok(res, { loans: await LoanRequest.find({ user: req.user!.id }).sort({ createdAt: -1 }).lean() });
}

export async function acceptOffer(req: Request, res: Response) {
  const l = await LoanRequest.findOne({ _id: req.params.id, user: req.user!.id });
  if (!l) throw AppError.notFound();
  const offer = l.offers.id(req.params.offerId);
  if (!offer || offer.status !== 'offered') throw AppError.badRequest('Offer not available');
  l.offers.forEach((o: any) => (o.status = o._id.equals(offer._id) ? 'accepted' : o.status === 'offered' ? 'declined' : o.status));
  l.status = 'offer_accepted';
  await l.save();
  await notify(offer.lender, { type: 'loan', title: 'Your loan offer was accepted', body: `₹${l.amount}. The borrower's contact is now visible in your dashboard.`, link: '/lender/dashboard' });
  await audit(req, 'loan.offer_accepted', { targetType: 'LoanRequest', targetId: l._id, meta: { lender: String(offer.lender) } });
  return ok(res, { loan: l }, 'Offer accepted. The lending partner will contact you to complete KYC and paperwork.');
}

export async function withdrawLoan(req: Request, res: Response) {
  const l = await LoanRequest.findOneAndUpdate({ _id: req.params.id, user: req.user!.id, status: { $in: ['submitted', 'offers_received'] } }, { status: 'withdrawn' }, { new: true });
  if (!l) throw AppError.notFound();
  return ok(res, { loan: l }, 'Request withdrawn');
}

/** Lenders see anonymised requests only; identity is shared only with the lender whose offer is accepted. */
export async function loanMarket(req: Request, res: Response) {
  const me = await User.findById(req.user!.id).select('isDemo').lean<any>();
  const loans = await LoanRequest.find({ consentToShareWithLenders: true, isDemo: !!me?.isDemo, $or: [{ status: { $in: ['submitted', 'offers_received'] } }, { 'offers.lender': req.user!.id }] })
    .sort({ createdAt: -1 })
    .limit(100)
    .populate('user', 'name phone email')
    .lean<any[]>();
  return ok(res, {
    loans: loans.map((l) => {
      const mine = (l.offers || []).find((o: any) => String(o.lender) === req.user!.id);
      const accepted = mine?.status === 'accepted';
      return {
        _id: l._id,
        amount: l.amount,
        purpose: l.purpose,
        description: l.description,
        tenureMonths: l.tenureMonths,
        monthlyIncome: l.monthlyIncome,
        city: l.city,
        state: l.state,
        status: l.status,
        createdAt: l.createdAt,
        myOffer: mine,
        offersCount: (l.offers || []).length,
        borrower: accepted ? { name: l.user?.name, phone: l.user?.phone, email: l.user?.email } : null,
      };
    }),
  });
}

export async function makeOffer(req: Request, res: Response) {
  const l = await LoanRequest.findOne({ _id: req.params.id, consentToShareWithLenders: true, status: { $in: ['submitted', 'offers_received'] } });
  if (!l) throw AppError.notFound('Request not open for offers');
  if (l.offers.some((o: any) => String(o.lender) === req.user!.id && o.status === 'offered')) throw AppError.conflict('You already made an offer');
  const lender = await User.findById(req.user!.id).select('name').lean<any>();
  l.offers.push({ ...req.body, lender: req.user!.id, lenderName: lender?.name });
  l.status = 'offers_received';
  await l.save();
  await notify(l.user, { type: 'loan', title: 'You received a loan offer', body: `${req.body.annualInterestRate}% p.a. for ${req.body.tenureMonths} months from ${lender?.name}`, link: '/financial-help', external: true });
  await audit(req, 'loan.offer', { targetType: 'LoanRequest', targetId: l._id });
  return created(res, {}, 'Offer sent');
}

/* ------------------------------ transparency ----------------------------- */
export async function transparency(_req: Request, res: Response) {
  const live = { isDemo: { $ne: true } };
  const [don, disb, fees, active, completed, byCat, monthly, demoDon] = await Promise.all([
    Transaction.aggregate([{ $match: { type: 'donation', status: 'captured', ...live } }, { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }]),
    Transaction.aggregate([{ $match: { type: 'disbursement', status: 'completed', ...live } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
    Transaction.aggregate([{ $match: { type: 'platform_fee', ...live } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
    Campaign.countDocuments({ status: 'active', ...live }),
    Campaign.countDocuments({ status: 'completed', ...live }),
    Campaign.aggregate([{ $match: { status: { $in: ['active', 'completed'] }, ...live } }, { $group: { _id: '$category', raised: { $sum: '$raisedAmount' }, disbursed: { $sum: '$disbursedAmount' }, count: { $sum: 1 } } }]),
    Transaction.aggregate([
      { $match: { type: { $in: ['donation', 'disbursement'] }, status: { $in: ['captured', 'completed'] }, ...live } },
      { $group: { _id: { m: { $dateToString: { format: '%Y-%m', date: '$createdAt' } }, t: '$type' }, total: { $sum: '$amount' } } },
      { $sort: { '_id.m': 1 } },
    ]),
    Transaction.aggregate([{ $match: { type: 'donation', status: 'captured', isDemo: true } }, { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }]),
  ]);
  return ok(res, {
    live: {
      totalDonations: don[0]?.total || 0,
      donationsCount: don[0]?.count || 0,
      amountDistributed: disb[0]?.total || 0,
      platformFees: fees[0]?.total || 0,
      activeCampaigns: active,
      completedCampaigns: completed,
      byCategory: byCat,
      monthly,
    },
    demo: { totalDonations: demoDon[0]?.total || 0, donationsCount: demoDon[0]?.count || 0 },
    note: 'Live figures exclude demo/test data. Figures are computed directly from verified transactions.',
    platformFeePercent: env.PLATFORM_FEE_PERCENT,
  });
}
