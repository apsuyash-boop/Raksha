import { Request, Response } from 'express';
import { z } from 'zod';
import { EmergencyContact, LocationEvent, LocationShare, SOSAlert, User } from '../models';
import { AppError, created, ok } from '../utils/http';
import { lat, lng, objectId } from '../validators/common';
import { recordLocation } from '../services/location';
import { canViewPreciseLocation } from '../services/access';
import { randomToken, sha256 } from '../utils/crypto';
import { env } from '../config/env';
import { sendMessage } from '../services/messaging';
import { notify } from '../services/notify';
import { audit } from '../services/audit';
import { mapsLink } from '../utils/geo';

export const updateSchema = z.object({
  lat,
  lng,
  accuracy: z.coerce.number().min(0).max(100000).optional(),
  speed: z.coerce.number().optional(),
  heading: z.coerce.number().optional(),
  battery: z.coerce.number().min(0).max(100).optional(),
});
export const shareSchema = z.object({
  durationMinutes: z.coerce.number().int().min(5).max(24 * 60),
  contactIds: z.array(objectId).max(10).optional(),
  reason: z.enum(['journey', 'manual']).default('manual'),
  lat: lat.optional(),
  lng: lng.optional(),
});

export async function update(req: Request, res: Response) {
  const r = await recordLocation(req.user!.id, req.body);
  return ok(res, r, r.recorded ? 'Location updated' : 'Location not stored (no active sharing)');
}

export async function startShare(req: Request, res: Response) {
  const me = await User.findById(req.user!.id).select('name isDemo').lean<any>();
  await LocationShare.updateMany({ user: req.user!.id, active: true, reason: { $ne: 'sos' } }, { active: false, stoppedAt: new Date() });
  const contacts = await EmergencyContact.find({ owner: req.user!.id, ...(req.body.contactIds?.length ? { _id: { $in: req.body.contactIds } } : {}) }).lean<any[]>();
  const token = randomToken(24);
  const share = await LocationShare.create({
    user: req.user!.id,
    active: true,
    expiresAt: new Date(Date.now() + req.body.durationMinutes * 60 * 1000),
    sharedWith: contacts.map((c) => c._id),
    trackTokenHash: sha256(token),
    reason: req.body.reason,
  });
  const trackUrl = `${env.APP_URL}/track/${token}`;
  if (req.body.lat != null && req.body.lng != null) await recordLocation(req.user!.id, { lat: req.body.lat, lng: req.body.lng });

  const demo = !!me?.isDemo;
  const text = `${demo ? '[RAKSHA DEMO] ' : ''}${me?.name} is sharing her live location with you on Raksha for ${req.body.durationMinutes} minutes: ${trackUrl}`;
  const deliveries: any[] = [];
  for (const c of contacts) {
    if (c.linkedUser) {
      await notify(c.linkedUser, { type: 'location_share', title: `${me?.name} is sharing her live location`, body: `For ${req.body.durationMinutes} minutes`, link: `/guardian/live/${req.user!.id}` });
      deliveries.push({ name: c.name, channel: 'app', status: 'sent' });
    }
    if (c.channels?.sms && c.phone) deliveries.push({ name: c.name, channel: 'sms', ...(await sendMessage('sms', c.phone, text, { demo })) });
    else if (c.channels?.whatsapp && c.phone) deliveries.push({ name: c.name, channel: 'whatsapp', ...(await sendMessage('whatsapp', c.phone, text, { demo })) });
    else if (c.channels?.email && c.email) deliveries.push({ name: c.name, channel: 'email', ...(await sendMessage('email', c.email, text, { demo, subject: 'Live location shared with you' })) });
  }
  await audit(req, 'location.share_started', { targetType: 'LocationShare', targetId: share._id, subjectUser: req.user!.id, meta: { minutes: req.body.durationMinutes, contacts: contacts.length } });
  return created(res, { share: { id: share._id, expiresAt: share.expiresAt, active: true, reason: share.reason }, trackUrl, deliveries }, 'Live location sharing started');
}

export async function stopShare(req: Request, res: Response) {
  const share = await LocationShare.findOne({ _id: req.params.id, user: req.user!.id });
  if (!share) throw AppError.notFound('Sharing session not found');
  if (share.reason === 'sos' && (await SOSAlert.exists({ _id: share.sos, status: 'active' })))
    throw AppError.conflict('Location sharing is part of your active SOS. Cancel or resolve the SOS to stop it.');
  share.active = false;
  share.stoppedAt = new Date();
  await share.save();
  await audit(req, 'location.share_stopped', { targetType: 'LocationShare', targetId: share._id, subjectUser: req.user!.id });
  return ok(res, {}, 'Location sharing stopped');
}

export async function activeShares(req: Request, res: Response) {
  const shares = await LocationShare.find({ user: req.user!.id, active: true, expiresAt: { $gt: new Date() } }).populate('sharedWith', 'name').lean();
  return ok(res, { shares });
}

export async function history(req: Request, res: Response) {
  const q: any = { user: req.user!.id };
  if (req.query.sos) q.sos = req.query.sos;
  const events = await LocationEvent.find(q).sort({ recordedAt: -1 }).limit(Math.min(1000, Number(req.query.limit) || 300)).lean<any[]>();
  return ok(res, { events: events.map((e) => ({ id: e._id, lat: e.location.coordinates[1], lng: e.location.coordinates[0], accuracy: e.accuracy, battery: e.battery, at: e.recordedAt, sos: e.sos })) });
}

export async function latestFor(req: Request, res: Response) {
  const ownerId = req.params.userId;
  if (!(await canViewPreciseLocation(req.user!, ownerId))) throw AppError.forbidden('You are not allowed to view this location');
  const ev = await LocationEvent.findOne({ user: ownerId }).sort({ recordedAt: -1 }).lean<any>();
  const owner = await User.findById(ownerId).select('name').lean<any>();
  await audit(req, 'location.viewed', { targetType: 'User', targetId: ownerId, subjectUser: ownerId });
  return ok(res, { person: { id: ownerId, name: owner?.name }, location: ev ? { lat: ev.location.coordinates[1], lng: ev.location.coordinates[0], accuracy: ev.accuracy, battery: ev.battery, at: ev.recordedAt } : null });
}

/** Public tracking link for emergency contacts without a Raksha account. Works only while sharing/SOS is active. */
export async function track(req: Request, res: Response) {
  const tokenHash = sha256(String(req.params.token || ''));
  const share = await LocationShare.findOne({ trackTokenHash: tokenHash }).select('+trackTokenHash').lean<any>();
  if (!share) throw AppError.notFound('This tracking link is invalid');
  const active = share.active && share.expiresAt > new Date();
  const owner = await User.findById(share.user).select('name').lean<any>();
  const firstName = String(owner?.name || 'Raksha user').split(' ')[0];
  if (!active) return ok(res, { active: false, name: firstName, endedAt: share.stoppedAt || share.expiresAt });
  const ev = await LocationEvent.findOne({ user: share.user, recordedAt: { $gte: share.createdAt } }).sort({ recordedAt: -1 }).lean<any>();
  const sos = share.sos ? await SOSAlert.findById(share.sos).select('status isDemo createdAt').lean<any>() : null;
  await audit(req, 'location.track_link_viewed', { targetType: 'LocationShare', targetId: share._id, subjectUser: share.user, actor: null, actorRole: 'public_link' });
  return ok(res, {
    active: true,
    name: firstName,
    reason: share.reason,
    sos: sos ? { status: sos.status, isDemo: sos.isDemo, since: sos.createdAt } : null,
    expiresAt: share.expiresAt,
    location: ev ? { lat: ev.location.coordinates[1], lng: ev.location.coordinates[0], accuracy: ev.accuracy, battery: ev.battery, at: ev.recordedAt, mapsUrl: mapsLink(ev.location.coordinates[1], ev.location.coordinates[0]) } : null,
    channel: `track:${share._id}`,
  });
}
