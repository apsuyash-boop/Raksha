import { Request, Response } from 'express';
import { z } from 'zod';
import { Types } from 'mongoose';
import { Evidence, Message, Notification, User, publicUser } from '../models';
import { AppError, created, ok } from '../utils/http';
import { objectId } from '../validators/common';
import { canChat } from '../services/access';
import { notify } from '../services/notify';
import { realtime } from '../services/realtime';
import { cleanText } from '../services/moderation';

export const sendSchema = z.object({ to: objectId, text: z.string().trim().max(4000).optional(), evidenceIds: z.array(objectId).max(5).optional(), caseId: objectId.optional() }).refine((d) => d.text || d.evidenceIds?.length, { message: 'Message is empty' });

export const convKey = (a: string, b: string) => [a, b].sort().join(':');

export async function sendMessageHandler(req: Request, res: Response) {
  const me = req.user!;
  const { to, text, evidenceIds, caseId } = req.body;
  if (!(await canChat(me, to))) throw AppError.forbidden('You can message people connected to your case, appointment or SOS only');
  let attachments: any[] = [];
  if (evidenceIds?.length) {
    // Attachments are vault items owned by the sender; the recipient is granted explicit access.
    const ev = await Evidence.find({ _id: { $in: evidenceIds }, owner: me.id, deletedAt: null });
    for (const e of ev) {
      if (!e.sharedWith.some((s: any) => String(s.user) === to)) e.sharedWith.push({ user: to, grantedAt: new Date() });
      e.accessLog.push({ user: me.id, role: me.role, action: 'share', reason: 'chat attachment', at: new Date() });
      await e.save();
    }
    attachments = ev.map((e) => ({ evidence: e._id, name: e.title, kind: e.kind }));
  }
  const m = await Message.create({ conversationKey: convKey(me.id, to), from: me.id, to, text: text ? cleanText(text) : undefined, attachments, case: caseId });
  const json = m.toJSON();
  realtime.toUser(to, 'message:new', json);
  realtime.toUser(me.id, 'message:new', json);
  // Avoid notification spam: only notify if there's no unread notification for this conversation.
  const unread = await Notification.exists({ user: to, type: 'message', read: false, 'meta.from': me.id });
  if (!unread) await notify(to, { type: 'message', title: `New message from ${me.name}`, link: `/messages?with=${me.id}`, meta: { from: me.id } });
  return created(res, { message: json });
}

export async function conversations(req: Request, res: Response) {
  const me = new Types.ObjectId(req.user!.id);
  const rows = await Message.aggregate([
    { $match: { $or: [{ from: me }, { to: me }], deletedFor: { $ne: me } } },
    { $sort: { createdAt: -1 } },
    { $group: { _id: '$conversationKey', last: { $first: '$$ROOT' }, unread: { $sum: { $cond: [{ $and: [{ $eq: ['$to', me] }, { $not: ['$readAt'] }] }, 1, 0] } } } },
    { $sort: { 'last.createdAt': -1 } },
    { $limit: 100 },
  ]);
  const otherIds = rows.map((r) => (String(r.last.from) === req.user!.id ? r.last.to : r.last.from));
  const users = await User.find({ _id: { $in: otherIds } }).select('name role verified avatarColor').lean<any[]>();
  return ok(res, {
    conversations: rows.map((r, i) => ({
      key: r._id,
      with: publicUser(users.find((u) => String(u._id) === String(otherIds[i]))),
      last: { text: r.last.text, at: r.last.createdAt, fromMe: String(r.last.from) === req.user!.id, attachments: r.last.attachments?.length || 0 },
      unread: r.unread,
    })),
  });
}

export async function thread(req: Request, res: Response) {
  const other = req.params.userId;
  if (!Types.ObjectId.isValid(other)) throw AppError.badRequest('Invalid user');
  const key = convKey(req.user!.id, other);
  const before = req.query.before ? new Date(String(req.query.before)) : new Date();
  const msgs = await Message.find({ conversationKey: key, createdAt: { $lt: before }, deletedFor: { $ne: req.user!.id } }).sort({ createdAt: -1 }).limit(50).lean();
  const otherUser = await User.findById(other).select('name role verified avatarColor').lean();
  const allowed = await canChat(req.user!, other);
  return ok(res, { messages: msgs.reverse(), with: publicUser(otherUser), canReply: allowed });
}

export async function markRead(req: Request, res: Response) {
  const key = convKey(req.user!.id, req.params.userId);
  const r = await Message.updateMany({ conversationKey: key, to: req.user!.id, readAt: null }, { readAt: new Date() });
  realtime.toUser(req.params.userId, 'message:read', { by: req.user!.id, at: new Date() });
  await Notification.updateMany({ user: req.user!.id, type: 'message', 'meta.from': req.params.userId, read: false }, { read: true });
  return ok(res, { updated: r.modifiedCount });
}

export async function contactsForChat(req: Request, res: Response) {
  // Suggest people the user is allowed to chat with: derived on the client from cases/appointments;
  // here we validate a single candidate.
  const allowed = await canChat(req.user!, String(req.query.userId || ''));
  return ok(res, { allowed });
}

/* ------------------------------ notifications ----------------------------- */
export async function listNotifications(req: Request, res: Response) {
  const q: any = { user: req.user!.id };
  if (req.query.unread === 'true') q.read = false;
  const [items, unread] = await Promise.all([Notification.find(q).sort({ createdAt: -1 }).limit(100).lean(), Notification.countDocuments({ user: req.user!.id, read: false })]);
  return ok(res, { items, unread });
}
export async function readNotification(req: Request, res: Response) {
  await Notification.updateOne({ _id: req.params.id, user: req.user!.id }, { read: true });
  return ok(res, {});
}
export async function readAllNotifications(req: Request, res: Response) {
  await Notification.updateMany({ user: req.user!.id, read: false }, { read: true });
  return ok(res, {}, 'All caught up');
}
