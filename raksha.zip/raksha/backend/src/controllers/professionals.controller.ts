import { Request, Response } from 'express';
import { z } from 'zod';
import { Counsellor, Lawyer, NGO, Responder, Verification } from '../models';
import { AppError, escapeRegex, ok, paginate } from '../utils/http';
import { caseType, lat, lng } from '../validators/common';
import { matchLawyers, matchNGOs, sanitizeProfile } from '../services/matching';
import { toPoint } from '../utils/geo';
import { audit } from '../services/audit';
import { CASE_TYPES } from '../config/roles';

const MODELS: Record<string, any> = { lawyer: Lawyer, ngo: NGO, counsellor: Counsellor };

const base = {
  languages: z.array(z.string().max(5)).max(12).optional(),
  city: z.string().max(80).optional(),
  state: z.string().max(80).optional(),
  lat: lat.optional(),
  lng: lng.optional(),
  availability: z.enum(['available', 'limited', 'unavailable']).optional(),
};

export const lawyerProfileSchema = z.object({
  ...base,
  displayName: z.string().trim().min(2).max(120),
  barCouncilId: z.string().max(60).optional(),
  enrollmentYear: z.coerce.number().int().min(1950).max(2100).optional(),
  bio: z.string().max(2000).optional(),
  specializations: z.array(z.enum(CASE_TYPES)).max(10).optional(),
  services: z.array(z.string().max(40)).max(10).optional(),
  courts: z.array(z.string().max(120)).max(10).optional(),
  feeType: z.enum(['pro_bono', 'low_fee', 'standard']).optional(),
  consultationFee: z.coerce.number().min(0).max(100000).optional(),
  proBono: z.boolean().optional(),
  freeFirstConsultation: z.boolean().optional(),
  maxActiveCases: z.coerce.number().int().min(1).max(200).optional(),
});
export const ngoProfileSchema = z.object({
  ...base,
  name: z.string().trim().min(2).max(200),
  registrationNumber: z.string().max(80).optional(),
  darpanId: z.string().max(40).optional(),
  about: z.string().max(3000).optional(),
  services: z.array(z.string().max(40)).max(15).optional(),
  focusAreas: z.array(z.enum(CASE_TYPES)).max(10).optional(),
  serviceAreas: z.array(z.string().max(80)).max(30).optional(),
  shelterCapacity: z.coerce.number().int().min(0).max(10000).optional(),
  shelterAvailable: z.coerce.number().int().min(0).max(10000).optional(),
  helpline: z.string().max(20).optional(),
  website: z.string().url().max(200).optional().or(z.literal('')),
  is24x7: z.boolean().optional(),
  isOneStopCentre: z.boolean().optional(),
});
export const counsellorProfileSchema = z.object({
  ...base,
  displayName: z.string().trim().min(2).max(120),
  qualification: z.string().max(200).optional(),
  licenseNumber: z.string().max(80).optional(),
  yearsExperience: z.coerce.number().int().min(0).max(70).optional(),
  bio: z.string().max(2000).optional(),
  specializations: z.array(z.string().max(40)).max(10).optional(),
  category: z.enum(['emotional', 'legal', 'career_money']).optional(),
  modes: z.array(z.enum(['chat', 'call', 'video'])).max(3).optional(),
  price: z.coerce.number().min(0).max(20000).optional(),
  freeSessions: z.boolean().optional(),
  weeklySlots: z.array(z.object({ day: z.number().int().min(0).max(6), from: z.string().regex(/^\d{2}:\d{2}$/), to: z.string().regex(/^\d{2}:\d{2}$/) })).max(30).optional(),
  meetingUrl: z.string().url().max(300).optional().or(z.literal('')),
});
export const responderProfileSchema = z.object({
  ...base,
  active: z.boolean().optional(),
  availabilityMode: z.enum(['always', 'scheduled', 'off']).optional(),
  skills: z.array(z.string().max(40)).max(10).optional(),
});
export const matchSchema = z.object({
  caseType,
  state: z.string().max(80).optional(),
  city: z.string().max(80).optional(),
  language: z.string().max(5).optional(),
  budget: z.enum(['free', 'low', 'standard', 'any']).default('any'),
  urgency: z.enum(['low', 'medium', 'high', 'emergency']).default('medium'),
  service: z.string().max(40).optional(),
  include: z.enum(['lawyers', 'ngos', 'both']).default('both'),
});
export const verifyRequestSchema = z.object({ details: z.record(z.string().max(500)).optional(), evidenceIds: z.array(z.string()).max(10).optional(), note: z.string().max(1000).optional() });

/* ------------------------------ public lists ----------------------------- */
export const listPublic = (kind: 'lawyer' | 'ngo' | 'counsellor') => async (req: Request, res: Response) => {
  const M = MODELS[kind];
  const { skip, limit } = paginate(req, 24, 60);
  const q: any = { verified: true };
  if (req.query.city) q.city = new RegExp(`^${escapeRegex(String(req.query.city))}$`, 'i');
  if (req.query.state) q.state = new RegExp(`^${escapeRegex(String(req.query.state))}$`, 'i');
  if (req.query.language) q.languages = String(req.query.language);
  if (req.query.specialization) q[kind === 'ngo' ? 'focusAreas' : 'specializations'] = String(req.query.specialization);
  if (req.query.category && kind === 'counsellor') q.category = String(req.query.category);
  if (req.query.free === 'true') Object.assign(q, kind === 'lawyer' ? { $or: [{ proBono: true }, { feeType: 'pro_bono' }] } : kind === 'counsellor' ? { $or: [{ freeSessions: true }, { price: 0 }] } : {});
  if (req.query.service) q.services = String(req.query.service);
  if (req.query.q) {
    const re = new RegExp(escapeRegex(String(req.query.q)), 'i');
    q.$and = [{ $or: [{ displayName: re }, { name: re }, { bio: re }, { about: re }] }];
  }
  const [items, total] = await Promise.all([M.find(q).sort({ rating: -1, createdAt: -1 }).skip(skip).limit(limit).populate('user', 'name avatarColor').lean(), M.countDocuments(q)]);
  return ok(res, { items: items.map(sanitizeProfile), total });
};

export const getPublic = (kind: 'lawyer' | 'ngo' | 'counsellor') => async (req: Request, res: Response) => {
  const p = await MODELS[kind].findOne({ _id: req.params.id, verified: true }).populate('user', 'name avatarColor').lean();
  if (!p) throw AppError.notFound('Profile not found');
  return ok(res, { profile: sanitizeProfile(p) });
};

export async function match(req: Request, res: Response) {
  const b = req.body;
  const [lawyers, ngos] = await Promise.all([b.include !== 'ngos' ? matchLawyers(b) : [], b.include !== 'lawyers' ? matchNGOs(b) : []]);
  return ok(res, { lawyers, ngos, criteria: b });
}

/* ------------------------------- my profile ------------------------------ */
export const getMine = (kind: 'lawyer' | 'ngo' | 'counsellor' | 'responder') => async (req: Request, res: Response) => {
  const M = kind === 'responder' ? Responder : MODELS[kind];
  const profile = await M.findOne({ user: req.user!.id }).select(kind === 'lawyer' ? '+barCouncilId' : kind === 'ngo' ? '+registrationNumber' : kind === 'counsellor' ? '+licenseNumber' : '').lean();
  const verification = await Verification.findOne({ user: req.user!.id }).sort({ createdAt: -1 }).lean();
  return ok(res, { profile, verification, verified: req.user!.verified });
};

export const upsertMine = (kind: 'lawyer' | 'ngo' | 'counsellor' | 'responder') => async (req: Request, res: Response) => {
  const M = kind === 'responder' ? Responder : MODELS[kind];
  const { lat: la, lng: ln, availabilityMode, ...rest } = req.body;
  const update: any = { ...rest, user: req.user!.id };
  if (la != null && ln != null) {
    update.location = toPoint(la, ln);
    if (kind === 'responder') update.locationUpdatedAt = new Date();
  }
  if (kind === 'responder') {
    delete update.availability;
    if (availabilityMode) update.availability = availabilityMode;
    delete update.availabilityMode;
    if (rest.active && !req.user!.verified) throw AppError.forbidden('Responder mode can be turned on after verification');
  }
  // Verification status is NEVER settable by the professional.
  delete update.verified;
  delete update.verifiedAt;
  delete update.rating;
  delete update.reviews;
  update.verified = req.user!.verified;
  const profile = await M.findOneAndUpdate({ user: req.user!.id }, { $set: update }, { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true });
  await audit(req, `${kind}.profile_updated`, { targetType: kind, targetId: profile._id });
  return ok(res, { profile }, 'Profile saved');
};

export const requestVerification = (role: string) => async (req: Request, res: Response) => {
  const pending = await Verification.findOne({ user: req.user!.id, role, status: { $in: ['pending', 'more_info'] } });
  const docs = (req.body.evidenceIds || []).map((id: string) => ({ evidence: id, label: 'Supporting document' }));
  if (pending) {
    pending.documents.push(...docs);
    pending.details = { ...(pending.details || {}), ...(req.body.details || {}), note: req.body.note };
    pending.status = 'pending';
    await pending.save();
    return ok(res, { verification: pending }, 'Verification request updated');
  }
  const v = await Verification.create({ user: req.user!.id, role, documents: docs, details: { ...(req.body.details || {}), note: req.body.note } });
  await audit(req, 'verification.requested', { targetType: 'Verification', targetId: v._id });
  return ok(res, { verification: v }, 'Verification submitted. Our team will review it shortly.');
};
