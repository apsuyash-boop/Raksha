import { Request, Response } from 'express';
import { z } from 'zod';
import { RightsArticle, Scheme, SchemeApplication } from '../models';
import { AppError, created, escapeRegex, ok } from '../utils/http';
import { rankSchemes } from '../services/schemeEligibility';
import { audit } from '../services/audit';
import { notify } from '../services/notify';

export const eligibilitySchema = z.object({
  state: z.string().max(80).optional(),
  age: z.coerce.number().int().min(0).max(120).optional(),
  gender: z.enum(['female', 'male', 'other']).optional(),
  annualFamilyIncome: z.coerce.number().min(0).max(1e9).optional(),
  maritalStatus: z.enum(['single', 'married', 'widowed', 'divorced', 'separated']).optional(),
  pregnantOrLactating: z.boolean().optional(),
  hasGirlChildUnder10: z.boolean().optional(),
  wantsToStartBusiness: z.boolean().optional(),
  isGovtEmployee: z.boolean().optional(),
  paysIncomeTax: z.boolean().optional(),
  employment: z.enum(['unemployed', 'self_employed', 'salaried', 'student', 'homemaker', 'other']).optional(),
});

export const schemeSchema = z.object({
  slug: z.string().regex(/^[a-z0-9-]+$/).max(80),
  name: z.string().max(200),
  nameHi: z.string().max(200).optional(),
  level: z.enum(['central', 'state']),
  states: z.array(z.string().max(80)).max(40).default([]),
  ministry: z.string().max(200).optional(),
  category: z.enum(['financial_aid', 'maternity', 'savings', 'entrepreneurship', 'support_services', 'education', 'housing', 'health', 'employment', 'other']),
  description: z.string().max(4000),
  descriptionHi: z.string().max(4000).optional(),
  eligibility: z.array(z.string().max(500)).max(30),
  benefits: z.array(z.string().max(500)).max(30),
  documents: z.array(z.string().max(300)).max(30),
  applicationMethod: z.string().max(2000),
  officialUrl: z.string().url().max(300),
  helpline: z.string().max(40).optional(),
  criteria: z
    .object({
      gender: z.enum(['female', 'any']).optional(),
      minAge: z.number().optional(),
      maxAge: z.number().optional(),
      maxAnnualFamilyIncome: z.number().optional(),
      maritalStatus: z.array(z.string()).optional(),
      requiresPregnantOrLactating: z.boolean().optional(),
      requiresGirlChildUnder10: z.boolean().optional(),
      requiresEntrepreneur: z.boolean().optional(),
      excludesGovtEmployees: z.boolean().optional(),
      excludesIncomeTaxPayers: z.boolean().optional(),
    })
    .default({}),
  tags: z.array(z.string().max(40)).max(20).default([]),
  active: z.boolean().default(true),
  sourceNote: z.string().max(1000).optional(),
});

export const applicationSchema = z.object({
  status: z.enum(['interested', 'documents_ready', 'applied', 'under_review', 'approved', 'rejected', 'benefit_received']).optional(),
  applicationRef: z.string().max(100).optional(),
  notes: z.string().max(2000).optional(),
  checklist: z.array(z.object({ item: z.string().max(300), done: z.boolean() })).max(40).optional(),
});

export async function listSchemes(req: Request, res: Response) {
  const q: any = { active: true };
  if (req.query.category) q.category = req.query.category;
  if (req.query.state) q.$or = [{ level: 'central' }, { states: new RegExp(`^${escapeRegex(String(req.query.state))}$`, 'i') }];
  if (req.query.q) {
    const re = new RegExp(escapeRegex(String(req.query.q)), 'i');
    q.$and = [{ $or: [{ name: re }, { description: re }, { tags: re }, { nameHi: re }] }];
  }
  const schemes = await Scheme.find(q).sort({ level: 1, name: 1 }).lean();
  return ok(res, { schemes });
}

export async function getScheme(req: Request, res: Response) {
  const s = await Scheme.findOne({ $or: [{ slug: req.params.id }, ...(req.params.id.match(/^[a-f0-9]{24}$/) ? [{ _id: req.params.id }] : [])] }).lean();
  if (!s) throw AppError.notFound('Scheme not found');
  return ok(res, { scheme: s });
}

export async function checkEligibility(req: Request, res: Response) {
  const schemes = await Scheme.find({ active: true }).lean();
  const results = rankSchemes(schemes, req.body);
  return ok(res, {
    results,
    disclaimer: 'This is a guide based on the official criteria we hold. Final eligibility is decided by the government department — always confirm on the official website.',
  });
}

export async function myApplications(req: Request, res: Response) {
  const apps = await SchemeApplication.find({ user: req.user!.id }).populate('scheme', 'name slug officialUrl documents category').sort({ updatedAt: -1 }).lean();
  return ok(res, { applications: apps });
}

export async function startApplication(req: Request, res: Response) {
  const scheme = await Scheme.findOne({ _id: req.params.id, active: true }).lean<any>();
  if (!scheme) throw AppError.notFound('Scheme not found');
  const existing = await SchemeApplication.findOne({ user: req.user!.id, scheme: scheme._id });
  if (existing) return ok(res, { application: existing }, 'Already tracking this scheme');
  const app = await SchemeApplication.create({
    user: req.user!.id,
    scheme: scheme._id,
    checklist: (scheme.documents || []).map((d: string) => ({ item: d, done: false })),
    history: [{ status: 'interested', note: 'Started tracking' }],
  });
  return created(res, { application: app }, 'Added to your applications');
}

export async function updateApplication(req: Request, res: Response) {
  const app = await SchemeApplication.findOne({ _id: req.params.id, user: req.user!.id });
  if (!app) throw AppError.notFound('Application not found');
  const prev = app.status;
  Object.assign(app, req.body);
  if (req.body.status && req.body.status !== prev) {
    app.history.push({ status: req.body.status, note: req.body.notes });
    await notify(req.user!.id, { type: 'scheme_update', title: 'Scheme application updated', body: `Status: ${req.body.status.replace(/_/g, ' ')}`, link: '/schemes' });
  }
  await app.save();
  return ok(res, { application: app }, 'Saved');
}

export async function removeApplication(req: Request, res: Response) {
  await SchemeApplication.deleteOne({ _id: req.params.id, user: req.user!.id });
  return ok(res, {}, 'Removed');
}

/* ------------------------------- admin CRUD ------------------------------ */
export async function adminCreate(req: Request, res: Response) {
  const s = await Scheme.create({ ...req.body, lastVerifiedAt: new Date(), updatedBy: req.user!.id });
  await audit(req, 'scheme.create', { targetType: 'Scheme', targetId: s._id });
  return created(res, { scheme: s });
}
export async function adminUpdate(req: Request, res: Response) {
  const s = await Scheme.findByIdAndUpdate(req.params.id, { ...req.body, lastVerifiedAt: new Date(), updatedBy: req.user!.id }, { new: true, runValidators: true });
  if (!s) throw AppError.notFound();
  await audit(req, 'scheme.update', { targetType: 'Scheme', targetId: s._id });
  return ok(res, { scheme: s }, 'Scheme updated');
}
export async function adminList(_req: Request, res: Response) {
  return ok(res, { schemes: await Scheme.find().sort({ updatedAt: -1 }).lean() });
}

/* ------------------------------ rights library ----------------------------- */
export async function listRights(req: Request, res: Response) {
  const q: any = { published: true };
  if (req.query.category) q.category = req.query.category;
  const lang = String(req.query.lang || 'en');
  let items = await RightsArticle.find(q).sort({ category: 1 }).lean<any[]>();
  if (req.query.q) {
    const term = String(req.query.q).toLowerCase();
    items = items.filter((a) => JSON.stringify(a.translations).toLowerCase().includes(term) || (a.laws || []).join(' ').toLowerCase().includes(term));
  }
  return ok(res, {
    items: items.map((a) => {
      const t = a.translations?.[lang] || a.translations?.en || {};
      return { _id: a._id, slug: a.slug, category: a.category, laws: a.laws, readMinutes: a.readMinutes, title: t.title, summary: t.summary, availableLanguages: Object.keys(a.translations || {}), lang: a.translations?.[lang] ? lang : 'en' };
    }),
    disclaimer: 'Raksha legal information is for education only and does not replace advice from a qualified lawyer.',
  });
}

export async function getRight(req: Request, res: Response) {
  const a = await RightsArticle.findOne({ slug: req.params.slug, published: true }).lean<any>();
  if (!a) throw AppError.notFound('Article not found');
  const lang = String(req.query.lang || 'en');
  const t = a.translations?.[lang] || a.translations?.en;
  return ok(res, { article: { ...a, translations: undefined, ...t, lang: a.translations?.[lang] ? lang : 'en', availableLanguages: Object.keys(a.translations || {}) } });
}
