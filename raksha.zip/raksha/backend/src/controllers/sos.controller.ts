import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { Responder, SOSAlert, User } from '../models';
import { AppError, created, ok, paginate } from '../utils/http';
import { approximate } from '../utils/geo';
import { lat, lng } from '../validators/common';
import { broadcastEnd, ownerView, responderView, sosRoom, startSOS } from '../services/sos';
import { canViewPreciseLocation } from '../services/access';
import { notify } from '../services/notify';
import { realtime } from '../services/realtime';
import { audit } from '../services/audit';
import { decryptString } from '../utils/crypto';
import { demoOutbox } from '../services/messaging';
import { env } from '../config/env';

export const activateSchema = z.object({
  /** The client must send confirm=true after a deliberate press-and-hold + countdown. */
  confirm: z.literal(true, { errorMap: () => ({ message: 'SOS must be deliberately confirmed' }) }),
  lat: lat.optional(),
  lng: lng.optional(),
  accuracy: z.coerce.number().min(0).max(100000).optional(),
  message: z.string().trim().max(500).optional(),
  trigger: z.enum(['button', 'shake', 'voice', 'widget', 'api']).default('button'),
  simulate: z.boolean().optional(),
});

export const cancelSchema = z.object({
  pin: z.string().regex(/^\d{4,6}$/).optional(),
  password: z.string().min(1).max(128).optional(),
  reason: z.string().max(300).optional(),
});

export const resolveSchema = z.object({ note: z.string().max(1000).optional(), pin: z.string().regex(/^\d{4,6}$/).optional(), password: z.string().min(1).max(128).optional() });
export const respondSchema = z.object({ action: z.enum(['accept', 'decline', 'arrived', 'complete']), report: z.string().max(2000).optional() });
export const recordingSchema = z.object({ kind: z.enum(['audio', 'video']), state: z.enum(['started', 'stopped', 'denied']) });

export async function activate(req: Request, res: Response) {
  const { alert, trackUrl, reused } = await startSOS(req.user!.id, req.body);
  await audit(req, reused ? 'sos.activate_duplicate' : 'sos.activate', { targetType: 'SOSAlert', targetId: alert._id, subjectUser: req.user!.id, meta: { isDemo: alert.isDemo } });
  return created(res, { alert: ownerView(alert), trackUrl, reused }, alert.isDemo ? 'Demo SOS activated (simulated — no real alerts sent)' : 'SOS activated');
}

export async function active(req: Request, res: Response) {
  const alert = await SOSAlert.findOne({ user: req.user!.id, status: 'active' });
  return ok(res, { alert: alert ? ownerView(alert) : null });
}

export async function history(req: Request, res: Response) {
  const { skip, limit } = paginate(req);
  const [items, total] = await Promise.all([
    SOSAlert.find({ user: req.user!.id }).sort({ createdAt: -1 }).skip(skip).limit(limit),
    SOSAlert.countDocuments({ user: req.user!.id }),
  ]);
  return ok(res, { items: items.map(ownerView), total });
}

export async function getOne(req: Request, res: Response) {
  const alert = await SOSAlert.findById(req.params.id);
  if (!alert) throw AppError.notFound('SOS not found');
  const ownerId = String(alert.user);
  const me = req.user!;
  if (ownerId === me.id) return ok(res, { alert: ownerView(alert), view: 'owner' });

  if (me.role === 'responder' && (alert.responders || []).some((r: any) => String(r.user) === me.id)) {
    const owner = await User.findById(ownerId).select('name').lean();
    return ok(res, { alert: responderView(alert, me.id, owner), view: 'responder' });
  }
  if (alert.status === 'active' && (await canViewPreciseLocation(me, ownerId))) {
    const owner = await User.findById(ownerId).select('name phone privacy +medicalEncrypted').lean<any>();
    const view: any = ownerView(alert);
    delete view.contactDeliveries;
    view.person = { name: owner?.name, phone: owner?.phone };
    if (owner?.privacy?.shareMedicalInfoInSOS && owner?.medicalEncrypted) view.medical = JSON.parse(decryptString(owner.medicalEncrypted) || '{}');
    await audit(req, 'sos.viewed_by_contact', { targetType: 'SOSAlert', targetId: alert._id, subjectUser: ownerId });
    return ok(res, { alert: view, view: 'contact' });
  }
  if (me.role === 'admin') {
    const [lngV, latV] = alert.location?.coordinates || [];
    return ok(res, {
      alert: { id: alert._id, status: alert.status, isDemo: alert.isDemo, createdAt: alert.createdAt, timeline: ownerView(alert).timeline, emergencyService: alert.emergencyService, location: latV != null ? approximate(latV, lngV) : null },
      view: 'admin',
    });
  }
  throw AppError.forbidden();
}

async function checkPinOrPassword(userId: string, pin?: string, password?: string) {
  const u = await User.findById(userId).select('+safetyPinHash +passwordHash').lean<any>();
  if (!u) return false;
  if (pin && u.safetyPinHash) return bcrypt.compare(pin, u.safetyPinHash);
  if (password) return bcrypt.compare(password, u.passwordHash);
  return false;
}

/** False-alarm cancellation. Requires the safety PIN (or password if no PIN is set). Always logged. */
export async function cancel(req: Request, res: Response) {
  const alert = await SOSAlert.findOne({ _id: req.params.id, user: req.user!.id });
  if (!alert) throw AppError.notFound('SOS not found');
  if (alert.status !== 'active') throw AppError.conflict('This SOS is no longer active');
  const valid = await checkPinOrPassword(req.user!.id, req.body.pin, req.body.password);
  if (!valid) {
    await audit(req, 'sos.cancel_failed', { targetType: 'SOSAlert', targetId: alert._id, subjectUser: req.user!.id });
    alert.timeline.push({ step: 'note', label: 'Cancellation attempt with incorrect PIN', at: new Date() });
    await alert.save();
    throw AppError.badRequest('Incorrect PIN. Your SOS is still active.');
  }
  alert.status = 'cancelled';
  alert.cancelledAt = new Date();
  alert.cancelReason = req.body.reason || 'False alarm';
  alert.timeline.push({ step: 'cancelled', label: 'Cancelled by user with safety PIN — contacts informed she is safe', at: new Date() });
  await alert.save();
  await broadcastEnd(alert, 'cancelled');
  await audit(req, 'sos.cancel', { targetType: 'SOSAlert', targetId: alert._id, subjectUser: req.user!.id });
  realtime.toUser(req.user!.id, 'sos:update', ownerView(alert));
  return ok(res, { alert: ownerView(alert) }, 'SOS cancelled. Your contacts have been told you are safe.');
}

export async function resolve(req: Request, res: Response) {
  const alert = await SOSAlert.findOne({ _id: req.params.id, user: req.user!.id });
  if (!alert) throw AppError.notFound('SOS not found');
  if (alert.status !== 'active') throw AppError.conflict('This SOS is no longer active');
  // Ending an SOS also requires the PIN, so it cannot be stopped by someone who grabs the phone.
  if (!(await checkPinOrPassword(req.user!.id, req.body.pin, req.body.password))) {
    await audit(req, 'sos.resolve_failed', { targetType: 'SOSAlert', targetId: alert._id, subjectUser: req.user!.id });
    throw AppError.badRequest('Incorrect PIN. Your SOS is still active.');
  }
  alert.status = 'resolved';
  alert.resolvedAt = new Date();
  alert.resolutionNote = req.body.note;
  alert.timeline.push({ step: 'resolved', label: 'Emergency resolved — marked safe', at: new Date() });
  await alert.save();
  await broadcastEnd(alert, 'resolved');
  await audit(req, 'sos.resolve', { targetType: 'SOSAlert', targetId: alert._id, subjectUser: req.user!.id });
  realtime.toUser(req.user!.id, 'sos:update', ownerView(alert));
  return ok(res, { alert: ownerView(alert) }, 'Glad you are safe. SOS resolved.');
}

export async function recordingState(req: Request, res: Response) {
  const alert = await SOSAlert.findOne({ _id: req.params.id, user: req.user!.id, status: 'active' });
  if (!alert) throw AppError.notFound('Active SOS not found');
  const label =
    req.body.state === 'started' ? `${req.body.kind === 'video' ? 'Video' : 'Audio'} evidence recording started` : req.body.state === 'denied' ? `${req.body.kind} permission denied by device` : `${req.body.kind} recording stopped`;
  alert.timeline.push({ step: req.body.state === 'started' ? 'recording_started' : 'note', label, at: new Date() });
  await alert.save();
  realtime.toUser(req.user!.id, 'sos:update', ownerView(alert));
  return ok(res, { alert: ownerView(alert) });
}

/* ------------------------------ responders ------------------------------ */
export async function responderInbox(req: Request, res: Response) {
  const alerts = await SOSAlert.find({ 'responders.user': req.user!.id }).sort({ createdAt: -1 }).limit(30);
  const owners = await User.find({ _id: { $in: alerts.map((a) => a.user) } }).select('name').lean<any[]>();
  return ok(res, { alerts: alerts.map((a) => responderView(a, req.user!.id, owners.find((o) => String(o._id) === String(a.user)))) });
}

export async function respond(req: Request, res: Response) {
  const alert = await SOSAlert.findById(req.params.id);
  if (!alert) throw AppError.notFound('SOS not found');
  const entry = (alert.responders || []).find((r: any) => String(r.user) === req.user!.id);
  if (!entry) throw AppError.forbidden('You were not asked to respond to this SOS');
  if (alert.status !== 'active' && req.body.action !== 'complete') throw AppError.conflict('This SOS is no longer active');

  const action = req.body.action as 'accept' | 'decline' | 'arrived' | 'complete';
  const statusMap = { accept: 'accepted', decline: 'declined', arrived: 'arrived', complete: 'completed' } as const;
  entry.status = statusMap[action];
  entry.respondedAt = new Date();
  if (req.body.report) entry.report = req.body.report;

  if (action === 'accept') {
    alert.timeline.push({ step: 'responder_accepted', label: `A verified responder is on the way (${entry.distanceKm ?? '?'} km away)`, at: new Date() });
    await Responder.updateOne({ user: req.user!.id }, { $inc: { 'stats.accepted': 1 } });
    await notify(alert.user, { type: 'sos_update', title: 'A verified Raksha responder is coming', body: `${req.user!.name.split(' ')[0]} accepted your SOS.`, link: '/sos', priority: 'high' });
  }
  if (action === 'arrived') alert.timeline.push({ step: 'note', label: 'Responder reports arriving at the safe meeting point', at: new Date() });
  if (action === 'complete') {
    alert.timeline.push({ step: 'note', label: 'Responder reported assistance completed', at: new Date() });
    await Responder.updateOne({ user: req.user!.id }, { $inc: { 'stats.completed': 1 } });
  }
  await alert.save();
  await audit(req, `sos.responder_${action}`, { targetType: 'SOSAlert', targetId: alert._id, subjectUser: alert.user });
  realtime.toUser(String(alert.user), 'sos:update', ownerView(alert));
  const owner = await User.findById(alert.user).select('name').lean();
  return ok(res, { alert: responderView(alert, req.user!.id, owner) }, 'Response recorded');
}

/** Demo-only: what messages WOULD have been sent (nothing real was sent). */
export async function demoOutboxList(req: Request, res: Response) {
  if (!env.DEMO_MODE) throw AppError.notFound();
  const user = await User.findById(req.user!.id).select('isDemo').lean<any>();
  if (!user?.isDemo && req.user!.role !== 'admin') throw AppError.forbidden();
  return ok(res, { messages: demoOutbox.slice(-50).reverse() });
}

export { sosRoom };
