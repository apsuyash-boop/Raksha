import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import {
  Appointment, AuditLog, Campaign, Case, Comment, CommunityPost, Complaint, Donation, EmergencyContact, Evidence, LoanRequest,
  LocationEvent, LocationShare, Message, Notification, SchemeApplication, Session, SOSAlert, User,
} from '../models';
import { AppError, ok } from '../utils/http';
import { decryptString, encryptString } from '../utils/crypto';
import { storage } from '../services/storage';
import { audit } from '../services/audit';
import { language, password, pin } from '../validators/common';

export const updateProfileSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  age: z.coerce.number().int().min(13).max(120).optional(),
  state: z.string().trim().max(80).optional(),
  city: z.string().trim().max(80).optional(),
  language: language.optional(),
  avatarColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
});

export const privacySchema = z.object({
  shareLocationWithContacts: z.boolean().optional(),
  allowNearbyResponders: z.boolean().optional(),
  shareMedicalInfoInSOS: z.boolean().optional(),
  autoRecordEvidenceOnSOS: z.boolean().optional(),
  showInCommunityAs: z.enum(['name', 'first_name', 'anonymous']).optional(),
  notificationPrefs: z.object({ email: z.boolean().optional(), sms: z.boolean().optional(), whatsapp: z.boolean().optional(), inApp: z.boolean().optional() }).optional(),
});

export const pinSchema = z.object({ pin, currentPassword: z.string().min(1) });
export const medicalSchema = z.object({
  bloodGroup: z.string().max(5).optional(),
  allergies: z.string().max(500).optional(),
  conditions: z.string().max(500).optional(),
  medications: z.string().max(500).optional(),
  notes: z.string().max(1000).optional(),
});
export const changePasswordSchema = z.object({ currentPassword: z.string().min(1), newPassword: password });
export const deleteAccountSchema = z.object({ password: z.string().min(1), confirm: z.literal('DELETE') });

export async function updateProfile(req: Request, res: Response) {
  const user = await User.findByIdAndUpdate(req.user!.id, req.body, { new: true, runValidators: true });
  return ok(res, { user }, 'Profile updated');
}

export async function updatePrivacy(req: Request, res: Response) {
  const { notificationPrefs, ...privacy } = req.body;
  const set: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(privacy)) set[`privacy.${k}`] = v;
  for (const [k, v] of Object.entries(notificationPrefs || {})) set[`notificationPrefs.${k}`] = v;
  const user = await User.findByIdAndUpdate(req.user!.id, { $set: set }, { new: true });
  await audit(req, 'user.privacy_updated', { subjectUser: req.user!.id, meta: set });
  return ok(res, { user }, 'Privacy settings saved');
}

export async function setSafetyPin(req: Request, res: Response) {
  const user = await User.findById(req.user!.id).select('+passwordHash');
  if (!user || !(await bcrypt.compare(req.body.currentPassword, user.passwordHash))) throw AppError.badRequest('Password is incorrect');
  user.safetyPinHash = await bcrypt.hash(req.body.pin, 10);
  await user.save();
  await audit(req, 'user.safety_pin_set', { subjectUser: user._id });
  return ok(res, {}, 'Safety PIN saved');
}

export async function getMedical(req: Request, res: Response) {
  const u = await User.findById(req.user!.id).select('+medicalEncrypted').lean<any>();
  const medical = u?.medicalEncrypted ? JSON.parse(decryptString(u.medicalEncrypted) || '{}') : {};
  return ok(res, { medical, shareInSOS: !!u?.privacy?.shareMedicalInfoInSOS });
}

export async function setMedical(req: Request, res: Response) {
  await User.updateOne({ _id: req.user!.id }, { medicalEncrypted: encryptString(JSON.stringify(req.body)) });
  return ok(res, {}, 'Medical & safety information saved (encrypted)');
}

export async function changePassword(req: Request, res: Response) {
  const user = await User.findById(req.user!.id).select('+passwordHash');
  if (!user || !(await bcrypt.compare(req.body.currentPassword, user.passwordHash))) throw AppError.badRequest('Current password is incorrect');
  user.passwordHash = await bcrypt.hash(req.body.newPassword, 12);
  await user.save();
  await audit(req, 'user.password_changed', { subjectUser: user._id });
  return ok(res, {}, 'Password changed');
}

export async function block(req: Request, res: Response) {
  if (req.params.id === req.user!.id) throw AppError.badRequest('You cannot block yourself');
  await User.updateOne({ _id: req.user!.id }, { $addToSet: { blockedUsers: req.params.id } });
  return ok(res, {}, 'User blocked');
}
export async function unblock(req: Request, res: Response) {
  await User.updateOne({ _id: req.user!.id }, { $pull: { blockedUsers: req.params.id } });
  return ok(res, {}, 'User unblocked');
}

/** Who has accessed my sensitive data (evidence, cases, location). */
export async function accessHistory(req: Request, res: Response) {
  const logs = await AuditLog.find({ subjectUser: req.user!.id, actor: { $ne: req.user!.id } })
    .sort({ createdAt: -1 })
    .limit(200)
    .populate('actor', 'name role')
    .lean();
  return ok(res, { logs });
}

/** Data export (portability). Evidence files are listed with hashes; download them from the vault. */
export async function exportData(req: Request, res: Response) {
  const id = req.user!.id;
  const [user, contacts, sos, locations, evidence, cases, complaints, appts, apps, posts, comments, donations, campaigns, loans, notifications, messages] = await Promise.all([
    User.findById(id).lean(),
    EmergencyContact.find({ owner: id }).lean(),
    SOSAlert.find({ user: id }).lean(),
    LocationEvent.find({ user: id }).sort({ recordedAt: -1 }).limit(5000).lean(),
    Evidence.find({ owner: id, deletedAt: null }).select('-accessLog').lean(),
    Case.find({ user: id }).lean(),
    Complaint.find({ user: id }).lean(),
    Appointment.find({ user: id }).lean(),
    SchemeApplication.find({ user: id }).populate('scheme', 'name').lean(),
    CommunityPost.find({ author: id }).lean(),
    Comment.find({ author: id }).lean(),
    Donation.find({ donor: id }).lean(),
    Campaign.find({ beneficiary: id }).lean(),
    LoanRequest.find({ user: id }).lean(),
    Notification.find({ user: id }).limit(1000).lean(),
    Message.find({ $or: [{ from: id }, { to: id }] }).limit(5000).lean(),
  ]);
  const u: any = user;
  if (u) {
    delete u.passwordHash;
    delete u.safetyPinHash;
    delete u.medicalEncrypted;
    delete u.passwordReset;
  }
  const sosClean = sos.map((s: any) => ({ ...s, trackTokenHash: undefined }));
  await audit(req, 'user.data_export', { subjectUser: id });
  res.setHeader('Content-Disposition', `attachment; filename="raksha-data-export-${new Date().toISOString().slice(0, 10)}.json"`);
  return ok(res, { exportedAt: new Date(), user: u, contacts, sos: sosClean, locations, evidence, cases, complaints, appointments: appts, schemeApplications: apps, posts, comments, donations, campaigns, loans, notifications, messages });
}

/**
 * Account deletion: removes personal data and evidence files, anonymises community content,
 * keeps minimal financial records required by law (donations/transactions) without identity.
 */
export async function deleteAccount(req: Request, res: Response) {
  const user = await User.findById(req.user!.id).select('+passwordHash');
  if (!user || !(await bcrypt.compare(req.body.password, user.passwordHash))) throw AppError.badRequest('Password is incorrect');
  const id = user._id;
  const active = await SOSAlert.exists({ user: id, status: 'active' });
  if (active) throw AppError.conflict('Please resolve your active SOS before deleting your account');

  const evidence = await Evidence.find({ owner: id }).select('+storageKey').lean<any[]>();
  for (const e of evidence) await storage.remove(e.storageKey).catch(() => undefined);
  await Promise.all([
    Evidence.deleteMany({ owner: id }),
    EmergencyContact.deleteMany({ owner: id }),
    LocationEvent.deleteMany({ user: id }),
    LocationShare.deleteMany({ user: id }),
    Session.deleteMany({ user: id }),
    Notification.deleteMany({ user: id }),
    Message.deleteMany({ $or: [{ from: id }, { to: id }] }),
    SchemeApplication.deleteMany({ user: id }),
    LoanRequest.deleteMany({ user: id, status: { $in: ['submitted', 'offers_received', 'withdrawn', 'rejected'] } }),
    CommunityPost.updateMany({ author: id }, { anonymous: true, alias: 'Former member' }),
    Comment.updateMany({ author: id }, { anonymous: true, alias: 'Former member' }),
    Donation.updateMany({ donor: id }, { donorName: 'Deleted user', donorEmail: null, anonymous: true }),
    Case.updateMany({ user: id }, { status: 'closed', description: '[deleted by user]', notes: [], closedAt: new Date() }),
    Complaint.updateMany({ user: id }, { draftText: '[deleted by user]', 'incident.description': '[deleted by user]' }),
  ]);
  user.status = 'deleted';
  user.name = 'Deleted user';
  user.email = undefined;
  user.phone = undefined;
  user.medicalEncrypted = undefined;
  user.safetyPinHash = undefined;
  user.deletionRequestedAt = new Date();
  await user.save();
  await audit(req, 'user.account_deleted', { subjectUser: id });
  res.clearCookie('raksha_rt', { path: '/api/auth' });
  return ok(res, {}, 'Your account and personal data have been deleted');
}
