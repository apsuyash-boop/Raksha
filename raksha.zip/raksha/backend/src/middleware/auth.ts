import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { Role } from '../config/roles';
import { User } from '../models';
import { AppError } from '../utils/http';

interface AccessPayload {
  sub: string;
  role: Role;
  typ: 'access';
}

export function signAccessToken(user: { _id: any; role: Role }) {
  return jwt.sign({ sub: String(user._id), role: user.role, typ: 'access' }, env.JWT_SECRET, {
    expiresIn: env.JWT_ACCESS_TTL as any,
    issuer: 'raksha',
    audience: 'raksha-api',
  });
}

export function verifyAccessToken(token: string): AccessPayload {
  const p = jwt.verify(token, env.JWT_SECRET, { issuer: 'raksha', audience: 'raksha-api' }) as AccessPayload;
  if (p.typ !== 'access') throw new Error('wrong token type');
  return p;
}

async function loadUser(token: string) {
  const payload = verifyAccessToken(token);
  const user = await User.findById(payload.sub).select('name role status verified isDemo').lean<any>();
  if (!user || user.status !== 'active') throw AppError.unauthorized('Account is not active');
  return { id: String(user._id), role: user.role as Role, name: user.name, verified: !!user.verified, isDemo: !!user.isDemo };
}

function extractToken(req: Request) {
  const h = req.headers.authorization;
  if (h && h.startsWith('Bearer ')) return h.slice(7);
  return null;
}

export async function authenticate(req: Request, _res: Response, next: NextFunction) {
  try {
    const token = extractToken(req);
    if (!token) throw AppError.unauthorized();
    req.user = await loadUser(token);
    next();
  } catch (e: any) {
    next(e instanceof AppError ? e : AppError.unauthorized(e?.name === 'TokenExpiredError' ? 'Session expired' : 'Invalid token'));
  }
}

export async function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const token = extractToken(req);
  if (!token) return next();
  try {
    req.user = await loadUser(token);
  } catch {
    /* anonymous */
  }
  next();
}

export const authorize =
  (...roles: Role[]) =>
  (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(AppError.unauthorized());
    if (!roles.includes(req.user.role)) return next(AppError.forbidden());
    next();
  };

/** Professionals must be admin-verified before acting on sensitive workflows. */
export const requireVerified = (req: Request, _res: Response, next: NextFunction) => {
  if (!req.user) return next(AppError.unauthorized());
  if (req.user.role === 'admin' || req.user.verified) return next();
  next(AppError.forbidden('Your account is awaiting verification by Raksha administrators'));
};

export { verifyAccessToken as _verifyAccessToken };
