import { NextFunction, Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import { env } from '../config/env';
import { AppError } from '../utils/http';

const handler = (_req: Request, res: Response) =>
  res.status(429).json({ success: false, message: 'Too many requests. Please wait a moment and try again.', error: { code: 'RATE_LIMITED' } });

const skip = () => env.isTest;

export const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 1000, standardHeaders: 'draft-7', legacyHeaders: false, handler, skip });
export const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false, handler, skip });
export const otpLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false, handler, skip });
/** SOS is never blocked for long; a generous limit only stops automated abuse. */
export const sosLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false, handler, skip });
export const uploadLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 200, standardHeaders: 'draft-7', legacyHeaders: false, handler, skip });

/**
 * CSRF protection for cookie-authenticated endpoints (refresh/logout).
 * Bearer-token endpoints are not CSRF-able. For cookie endpoints we require
 * the Origin (or Referer) to be in the CORS allow-list plus a custom header,
 * which browsers will not send cross-site without a CORS preflight.
 */
export function csrfGuard(req: Request, _res: Response, next: NextFunction) {
  if (env.isTest) return next();
  const origin = req.headers.origin || (req.headers.referer ? new URL(req.headers.referer).origin : undefined);
  if (!origin || !env.CORS_ORIGINS.includes(origin)) return next(AppError.forbidden('Origin not allowed'));
  if (req.headers['x-requested-with'] !== 'raksha-web') return next(AppError.forbidden('Missing CSRF header'));
  next();
}
