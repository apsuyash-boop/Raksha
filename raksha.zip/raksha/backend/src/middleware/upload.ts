import multer from 'multer';
import { env } from '../config/env';

/**
 * Files are held in memory only long enough to hash, validate magic bytes, scan and encrypt them.
 * They are never written to disk unencrypted.
 */
export const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.MAX_UPLOAD_MB * 1024 * 1024, files: 10, fields: 30 },
});
