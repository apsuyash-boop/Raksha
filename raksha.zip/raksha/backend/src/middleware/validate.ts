import { NextFunction, Request, Response } from 'express';
import { ZodSchema } from 'zod';

/** Validates and replaces req.body / req.query with the parsed (whitelisted) value. */
export const validate =
  (schema: ZodSchema, source: 'body' | 'query' | 'params' = 'body') =>
  (req: Request, _res: Response, next: NextFunction) => {
    const parsed = schema.safeParse((req as any)[source]);
    if (!parsed.success) return next(parsed.error);
    if (source === 'query') {
      // req.query is a getter in some Express versions; mutate in place.
      const q = req.query as any;
      for (const k of Object.keys(q)) delete q[k];
      Object.assign(q, parsed.data);
    } else {
      (req as any)[source] = parsed.data;
    }
    next();
  };
