import { Schema, model } from 'mongoose';

/* ----------------------------- Verification ---------------------------- */
const VerificationSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    role: { type: String, enum: ['lawyer', 'ngo', 'counsellor', 'responder', 'police', 'lender', 'campaign_kyc'], required: true },
    documents: [{ evidence: { type: Schema.Types.ObjectId, ref: 'Evidence' }, label: String }],
    details: Schema.Types.Mixed, // e.g. bar council number, NGO Darpan ID, RBI registration
    status: { type: String, enum: ['pending', 'approved', 'rejected', 'more_info'], default: 'pending', index: true },
    reviewer: { type: Schema.Types.ObjectId, ref: 'User' },
    reviewNote: String,
    reviewedAt: Date,
    campaign: { type: Schema.Types.ObjectId, ref: 'Campaign' },
  },
  { timestamps: true },
);

/* ------------------------------- AuditLog ------------------------------ */
const AuditLogSchema = new Schema(
  {
    actor: { type: Schema.Types.ObjectId, ref: 'User', index: true },
    actorRole: String,
    action: { type: String, required: true, index: true },
    targetType: String,
    targetId: { type: Schema.Types.ObjectId, index: true },
    /** Owner of the data being touched, so users can see who accessed their information. */
    subjectUser: { type: Schema.Types.ObjectId, ref: 'User', index: true },
    ip: String,
    userAgent: String,
    meta: Schema.Types.Mixed,
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);
AuditLogSchema.index({ createdAt: -1 });

/* ------------------------------- Setting ------------------------------- */
const SettingSchema = new Schema(
  {
    key: { type: String, required: true, unique: true },
    value: Schema.Types.Mixed,
    description: String,
    updatedBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true },
);

/* ----------------------------- RightsArticle --------------------------- */
const RightsArticleSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true },
    category: { type: String, enum: ['domestic_violence', 'dowry', 'workplace_harassment', 'divorce', 'maintenance', 'child_custody', 'womens_protection', 'cyber_safety', 'police_procedure'], required: true, index: true },
    /** translations.<lang> = { title, summary, body (markdown-lite), keyPoints[] }. Add any language code. */
    translations: { type: Schema.Types.Mixed, required: true },
    laws: [String],
    helplines: [{ name: String, number: String }],
    readMinutes: { type: Number, default: 4 },
    sources: [{ title: String, url: String }],
    published: { type: Boolean, default: true },
    updatedBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true },
);

export const Verification = model<any>('Verification', VerificationSchema);
export const AuditLog = model<any>('AuditLog', AuditLogSchema);
export const Setting = model<any>('Setting', SettingSchema);
export const RightsArticle = model<any>('RightsArticle', RightsArticleSchema);
