import { Schema, model } from 'mongoose';

const AppointmentSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    counsellor: { type: Schema.Types.ObjectId, ref: 'Counsellor', required: true, index: true },
    counsellorUser: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    mode: { type: String, enum: ['chat', 'call', 'video'], default: 'chat' },
    scheduledAt: { type: Date, required: true, index: true },
    durationMin: { type: Number, default: 45 },
    status: { type: String, enum: ['requested', 'confirmed', 'completed', 'cancelled', 'declined'], default: 'requested', index: true },
    topic: { type: String, maxlength: 500 },
    price: { type: Number, default: 0 },
    free: { type: Boolean, default: true },
    meetingUrl: String,
    reminderSent: { type: Boolean, default: false },
    counsellorNotes: { type: String, select: false, maxlength: 5000 },
    cancelledBy: { type: Schema.Types.ObjectId, ref: 'User' },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);

export const Appointment = model<any>('Appointment', AppointmentSchema);
