import { Schema, model } from 'mongoose';
import { CASE_TYPES } from '../config/roles';

const CaseSchema = new Schema(
  {
    caseNumber: { type: String, required: true, unique: true }, // RK-2026-000123
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: { type: String, enum: CASE_TYPES, required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 200 },
    description: { type: String, maxlength: 5000 },
    status: {
      type: String,
      enum: ['open', 'seeking_help', 'in_progress', 'complaint_filed', 'in_court', 'resolved', 'closed'],
      default: 'open',
      index: true,
    },
    urgency: { type: String, enum: ['low', 'medium', 'high', 'emergency'], default: 'medium' },
    lawyer: { type: Schema.Types.ObjectId, ref: 'Lawyer', index: true },
    ngo: { type: Schema.Types.ObjectId, ref: 'NGO', index: true },
    counsellor: { type: Schema.Types.ObjectId, ref: 'Counsellor' },
    /** Assistance requests sent to professionals, pending their acceptance. */
    requests: [
      {
        providerType: { type: String, enum: ['lawyer', 'ngo'] },
        provider: { type: Schema.Types.ObjectId, refPath: 'requests.providerModel' },
        providerModel: { type: String, enum: ['Lawyer', 'NGO'] },
        providerUser: { type: Schema.Types.ObjectId, ref: 'User', index: true },
        service: String,
        message: String,
        status: { type: String, enum: ['pending', 'accepted', 'rejected', 'withdrawn'], default: 'pending' },
        at: { type: Date, default: Date.now },
        respondedAt: Date,
      },
    ],
    evidence: [{ type: Schema.Types.ObjectId, ref: 'Evidence' }],
    complaints: [{ type: Schema.Types.ObjectId, ref: 'Complaint' }],
    sos: [{ type: Schema.Types.ObjectId, ref: 'SOSAlert' }],
    documents: [
      { title: String, evidence: { type: Schema.Types.ObjectId, ref: 'Evidence' }, preparedBy: { type: Schema.Types.ObjectId, ref: 'User' }, body: String, at: { type: Date, default: Date.now } },
    ],
    hearings: [{ date: Date, court: String, purpose: String, outcome: String, reminderSent: { type: Boolean, default: false } }],
    importantDates: [{ date: Date, label: String }],
    notes: [
      {
        author: { type: Schema.Types.ObjectId, ref: 'User' },
        text: { type: String, maxlength: 5000 },
        visibility: { type: String, enum: ['shared', 'professional_only'], default: 'shared' },
        at: { type: Date, default: Date.now },
      },
    ],
    timeline: [{ label: String, detail: String, by: { type: Schema.Types.ObjectId, ref: 'User' }, at: { type: Date, default: Date.now } }],
    consent: {
      shareEvidenceWithAssigned: { type: Boolean, default: true },
      shareContactWithAssigned: { type: Boolean, default: true },
    },
    location: { city: String, state: String },
    language: String,
    budget: { type: String, enum: ['free', 'low', 'standard', 'any'], default: 'any' },
    isDemo: { type: Boolean, default: false },
    closedAt: Date,
  },
  { timestamps: true },
);
CaseSchema.index({ 'requests.providerUser': 1, 'requests.status': 1 });

export const Case = model<any>('Case', CaseSchema);
