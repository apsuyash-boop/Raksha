import { Schema, model } from 'mongoose';

const REACTIONS = ['support', 'heart', 'strength'] as const;

/* ---------------------------- CommunityPost --------------------------- */
const CommunityPostSchema = new Schema(
  {
    /** Stored only for moderation/abuse handling. Never serialized for anonymous posts. */
    author: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    anonymous: { type: Boolean, default: false },
    alias: String, // e.g. "Anonymous Marigold"
    type: { type: String, enum: ['article', 'story', 'discussion', 'question'], default: 'discussion', index: true },
    title: { type: String, required: true, maxlength: 200 },
    body: { type: String, required: true, maxlength: 20000 },
    tags: [String],
    language: { type: String, default: 'en' },
    status: { type: String, enum: ['published', 'pending_review', 'removed'], default: 'published', index: true },
    moderation: {
      autoFlags: [String],
      reviewedBy: { type: Schema.Types.ObjectId, ref: 'User' },
      reviewedAt: Date,
      reason: String,
    },
    reactions: [{ user: { type: Schema.Types.ObjectId, ref: 'User' }, type: { type: String, enum: REACTIONS } }],
    reactionCounts: { support: { type: Number, default: 0 }, heart: { type: Number, default: 0 }, strength: { type: Number, default: 0 } },
    commentsCount: { type: Number, default: 0 },
    reportsCount: { type: Number, default: 0 },
    featured: { type: Boolean, default: false },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);
CommunityPostSchema.index({ title: 'text', body: 'text', tags: 'text' }, { language_override: 'textIndexLanguage', default_language: 'none' });
CommunityPostSchema.index({ status: 1, createdAt: -1 });

/* ------------------------------- Comment ------------------------------ */
const CommentSchema = new Schema(
  {
    post: { type: Schema.Types.ObjectId, ref: 'CommunityPost', required: true, index: true },
    author: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    anonymous: { type: Boolean, default: false },
    alias: String,
    body: { type: String, required: true, maxlength: 4000 },
    status: { type: String, enum: ['published', 'pending_review', 'removed'], default: 'published' },
    autoFlags: [String],
  },
  { timestamps: true },
);

/* -------------------------------- Report ------------------------------- */
const ReportSchema = new Schema(
  {
    reporter: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    targetType: { type: String, enum: ['post', 'comment', 'user', 'message', 'campaign', 'professional'], required: true },
    targetId: { type: Schema.Types.ObjectId, required: true, index: true },
    reason: { type: String, enum: ['harassment', 'hate', 'spam', 'fake_profile', 'privacy', 'self_harm', 'misinformation', 'fraud', 'other'], required: true },
    details: { type: String, maxlength: 2000 },
    status: { type: String, enum: ['open', 'actioned', 'dismissed'], default: 'open', index: true },
    resolvedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    resolution: String,
  },
  { timestamps: true },
);

export const CommunityPost = model<any>('CommunityPost', CommunityPostSchema);
export const Comment = model<any>('Comment', CommentSchema);
export const Report = model<any>('Report', ReportSchema);
