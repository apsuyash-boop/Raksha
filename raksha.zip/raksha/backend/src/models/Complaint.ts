import { Schema, model } from 'mongoose';
import { COMPLAINT_STATUSES } from '../config/roles';

const ComplaintSchema = new Schema(
  {
    complaintNumber: { type: String, required: true, unique: true },
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    case: { type: Schema.Types.ObjectId, ref: 'Case', index: true },
    incident: {
      type: { type: String },
      date: Date,
      time: String,
      place: String,
      city: String,
      state: String,
      description: { type: String, maxlength: 10000 },
      accused: [{ name: String, relation: String, address: String }],
      witnesses: [{ name: String, contact: String }],
      injuries: String,
      previousComplaints: String,
    },
    policeStation: String,
    draftText: { type: String, maxlength: 30000 },
    evidence: [{ type: Schema.Types.ObjectId, ref: 'Evidence' }],
    status: { type: String, enum: COMPLAINT_STATUSES, default: 'draft', index: true },
    submission: {
      method: { type: String, enum: ['none', 'printed_in_person', 'online_portal_self', 'integration', 'via_ngo'], default: 'none' },
      /** True ONLY if an external integration or a verified police official confirmed receipt/registration. */
      confirmedByAuthority: { type: Boolean, default: false },
      integrationRef: String,
      submittedAt: Date,
    },
    firNumber: String,
    firSource: { type: String, enum: ['self_reported', 'police_official', 'integration'] },
    sharedWithPolice: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    statusHistory: [
      {
        status: String,
        note: String,
        by: { type: Schema.Types.ObjectId, ref: 'User' },
        source: { type: String, enum: ['user', 'lawyer', 'ngo', 'police_official', 'integration', 'system'], default: 'user' },
        at: { type: Date, default: Date.now },
      },
    ],
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);

export const Complaint = model<any>('Complaint', ComplaintSchema);
