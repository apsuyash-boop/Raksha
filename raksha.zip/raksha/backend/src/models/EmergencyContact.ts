import { Schema, model } from 'mongoose';

const EmergencyContactSchema = new Schema(
  {
    owner: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: { type: String, required: true, trim: true, maxlength: 120 },
    relation: { type: String, trim: true, maxlength: 60 },
    phone: { type: String, trim: true, maxlength: 20 },
    email: { type: String, trim: true, lowercase: true, maxlength: 200 },
    channels: {
      sms: { type: Boolean, default: true },
      whatsapp: { type: Boolean, default: false },
      email: { type: Boolean, default: true },
      app: { type: Boolean, default: true },
    },
    /** If the contact has a Raksha account, they receive in-app alerts and can follow live location. */
    linkedUser: { type: Schema.Types.ObjectId, ref: 'User', index: true },
    priority: { type: Number, default: 1 },
    canViewLiveLocation: { type: Boolean, default: true },
  },
  { timestamps: true },
);

export const EmergencyContact = model<any>('EmergencyContact', EmergencyContactSchema);
