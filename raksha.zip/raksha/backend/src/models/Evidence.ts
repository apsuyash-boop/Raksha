import { Schema, model } from 'mongoose';

const EvidenceSchema = new Schema(
  {
    evidenceId: { type: String, required: true, unique: true }, // human-readable e.g. EV-2026-8F3K2Q
    owner: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, trim: true, maxlength: 200 },
    description: { type: String, maxlength: 2000 },
    category: {
      type: String,
      enum: ['photo', 'video', 'audio', 'document', 'medical_report', 'screenshot', 'complaint_document', 'sos_recording', 'other'],
      default: 'other',
    },
    kind: { type: String, enum: ['image', 'video', 'audio', 'document'], required: true },
    mimeType: String,
    originalName: String,
    size: Number,
    /** SHA-256 of the plaintext file, computed server-side at upload time. */
    sha256: { type: String, required: true, index: true },
    storageKey: { type: String, required: true, select: false },
    storageDriver: { type: String, select: false },
    encrypted: { type: Boolean, default: true },
    capturedAt: Date, // device timestamp (user supplied / from recorder)
    uploadedAt: { type: Date, default: Date.now },
    gps: { lat: Number, lng: Number, accuracy: Number },
    sos: { type: Schema.Types.ObjectId, ref: 'SOSAlert', index: true },
    cases: [{ type: Schema.Types.ObjectId, ref: 'Case', index: true }],
    verificationStatus: { type: String, enum: ['unverified', 'hash_verified', 'verified_by_professional', 'disputed'], default: 'hash_verified' },
    scanStatus: { type: String, enum: ['not_scanned', 'pending', 'clean', 'infected', 'error'], default: 'not_scanned' },
    /** Explicit grants by the owner, in addition to case-based access. */
    sharedWith: [{ user: { type: Schema.Types.ObjectId, ref: 'User' }, grantedAt: { type: Date, default: Date.now } }],
    accessLog: [
      {
        user: { type: Schema.Types.ObjectId, ref: 'User' },
        role: String,
        action: { type: String, enum: ['view_metadata', 'download', 'package', 'verify', 'share', 'revoke', 'upload', 'delete'] },
        reason: String,
        ip: String,
        at: { type: Date, default: Date.now },
      },
    ],
    deletedAt: Date,
  },
  { timestamps: true },
);

export const Evidence = model<any>('Evidence', EvidenceSchema);
