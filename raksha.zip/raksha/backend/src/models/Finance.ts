import { Schema, model } from 'mongoose';

/* ------------------------------ Campaign ------------------------------ */
const CampaignSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true },
    beneficiary: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    case: { type: Schema.Types.ObjectId, ref: 'Case' },
    title: { type: String, required: true, maxlength: 160 },
    story: { type: String, required: true, maxlength: 6000 },
    category: { type: String, enum: ['legal_fees', 'rent', 'shelter', 'medical', 'recovery', 'education', 'livelihood'], required: true },
    goalAmount: { type: Number, required: true, min: 500 },
    raisedAmount: { type: Number, default: 0 },
    disbursedAmount: { type: Number, default: 0 },
    donorsCount: { type: Number, default: 0 },
    displayName: { type: String, default: 'A Raksha beneficiary' }, // public name (pseudonym allowed)
    city: String,
    state: String,
    status: { type: String, enum: ['pending_verification', 'active', 'paused', 'completed', 'rejected'], default: 'pending_verification', index: true },
    kycVerified: { type: Boolean, default: false },
    verifiedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    payee: { type: { type: String, enum: ['lawyer', 'landlord', 'hospital', 'ngo', 'beneficiary'] }, name: String, reference: String },
    utilization: [{ amount: Number, purpose: String, paidTo: String, at: { type: Date, default: Date.now }, transaction: { type: Schema.Types.ObjectId, ref: 'Transaction' } }],
    endsAt: Date,
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);

/* ------------------------------ Donation ------------------------------ */
const DonationSchema = new Schema(
  {
    donor: { type: Schema.Types.ObjectId, ref: 'User', index: true },
    donorName: String,
    donorEmail: String,
    anonymous: { type: Boolean, default: false },
    campaign: { type: Schema.Types.ObjectId, ref: 'Campaign', index: true },
    generalFund: { type: Boolean, default: false },
    amount: { type: Number, required: true, min: 1 }, // INR
    platformFee: { type: Number, default: 0 },
    status: { type: String, enum: ['created', 'paid', 'failed', 'refunded'], default: 'created', index: true },
    transaction: { type: Schema.Types.ObjectId, ref: 'Transaction' },
    message: { type: String, maxlength: 300 },
    receiptNumber: String,
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);

/* ----------------------------- Transaction ---------------------------- */
const TransactionSchema = new Schema(
  {
    type: { type: String, enum: ['donation', 'disbursement', 'platform_fee', 'refund', 'loan_disbursement', 'loan_repayment'], required: true, index: true },
    provider: { type: String, enum: ['razorpay', 'mock', 'manual'], required: true },
    orderId: { type: String, index: true },
    paymentId: { type: String, index: true },
    signatureVerified: { type: Boolean, default: false },
    amount: { type: Number, required: true }, // INR
    currency: { type: String, default: 'INR' },
    status: { type: String, enum: ['created', 'captured', 'failed', 'refunded', 'completed'], default: 'created', index: true },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    campaign: { type: Schema.Types.ObjectId, ref: 'Campaign' },
    donation: { type: Schema.Types.ObjectId, ref: 'Donation' },
    loan: { type: Schema.Types.ObjectId, ref: 'LoanRequest' },
    paidTo: String,
    receiptNumber: String,
    raw: { type: Schema.Types.Mixed, select: false },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);

/* ----------------------------- LoanRequest ---------------------------- */
const LoanRequestSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    amount: { type: Number, required: true, min: 1000, max: 500000 },
    purpose: { type: String, enum: ['rent_deposit', 'legal_fees', 'small_business', 'education', 'medical', 'relocation', 'other'], required: true },
    description: { type: String, maxlength: 2000 },
    tenureMonths: { type: Number, min: 1, max: 60 },
    monthlyIncome: Number,
    city: String,
    state: String,
    status: { type: String, enum: ['submitted', 'offers_received', 'offer_accepted', 'disbursed', 'repaying', 'closed', 'withdrawn', 'rejected'], default: 'submitted', index: true },
    offers: [
      {
        lender: { type: Schema.Types.ObjectId, ref: 'User' },
        lenderName: String,
        regulatoryId: String, // e.g. RBI NBFC registration number of the partner
        annualInterestRate: { type: Number, min: 0, max: 36 },
        processingFee: { type: Number, default: 0 },
        tenureMonths: Number,
        terms: String,
        status: { type: String, enum: ['offered', 'accepted', 'declined', 'withdrawn'], default: 'offered' },
        at: { type: Date, default: Date.now },
      },
    ],
    consentToShareWithLenders: { type: Boolean, default: false },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);

export const Campaign = model<any>('Campaign', CampaignSchema);
export const Donation = model<any>('Donation', DonationSchema);
export const Transaction = model<any>('Transaction', TransactionSchema);
export const LoanRequest = model<any>('LoanRequest', LoanRequestSchema);
