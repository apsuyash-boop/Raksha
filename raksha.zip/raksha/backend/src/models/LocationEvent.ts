import { Schema, model } from 'mongoose';

const LocationEventSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    sos: { type: Schema.Types.ObjectId, ref: 'SOSAlert', index: true },
    share: { type: Schema.Types.ObjectId, ref: 'LocationShare', index: true },
    location: {
      type: { type: String, enum: ['Point'], default: 'Point' },
      coordinates: { type: [Number], required: true },
    },
    accuracy: Number,
    speed: Number,
    heading: Number,
    battery: Number,
    source: { type: String, enum: ['gps', 'network', 'manual'], default: 'gps' },
    recordedAt: { type: Date, default: Date.now, index: true },
  },
  { timestamps: true },
);
LocationEventSchema.index({ location: '2dsphere' });
LocationEventSchema.index({ user: 1, recordedAt: -1 });

export const LocationEvent = model<any>('LocationEvent', LocationEventSchema);
