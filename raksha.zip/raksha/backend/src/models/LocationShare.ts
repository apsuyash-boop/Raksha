import { Schema, model } from 'mongoose';

/** A time-boxed live location sharing session (journey tracking, "watch me walk home"). */
const LocationShareSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    active: { type: Boolean, default: true, index: true },
    expiresAt: { type: Date, required: true },
    sharedWith: [{ type: Schema.Types.ObjectId, ref: 'EmergencyContact' }],
    trackTokenHash: { type: String, select: false, index: true },
    reason: { type: String, enum: ['journey', 'sos', 'manual'], default: 'manual' },
    sos: { type: Schema.Types.ObjectId, ref: 'SOSAlert' },
    stoppedAt: Date,
  },
  { timestamps: true },
);

export const LocationShare = model<any>('LocationShare', LocationShareSchema);
