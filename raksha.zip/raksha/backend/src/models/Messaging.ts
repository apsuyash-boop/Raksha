import { Schema, model } from 'mongoose';

/* ------------------------------- Message ------------------------------ */
const MessageSchema = new Schema(
  {
    conversationKey: { type: String, required: true, index: true }, // sorted "<userA>:<userB>"
    from: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    to: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    case: { type: Schema.Types.ObjectId, ref: 'Case' },
    text: { type: String, maxlength: 4000 },
    attachments: [{ evidence: { type: Schema.Types.ObjectId, ref: 'Evidence' }, name: String, kind: String }],
    readAt: Date,
    deletedFor: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: true },
);
MessageSchema.index({ conversationKey: 1, createdAt: -1 });

/* ----------------------------- Notification ---------------------------- */
const NotificationSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: {
      type: String,
      enum: ['sos', 'sos_update', 'emergency_contact', 'case_request', 'case_accepted', 'case_update', 'message', 'appointment', 'appointment_reminder', 'complaint_update', 'hearing_reminder', 'scheme_update', 'donation', 'campaign', 'loan', 'verification', 'moderation', 'system', 'location_share'],
      required: true,
    },
    title: { type: String, required: true },
    body: String,
    link: String,
    priority: { type: String, enum: ['normal', 'high', 'critical'], default: 'normal' },
    read: { type: Boolean, default: false, index: true },
    deliveries: [{ channel: String, status: String, at: { type: Date, default: Date.now } }],
    meta: Schema.Types.Mixed,
  },
  { timestamps: true },
);
NotificationSchema.index({ user: 1, createdAt: -1 });

export const Message = model<any>('Message', MessageSchema);
export const Notification = model<any>('Notification', NotificationSchema);
