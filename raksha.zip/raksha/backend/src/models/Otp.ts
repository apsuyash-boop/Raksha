import { Schema, model } from 'mongoose';

const OtpSchema = new Schema(
  {
    target: { type: String, required: true, index: true }, // email or phone
    purpose: { type: String, enum: ['verify_email', 'verify_phone', 'login'], required: true },
    codeHash: { type: String, required: true },
    attempts: { type: Number, default: 0 },
    expiresAt: { type: Date, required: true },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true },
);
OtpSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export const Otp = model<any>('Otp', OtpSchema);
