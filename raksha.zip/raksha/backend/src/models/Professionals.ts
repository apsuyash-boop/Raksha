import { Schema, model } from 'mongoose';
import { CASE_TYPES } from '../config/roles';

const geo = {
  type: { type: String, enum: ['Point'], default: 'Point' },
  coordinates: { type: [Number], default: [0, 0] },
};

const ReviewSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    rating: { type: Number, min: 1, max: 5 },
    text: { type: String, maxlength: 1000 },
    case: { type: Schema.Types.ObjectId, ref: 'Case' },
    at: { type: Date, default: Date.now },
  },
  { _id: false },
);

/* ------------------------------- Lawyer ------------------------------- */
const LawyerSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    displayName: { type: String, required: true },
    barCouncilId: { type: String, select: false },
    enrollmentYear: Number,
    bio: { type: String, maxlength: 2000 },
    specializations: [{ type: String, enum: CASE_TYPES }],
    services: [{ type: String }], // consultation, drafting, court_representation, mediation
    languages: [{ type: String }],
    city: String,
    state: String,
    courts: [String],
    location: geo,
    availability: { type: String, enum: ['available', 'limited', 'unavailable'], default: 'available' },
    feeType: { type: String, enum: ['pro_bono', 'low_fee', 'standard'], default: 'standard' },
    consultationFee: { type: Number, default: 0 },
    proBono: { type: Boolean, default: false },
    freeFirstConsultation: { type: Boolean, default: true },
    verified: { type: Boolean, default: false, index: true },
    verifiedAt: Date,
    reviews: [ReviewSchema],
    rating: { type: Number, default: 0 },
    activeCases: { type: Number, default: 0 },
    maxActiveCases: { type: Number, default: 20 },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);
LawyerSchema.index({ location: '2dsphere' });
LawyerSchema.index({ verified: 1, specializations: 1, state: 1, city: 1, languages: 1 });

/* --------------------------------- NGO -------------------------------- */
const NGOSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    name: { type: String, required: true },
    registrationNumber: { type: String, select: false },
    darpanId: String,
    about: { type: String, maxlength: 3000 },
    services: [{ type: String }], // shelter, rescue, legal_aid, counselling, rehabilitation, skills_training, medical
    focusAreas: [{ type: String, enum: CASE_TYPES }],
    languages: [String],
    city: String,
    state: String,
    serviceAreas: [String],
    location: geo,
    shelterCapacity: { type: Number, default: 0 },
    shelterAvailable: { type: Number, default: 0 },
    helpline: String,
    website: String,
    availability: { type: String, enum: ['available', 'limited', 'unavailable'], default: 'available' },
    is24x7: { type: Boolean, default: false },
    isOneStopCentre: { type: Boolean, default: false },
    verified: { type: Boolean, default: false, index: true },
    verifiedAt: Date,
    reviews: [ReviewSchema],
    rating: { type: Number, default: 0 },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);
NGOSchema.index({ location: '2dsphere' });
NGOSchema.index({ verified: 1, focusAreas: 1, state: 1, city: 1 });

/* ------------------------------ Counsellor ----------------------------- */
const CounsellorSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    displayName: { type: String, required: true },
    qualification: String,
    licenseNumber: { type: String, select: false },
    yearsExperience: Number,
    bio: { type: String, maxlength: 2000 },
    specializations: [String], // trauma, domestic_violence, anxiety, career, financial, legal_advice, family
    category: { type: String, enum: ['emotional', 'legal', 'career_money'], default: 'emotional' },
    languages: [String],
    modes: [{ type: String, enum: ['chat', 'call', 'video'] }],
    price: { type: Number, default: 0 },
    freeSessions: { type: Boolean, default: false },
    weeklySlots: [{ day: Number, from: String, to: String }],
    meetingUrl: String, // counsellor's own secure video room link (e.g. self-hosted Jitsi)
    city: String,
    state: String,
    verified: { type: Boolean, default: false, index: true },
    verifiedAt: Date,
    reviews: [ReviewSchema],
    rating: { type: Number, default: 0 },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true },
);
CounsellorSchema.index({ verified: 1, category: 1, languages: 1 });

export const Lawyer = model<any>('Lawyer', LawyerSchema);
export const NGO = model<any>('NGO', NGOSchema);
export const Counsellor = model<any>('Counsellor', CounsellorSchema);
