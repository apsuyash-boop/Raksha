import { Schema, model } from 'mongoose';

const ResponderSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    verified: { type: Boolean, default: false, index: true },
    active: { type: Boolean, default: false, index: true }, // responder mode on/off
    availability: { type: String, enum: ['always', 'scheduled', 'off'], default: 'off' },
    schedule: [{ day: Number, from: String, to: String }],
    skills: [{ type: String }], // first_aid, self_defence, legal_volunteer, counselling...
    languages: [{ type: String }],
    city: String,
    state: String,
    location: {
      type: { type: String, enum: ['Point'], default: 'Point' },
      coordinates: { type: [Number], default: [0, 0] },
    },
    locationUpdatedAt: Date,
    stats: {
      requestsReceived: { type: Number, default: 0 },
      accepted: { type: Number, default: 0 },
      completed: { type: Number, default: 0 },
    },
  },
  { timestamps: true },
);
ResponderSchema.index({ location: '2dsphere' });

export const Responder = model<any>('Responder', ResponderSchema);
