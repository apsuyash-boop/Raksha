import { Schema, model } from 'mongoose';

const DeliverySchema = new Schema(
  {
    contact: { type: Schema.Types.ObjectId, ref: 'EmergencyContact' },
    name: String,
    channel: { type: String, enum: ['sms', 'whatsapp', 'email', 'app'] },
    /** sent = provider accepted it; simulated = demo/mock provider; not_configured; failed */
    status: { type: String, enum: ['sent', 'simulated', 'not_configured', 'failed', 'skipped'] },
    providerRef: String,
    error: String,
    at: { type: Date, default: Date.now },
  },
  { _id: false },
);

const SOSAlertSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    status: { type: String, enum: ['active', 'cancelled', 'resolved'], default: 'active', index: true },
    isDemo: { type: Boolean, default: false, index: true },
    trigger: { type: String, enum: ['button', 'shake', 'voice', 'widget', 'api'], default: 'button' },
    message: { type: String, maxlength: 500 },
    location: {
      type: { type: String, enum: ['Point'], default: 'Point' },
      coordinates: { type: [Number] },
    },
    accuracy: Number,
    /** Opaque token used in the tracking link sent to contacts without Raksha accounts (hash only). */
    trackTokenHash: { type: String, select: false, index: true },
    contactDeliveries: [DeliverySchema],
    responders: [
      {
        responder: { type: Schema.Types.ObjectId, ref: 'Responder' },
        user: { type: Schema.Types.ObjectId, ref: 'User' },
        distanceKm: Number,
        status: { type: String, enum: ['notified', 'accepted', 'declined', 'arrived', 'completed'], default: 'notified' },
        notifiedAt: { type: Date, default: Date.now },
        respondedAt: Date,
        report: String,
      },
    ],
    emergencyService: {
      status: { type: String, enum: ['not_configured', 'simulated', 'pending', 'confirmed', 'failed'], default: 'not_configured' },
      reference: String,
      message: String,
      at: Date,
    },
    evidence: [{ type: Schema.Types.ObjectId, ref: 'Evidence' }],
    timeline: [
      {
        step: {
          type: String,
          enum: ['activated', 'contacts_alerted', 'responders_notified', 'recording_started', 'emergency_service', 'location_update', 'responder_accepted', 'cancelled', 'resolved', 'note'],
        },
        label: String,
        at: { type: Date, default: Date.now },
        meta: Schema.Types.Mixed,
      },
    ],
    contactsAlertedAt: Date,
    cancelledAt: Date,
    cancelReason: String,
    resolvedAt: Date,
    resolutionNote: String,
    case: { type: Schema.Types.ObjectId, ref: 'Case' },
  },
  { timestamps: true },
);
SOSAlertSchema.index({ location: '2dsphere' });
SOSAlertSchema.index({ status: 1, createdAt: -1 });

export const SOSAlert = model<any>('SOSAlert', SOSAlertSchema);
