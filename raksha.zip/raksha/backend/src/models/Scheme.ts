import { Schema, model } from 'mongoose';

/**
 * Government scheme. `criteria` holds ONLY machine-checkable rules that come from the official source.
 * Any criterion left undefined is treated as "unknown — check the official source", never as "eligible".
 */
const SchemeSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    nameHi: String,
    level: { type: String, enum: ['central', 'state'], default: 'central' },
    states: [String], // empty for central schemes (all India)
    ministry: String,
    category: { type: String, enum: ['financial_aid', 'maternity', 'savings', 'entrepreneurship', 'support_services', 'education', 'housing', 'health', 'employment', 'other'] },
    description: String,
    descriptionHi: String,
    eligibility: [String], // human-readable, copied from the official source
    benefits: [String],
    documents: [String],
    applicationMethod: String,
    officialUrl: String,
    helpline: String,
    criteria: {
      gender: { type: String, enum: ['female', 'any'] },
      minAge: Number,
      maxAge: Number,
      maxAnnualFamilyIncome: Number,
      maritalStatus: [String], // married, widowed, divorced, separated, single
      requiresPregnantOrLactating: Boolean,
      requiresGirlChildUnder10: Boolean,
      requiresEntrepreneur: Boolean,
      excludesGovtEmployees: Boolean,
      excludesIncomeTaxPayers: Boolean,
    },
    tags: [String],
    active: { type: Boolean, default: true, index: true },
    lastVerifiedAt: Date,
    sourceNote: String,
    updatedBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true },
);
SchemeSchema.index({ name: 'text', description: 'text', tags: 'text' }, { language_override: 'textIndexLanguage', default_language: 'none' });
SchemeSchema.index({ active: 1, level: 1, states: 1, category: 1 });

export const Scheme = model<any>('Scheme', SchemeSchema);

const SchemeApplicationSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    scheme: { type: Schema.Types.ObjectId, ref: 'Scheme', required: true },
    status: {
      type: String,
      enum: ['interested', 'documents_ready', 'applied', 'under_review', 'approved', 'rejected', 'benefit_received'],
      default: 'interested',
    },
    applicationRef: String,
    checklist: [{ item: String, done: { type: Boolean, default: false } }],
    notes: String,
    helpedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    history: [{ status: String, at: { type: Date, default: Date.now }, note: String }],
  },
  { timestamps: true },
);
SchemeApplicationSchema.index({ user: 1, scheme: 1 }, { unique: true });

export const SchemeApplication = model<any>('SchemeApplication', SchemeApplicationSchema);
