import { Schema, model } from 'mongoose';

/** Refresh-token sessions. Only a SHA-256 hash of the refresh token is stored. Rotated on every refresh. */
const SessionSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    tokenHash: { type: String, required: true, unique: true },
    userAgent: String,
    ip: String,
    expiresAt: { type: Date, required: true },
    revokedAt: Date,
    lastUsedAt: { type: Date, default: Date.now },
  },
  { timestamps: true },
);
SessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export const Session = model<any>('Session', SessionSchema);
