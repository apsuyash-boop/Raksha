import { Schema, model } from 'mongoose';
import { ROLES, LANGUAGES } from '../config/roles';

const SENSITIVE = ['passwordHash', 'safetyPinHash', 'medicalEncrypted', 'passwordReset', '__v'];

const UserSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    email: { type: String, lowercase: true, trim: true, unique: true, sparse: true, maxlength: 200 },
    phone: { type: String, trim: true, unique: true, sparse: true, maxlength: 20 },
    passwordHash: { type: String, required: true, select: false },
    role: { type: String, enum: ROLES, default: 'user', index: true },
    status: { type: String, enum: ['active', 'suspended', 'deleted'], default: 'active', index: true },
    emailVerified: { type: Boolean, default: false },
    phoneVerified: { type: Boolean, default: false },
    /** Professionals (lawyer/ngo/counsellor/responder/police/lender) must be verified by an admin. */
    verified: { type: Boolean, default: false, index: true },
    age: { type: Number, min: 13, max: 120 },
    state: { type: String, trim: true, maxlength: 80 },
    city: { type: String, trim: true, maxlength: 80 },
    language: { type: String, enum: LANGUAGES, default: 'en' },
    avatarColor: { type: String, default: '#B4233C' },
    isDemo: { type: Boolean, default: false, index: true },

    safetyPinHash: { type: String, select: false },
    /** AES-256-GCM encrypted JSON: { bloodGroup, allergies, conditions, medications, notes } */
    medicalEncrypted: { type: String, select: false },

    privacy: {
      shareLocationWithContacts: { type: Boolean, default: true },
      allowNearbyResponders: { type: Boolean, default: true },
      shareMedicalInfoInSOS: { type: Boolean, default: false },
      autoRecordEvidenceOnSOS: { type: Boolean, default: true },
      showInCommunityAs: { type: String, enum: ['name', 'first_name', 'anonymous'], default: 'first_name' },
    },
    notificationPrefs: {
      email: { type: Boolean, default: true },
      sms: { type: Boolean, default: true },
      whatsapp: { type: Boolean, default: false },
      inApp: { type: Boolean, default: true },
    },
    consents: [
      {
        key: String, // e.g. terms_v1, privacy_v1, evidence_sharing
        granted: Boolean,
        at: { type: Date, default: Date.now },
      },
    ],
    blockedUsers: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    passwordReset: {
      tokenHash: String,
      expiresAt: Date,
    },
    lastLoginAt: Date,
    deletionRequestedAt: Date,
  },
  {
    timestamps: true,
    toJSON: {
      transform: (_doc, ret: any) => {
        for (const k of SENSITIVE) delete ret[k];
        ret.id = ret._id;
        return ret;
      },
    },
  },
);

UserSchema.index({ name: 'text', email: 'text' }, { language_override: 'textIndexLanguage', default_language: 'none' });

/** Public-safe projection for showing a user to other users (no contact data). */
export function publicUser(u: any) {
  if (!u) return null;
  return { id: u._id, name: u.name, role: u.role, verified: !!u.verified, avatarColor: u.avatarColor };
}

export const User = model<any>('User', UserSchema);
