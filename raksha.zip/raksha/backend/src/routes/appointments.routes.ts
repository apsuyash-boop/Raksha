import { Router } from 'express';
import * as c from '../controllers/appointments.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { asyncHandler as h } from '../utils/http';

const r = Router();
r.use(authenticate);
r.post('/', validate(c.createSchema), h(c.create));
r.get('/', h(c.mine));
r.post('/:id/status', validate(c.statusSchema), h(c.changeStatus));
export default r;
