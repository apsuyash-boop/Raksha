import { Router } from 'express';
import * as c from '../controllers/community.controller';
import { authenticate, optionalAuth } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { asyncHandler as h } from '../utils/http';

const r = Router();
r.get('/posts', optionalAuth, h(c.list));
r.get('/posts/mine', authenticate, h(c.mine));
r.get('/posts/:id', optionalAuth, h(c.getOne));
r.post('/posts', authenticate, validate(c.postSchema), h(c.create));
r.delete('/posts/:id', authenticate, h(c.remove));
r.post('/posts/:id/comments', authenticate, validate(c.commentSchema), h(c.comment));
r.post('/posts/:id/react', authenticate, validate(c.reactSchema), h(c.react));
r.post('/reports', authenticate, validate(c.reportSchema), h(c.report));
export default r;
