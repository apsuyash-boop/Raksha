import { Router } from 'express';
import * as c from '../controllers/complaints.controller';
import { authenticate, authorize, requireVerified } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { asyncHandler as h } from '../utils/http';

const r = Router();
r.use(authenticate);
r.post('/', validate(c.createSchema), h(c.createComplaint));
r.get('/', h(c.list));
r.get('/police/officers', h(c.policeOfficers));
r.get('/police/inbox', authorize('police'), requireVerified, h(c.policeInbox));
r.get('/:id', h(c.getOne));
r.patch('/:id', validate(c.updateSchema), h(c.update));
r.post('/:id/ready', h(c.markReady));
r.post('/:id/submit', validate(c.submitSchema), h(c.submit));
r.post('/:id/status', validate(c.statusSchema), h(c.updateStatus));
r.post('/:id/share-police', validate(c.shareSchema), h(c.shareWithPolice));
export default r;
