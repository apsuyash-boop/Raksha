import { Router } from 'express';
import * as c from '../controllers/contacts.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { asyncHandler as h } from '../utils/http';

const r = Router();
r.use(authenticate);
r.get('/', h(c.list));
r.post('/', validate(c.contactSchema), h(c.create));
r.patch('/:id', validate(c.contactSchema), h(c.update));
r.delete('/:id', h(c.remove));
r.get('/protecting', h(c.protecting));
export default r;
