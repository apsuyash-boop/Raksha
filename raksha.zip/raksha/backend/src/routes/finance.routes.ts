import { Router } from 'express';
import * as c from '../controllers/finance.controller';
import { authenticate, authorize, optionalAuth, requireVerified } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { asyncHandler as h } from '../utils/http';

export const campaignsRouter = Router();
campaignsRouter.get('/', h(c.listCampaigns));
campaignsRouter.get('/mine', authenticate, h(c.myCampaigns));
campaignsRouter.post('/', authenticate, authorize('user'), validate(c.campaignSchema), h(c.createCampaign));
campaignsRouter.post('/:id/utilization', authenticate, authorize('admin'), validate(c.utilizationSchema), h(c.addUtilization));
campaignsRouter.get('/:slug', h(c.getCampaign));

export const donationsRouter = Router();
donationsRouter.get('/config', h(c.paymentConfig));
donationsRouter.post('/order', optionalAuth, validate(c.orderSchema), h(c.createDonationOrder));
donationsRouter.post('/verify', optionalAuth, validate(c.verifySchema), h(c.verifyDonation));
donationsRouter.get('/mine', authenticate, h(c.myDonations));
donationsRouter.get('/:id/receipt', authenticate, h(c.getReceipt));

export const paymentsRouter = Router();
paymentsRouter.post('/mock/pay', h(c.mockPay));
paymentsRouter.post('/webhook', h(c.webhook));

export const loansRouter = Router();
loansRouter.use(authenticate);
loansRouter.post('/', authorize('user'), validate(c.loanSchema), h(c.createLoan));
loansRouter.get('/mine', h(c.myLoans));
loansRouter.post('/:id/offers/:offerId/accept', h(c.acceptOffer));
loansRouter.post('/:id/withdraw', h(c.withdrawLoan));
loansRouter.get('/market', authorize('lender'), requireVerified, h(c.loanMarket));
loansRouter.post('/:id/offers', authorize('lender'), requireVerified, validate(c.offerSchema), h(c.makeOffer));

export const transparencyRouter = Router();
transparencyRouter.get('/', h(c.transparency));
