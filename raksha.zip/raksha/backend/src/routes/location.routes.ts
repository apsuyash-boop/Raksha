import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import * as c from '../controllers/location.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { env } from '../config/env';
import { asyncHandler as h } from '../utils/http';

const trackLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, skip: () => env.isTest });
const r = Router();
r.get('/track/:token', trackLimiter, h(c.track)); // public, token-gated
r.use(authenticate);
r.post('/', validate(c.updateSchema), h(c.update));
r.post('/share', validate(c.shareSchema), h(c.startShare));
r.post('/share/:id/stop', h(c.stopShare));
r.get('/shares/active', h(c.activeShares));
r.get('/history', h(c.history));
r.get('/user/:userId/latest', h(c.latestFor));
export default r;
