import { Router } from 'express';
import * as c from '../controllers/messages.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { asyncHandler as h } from '../utils/http';

export const messagesRouter = Router();
messagesRouter.use(authenticate);
messagesRouter.get('/conversations', h(c.conversations));
messagesRouter.get('/can-chat', h(c.contactsForChat));
messagesRouter.get('/with/:userId', h(c.thread));
messagesRouter.post('/with/:userId/read', h(c.markRead));
messagesRouter.post('/', validate(c.sendSchema), h(c.sendMessageHandler));

export const notificationsRouter = Router();
notificationsRouter.use(authenticate);
notificationsRouter.get('/', h(c.listNotifications));
notificationsRouter.post('/read-all', h(c.readAllNotifications));
notificationsRouter.post('/:id/read', h(c.readNotification));
