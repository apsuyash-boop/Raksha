import { Router } from 'express';
import * as c from '../controllers/professionals.controller';
import { authenticate, authorize } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { AppError, asyncHandler as h } from '../utils/http';

function professionalRouter(kind: 'lawyer' | 'ngo' | 'counsellor', schema: any) {
  const r = Router();
  r.get('/', h(c.listPublic(kind)));
  r.get('/me/profile', authenticate, authorize(kind), h(c.getMine(kind)));
  r.put('/me/profile', authenticate, authorize(kind), validate(schema), h(c.upsertMine(kind)));
  r.post('/me/verification', authenticate, authorize(kind), validate(c.verifyRequestSchema), h(c.requestVerification(kind)));
  r.get('/:id', h(c.getPublic(kind)));
  return r;
}

export const lawyersRouter = professionalRouter('lawyer', c.lawyerProfileSchema);
export const ngosRouter = professionalRouter('ngo', c.ngoProfileSchema);
export const counsellorsRouter = professionalRouter('counsellor', c.counsellorProfileSchema);

export const respondersRouter = Router();
respondersRouter.use(authenticate, authorize('responder'));
respondersRouter.get('/me', h(c.getMine('responder')));
respondersRouter.put('/me', validate(c.responderProfileSchema), h(c.upsertMine('responder')));
respondersRouter.post('/me/verification', validate(c.verifyRequestSchema), h(c.requestVerification('responder')));

export const partnerVerificationRouter = Router();
partnerVerificationRouter.post('/:role', authenticate, validate(c.verifyRequestSchema), h(async (req, res, next) => {
  const role = req.params.role;
  if (!['police', 'lender'].includes(role) || req.user!.role !== role) return next(AppError.forbidden());
  return c.requestVerification(role)(req, res);
}));

export const matchRouter = Router();
matchRouter.post('/', authenticate, validate(c.matchSchema), h(c.match));
