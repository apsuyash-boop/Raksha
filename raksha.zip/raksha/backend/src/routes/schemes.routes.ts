import { Router } from 'express';
import * as c from '../controllers/schemes.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { asyncHandler as h } from '../utils/http';

export const schemesRouter = Router();
schemesRouter.get('/', h(c.listSchemes));
schemesRouter.post('/eligibility', validate(c.eligibilitySchema), h(c.checkEligibility));
schemesRouter.get('/applications/mine', authenticate, h(c.myApplications));
schemesRouter.patch('/applications/:id', authenticate, validate(c.applicationSchema), h(c.updateApplication));
schemesRouter.delete('/applications/:id', authenticate, h(c.removeApplication));
schemesRouter.post('/:id/apply', authenticate, h(c.startApplication));
schemesRouter.get('/:id', h(c.getScheme));

export const rightsRouter = Router();
rightsRouter.get('/', h(c.listRights));
rightsRouter.get('/:slug', h(c.getRight));
