/**
 * Seeds reference data (schemes, rights library, settings) and DEMO data (clearly labelled isDemo=true).
 *
 *   npm run seed            upsert reference data + recreate demo data
 *   npm run seed -- --fresh DROP the whole database first (development only)
 *
 * Demo accounts all use the password printed at the end. Demo SOS / payments are always simulated.
 */
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';
import { connectDB } from '../config/db';
import { env } from '../config/env';
import {
  Appointment, AuditLog, Campaign, Case, Comment, CommunityPost, Complaint, Counsellor, Donation, EmergencyContact, Evidence, Lawyer,
  LoanRequest, LocationEvent, LocationShare, Message, NGO, Notification, Responder, RightsArticle, Scheme, SchemeApplication, Session,
  Setting, SOSAlert, Transaction, User, Verification,
} from '../models';
import { caseNumber, complaintNumber, evidenceId, receiptNumber, slugify } from '../services/ids';
import { storage } from '../services/storage';
import { sha256 } from '../utils/crypto';
import { toPoint } from '../utils/geo';
import { buildComplaintDraft } from '../services/complaintDraft';

export const DEMO_PASSWORD = 'RakshaDemo@2026';

const SEED_DIR = process.env.SEED_DIR || [path.resolve(__dirname, '../../../database/seed'), path.resolve(process.cwd(), '../database/seed'), path.resolve(process.cwd(), 'database/seed')].find((p) => fs.existsSync(p));

const readJson = (f: string) => JSON.parse(fs.readFileSync(path.join(SEED_DIR!, f), 'utf8'));

const CITIES: Record<string, { state: string; lat: number; lng: number }> = {
  Bhopal: { state: 'Madhya Pradesh', lat: 23.2599, lng: 77.4126 },
  Indore: { state: 'Madhya Pradesh', lat: 22.7196, lng: 75.8577 },
  Delhi: { state: 'Delhi', lat: 28.6139, lng: 77.209 },
  Mumbai: { state: 'Maharashtra', lat: 19.076, lng: 72.8777 },
  Lucknow: { state: 'Uttar Pradesh', lat: 26.8467, lng: 80.9462 },
  Bengaluru: { state: 'Karnataka', lat: 12.9716, lng: 77.5946 },
  Patna: { state: 'Bihar', lat: 25.5941, lng: 85.1376 },
  Jaipur: { state: 'Rajasthan', lat: 26.9124, lng: 75.7873 },
};

// 1x1 PNG used as a harmless demo evidence file.
const DEMO_PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');

async function upsertReference() {
  const schemes = readJson('schemes.json');
  for (const s of schemes) await Scheme.updateOne({ slug: s.slug }, { $set: { ...s, active: true, lastVerifiedAt: new Date() } }, { upsert: true });
  const rights = readJson('rights.json');
  for (const r of rights) await RightsArticle.updateOne({ slug: r.slug }, { $set: { ...r, published: true } }, { upsert: true });
  await Setting.updateOne({ key: 'moderation.keywords' }, { $setOnInsert: { value: [], description: 'Extra blocked words/phrases for auto-moderation (default list is built in)' } }, { upsert: true });
  await Setting.updateOne({ key: 'sos.responderRadiusKm' }, { $setOnInsert: { value: env.SOS_RESPONDER_RADIUS_KM, description: 'Radius for notifying verified responders' } }, { upsert: true });
  console.log(`✓ ${schemes.length} schemes, ${rights.length} rights articles`);
}

async function wipeDemo() {
  const demoUsers = await User.find({ isDemo: true }).select('_id').lean<any[]>();
  const ids = demoUsers.map((u) => u._id);
  const ev = await Evidence.find({ owner: { $in: ids } }).select('+storageKey').lean<any[]>();
  for (const e of ev) await storage.remove(e.storageKey).catch(() => undefined);
  await Promise.all([
    Evidence.deleteMany({ owner: { $in: ids } }),
    EmergencyContact.deleteMany({ owner: { $in: ids } }),
    Responder.deleteMany({ user: { $in: ids } }),
    Lawyer.deleteMany({ user: { $in: ids } }),
    NGO.deleteMany({ user: { $in: ids } }),
    Counsellor.deleteMany({ user: { $in: ids } }),
    SOSAlert.deleteMany({ user: { $in: ids } }),
    LocationEvent.deleteMany({ user: { $in: ids } }),
    LocationShare.deleteMany({ user: { $in: ids } }),
    Case.deleteMany({ user: { $in: ids } }),
    Complaint.deleteMany({ user: { $in: ids } }),
    Appointment.deleteMany({ user: { $in: ids } }),
    SchemeApplication.deleteMany({ user: { $in: ids } }),
    Campaign.deleteMany({ isDemo: true }),
    Donation.deleteMany({ isDemo: true }),
    Transaction.deleteMany({ isDemo: true }),
    LoanRequest.deleteMany({ user: { $in: ids } }),
    Message.deleteMany({ $or: [{ from: { $in: ids } }, { to: { $in: ids } }] }),
    Notification.deleteMany({ user: { $in: ids } }),
    CommunityPost.deleteMany({ author: { $in: ids } }),
    Comment.deleteMany({ author: { $in: ids } }),
    Verification.deleteMany({ user: { $in: ids } }),
    Session.deleteMany({ user: { $in: ids } }),
    AuditLog.deleteMany({ actor: { $in: ids } }),
  ]);
  await User.deleteMany({ isDemo: true });
}

async function main() {
  await connectDB();
  if (process.argv.includes('--fresh')) {
    if (env.isProd) throw new Error('Refusing to drop a production database');
    await mongoose.connection.db!.dropDatabase();
    console.log('✓ database dropped');
  }
  await Promise.all(mongoose.modelNames().map((n) => mongoose.model(n).syncIndexes()));
  await upsertReference();
  await wipeDemo();

  const hash = await bcrypt.hash(DEMO_PASSWORD, 12);
  const pinHash = await bcrypt.hash('2580', 10);
  const mk = (o: any) => User.create({ passwordHash: hash, isDemo: true, emailVerified: true, status: 'active', consents: [{ key: 'terms_v1', granted: true }], ...o });

  /* ------------------------------- people -------------------------------- */
  const priya = await mk({ name: 'Priya Sharma (Demo)', email: 'priya.demo@raksha.app', phone: '+910000000101', role: 'user', verified: true, age: 29, city: 'Bhopal', state: 'Madhya Pradesh', language: 'hi', safetyPinHash: pinHash, avatarColor: '#B4233C' });
  const anita = await mk({ name: 'Anita Sharma (Demo)', email: 'contact.demo@raksha.app', phone: '+910000000102', role: 'emergency_contact', verified: true, city: 'Bhopal', state: 'Madhya Pradesh', avatarColor: '#7C3AED' });
  const admin = await mk({ name: 'Raksha Admin (Demo)', email: 'admin.demo@raksha.app', phone: '+910000000199', role: 'admin', verified: true, avatarColor: '#0F172A' });
  const police = await mk({ name: 'SI Kavita Verma (Demo)', email: 'police.demo@raksha.app', phone: '+910000000110', role: 'police', verified: true, city: 'Bhopal', state: 'Madhya Pradesh', avatarColor: '#1D4ED8' });
  const donor = await mk({ name: 'Rahul Mehta (Demo)', email: 'donor.demo@raksha.app', phone: '+910000000120', role: 'donor', verified: true, city: 'Mumbai', state: 'Maharashtra', avatarColor: '#047857' });
  const lender = await mk({ name: 'Sahayak Microfinance (Demo)', email: 'lender.demo@raksha.app', phone: '+910000000130', role: 'lender', verified: true, city: 'Indore', state: 'Madhya Pradesh', avatarColor: '#B45309' });
  const others = await Promise.all([
    mk({ name: 'Fatima Khan (Demo)', email: 'fatima.demo@raksha.app', phone: '+910000000103', role: 'user', verified: true, age: 34, city: 'Lucknow', state: 'Uttar Pradesh', language: 'hi' }),
    mk({ name: 'Lakshmi Iyer (Demo)', email: 'lakshmi.demo@raksha.app', phone: '+910000000104', role: 'user', verified: true, age: 41, city: 'Bengaluru', state: 'Karnataka', language: 'en' }),
  ]);

  await EmergencyContact.insertMany([
    { owner: priya._id, name: 'Anita Sharma (Mother)', relation: 'Mother', phone: anita.phone, email: anita.email, linkedUser: anita._id, priority: 1, channels: { sms: true, whatsapp: true, email: true, app: true } },
    { owner: priya._id, name: 'Neha Gupta (Friend)', relation: 'Friend', phone: '+910000000105', email: 'neha.friend@example.com', priority: 2, channels: { sms: true, whatsapp: false, email: true, app: true } },
  ]);

  /* ------------------------------ lawyers ------------------------------- */
  const lawyerSeeds = [
    { name: 'Adv. Meera Joshi', email: 'lawyer.demo@raksha.app', city: 'Bhopal', spec: ['domestic_violence', 'dowry', 'maintenance', 'divorce'], langs: ['hi', 'en'], fee: 'pro_bono', proBono: true, rating: 4.8, bio: 'Family-law advocate with 12 years at the Bhopal Family Court and District Court. Takes domestic-violence and dowry cases pro bono.' },
    { name: 'Adv. Rakesh Tiwari', city: 'Indore', spec: ['divorce', 'child_custody', 'maintenance'], langs: ['hi'], fee: 'low_fee', rating: 4.5, bio: 'Matrimonial disputes, custody and maintenance. Low-fee consultations.' },
    { name: 'Adv. Shalini Kapoor', city: 'Delhi', spec: ['workplace_harassment', 'harassment', 'cyber_crime'], langs: ['en', 'hi'], fee: 'standard', rating: 4.7, bio: 'POSH compliance and workplace harassment specialist; represents complainants before Internal and Local Committees.' },
    { name: 'Adv. Ayesha Siddiqui', city: 'Lucknow', spec: ['domestic_violence', 'divorce', 'maintenance'], langs: ['hi', 'ur', 'en'], fee: 'pro_bono', proBono: true, rating: 4.9, bio: 'Women’s rights lawyer working with legal-aid clinics in Lucknow.' },
    { name: 'Adv. Priyanka Deshmukh', city: 'Mumbai', spec: ['sexual_assault', 'harassment', 'domestic_violence'], langs: ['mr', 'hi', 'en'], fee: 'low_fee', rating: 4.6, bio: 'Criminal-law practitioner supporting survivors through trial.' },
    { name: 'Adv. Nandini Rao', city: 'Bengaluru', spec: ['divorce', 'child_custody', 'workplace_harassment'], langs: ['kn', 'en'], fee: 'standard', rating: 4.4, bio: 'Family court and employment matters in Bengaluru.' },
  ];
  const lawyers: any[] = [];
  for (const [i, l] of lawyerSeeds.entries()) {
    const c = CITIES[l.city];
    const u = await mk({ name: `${l.name} (Demo)`, email: l.email || `lawyer${i}.demo@raksha.app`, phone: `+9100000002${String(i).padStart(2, '0')}`, role: 'lawyer', verified: true, city: l.city, state: c.state, avatarColor: '#9F1239' });
    lawyers.push(
      await Lawyer.create({
        user: u._id, displayName: `${l.name} (Demo)`, barCouncilId: `DEMO/${1000 + i}/2014`, enrollmentYear: 2012 + (i % 6), bio: l.bio, specializations: l.spec,
        services: ['consultation', 'drafting', 'court_representation'], languages: l.langs, city: l.city, state: c.state, location: toPoint(c.lat, c.lng),
        feeType: l.fee, proBono: !!l.proBono, consultationFee: l.fee === 'standard' ? 1500 : l.fee === 'low_fee' ? 300 : 0, freeFirstConsultation: true,
        verified: true, verifiedAt: new Date(), rating: l.rating, isDemo: true, courts: [`${l.city} Family Court`, `${l.city} District Court`],
      }),
    );
  }
  // One lawyer awaiting verification (shows the admin workflow).
  const pendingLawyerUser = await mk({ name: 'Adv. Rohan Malhotra (Demo, unverified)', email: 'lawyer.pending.demo@raksha.app', phone: '+910000000299', role: 'lawyer', verified: false, city: 'Jaipur', state: 'Rajasthan' });
  await Lawyer.create({ user: pendingLawyerUser._id, displayName: 'Adv. Rohan Malhotra (Demo)', barCouncilId: 'DEMO/RJ/2219/2018', specializations: ['dowry', 'domestic_violence'], languages: ['hi', 'en'], city: 'Jaipur', state: 'Rajasthan', location: toPoint(CITIES.Jaipur.lat, CITIES.Jaipur.lng), verified: false, isDemo: true });
  await Verification.create({ user: pendingLawyerUser._id, role: 'lawyer', details: { barCouncilId: 'DEMO/RJ/2219/2018', note: 'Enrolled with Bar Council of Rajasthan (demo data)' }, status: 'pending' });

  /* -------------------------------- NGOs -------------------------------- */
  const ngoSeeds = [
    { name: 'Sahas Women’s Collective', email: 'ngo.demo@raksha.app', city: 'Bhopal', services: ['shelter', 'legal_aid', 'counselling', 'rescue'], focus: ['domestic_violence', 'dowry', 'harassment'], langs: ['hi', 'en'], cap: 20, avail: 6, h24: true },
    { name: 'Nayi Disha Trust', city: 'Lucknow', services: ['legal_aid', 'skills_training', 'counselling'], focus: ['domestic_violence', 'maintenance', 'divorce'], langs: ['hi', 'ur'], cap: 0, avail: 0 },
    { name: 'Suraksha Mumbai', city: 'Mumbai', services: ['rescue', 'shelter', 'medical', 'rehabilitation'], focus: ['sexual_assault', 'domestic_violence', 'harassment'], langs: ['mr', 'hi', 'en'], cap: 35, avail: 4, h24: true },
    { name: 'Sakhi One Stop Centre – Bhopal (Demo listing)', city: 'Bhopal', services: ['shelter', 'legal_aid', 'medical', 'counselling', 'rescue'], focus: ['domestic_violence', 'sexual_assault', 'harassment', 'dowry', 'other'], langs: ['hi'], cap: 10, avail: 3, h24: true, osc: true },
  ];
  const ngos: any[] = [];
  for (const [i, n] of ngoSeeds.entries()) {
    const c = CITIES[n.city];
    const u = await mk({ name: `${n.name} (Demo)`, email: n.email || `ngo${i}.demo@raksha.app`, phone: `+9100000003${String(i).padStart(2, '0')}`, role: 'ngo', verified: true, city: n.city, state: c.state, avatarColor: '#0E7490' });
    ngos.push(
      await NGO.create({
        user: u._id, name: `${n.name} (Demo)`, registrationNumber: `DEMO-REG-${200 + i}`, about: `${n.name} supports women facing violence with ${n.services.join(', ').replace(/_/g, ' ')}. This is demo data.`,
        services: n.services, focusAreas: n.focus, languages: n.langs, city: n.city, state: c.state, serviceAreas: [n.city], location: toPoint(c.lat + 0.01 * i, c.lng),
        shelterCapacity: n.cap, shelterAvailable: n.avail, helpline: '181', is24x7: !!n.h24, isOneStopCentre: !!n.osc, verified: true, verifiedAt: new Date(), rating: 4.5 + (i % 5) / 10, isDemo: true,
      }),
    );
  }

  /* ----------------------------- counsellors ----------------------------- */
  const cSeeds = [
    { name: 'Dr. Kavya Rao', email: 'counsellor.demo@raksha.app', cat: 'emotional', spec: ['trauma', 'domestic_violence', 'anxiety'], langs: ['hi', 'en', 'kn'], modes: ['chat', 'call', 'video'], price: 0, free: true, q: 'M.Phil Clinical Psychology (RCI registered — demo)' },
    { name: 'Sunita Bhatt', cat: 'career_money', spec: ['career', 'financial', 'skills'], langs: ['hi', 'en'], modes: ['chat', 'video'], price: 200, free: false, q: 'Certified career coach (demo)' },
    { name: 'Adv. Reena Saxena', cat: 'legal', spec: ['legal_advice', 'family'], langs: ['hi', 'en'], modes: ['call', 'video'], price: 0, free: true, q: 'Advocate — free first legal consultation (demo)' },
    { name: 'Dr. Farah Ali', cat: 'emotional', spec: ['trauma', 'family', 'grief'], langs: ['ur', 'hi', 'en'], modes: ['chat', 'call'], price: 300, free: false, q: 'Counselling psychologist (demo)' },
  ];
  const counsellors: any[] = [];
  for (const [i, s] of cSeeds.entries()) {
    const u = await mk({ name: `${s.name} (Demo)`, email: s.email || `counsellor${i}.demo@raksha.app`, phone: `+9100000004${String(i).padStart(2, '0')}`, role: 'counsellor', verified: true, avatarColor: '#6D28D9' });
    counsellors.push(
      await Counsellor.create({
        user: u._id, displayName: `${s.name} (Demo)`, qualification: s.q, licenseNumber: `DEMO-LIC-${300 + i}`, yearsExperience: 6 + i * 2, bio: `${s.name} offers ${s.cat.replace('_', ' & ')} support in a safe, confidential space. Demo profile.`,
        specializations: s.spec, category: s.cat, languages: s.langs, modes: s.modes, price: s.price, freeSessions: s.free,
        weeklySlots: [1, 2, 3, 4, 5].map((d) => ({ day: d, from: '10:00', to: '17:00' })), meetingUrl: 'https://meet.jit.si/raksha-demo-room', verified: true, verifiedAt: new Date(), rating: 4.6 + (i % 4) / 10, isDemo: true,
      }),
    );
  }

  /* ------------------------------ responders ----------------------------- */
  const responderUser = await mk({ name: 'Rohini Patel (Demo responder)', email: 'responder.demo@raksha.app', phone: '+910000000501', role: 'responder', verified: true, city: 'Bhopal', state: 'Madhya Pradesh', avatarColor: '#15803D' });
  await Responder.create({ user: responderUser._id, verified: true, active: true, availability: 'always', skills: ['first_aid', 'self_defence'], languages: ['hi', 'en'], city: 'Bhopal', state: 'Madhya Pradesh', location: toPoint(23.2645, 77.4022), locationUpdatedAt: new Date() });
  for (let i = 0; i < 3; i++) {
    const u = await mk({ name: `Bhopal Responder ${i + 2} (Demo)`, email: `responder${i + 2}.demo@raksha.app`, phone: `+91000000050${i + 2}`, role: 'responder', verified: true, city: 'Bhopal', state: 'Madhya Pradesh' });
    await Responder.create({ user: u._id, verified: true, active: true, availability: 'always', skills: ['first_aid'], city: 'Bhopal', state: 'Madhya Pradesh', location: toPoint(23.2599 + (i - 1) * 0.008, 77.4126 + (i - 1) * 0.01), locationUpdatedAt: new Date() });
  }

  /* ------------------------- Priya's journey (demo) ------------------------ */
  const { key } = await storage.putEncrypted(`evidence/${priya._id}`, DEMO_PNG);
  const ev = await Evidence.create({
    evidenceId: evidenceId(), owner: priya._id, title: 'Photo of injury (demo placeholder image)', category: 'photo', kind: 'image', mimeType: 'image/png', originalName: 'demo-photo.png', size: DEMO_PNG.length,
    sha256: sha256(DEMO_PNG), storageKey: key, storageDriver: storage.driverName(), capturedAt: new Date(Date.now() - 12 * 86400000), gps: { lat: 23.2599, lng: 77.4126, accuracy: 15 },
    accessLog: [{ user: priya._id, role: 'user', action: 'upload', at: new Date(Date.now() - 12 * 86400000) }],
  });
  const pastSos = await SOSAlert.create({
    user: priya._id, status: 'resolved', isDemo: true, location: toPoint(23.2599, 77.4126), accuracy: 18, message: 'Demo: past SOS', evidence: [ev._id],
    contactsAlertedAt: new Date(Date.now() - 14 * 86400000 + 6000), resolvedAt: new Date(Date.now() - 14 * 86400000 + 40 * 60000), emergencyService: { status: 'simulated', message: 'Demo SOS — emergency services were NOT contacted.' },
    timeline: [
      { step: 'activated', label: 'SOS activated (DEMO — simulated)', at: new Date(Date.now() - 14 * 86400000) },
      { step: 'contacts_alerted', label: '4 alert(s) simulated to 2 contact(s)', at: new Date(Date.now() - 14 * 86400000 + 6000) },
      { step: 'responders_notified', label: '2 verified responder(s) nearby notified', at: new Date(Date.now() - 14 * 86400000 + 7000) },
      { step: 'recording_started', label: 'Audio evidence recording started', at: new Date(Date.now() - 14 * 86400000 + 9000) },
      { step: 'resolved', label: 'Emergency resolved — marked safe', at: new Date(Date.now() - 14 * 86400000 + 40 * 60000) },
    ],
  });
  (pastSos as any).createdAt = new Date(Date.now() - 14 * 86400000);
  await SOSAlert.collection.updateOne({ _id: pastSos._id }, { $set: { createdAt: new Date(Date.now() - 14 * 86400000) } });

  const priyaCase = await Case.create({
    caseNumber: caseNumber(), user: priya._id, type: 'domestic_violence', title: 'Domestic violence and dowry harassment by in-laws', urgency: 'high', status: 'in_court',
    description: 'Demo case: repeated physical and verbal abuse at the matrimonial home, with demands for money from my family.', lawyer: lawyers[0]._id, ngo: ngos[0]._id,
    evidence: [ev._id], sos: [pastSos._id], location: { city: 'Bhopal', state: 'Madhya Pradesh' }, language: 'hi', budget: 'free', isDemo: true,
    requests: [
      { providerType: 'lawyer', provider: lawyers[0]._id, providerModel: 'Lawyer', providerUser: lawyers[0].user, status: 'accepted', respondedAt: new Date(Date.now() - 10 * 86400000) },
      { providerType: 'ngo', provider: ngos[0]._id, providerModel: 'NGO', providerUser: ngos[0].user, status: 'accepted', respondedAt: new Date(Date.now() - 11 * 86400000) },
    ],
    hearings: [{ date: new Date(Date.now() + 9 * 86400000), court: 'Family Court, Bhopal (demo)', purpose: 'Protection order — first hearing', reminderSent: false }],
    importantDates: [{ date: new Date(Date.now() + 5 * 86400000), label: 'Submit medical report copy to lawyer' }],
    notes: [{ author: lawyers[0].user, text: 'Application under Sections 12, 18, 19 and 20 of the PWDVA drafted. Please bring originals of the medical report.', visibility: 'shared', at: new Date(Date.now() - 6 * 86400000) }],
    documents: [{ title: 'DV Act application (draft)', preparedBy: lawyers[0].user, body: 'Demo draft prepared by counsel.' }],
    timeline: [
      { label: 'Case created', by: priya._id, at: new Date(Date.now() - 13 * 86400000) },
      { label: 'Sahas Women’s Collective (Demo) accepted your case', by: ngos[0].user, at: new Date(Date.now() - 11 * 86400000) },
      { label: 'Adv. Meera Joshi (Demo) accepted your case', by: lawyers[0].user, at: new Date(Date.now() - 10 * 86400000) },
      { label: 'Complaint submitted', detail: 'Self-reported', by: priya._id, at: new Date(Date.now() - 8 * 86400000) },
      { label: 'Hearing scheduled: Protection order — first hearing', by: lawyers[0].user, at: new Date(Date.now() - 5 * 86400000) },
    ],
  });
  await Evidence.updateOne({ _id: ev._id }, { cases: [priyaCase._id] });
  const incident = { type: 'domestic_violence', date: new Date(Date.now() - 12 * 86400000), time: '9:30 PM', place: 'Matrimonial home, Arera Colony', city: 'Bhopal', state: 'Madhya Pradesh', description: 'Demo account: My husband and mother-in-law have been demanding ₹2 lakh from my parents. On the night of the incident my husband hit me and pushed me against the wall when I refused to call my father. I have a medical report from the hospital.', accused: [{ name: 'Demo Accused 1', relation: 'Husband' }, { name: 'Demo Accused 2', relation: 'Mother-in-law' }] };
  const complaint = await Complaint.create({
    complaintNumber: complaintNumber(), user: priya._id, case: priyaCase._id, incident, policeStation: 'Mahila Thana, Bhopal (demo)', evidence: [ev._id], status: 'registered', isDemo: true,
    draftText: buildComplaintDraft({ complainant: { name: priya.name, age: 29, city: 'Bhopal', state: 'Madhya Pradesh', phone: priya.phone }, incident, policeStation: 'Mahila Thana, Bhopal (demo)', evidence: [{ evidenceId: ev.evidenceId, title: ev.title, sha256: ev.sha256, capturedAt: ev.capturedAt }] }),
    submission: { method: 'via_ngo', confirmedByAuthority: true, submittedAt: new Date(Date.now() - 8 * 86400000) }, firNumber: 'DEMO-0000/2026', firSource: 'police_official', sharedWithPolice: [police._id],
    statusHistory: [
      { status: 'draft', note: 'Draft created', by: priya._id, source: 'user', at: new Date(Date.now() - 9 * 86400000) },
      { status: 'submitted', note: 'Self-reported: submitted with help from an NGO volunteer. Not confirmed by police.', by: priya._id, source: 'user', at: new Date(Date.now() - 8 * 86400000) },
      { status: 'registered', note: 'FIR registered (demo data entered by a verified police official account)', by: police._id, source: 'police_official', at: new Date(Date.now() - 7 * 86400000) },
    ],
  });
  await Case.updateOne({ _id: priyaCase._id }, { complaints: [complaint._id] });

  await Appointment.create({ user: priya._id, counsellor: counsellors[0]._id, counsellorUser: counsellors[0].user, mode: 'video', scheduledAt: new Date(Date.now() + 26 * 3600000), status: 'confirmed', topic: 'Coping with anxiety after the incident', free: true, price: 0, meetingUrl: 'https://meet.jit.si/raksha-demo-room', isDemo: true });
  await Appointment.create({ user: priya._id, counsellor: counsellors[0]._id, counsellorUser: counsellors[0].user, mode: 'chat', scheduledAt: new Date(Date.now() - 7 * 86400000), status: 'completed', free: true, isDemo: true });
  const ladli = await Scheme.findOne({ slug: 'ladli-behna-yojana-mp' }).lean<any>();
  const osc = await Scheme.findOne({ slug: 'one-stop-centre-sakhi' }).lean<any>();
  if (ladli) await SchemeApplication.create({ user: priya._id, scheme: ladli._id, status: 'documents_ready', checklist: (ladli.documents || []).map((d: string, i: number) => ({ item: d, done: i < 2 })), history: [{ status: 'interested' }, { status: 'documents_ready' }] });
  if (osc) await SchemeApplication.create({ user: priya._id, scheme: osc._id, status: 'benefit_received', history: [{ status: 'interested' }, { status: 'benefit_received', note: 'Received counselling and legal aid (demo)' }] });

  await Message.insertMany([
    { conversationKey: [String(priya._id), String(lawyers[0].user)].sort().join(':'), from: lawyers[0].user, to: priya._id, text: 'Namaste Priya ji, I have reviewed your documents. We will file for a protection order this week.', createdAt: new Date(Date.now() - 6 * 86400000), readAt: new Date() },
    { conversationKey: [String(priya._id), String(lawyers[0].user)].sort().join(':'), from: priya._id, to: lawyers[0].user, text: 'Thank you. I will bring the medical report on Monday.', createdAt: new Date(Date.now() - 6 * 86400000 + 3600000), readAt: new Date() },
    { conversationKey: [String(priya._id), String(lawyers[0].user)].sort().join(':'), from: lawyers[0].user, to: priya._id, text: 'Hearing is fixed. I will see you 30 minutes before at the Family Court gate.', createdAt: new Date(Date.now() - 3600000) },
  ]);

  await Notification.insertMany([
    { user: priya._id, type: 'hearing_reminder', title: 'Court hearing in 9 days', body: 'Protection order — first hearing, Family Court Bhopal', link: `/cases/${priyaCase._id}`, priority: 'high' },
    { user: priya._id, type: 'appointment', title: 'Counselling session confirmed', body: 'Video session with Dr. Kavya Rao tomorrow', link: '/counselling' },
    { user: priya._id, type: 'complaint_update', title: 'FIR registered (demo)', body: 'Confirmed by a verified police official account', link: `/complaints/${complaint._id}`, read: true },
    { user: priya._id, type: 'system', title: 'Welcome to the Raksha demo', body: 'This account is for demonstration. SOS here is simulated and never contacts real services.', read: true },
  ]);

  /* ----------------------------- community ------------------------------ */
  const posts = [
    { author: others[0]._id, anonymous: true, alias: 'Anonymous Marigold', type: 'story', title: 'I left after eight years — and I am finally sleeping again', body: 'For years I thought it was my fault. When I finally told a friend, she helped me find a lawyer who did not charge me. The protection order took weeks, not years. If you are reading this and you are scared — you are not alone. Small steps count. (Demo story)', tags: ['domestic violence', 'hope'] },
    { author: lawyers[0].user, anonymous: false, type: 'article', title: 'What happens at the first hearing under the Domestic Violence Act?', body: 'Many women worry about the first hearing. Usually the Magistrate reads your application, may ask a few questions, and can pass interim orders the same day — such as stopping the abuser from contacting you or allowing you to stay in the shared home. Bring your ID, copies of any medical reports and your Domestic Incident Report if you have one. (Demo article — educational, not legal advice.)', tags: ['legal', 'dv act'], featured: true },
    { author: others[1]._id, anonymous: false, type: 'discussion', title: 'How did you prepare for your POSH committee inquiry?', body: 'I have filed a complaint with my company’s Internal Committee. I am nervous about the inquiry meeting. For those who have been through it — what helped you prepare? Did you bring a support person? (Demo discussion)', tags: ['posh', 'workplace'] },
    { author: counsellors[0].user, anonymous: false, type: 'article', title: 'Grounding when panic hits: the 5-4-3-2-1 technique', body: 'When anxiety rises, name 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell and 1 you can taste. Breathe slowly in for four counts and out for six. It does not solve the problem, but it can bring you back to the present so you can take the next step. (Demo article)', tags: ['wellbeing', 'anxiety'] },
    { author: priya._id, anonymous: true, alias: 'Anonymous Lotus', type: 'question', title: 'Can I get my jewellery (stridhan) back from my in-laws?', body: 'My in-laws kept all my wedding jewellery when I moved back to my parents’ home. Is there a way to get it back without going to court for years? (Demo question)', tags: ['stridhan', 'dowry'] },
  ];
  const createdPosts = await CommunityPost.insertMany(posts.map((p, i) => ({ ...p, status: 'published', isDemo: true, reactionCounts: { support: 12 - i, heart: 8 + i, strength: 5 }, createdAt: new Date(Date.now() - (i + 1) * 86400000) })));
  await Comment.create({ post: createdPosts[4]._id, author: lawyers[0].user, body: 'Yes — stridhan is legally yours. You can ask for it in writing; if they refuse, you can seek its return through a Domestic Violence Act application, and refusing to return it can also be a criminal offence. A lawyer can send a notice first. (Demo reply, not legal advice)' });
  await CommunityPost.updateOne({ _id: createdPosts[4]._id }, { commentsCount: 1 });
  await CommunityPost.create({ author: others[0]._id, type: 'discussion', title: 'Pending review example (demo)', body: 'This demo post contains a phone number 9876543210 so auto-moderation holds it for manual review.', status: 'pending_review', moderation: { autoFlags: ['phone_number'] }, isDemo: true });

  /* ----------------------------- campaigns ------------------------------ */
  const campaignSeeds = [
    { b: priya, title: 'Help Priya pay a rent deposit for a safe new home', cat: 'rent', goal: 30000, raised: 18500, story: 'After leaving an abusive home, Priya (name changed) is staying temporarily at a shelter. She has found a small rented room near her new job but needs a deposit and the first month’s rent. Funds will be paid directly to the landlord after verification. This is demo data.', payee: { type: 'landlord', name: 'Verified landlord (demo)' }, name: 'P., Bhopal' },
    { b: others[0], title: 'Legal fees for a custody case in Lucknow', cat: 'legal_fees', goal: 45000, raised: 12000, story: 'A mother of two is seeking custody of her children after years of domestic violence. Her advocate charges a reduced fee; donations will be paid directly to the advocate’s office against invoices. This is demo data.', payee: { type: 'lawyer', name: 'Advocate’s office (demo)' }, name: 'F., Lucknow' },
    { b: others[1], title: 'Medical treatment and recovery support', cat: 'medical', goal: 60000, raised: 60000, completed: true, story: 'Funds raised for surgery and physiotherapy following an assault. Paid directly to the hospital. This is demo data.', payee: { type: 'hospital', name: 'Partner hospital (demo)' }, name: 'L., Bengaluru' },
  ];
  for (const s of campaignSeeds) {
    const c = await Campaign.create({
      slug: slugify(s.title), beneficiary: s.b._id, title: s.title, story: s.story, category: s.cat, goalAmount: s.goal, raisedAmount: s.raised, donorsCount: Math.round(s.raised / 1500),
      displayName: s.name, city: s.b.city, state: s.b.state, status: s.completed ? 'completed' : 'active', kycVerified: true, verifiedBy: admin._id, payee: s.payee, isDemo: true,
      disbursedAmount: s.completed ? 55000 : 0,
      utilization: s.completed ? [{ amount: 40000, purpose: 'Surgery', paidTo: 'Partner hospital (demo)' }, { amount: 15000, purpose: 'Physiotherapy (10 sessions)', paidTo: 'Partner hospital (demo)' }] : [],
    });
    const tx = await Transaction.create({ type: 'donation', provider: 'mock', orderId: `order_mock_seed_${c._id}`, paymentId: `pay_mock_seed_${c._id}`, signatureVerified: true, amount: s.raised, status: 'captured', user: donor._id, campaign: c._id, receiptNumber: receiptNumber(), isDemo: true });
    await Donation.create({ donor: donor._id, donorName: donor.name, campaign: c._id, amount: s.raised, status: 'paid', transaction: tx._id, receiptNumber: tx.receiptNumber, isDemo: true, message: 'Stay strong. (demo)' });
    if (s.completed) await Transaction.create({ type: 'disbursement', provider: 'manual', amount: 55000, status: 'completed', campaign: c._id, paidTo: 'Partner hospital (demo)', isDemo: true });
  }

  await LoanRequest.create({ user: priya._id, amount: 25000, purpose: 'small_business', description: 'Tailoring machine and materials to start working from home (demo).', tenureMonths: 12, monthlyIncome: 6000, city: 'Bhopal', state: 'Madhya Pradesh', consentToShareWithLenders: true, status: 'offers_received', isDemo: true, offers: [{ lender: lender._id, lenderName: lender.name, regulatoryId: 'DEMO-NBFC-MFI-0001', annualInterestRate: 0, processingFee: 0, tenureMonths: 12, terms: 'Interest-free micro-loan under CSR programme (demo). Monthly instalment ₹2,084.' }] });

  console.log('✓ demo data created\n');
  console.log('Demo accounts (password for all: ' + DEMO_PASSWORD + ', safety PIN for Priya: 2580)');
  for (const e of ['priya.demo', 'contact.demo', 'lawyer.demo', 'ngo.demo', 'counsellor.demo', 'responder.demo', 'police.demo', 'donor.demo', 'lender.demo', 'admin.demo']) console.log(`  • ${e}@raksha.app`);
  await mongoose.disconnect();
}

if (require.main === module) {
  main().catch(async (e) => {
    console.error(e);
    await mongoose.disconnect();
    process.exit(1);
  });
}
