import http from 'http';
import { env } from './config/env';
import { connectDB, disconnectDB } from './config/db';
import { createApp } from './app';
import { createSocketServer } from './sockets';
import { startScheduler, stopScheduler } from './services/scheduler';
import { logger } from './utils/logger';

async function main() {
  await connectDB();
  const app = createApp();
  const server = http.createServer(app);
  createSocketServer(server);
  if (process.env.RUN_SCHEDULER !== 'false') startScheduler();

  server.listen(env.PORT, () => {
    logger.info(`Raksha API listening on :${env.PORT} (${env.NODE_ENV})${env.DEMO_MODE ? ' — DEMO MODE: SOS and payments are simulated for demo accounts' : ''}`);
  });

  const shutdown = async (sig: string) => {
    logger.info(`${sig} received, shutting down`);
    stopScheduler();
    server.close();
    await disconnectDB();
    process.exit(0);
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (e: any) => logger.error('unhandledRejection', { err: e?.message }));
}

main().catch((e) => {
  logger.error('Failed to start', { err: e.message });
  process.exit(1);
});
