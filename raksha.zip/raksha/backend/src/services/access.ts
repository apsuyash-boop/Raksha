/**
 * Central authorization rules for sensitive resources.
 * Principle of least privilege: access is denied unless a rule explicitly grants it.
 */
import { Types } from 'mongoose';
import type { AuthUser } from '../types/express';
import { Appointment, Case, Complaint, Counsellor, EmergencyContact, Lawyer, LocationShare, NGO, SOSAlert, User } from '../models';

const sid = (x: any) => (x == null ? '' : String(x._id ?? x));

export async function professionalProfiles(userId: string) {
  const [lawyer, ngo, counsellor] = await Promise.all([
    Lawyer.findOne({ user: userId }).select('_id verified').lean<any>(),
    NGO.findOne({ user: userId }).select('_id verified').lean<any>(),
    Counsellor.findOne({ user: userId }).select('_id verified').lean<any>(),
  ]);
  return { lawyer, ngo, counsellor };
}

export type CaseAccess = 'owner' | 'assigned' | 'requested' | 'admin' | null;

export async function caseAccess(user: AuthUser, c: any): Promise<CaseAccess> {
  if (!c) return null;
  if (sid(c.user) === user.id) return 'owner';
  if (user.role === 'admin') return 'admin';
  if (user.role === 'lawyer' || user.role === 'ngo') {
    const p = await professionalProfiles(user.id);
    if (p.lawyer && c.lawyer && sid(c.lawyer) === sid(p.lawyer)) return 'assigned';
    if (p.ngo && c.ngo && sid(c.ngo) === sid(p.ngo)) return 'assigned';
    if ((c.requests || []).some((r: any) => sid(r.providerUser) === user.id && r.status === 'pending')) return 'requested';
  }
  return null;
}

/** Returns a reason string if access is granted, or null if denied. Admin access is handled by the caller (requires justification). */
export async function evidenceAccess(user: AuthUser, ev: any): Promise<string | null> {
  if (!ev || ev.deletedAt) return null;
  if (sid(ev.owner) === user.id) return 'owner';
  if ((ev.sharedWith || []).some((s: any) => sid(s.user) === user.id)) return 'explicit_share';

  if ((user.role === 'lawyer' || user.role === 'ngo') && user.verified && ev.cases?.length) {
    const p = await professionalProfiles(user.id);
    const or: any[] = [];
    if (p.lawyer) or.push({ lawyer: p.lawyer._id });
    if (p.ngo) or.push({ ngo: p.ngo._id });
    if (or.length) {
      const c = await Case.findOne({ _id: { $in: ev.cases }, user: ev.owner, 'consent.shareEvidenceWithAssigned': true, $or: or }).select('_id').lean();
      if (c) return 'assigned_case_with_consent';
    }
  }
  if (user.role === 'police' && user.verified) {
    const cmp = await Complaint.findOne({ evidence: ev._id, user: ev.owner, sharedWithPolice: new Types.ObjectId(user.id) }).select('_id').lean();
    if (cmp) return 'complaint_shared_with_police';
  }
  return null;
}

export async function isBlocked(a: string, b: string) {
  const users = await User.find({ _id: { $in: [a, b] } }).select('blockedUsers').lean<any[]>();
  return users.some((u) => (u.blockedUsers || []).some((x: any) => sid(x) === (sid(u._id) === a ? b : a)));
}

/** Two users may chat only if there is a legitimate relationship between them. */
export async function canChat(user: AuthUser, otherId: string): Promise<boolean> {
  if (!Types.ObjectId.isValid(otherId) || otherId === user.id) return false;
  const other = await User.findById(otherId).select('role status').lean<any>();
  if (!other || other.status !== 'active') return false;
  if (await isBlocked(user.id, otherId)) return false;
  if (user.role === 'admin' || other.role === 'admin') return true;

  const pair = [user.id, otherId];
  // Case relationship (owner <-> assigned lawyer / NGO)
  const [pa, pb] = await Promise.all([professionalProfiles(user.id), professionalProfiles(otherId)]);
  const profIds = [pa.lawyer?._id, pa.ngo?._id, pb.lawyer?._id, pb.ngo?._id].filter(Boolean);
  if (profIds.length) {
    const c = await Case.findOne({ user: { $in: pair }, $or: [{ lawyer: { $in: profIds } }, { ngo: { $in: profIds } }] }).select('_id').lean();
    if (c) return true;
  }
  // Counselling relationship
  const appt = await Appointment.findOne({
    $or: [
      { user: user.id, counsellorUser: otherId },
      { user: otherId, counsellorUser: user.id },
    ],
    status: { $in: ['requested', 'confirmed', 'completed'] },
  })
    .select('_id')
    .lean();
  if (appt) return true;
  // Emergency-contact relationship (linked accounts)
  const ec = await EmergencyContact.findOne({
    $or: [
      { owner: user.id, linkedUser: otherId },
      { owner: otherId, linkedUser: user.id },
    ],
  })
    .select('_id')
    .lean();
  if (ec) return true;
  // Accepted responder on an active SOS
  const sos = await SOSAlert.findOne({
    status: 'active',
    $or: [
      { user: user.id, responders: { $elemMatch: { user: otherId, status: { $in: ['accepted', 'arrived'] } } } },
      { user: otherId, responders: { $elemMatch: { user: user.id, status: { $in: ['accepted', 'arrived'] } } } },
    ],
  })
    .select('_id')
    .lean();
  return !!sos;
}

/**
 * Precise location of `ownerId` is visible only to:
 *  - the owner,
 *  - linked emergency contacts (with permission) while a share or SOS is active,
 *  - responders who ACCEPTED an active SOS.
 * Admins and unaccepted responders only ever receive approximate locations.
 */
export async function canViewPreciseLocation(user: AuthUser, ownerId: string): Promise<boolean> {
  if (user.id === ownerId) return true;
  const [activeSos, activeShare] = await Promise.all([
    SOSAlert.findOne({ user: ownerId, status: 'active' }).select('responders').lean<any>(),
    LocationShare.findOne({ user: ownerId, active: true, expiresAt: { $gt: new Date() } }).select('_id').lean(),
  ]);
  if (!activeSos && !activeShare) return false;
  const owner = await User.findById(ownerId).select('privacy').lean<any>();
  const contact = await EmergencyContact.findOne({ owner: ownerId, linkedUser: user.id, canViewLiveLocation: true }).select('_id').lean();
  if (contact && owner?.privacy?.shareLocationWithContacts !== false) return true;
  if (activeSos && (activeSos.responders || []).some((r: any) => sid(r.user) === user.id && ['accepted', 'arrived'].includes(r.status))) return true;
  return false;
}
