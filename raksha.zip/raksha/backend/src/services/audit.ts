import { Request } from 'express';
import { AuditLog } from '../models';
import { logger } from '../utils/logger';

export async function audit(
  req: Request | null,
  action: string,
  opts: { targetType?: string; targetId?: any; subjectUser?: any; meta?: Record<string, unknown>; actor?: any; actorRole?: string } = {},
) {
  try {
    await AuditLog.create({
      actor: opts.actor ?? req?.user?.id,
      actorRole: opts.actorRole ?? req?.user?.role,
      action,
      targetType: opts.targetType,
      targetId: opts.targetId,
      subjectUser: opts.subjectUser,
      ip: req?.ip,
      userAgent: req?.headers['user-agent']?.slice(0, 200),
      meta: opts.meta,
    });
  } catch (e: any) {
    logger.error('Audit log write failed', { action, err: e.message });
  }
}
