/**
 * Generates a structured complaint draft from the woman's own account.
 * Template-based (no AI) so the text is predictable and she stays in control of every word.
 * This is a DRAFT to help her; it is not legal advice and is not filed anywhere automatically.
 */
const TYPE_LABEL: Record<string, string> = {
  domestic_violence: 'domestic violence',
  dowry: 'dowry harassment',
  harassment: 'harassment',
  workplace_harassment: 'sexual harassment at the workplace',
  sexual_assault: 'sexual assault',
  cyber_crime: 'online harassment / cyber crime',
  divorce: 'matrimonial dispute',
  maintenance: 'non-payment of maintenance',
  child_custody: 'child custody dispute',
  other: 'an offence',
};

const fmtDate = (d?: Date | string) => (d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }) : '[date]');

export function buildComplaintDraft(input: { complainant: { name: string; age?: number; city?: string; state?: string; phone?: string }; incident: any; policeStation?: string; evidence?: Array<{ evidenceId: string; title?: string; category?: string; sha256: string; capturedAt?: Date }> }) {
  const { complainant: c, incident: i } = input;
  const accused = (i.accused || []).filter((a: any) => a?.name);
  const lines: string[] = [];
  lines.push('To,');
  lines.push(`The Station House Officer,`);
  lines.push(`${input.policeStation || '[Name of Police Station]'},`);
  lines.push(`${i.city || c.city || '[City]'}, ${i.state || c.state || '[State]'}`);
  lines.push('');
  lines.push(`Date: ${fmtDate(new Date())}`);
  lines.push('');
  lines.push(`Subject: Complaint regarding ${TYPE_LABEL[i.type] || 'an incident'} and request for necessary legal action`);
  lines.push('');
  lines.push('Respected Sir/Madam,');
  lines.push('');
  lines.push(
    `I, ${c.name}${c.age ? `, aged ${c.age} years` : ''}, resident of ${c.city || '[address]'}${c.state ? `, ${c.state}` : ''}, wish to report the following incident:`,
  );
  lines.push('');
  lines.push(`1. Date and time of incident: ${fmtDate(i.date)}${i.time ? ` at about ${i.time}` : ''}`);
  lines.push(`2. Place of incident: ${i.place || '[place]'}`);
  if (accused.length) {
    lines.push(`3. Person(s) responsible:`);
    accused.forEach((a: any, idx: number) => lines.push(`   ${String.fromCharCode(97 + idx)}) ${a.name}${a.relation ? ` (${a.relation})` : ''}${a.address ? `, ${a.address}` : ''}`));
  } else lines.push('3. Person(s) responsible: [name / description]');
  lines.push('4. Description of what happened, in my own words:');
  lines.push('');
  lines.push(String(i.description || '').trim() || '[Describe what happened]');
  lines.push('');
  if (i.injuries) lines.push(`5. Injuries / medical treatment: ${i.injuries}`);
  if (i.previousComplaints) lines.push(`6. Previous incidents / complaints: ${i.previousComplaints}`);
  if ((i.witnesses || []).filter((w: any) => w?.name).length)
    lines.push(`7. Witnesses: ${(i.witnesses || []).filter((w: any) => w?.name).map((w: any) => w.name).join(', ')}`);
  if (input.evidence?.length) {
    lines.push('');
    lines.push('Evidence enclosed (each item is preserved in the Raksha Evidence Vault with a SHA-256 fingerprint):');
    input.evidence.forEach((e, idx) => lines.push(`   ${idx + 1}. ${e.title || e.category} — ID ${e.evidenceId}${e.capturedAt ? `, recorded ${fmtDate(e.capturedAt)}` : ''}, SHA-256 ${e.sha256.slice(0, 16)}…`));
  }
  lines.push('');
  lines.push(
    'I request you to kindly register my complaint, take appropriate action against the person(s) responsible under the applicable law, and provide me with a copy of the FIR / complaint receipt free of cost.',
  );
  lines.push('');
  lines.push('I declare that the information given above is true to the best of my knowledge.');
  lines.push('');
  lines.push('Yours faithfully,');
  lines.push(c.name);
  if (c.phone) lines.push(`Contact: ${c.phone}`);
  lines.push('');
  lines.push('Signature: ____________________');
  return lines.join('\n');
}
