/**
 * Emergency-services (police / 112) integration layer.
 *
 * IMPORTANT: Raksha never claims police were contacted unless the configured
 * integration returns an explicit confirmation. Demo SOS events are ALWAYS
 * simulated and can never reach the real integration — this is enforced here
 * and covered by tests.
 */
import { env } from '../config/env';
import { logger } from '../utils/logger';

export interface EmergencyDispatchInput {
  alertId: string;
  isDemo: boolean;
  lat?: number;
  lng?: number;
  accuracy?: number;
  name?: string;
  phone?: string;
  message?: string;
}

export interface EmergencyDispatchResult {
  status: 'not_configured' | 'simulated' | 'pending' | 'confirmed' | 'failed';
  reference?: string;
  message: string;
}

/** Exposed for tests so we can assert the real transport is never invoked for demo alerts. */
export const emergencyTransport = {
  async post(url: string, payload: unknown, apiKey: string): Promise<any> {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify(payload),
    });
    const json: any = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`Emergency API HTTP ${res.status}`);
    return json;
  },
};

export async function dispatchEmergency(input: EmergencyDispatchInput): Promise<EmergencyDispatchResult> {
  if (input.isDemo) {
    return {
      status: 'simulated',
      message: 'Demo SOS — emergency services were NOT contacted. In a real emergency call 112.',
    };
  }
  if (!env.EMERGENCY_API_URL || !env.EMERGENCY_API_KEY) {
    return {
      status: 'not_configured',
      message: 'Emergency-service integration is not configured. Your contacts were alerted; please call 112 directly if you can.',
    };
  }
  try {
    const r = await emergencyTransport.post(
      env.EMERGENCY_API_URL,
      {
        externalId: input.alertId,
        location: input.lat != null ? { lat: input.lat, lng: input.lng, accuracy: input.accuracy } : undefined,
        caller: { name: input.name, phone: input.phone },
        message: input.message || 'Raksha SOS: woman in distress',
      },
      env.EMERGENCY_API_KEY,
    );
    // Only treat as confirmed if the integration explicitly says so.
    const confirmed = r?.confirmed === true || r?.status === 'confirmed' || r?.status === 'accepted';
    return {
      status: confirmed ? 'confirmed' : 'pending',
      reference: r?.reference || r?.incidentId,
      message: confirmed ? 'Emergency services confirmed receipt of your alert.' : 'Request sent to emergency services; awaiting confirmation.',
    };
  } catch (e: any) {
    logger.error('Emergency dispatch failed', { alertId: input.alertId, err: e.message });
    return { status: 'failed', message: 'Could not reach emergency services integration. Please call 112.' };
  }
}

/** Police complaint submission integration (e.g. a state CCTNS citizen-portal partner API). */
export async function submitComplaintToPolice(payload: { complaintNumber: string; text: string; isDemo: boolean }) {
  if (payload.isDemo) return { status: 'simulated' as const, message: 'Demo — complaint was NOT submitted to any police system.' };
  if (!env.POLICE_COMPLAINT_API_URL || !env.POLICE_COMPLAINT_API_KEY)
    return { status: 'not_configured' as const, message: 'Online police submission is not available yet. Download the complaint and submit it at the police station or your state police citizen portal.' };
  try {
    const r = await emergencyTransport.post(env.POLICE_COMPLAINT_API_URL, payload, env.POLICE_COMPLAINT_API_KEY);
    if (r?.acknowledged === true && r?.reference) return { status: 'confirmed' as const, reference: String(r.reference), message: 'Police system acknowledged the complaint.' };
    return { status: 'pending' as const, message: 'Sent; awaiting acknowledgement from the police system.' };
  } catch (e: any) {
    return { status: 'failed' as const, message: `Submission failed: ${e.message}` };
  }
}
