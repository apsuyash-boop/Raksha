import crypto from 'crypto';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function code(len: number) {
  const bytes = crypto.randomBytes(len);
  let s = '';
  for (let i = 0; i < len; i++) s += ALPHABET[bytes[i] % ALPHABET.length];
  return s;
}

const year = () => new Date().getFullYear();
export const caseNumber = () => `RK-${year()}-${code(6)}`;
export const complaintNumber = () => `CMP-${year()}-${code(6)}`;
export const evidenceId = () => `EV-${year()}-${code(8)}`;
export const receiptNumber = () => `RCPT-${year()}-${code(8)}`;
export const slugify = (s: string) =>
  `${s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60)}-${code(4).toLowerCase()}`;

const ALIASES = ['Marigold', 'Lotus', 'Jasmine', 'Peacock', 'Banyan', 'Monsoon', 'Saffron', 'Tulsi', 'Firefly', 'Sparrow', 'River', 'Kite', 'Lantern', 'Sunbird', 'Neem', 'Champa'];
export const anonymousAlias = () => `Anonymous ${ALIASES[crypto.randomInt(0, ALIASES.length)]}`;
