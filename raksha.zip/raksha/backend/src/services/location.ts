import { LocationEvent, LocationShare, SOSAlert } from '../models';
import { toPoint } from '../utils/geo';
import { realtime } from './realtime';

export interface LocationInput {
  lat: number;
  lng: number;
  accuracy?: number;
  speed?: number;
  heading?: number;
  battery?: number;
}

/**
 * Records a location update ONLY while the user has an active share or SOS (data minimisation),
 * and pushes it to authorised real-time rooms.
 */
export async function recordLocation(userId: string, i: LocationInput) {
  const now = new Date();
  const [sos, share] = await Promise.all([
    SOSAlert.findOne({ user: userId, status: 'active' }).select('_id'),
    LocationShare.findOne({ user: userId, active: true, expiresAt: { $gt: now } }).select('_id').lean<any>(),
  ]);
  if (!sos && !share) return { recorded: false, reason: 'No active sharing session or SOS' };

  const ev = await LocationEvent.create({
    user: userId,
    sos: sos?._id,
    share: share?._id,
    location: toPoint(i.lat, i.lng),
    accuracy: i.accuracy,
    speed: i.speed,
    heading: i.heading,
    battery: i.battery,
    recordedAt: now,
  });
  if (sos) await SOSAlert.updateOne({ _id: sos._id }, { location: toPoint(i.lat, i.lng), accuracy: i.accuracy });

  const payload = { userId, lat: i.lat, lng: i.lng, accuracy: i.accuracy, battery: i.battery, at: now, sosId: sos?._id };
  // `loc:<userId>` room membership is authorised in the socket layer (canViewPreciseLocation).
  realtime.toRoom(`loc:${userId}`, 'location:update', payload);
  return { recorded: true, id: ev._id };
}
