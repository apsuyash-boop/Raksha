/**
 * Lawyer / NGO matching engine.
 * Deterministic, explainable weighted scoring. Only VERIFIED professionals are ever returned.
 */
import { Lawyer, NGO } from '../models';

export interface MatchInput {
  caseType: string;
  state?: string;
  city?: string;
  language?: string;
  budget?: 'free' | 'low' | 'standard' | 'any';
  urgency?: 'low' | 'medium' | 'high' | 'emergency';
  service?: string; // legal_aid, shelter, rescue, counselling, court_representation...
  lat?: number;
  lng?: number;
}

const W = { specialization: 35, location: 20, language: 15, availability: 15, budget: 10, rating: 5 };

const norm = (s?: string) => (s || '').trim().toLowerCase();

function locationScore(p: any, i: MatchInput) {
  if (i.city && norm(p.city) === norm(i.city)) return { s: 1, why: `Based in ${p.city}` };
  if (i.city && (p.serviceAreas || []).map(norm).includes(norm(i.city))) return { s: 0.9, why: `Serves ${i.city}` };
  if (i.state && norm(p.state) === norm(i.state)) return { s: 0.6, why: `Same state (${p.state})` };
  return { s: 0.1, why: '' };
}

function availabilityScore(p: any, urgency?: string) {
  const base = p.availability === 'available' ? 1 : p.availability === 'limited' ? 0.5 : 0;
  if ((urgency === 'emergency' || urgency === 'high') && p.is24x7) return { s: 1, why: 'Available 24×7' };
  return { s: base, why: base === 1 ? 'Taking new cases' : base > 0 ? 'Limited availability' : '' };
}

export async function matchLawyers(i: MatchInput, limit = 10) {
  const q: any = { verified: true, availability: { $ne: 'unavailable' } };
  const pool = await Lawyer.find(q).populate('user', 'name avatarColor').limit(300).lean<any[]>();
  const scored = pool.map((p) => {
    const reasons: string[] = [];
    let score = 0;
    const spec = (p.specializations || []).includes(i.caseType) ? 1 : (p.specializations || []).includes('other') ? 0.3 : 0;
    if (spec === 1) reasons.push('Specialises in this type of case');
    score += spec * W.specialization;
    const loc = locationScore(p, i);
    if (loc.why) reasons.push(loc.why);
    score += loc.s * W.location;
    const lang = i.language && (p.languages || []).includes(i.language) ? 1 : !i.language ? 0.5 : 0;
    if (lang === 1) reasons.push('Speaks your language');
    score += lang * W.language;
    const av = availabilityScore(p, i.urgency);
    if (av.why) reasons.push(av.why);
    score += av.s * W.availability;
    let budget = 0.5;
    if (i.budget === 'free') budget = p.proBono || p.feeType === 'pro_bono' ? 1 : 0;
    else if (i.budget === 'low') budget = p.feeType === 'standard' ? 0.3 : 1;
    else budget = 1;
    if (p.proBono || p.feeType === 'pro_bono') reasons.push('Offers free (pro bono) help');
    else if (p.freeFirstConsultation) reasons.push('Free first consultation');
    score += budget * W.budget;
    score += ((p.rating || 0) / 5) * W.rating;
    if (i.service && (p.services || []).includes(i.service)) score += 5;
    return { type: 'lawyer' as const, profile: sanitizeProfile(p), score: Math.round(score), reasons };
  });
  return scored.filter((s) => s.score >= 30).sort((a, b) => b.score - a.score).slice(0, limit);
}

export async function matchNGOs(i: MatchInput, limit = 10) {
  const pool = await NGO.find({ verified: true, availability: { $ne: 'unavailable' } }).populate('user', 'name avatarColor').limit(300).lean<any[]>();
  const scored = pool.map((p) => {
    const reasons: string[] = [];
    let score = 0;
    const spec = (p.focusAreas || []).includes(i.caseType) ? 1 : 0.2;
    if (spec === 1) reasons.push('Works on this type of case');
    score += spec * W.specialization;
    const loc = locationScore(p, i);
    if (loc.why) reasons.push(loc.why);
    score += loc.s * W.location;
    const lang = i.language && (p.languages || []).includes(i.language) ? 1 : !i.language ? 0.5 : 0;
    if (lang === 1) reasons.push('Speaks your language');
    score += lang * W.language;
    const av = availabilityScore(p, i.urgency);
    if (av.why) reasons.push(av.why);
    score += av.s * W.availability;
    score += W.budget; // NGO services are free to beneficiaries
    reasons.push('Free services');
    if (i.service && (p.services || []).includes(i.service)) {
      score += 10;
      reasons.push(`Provides ${i.service.replace(/_/g, ' ')}`);
    }
    if (p.isOneStopCentre) reasons.push('Government One Stop Centre');
    if (p.shelterAvailable > 0) reasons.push(`${p.shelterAvailable} shelter place(s) available`);
    score += ((p.rating || 0) / 5) * W.rating;
    return { type: 'ngo' as const, profile: sanitizeProfile(p), score: Math.round(score), reasons };
  });
  return scored.filter((s) => s.score >= 30).sort((a, b) => b.score - a.score).slice(0, limit);
}

/** Strip private verification identifiers from public profiles. */
export function sanitizeProfile(p: any) {
  const { barCouncilId, registrationNumber, licenseNumber, location, ...rest } = p;
  void barCouncilId;
  void registrationNumber;
  void licenseNumber;
  void location;
  rest.reviews = (rest.reviews || []).slice(-5).map((r: any) => ({ rating: r.rating, text: r.text, at: r.at }));
  return rest;
}
