/**
 * Outbound messaging abstraction (SMS, WhatsApp, Email).
 *
 * Each provider returns an honest delivery status:
 *  - "sent"            provider API accepted the message (we have a provider reference)
 *  - "simulated"       demo mode — NOTHING was sent to a real phone/email
 *  - "not_configured"  no credentials configured — nothing was sent
 *  - "failed"          provider returned an error
 */
import nodemailer from 'nodemailer';
import { env } from '../config/env';
import { logger } from '../utils/logger';

export type Channel = 'sms' | 'whatsapp' | 'email';
export interface DeliveryResult {
  status: 'sent' | 'simulated' | 'not_configured' | 'failed';
  providerRef?: string;
  error?: string;
}
export interface SendOptions {
  demo?: boolean;
  subject?: string;
}

/** In-memory outbox used in demo/test so the UI and tests can show exactly what *would* have been sent. */
export const demoOutbox: Array<{ channel: Channel; to: string; body: string; at: Date }> = [];

function simulate(channel: Channel, to: string, body: string): DeliveryResult {
  demoOutbox.push({ channel, to, body, at: new Date() });
  if (demoOutbox.length > 500) demoOutbox.shift();
  logger.info('[DEMO] message simulated (not sent)', { channel, to: mask(to) });
  return { status: 'simulated', providerRef: `demo-${Date.now()}` };
}

export const mask = (s: string) => (s.length <= 4 ? '****' : `${'*'.repeat(Math.max(0, s.length - 4))}${s.slice(-4)}`);

async function postJson(url: string, body: unknown, headers: Record<string, string>) {
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });
  const text = await res.text();
  let json: any = {};
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text };
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${text.slice(0, 200)}`);
  return json;
}

/* --------------------------------- SMS --------------------------------- */
async function sendSms(to: string, body: string, opts: SendOptions): Promise<DeliveryResult> {
  if (opts.demo) return simulate('sms', to, body);
  if (!env.SMS_API_KEY || !env.SMS_API_URL) return { status: 'not_configured', error: 'SMS provider not configured' };
  try {
    // Generic JSON SMS gateway contract. Adapt payload to your provider (MSG91, Twilio, Gupshup, etc.).
    const r = await postJson(env.SMS_API_URL, { to, message: body, sender: env.SMS_SENDER_ID }, { Authorization: `Bearer ${env.SMS_API_KEY}` });
    return { status: 'sent', providerRef: String(r.id || r.messageId || r.request_id || 'accepted') };
  } catch (e: any) {
    logger.warn('SMS send failed', { err: e.message });
    return { status: 'failed', error: e.message };
  }
}

/* ------------------------------- WhatsApp ------------------------------ */
async function sendWhatsApp(to: string, body: string, opts: SendOptions): Promise<DeliveryResult> {
  if (opts.demo) return simulate('whatsapp', to, body);
  if (!env.WHATSAPP_API_KEY || !env.WHATSAPP_PHONE_NUMBER_ID) return { status: 'not_configured', error: 'WhatsApp API not configured' };
  try {
    // WhatsApp Cloud API. Note: business-initiated messages outside a 24h window require an approved template.
    const r = await postJson(
      `${env.WHATSAPP_API_URL}/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
      { messaging_product: 'whatsapp', to: to.replace(/[^\d]/g, ''), type: 'text', text: { body } },
      { Authorization: `Bearer ${env.WHATSAPP_API_KEY}` },
    );
    return { status: 'sent', providerRef: r?.messages?.[0]?.id || 'accepted' };
  } catch (e: any) {
    logger.warn('WhatsApp send failed', { err: e.message });
    return { status: 'failed', error: e.message };
  }
}

/* -------------------------------- Email -------------------------------- */
let transporter: nodemailer.Transporter | null = null;
function getTransport() {
  if (!env.SMTP_HOST) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT,
      secure: env.SMTP_PORT === 465,
      auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS || env.EMAIL_API_KEY } : undefined,
    });
  }
  return transporter;
}

async function sendEmail(to: string, body: string, opts: SendOptions): Promise<DeliveryResult> {
  if (opts.demo) return simulate('email', to, `${opts.subject || ''}\n${body}`);
  const t = getTransport();
  if (!t) return { status: 'not_configured', error: 'Email (SMTP) not configured' };
  try {
    const info = await t.sendMail({ from: env.EMAIL_FROM, to, subject: opts.subject || 'Raksha notification', text: body });
    return { status: 'sent', providerRef: info.messageId };
  } catch (e: any) {
    logger.warn('Email send failed', { err: e.message });
    return { status: 'failed', error: e.message };
  }
}

export async function sendMessage(channel: Channel, to: string, body: string, opts: SendOptions = {}): Promise<DeliveryResult> {
  if (!to) return { status: 'failed', error: 'No destination' };
  if (channel === 'sms') return sendSms(to, body, opts);
  if (channel === 'whatsapp') return sendWhatsApp(to, body, opts);
  return sendEmail(to, body, opts);
}

export function providerStatus() {
  return {
    sms: !!(env.SMS_API_KEY && env.SMS_API_URL),
    whatsapp: !!(env.WHATSAPP_API_KEY && env.WHATSAPP_PHONE_NUMBER_ID),
    email: !!env.SMTP_HOST,
    emergency: !!(env.EMERGENCY_API_URL && env.EMERGENCY_API_KEY),
    policeComplaints: !!(env.POLICE_COMPLAINT_API_URL && env.POLICE_COMPLAINT_API_KEY),
    payments: !!(env.RAZORPAY_KEY_ID && env.RAZORPAY_KEY_SECRET),
    storage: env.STORAGE_DRIVER,
    malwareScan: !!env.CLAMAV_HOST,
    streaming: !!env.STREAMING_SERVER_URL,
    maps: env.MAPS_PROVIDER,
    demoMode: env.DEMO_MODE,
  };
}
