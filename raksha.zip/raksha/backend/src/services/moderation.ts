/**
 * Automatic moderation (first pass). Anything flagged goes to the manual review queue
 * instead of being published. Admin-configurable keywords live in Setting "moderation.keywords".
 */
import sanitizeHtml from 'sanitize-html';
import { Setting } from '../models';

const DEFAULT_BLOCKLIST = ['kill you', 'rape you', 'slut', 'whore', 'randi', 'kutiya', 'chutiya', 'madarchod', 'bhenchod', 'behenchod'];

const PII_PATTERNS: Array<[RegExp, string]> = [
  [/(?:\+?91[\s-]?)?[6-9]\d{9}\b/, 'phone_number'],
  [/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i, 'email_address'],
  [/\b\d{4}\s?\d{4}\s?\d{4}\b/, 'possible_aadhaar_number'],
  [/\b(?:house|h\.?\s?no|flat)\s*(?:no\.?)?\s*\d+/i, 'street_address'],
];

/** Strip ALL HTML. Community content is stored and rendered as plain text. */
export const cleanText = (s: string) => sanitizeHtml(s || '', { allowedTags: [], allowedAttributes: {} }).trim();

export async function autoModerate(text: string, opts: { anonymous?: boolean } = {}) {
  const flags: string[] = [];
  const lower = text.toLowerCase();
  const s = await Setting.findOne({ key: 'moderation.keywords' }).lean<any>();
  const words: string[] = Array.isArray(s?.value) && s.value.length ? s.value : DEFAULT_BLOCKLIST;
  if (words.some((w) => lower.includes(w.toLowerCase()))) flags.push('abusive_language');
  for (const [re, label] of PII_PATTERNS) if (re.test(text)) flags.push(label);
  if (/(https?:\/\/|www\.)\S+/i.test(text) && (text.match(/https?:\/\//g) || []).length > 2) flags.push('many_links');
  if (/\b(suicide|kill myself|end my life|want to die)\b/i.test(text)) flags.push('self_harm_risk');
  // Anonymous posts that contain identifying details are held so the author is protected.
  const hold = flags.length > 0;
  return { flags, status: hold ? ('pending_review' as const) : ('published' as const), anonymous: !!opts.anonymous };
}
