import { Notification, User } from '../models';
import { realtime } from './realtime';
import { sendMessage } from './messaging';
import { env } from '../config/env';

interface NotifyInput {
  type: string;
  title: string;
  body?: string;
  link?: string;
  priority?: 'normal' | 'high' | 'critical';
  meta?: Record<string, unknown>;
  /** Also send via external channels the user has enabled. */
  external?: boolean;
}

export async function notify(userId: any, input: NotifyInput) {
  const n = await Notification.create({ user: userId, ...input, deliveries: [{ channel: 'in_app', status: 'delivered' }] });
  realtime.toUser(String(userId), 'notification', n.toJSON());

  if (input.external) {
    const u = await User.findById(userId).select('email phone notificationPrefs isDemo').lean<any>();
    if (u) {
      const demo = env.DEMO_MODE && u.isDemo;
      const text = `${input.title}${input.body ? ` — ${input.body}` : ''}${input.link ? `\n${env.APP_URL}${input.link}` : ''}`;
      const deliveries: any[] = [];
      if (u.notificationPrefs?.email && u.email) deliveries.push({ channel: 'email', ...(await sendMessage('email', u.email, text, { demo, subject: input.title })) });
      if (u.notificationPrefs?.sms && u.phone && input.priority !== 'normal') deliveries.push({ channel: 'sms', ...(await sendMessage('sms', u.phone, text, { demo })) });
      if (u.notificationPrefs?.whatsapp && u.phone) deliveries.push({ channel: 'whatsapp', ...(await sendMessage('whatsapp', u.phone, text, { demo })) });
      if (deliveries.length) await Notification.updateOne({ _id: n._id }, { $push: { deliveries: { $each: deliveries.map((d) => ({ channel: d.channel, status: d.status })) } } });
    }
  }
  return n;
}

export async function notifyMany(userIds: any[], input: NotifyInput) {
  await Promise.all(userIds.map((id) => notify(id, input)));
}
