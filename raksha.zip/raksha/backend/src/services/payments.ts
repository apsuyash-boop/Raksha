/**
 * Payments: Create Order → Payment → Verify Signature (server) → Update Transaction → Receipt.
 *
 * - Razorpay is used when RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET are configured.
 * - Otherwise, in DEMO_MODE only, a clearly-labelled mock gateway is used. The mock signs with a
 *   server-only secret, so the frontend can NEVER fabricate a successful payment.
 */
import crypto from 'crypto';
import { env } from '../config/env';
import { hmacSha256, safeEqual } from '../utils/crypto';
import { AppError } from '../utils/http';

const MOCK_SECRET = crypto.randomBytes(32).toString('hex'); // process-local, never sent to clients

export type Gateway = 'razorpay' | 'mock';

export function activeGateway(): Gateway | null {
  if (env.RAZORPAY_KEY_ID && env.RAZORPAY_KEY_SECRET) return 'razorpay';
  if (env.DEMO_MODE) return 'mock';
  return null;
}

export async function createOrder(amountInr: number, receipt: string, notes: Record<string, string> = {}) {
  const gateway = activeGateway();
  if (!gateway) throw AppError.unavailable('Payments are not configured');
  const amountPaise = Math.round(amountInr * 100);
  if (gateway === 'mock') {
    return { gateway, orderId: `order_mock_${crypto.randomBytes(8).toString('hex')}`, amount: amountPaise, currency: 'INR', keyId: 'mock' };
  }
  const auth = Buffer.from(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`).toString('base64');
  const res = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ amount: amountPaise, currency: 'INR', receipt: receipt.slice(0, 40), notes }),
  });
  const json: any = await res.json();
  if (!res.ok) throw new AppError(502, json?.error?.description || 'Could not create payment order', 'PAYMENT_GATEWAY_ERROR');
  return { gateway, orderId: json.id as string, amount: json.amount as number, currency: json.currency as string, keyId: env.RAZORPAY_KEY_ID };
}

/** Razorpay checkout signature = HMAC_SHA256(order_id + "|" + payment_id, key_secret). */
export function verifyPaymentSignature(gateway: Gateway, orderId: string, paymentId: string, signature: string) {
  if (!orderId || !paymentId || !signature) return false;
  const secret = gateway === 'razorpay' ? env.RAZORPAY_KEY_SECRET : MOCK_SECRET;
  if (!secret) return false;
  const expected = hmacSha256(secret, `${orderId}|${paymentId}`);
  return safeEqual(expected, signature);
}

/** Webhook signature = HMAC_SHA256(raw_body, webhook_secret). */
export function verifyWebhookSignature(rawBody: Buffer, signature: string) {
  if (!env.RAZORPAY_WEBHOOK_SECRET || !signature) return false;
  return safeEqual(hmacSha256(env.RAZORPAY_WEBHOOK_SECRET, rawBody.toString('utf8')), signature);
}

/**
 * DEMO ONLY: simulates the gateway completing a payment (what Razorpay Checkout does in the browser).
 * The signature is produced server-side with a secret the client never sees, and still has to pass
 * verifyPaymentSignature in the normal /verify endpoint.
 */
export function mockGatewayPay(orderId: string) {
  if (activeGateway() !== 'mock') throw AppError.forbidden('Mock payments are disabled');
  if (!orderId.startsWith('order_mock_')) throw AppError.badRequest('Not a mock order');
  const paymentId = `pay_mock_${crypto.randomBytes(8).toString('hex')}`;
  return { orderId, paymentId, signature: hmacSha256(MOCK_SECRET, `${orderId}|${paymentId}`) };
}

export function feeFor(amount: number) {
  return Math.round(((amount * env.PLATFORM_FEE_PERCENT) / 100) * 100) / 100;
}
