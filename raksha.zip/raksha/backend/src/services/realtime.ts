import type { Server } from 'socket.io';

/** Holds the Socket.io server so services can emit without circular imports. */
let io: Server | null = null;

export const realtime = {
  attach(server: Server) {
    io = server;
  },
  toUser(userId: string, event: string, payload: unknown) {
    io?.to(`user:${userId}`).emit(event, payload);
  },
  toRoom(room: string, event: string, payload: unknown) {
    io?.to(room).emit(event, payload);
  },
  get io() {
    return io;
  },
};
