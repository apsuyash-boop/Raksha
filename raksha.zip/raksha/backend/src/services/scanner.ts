/**
 * Malware scanning via ClamAV's clamd INSTREAM protocol.
 * If CLAMAV_HOST is not configured the file is marked "not_scanned" (never "clean").
 */
import net from 'net';
import { env } from '../config/env';

export type ScanStatus = 'not_scanned' | 'clean' | 'infected' | 'error';

export function scanBuffer(buf: Buffer): Promise<{ status: ScanStatus; signature?: string }> {
  if (!env.CLAMAV_HOST) return Promise.resolve({ status: 'not_scanned' });
  return new Promise((resolve) => {
    const socket = net.createConnection({ host: env.CLAMAV_HOST, port: env.CLAMAV_PORT });
    let response = '';
    const done = (r: { status: ScanStatus; signature?: string }) => {
      socket.destroy();
      resolve(r);
    };
    socket.setTimeout(30000, () => done({ status: 'error' }));
    socket.on('error', () => done({ status: 'error' }));
    socket.on('data', (d) => (response += d.toString()));
    socket.on('end', () => {
      if (/OK\s*$/.test(response.trim()) && !/FOUND/.test(response)) return done({ status: 'clean' });
      const m = response.match(/stream: (.+) FOUND/);
      if (m) return done({ status: 'infected', signature: m[1] });
      done({ status: 'error' });
    });
    socket.on('connect', () => {
      socket.write('zINSTREAM\0');
      const chunk = 64 * 1024;
      for (let i = 0; i < buf.length; i += chunk) {
        const part = buf.subarray(i, i + chunk);
        const len = Buffer.alloc(4);
        len.writeUInt32BE(part.length, 0);
        socket.write(len);
        socket.write(part);
      }
      socket.write(Buffer.from([0, 0, 0, 0]));
    });
  });
}
