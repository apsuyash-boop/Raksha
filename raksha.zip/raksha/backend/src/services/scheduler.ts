/**
 * Lightweight in-process scheduler for reminders and housekeeping.
 * For multi-instance deployments, run this in a single worker (set RUN_SCHEDULER=true on one instance).
 */
import { Appointment, Case, LocationShare } from '../models';
import { notify } from './notify';
import { logger } from '../utils/logger';

let timer: NodeJS.Timeout | null = null;

export async function runRemindersOnce() {
  const now = new Date();
  // Appointment reminders (next 60 minutes)
  const soon = await Appointment.find({ status: 'confirmed', reminderSent: false, scheduledAt: { $gte: now, $lte: new Date(now.getTime() + 60 * 60 * 1000) } }).limit(200);
  for (const a of soon) {
    const when = a.scheduledAt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata' });
    await notify(a.user, { type: 'appointment_reminder', title: `Counselling session at ${when}`, body: `Your ${a.mode} session starts soon.`, link: '/counselling', external: true });
    await notify(a.counsellorUser, { type: 'appointment_reminder', title: `Session at ${when}`, body: 'You have an upcoming session.', link: '/counsellor/dashboard' });
    a.reminderSent = true;
    await a.save();
  }
  // Court hearing reminders (next 24 hours)
  const cases = await Case.find({ hearings: { $elemMatch: { reminderSent: false, date: { $gte: now, $lte: new Date(now.getTime() + 24 * 3600 * 1000) } } } }).limit(200);
  for (const c of cases) {
    for (const h of c.hearings as any[]) {
      if (!h.reminderSent && h.date >= now && h.date <= new Date(now.getTime() + 24 * 3600 * 1000)) {
        await notify(c.user, { type: 'hearing_reminder', title: `Court hearing tomorrow: ${h.purpose || 'hearing'}`, body: `${h.court || ''} — ${h.date.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}`, link: `/cases/${c._id}`, external: true, priority: 'high' });
        h.reminderSent = true;
      }
    }
    await c.save();
  }
  // Expire location shares
  await LocationShare.updateMany({ active: true, expiresAt: { $lte: now } }, { active: false, stoppedAt: now });
}

export function startScheduler(intervalMs = 60_000) {
  if (timer) return;
  timer = setInterval(() => runRemindersOnce().catch((e) => logger.error('scheduler error', { err: e.message })), intervalMs);
  timer.unref();
}

export function stopScheduler() {
  if (timer) clearInterval(timer);
  timer = null;
}
