/**
 * Scheme eligibility checker.
 *
 * Returns, for each scheme, one of:
 *  - "likely_eligible"   every rule we hold was checked and passed
 *  - "check_details"     no rule failed, but some information is missing or not machine-checkable
 *  - "not_eligible"      at least one official rule clearly fails
 *
 * We never invent rules. Rules come only from Scheme.criteria (admin-maintained from official sources),
 * and the official source link is always returned for final confirmation.
 */
export interface EligibilityProfile {
  state?: string;
  age?: number;
  gender?: 'female' | 'male' | 'other';
  annualFamilyIncome?: number;
  maritalStatus?: 'single' | 'married' | 'widowed' | 'divorced' | 'separated';
  pregnantOrLactating?: boolean;
  hasGirlChildUnder10?: boolean;
  wantsToStartBusiness?: boolean;
  isGovtEmployee?: boolean;
  paysIncomeTax?: boolean;
  employment?: 'unemployed' | 'self_employed' | 'salaried' | 'student' | 'homemaker' | 'other';
}

export function evaluateScheme(s: any, p: EligibilityProfile) {
  const c = s.criteria || {};
  const pass: string[] = [];
  const fail: string[] = [];
  const unknown: string[] = [];

  const check = (cond: boolean | undefined, okMsg: string, failMsg: string, unknownMsg: string) => {
    if (cond === undefined) unknown.push(unknownMsg);
    else if (cond) pass.push(okMsg);
    else fail.push(failMsg);
  };

  if (s.level === 'state' && s.states?.length) {
    check(p.state ? s.states.map((x: string) => x.toLowerCase()).includes(p.state.toLowerCase()) : undefined, `Available in ${p.state}`, `Only for residents of ${s.states.join(', ')}`, 'State of residence');
  }
  if (c.gender === 'female') check(p.gender ? p.gender === 'female' : undefined, 'For women', 'This scheme is for women', 'Gender');
  if (c.minAge != null || c.maxAge != null) {
    const okAge = p.age == null ? undefined : (c.minAge == null || p.age >= c.minAge) && (c.maxAge == null || p.age <= c.maxAge);
    const range = `${c.minAge ?? ''}${c.minAge != null && c.maxAge != null ? '–' : ''}${c.maxAge ?? ''}`;
    check(okAge, `Age within ${range}`, `Age must be ${range}`, 'Age');
  }
  if (c.maxAnnualFamilyIncome != null)
    check(
      p.annualFamilyIncome == null ? undefined : p.annualFamilyIncome <= c.maxAnnualFamilyIncome,
      `Family income within ₹${c.maxAnnualFamilyIncome.toLocaleString('en-IN')}`,
      `Family income must be ≤ ₹${c.maxAnnualFamilyIncome.toLocaleString('en-IN')} per year`,
      'Annual family income',
    );
  if (c.maritalStatus?.length)
    check(p.maritalStatus ? c.maritalStatus.includes(p.maritalStatus) : undefined, 'Marital status matches', `For women who are ${c.maritalStatus.join(' / ')}`, 'Marital status');
  if (c.requiresPregnantOrLactating) check(p.pregnantOrLactating, 'Pregnant or nursing mother', 'For pregnant women and nursing mothers', 'Pregnancy / nursing');
  if (c.requiresGirlChildUnder10) check(p.hasGirlChildUnder10, 'Has a girl child under 10', 'Requires a girl child below 10 years', 'Girl child under 10');
  if (c.requiresEntrepreneur) check(p.wantsToStartBusiness, 'Starting a new enterprise', 'For women setting up a new (greenfield) enterprise', 'Business plans');
  if (c.excludesGovtEmployees) check(p.isGovtEmployee === undefined ? undefined : !p.isGovtEmployee, 'Not a regular government employee', 'Not for regular government employees', 'Government employment');
  if (c.excludesIncomeTaxPayers) check(p.paysIncomeTax === undefined ? undefined : !p.paysIncomeTax, 'Not an income-tax payer', 'Not for income-tax payers', 'Income-tax status');

  const result = fail.length ? 'not_eligible' : unknown.length ? 'check_details' : 'likely_eligible';
  return { result, pass, fail, unknown };
}

export function rankSchemes(schemes: any[], profile: EligibilityProfile) {
  const order = { likely_eligible: 0, check_details: 1, not_eligible: 2 } as const;
  return schemes
    .map((s) => ({ scheme: s, ...evaluateScheme(s, profile) }))
    .sort((a, b) => order[a.result as keyof typeof order] - order[b.result as keyof typeof order] || b.pass.length - a.pass.length);
}
