import { env } from '../config/env';
import { EmergencyContact, LocationEvent, LocationShare, Responder, SOSAlert, User } from '../models';
import { approximate, haversineKm, mapsLink, toPoint } from '../utils/geo';
import { randomToken, sha256 } from '../utils/crypto';
import { sendMessage, Channel } from './messaging';
import { dispatchEmergency } from './emergency';
import { notify } from './notify';
import { realtime } from './realtime';
import { logger } from '../utils/logger';

export interface StartSOSInput {
  lat?: number;
  lng?: number;
  accuracy?: number;
  message?: string;
  trigger?: string;
  simulate?: boolean;
}

const fmtTime = (d: Date) => d.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour12: true });

export function sosRoom(id: string) {
  return `sos:${id}`;
}

function publicTimeline(alert: any) {
  return (alert.timeline || []).filter((t: any) => t.step !== 'location_update');
}

/** Serialise an SOS alert for the woman herself (full detail). */
export function ownerView(alert: any) {
  const a = alert.toJSON ? alert.toJSON() : alert;
  delete a.trackTokenHash;
  a.timeline = publicTimeline(a);
  return a;
}

/** Serialise for a responder. Precise location only after acceptance. */
export function responderView(alert: any, responderUserId: string, owner?: any) {
  const me = (alert.responders || []).find((r: any) => String(r.user) === responderUserId);
  const accepted = me && ['accepted', 'arrived', 'completed'].includes(me.status);
  const [lng, lat] = alert.location?.coordinates || [];
  return {
    id: alert._id,
    status: alert.status,
    isDemo: alert.isDemo,
    createdAt: alert.createdAt,
    myStatus: me?.status,
    distanceKm: me?.distanceKm,
    location: lat == null ? null : accepted ? { lat, lng, accuracy: alert.accuracy, precise: true } : { ...approximate(lat, lng), precise: false },
    person: accepted && owner ? { firstName: String(owner.name || '').split(' ')[0] } : null,
    message: accepted ? alert.message : undefined,
  };
}

export async function startSOS(userId: string, input: StartSOSInput) {
  const user = await User.findById(userId).select('name phone isDemo privacy').lean<any>();
  if (!user) throw new Error('User not found');
  const isDemo = !!user.isDemo || !!input.simulate;

  const existing = await SOSAlert.findOne({ user: userId, status: 'active' });
  if (existing) return { alert: existing, trackUrl: null, reused: true };

  const token = randomToken(24);
  const hasLoc = typeof input.lat === 'number' && typeof input.lng === 'number';
  const alert = await SOSAlert.create({
    user: userId,
    isDemo,
    trigger: input.trigger || 'button',
    message: input.message?.slice(0, 500),
    location: hasLoc ? toPoint(input.lat!, input.lng!) : undefined,
    accuracy: input.accuracy,
    trackTokenHash: sha256(token),
    timeline: [{ step: 'activated', label: isDemo ? 'SOS activated (DEMO — simulated)' : 'SOS activated', at: new Date() }],
  });
  const trackUrl = `${env.APP_URL}/track/${token}`;

  // Live location sharing runs for the life of the SOS.
  await LocationShare.create({ user: userId, active: true, expiresAt: new Date(Date.now() + 24 * 3600 * 1000), reason: 'sos', sos: alert._id, trackTokenHash: sha256(token) });
  if (hasLoc) await LocationEvent.create({ user: userId, sos: alert._id, location: toPoint(input.lat!, input.lng!), accuracy: input.accuracy });

  // Run the fan-out in parallel. Each step records an honest outcome.
  const [contactsRes, respondersRes, emergencyRes] = await Promise.allSettled([
    alertContacts(alert, user, trackUrl, isDemo),
    alertResponders(alert, user, isDemo),
    dispatchEmergency({ alertId: String(alert._id), isDemo, lat: input.lat, lng: input.lng, accuracy: input.accuracy, name: user.name, phone: user.phone, message: input.message }),
  ]);

  if (contactsRes.status === 'fulfilled') {
    alert.contactDeliveries = contactsRes.value.deliveries as any;
    alert.contactsAlertedAt = new Date();
    const delivered = contactsRes.value.deliveries.filter((d) => d.status === 'sent' || d.status === 'simulated').length;
    alert.timeline.push({
      step: 'contacts_alerted',
      label: contactsRes.value.contacts === 0 ? 'No emergency contacts saved' : `${delivered} alert(s) ${isDemo ? 'simulated' : 'delivered'} to ${contactsRes.value.contacts} contact(s)`,
      at: new Date(),
      meta: { delivered, total: contactsRes.value.deliveries.length },
    });
  } else logger.error('contact alert failed', { err: String(contactsRes.reason) });

  if (respondersRes.status === 'fulfilled') {
    alert.responders = respondersRes.value as any;
    alert.timeline.push({ step: 'responders_notified', label: respondersRes.value.length ? `${respondersRes.value.length} verified responder(s) nearby notified` : 'No verified responders available nearby', at: new Date() });
  }

  if (emergencyRes.status === 'fulfilled') {
    alert.emergencyService = { ...emergencyRes.value, at: new Date() } as any;
    alert.timeline.push({ step: 'emergency_service', label: emergencyRes.value.message, at: new Date(), meta: { status: emergencyRes.value.status } });
  }

  await alert.save();
  realtime.toUser(userId, 'sos:update', ownerView(alert));
  return { alert, trackUrl, reused: false };
}

async function alertContacts(alert: any, user: any, trackUrl: string, isDemo: boolean) {
  const contacts = await EmergencyContact.find({ owner: user._id }).sort({ priority: 1 }).lean<any[]>();
  const [lng, lat] = alert.location?.coordinates || [];
  const prefix = isDemo ? '[RAKSHA DEMO — NOT A REAL EMERGENCY] ' : '';
  const body =
    `${prefix}RAKSHA SOS: ${user.name} needs help.` +
    (lat != null ? ` Location: ${mapsLink(lat, lng)}${alert.accuracy ? ` (±${Math.round(alert.accuracy)} m)` : ''}.` : ' Location unavailable.') +
    ` Time: ${fmtTime(alert.createdAt)} IST. Live tracking: ${trackUrl}` +
    (alert.message ? ` Message: "${alert.message}"` : '') +
    (isDemo ? '' : ' If you cannot reach her, call 112.');

  const deliveries: any[] = [];
  await Promise.all(
    contacts.map(async (c) => {
      const jobs: Array<Promise<void>> = [];
      const push = (channel: Channel | 'app', p: Promise<any>) =>
        jobs.push(p.then((r) => void deliveries.push({ contact: c._id, name: c.name, channel, ...r })));
      if (c.channels?.sms && c.phone) push('sms', sendMessage('sms', c.phone, body, { demo: isDemo }));
      if (c.channels?.whatsapp && c.phone) push('whatsapp', sendMessage('whatsapp', c.phone, body, { demo: isDemo }));
      if (c.channels?.email && c.email) push('email', sendMessage('email', c.email, body, { demo: isDemo, subject: `${prefix}SOS from ${user.name}` }));
      if (c.channels?.app !== false && c.linkedUser) {
        push(
          'app',
          notify(c.linkedUser, {
            type: 'sos',
            title: `${prefix}${user.name} pressed SOS`,
            body: 'Open Raksha to see her live location and status.',
            link: `/guardian/sos/${alert._id}`,
            priority: 'critical',
            meta: { sosId: String(alert._id), isDemo },
          }).then(() => {
            realtime.toUser(String(c.linkedUser), 'sos:contact-alert', { sosId: alert._id, name: user.name, isDemo });
            return { status: isDemo ? 'simulated' : 'sent' };
          }),
        );
      }
      await Promise.all(jobs);
    }),
  );
  return { contacts: contacts.length, deliveries };
}

async function alertResponders(alert: any, user: any, isDemo: boolean) {
  if (!alert.location?.coordinates?.length || user.privacy?.allowNearbyResponders === false) return [];
  const [lng, lat] = alert.location.coordinates;
  const candidates = await Responder.find({
    verified: true,
    active: true,
    user: { $ne: user._id },
    location: { $nearSphere: { $geometry: { type: 'Point', coordinates: [lng, lat] }, $maxDistance: env.SOS_RESPONDER_RADIUS_KM * 1000 } },
  })
    .limit(env.SOS_MAX_RESPONDERS * 3)
    .lean<any[]>();
  // Demo alerts may only reach demo responders, and real alerts only real responders.
  const users = await User.find({ _id: { $in: candidates.map((c) => c.user) }, status: 'active', isDemo }).select('_id').lean<any[]>();
  const allowed = new Set(users.map((u) => String(u._id)));
  const chosen = candidates.filter((c) => allowed.has(String(c.user))).slice(0, env.SOS_MAX_RESPONDERS);

  const approx = approximate(lat, lng);
  const out = chosen.map((r) => ({
    responder: r._id,
    user: r.user,
    distanceKm: Math.round(haversineKm({ lat, lng }, { lat: r.location.coordinates[1], lng: r.location.coordinates[0] }) * 10) / 10,
    status: 'notified',
    notifiedAt: new Date(),
  }));
  await Promise.all(
    out.map(async (r) => {
      await Responder.updateOne({ _id: r.responder }, { $inc: { 'stats.requestsReceived': 1 } });
      await notify(r.user, {
        type: 'sos',
        title: `${isDemo ? '[DEMO] ' : ''}Someone nearby needs help (~${r.distanceKm} km)`,
        body: 'Open your responder dashboard to accept. Exact location is shared only after you accept.',
        link: '/responder/dashboard',
        priority: 'critical',
        meta: { sosId: String(alert._id), isDemo },
      });
      realtime.toUser(String(r.user), 'sos:nearby', { sosId: alert._id, distanceKm: r.distanceKm, approxLocation: approx, isDemo });
    }),
  );
  return out;
}

/** Notify everyone involved that the SOS ended (cancelled or resolved). */
export async function broadcastEnd(alert: any, kind: 'cancelled' | 'resolved') {
  const user = await User.findById(alert.user).select('name').lean<any>();
  const contacts = await EmergencyContact.find({ owner: alert.user }).lean<any[]>();
  const prefix = alert.isDemo ? '[RAKSHA DEMO] ' : '';
  const body = `${prefix}${user?.name} is marked SAFE. Her SOS was ${kind === 'cancelled' ? 'cancelled by her using her safety PIN' : 'resolved'} at ${fmtTime(new Date())} IST.`;
  await Promise.all(
    contacts.flatMap((c) => {
      const jobs: Promise<any>[] = [];
      if (c.channels?.sms && c.phone) jobs.push(sendMessage('sms', c.phone, body, { demo: alert.isDemo }));
      if (c.channels?.whatsapp && c.phone) jobs.push(sendMessage('whatsapp', c.phone, body, { demo: alert.isDemo }));
      if (c.channels?.email && c.email) jobs.push(sendMessage('email', c.email, body, { demo: alert.isDemo, subject: `${prefix}${user?.name} is safe` }));
      if (c.linkedUser) jobs.push(notify(c.linkedUser, { type: 'sos_update', title: `${prefix}${user?.name} is safe`, body, link: `/guardian/sos/${alert._id}` }));
      return jobs;
    }),
  );
  for (const r of alert.responders || []) {
    await notify(r.user, { type: 'sos_update', title: `${prefix}Emergency ${kind}`, body: 'Thank you. No further action is needed.', link: '/responder/dashboard' });
  }
  realtime.toRoom(sosRoom(String(alert._id)), 'sos:ended', { sosId: alert._id, kind });
  await LocationShare.updateMany({ sos: alert._id, active: true }, { active: false, stoppedAt: new Date() });
}
