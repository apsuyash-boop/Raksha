/**
 * Private object storage. Files are ALWAYS encrypted (AES-256-GCM) before they
 * leave the process, and are only ever served through authorized API routes —
 * never through public URLs.
 */
import fs from 'fs/promises';
import path from 'path';
import { env } from '../config/env';
import { decryptBuffer, encryptBuffer, randomToken } from '../utils/crypto';

interface StorageDriver {
  name: string;
  put(key: string, data: Buffer): Promise<void>;
  get(key: string): Promise<Buffer>;
  remove(key: string): Promise<void>;
}

class LocalDriver implements StorageDriver {
  name = 'local';
  constructor(private root: string) {}
  private resolve(key: string) {
    const p = path.resolve(this.root, key);
    if (!p.startsWith(path.resolve(this.root))) throw new Error('Invalid storage key');
    return p;
  }
  async put(key: string, data: Buffer) {
    const p = this.resolve(key);
    await fs.mkdir(path.dirname(p), { recursive: true });
    await fs.writeFile(p, data, { mode: 0o600 });
  }
  async get(key: string) {
    return fs.readFile(this.resolve(key));
  }
  async remove(key: string) {
    await fs.rm(this.resolve(key), { force: true });
  }
}

class S3Driver implements StorageDriver {
  name = 's3';
  private client: any;
  private sdk: any;
  constructor() {
    // Lazy-require so local development does not need AWS credentials.
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    this.sdk = require('@aws-sdk/client-s3');
    this.client = new this.sdk.S3Client({
      region: env.STORAGE_REGION,
      endpoint: env.STORAGE_ENDPOINT || undefined,
      forcePathStyle: !!env.STORAGE_ENDPOINT,
      credentials: { accessKeyId: env.STORAGE_ACCESS_KEY, secretAccessKey: env.STORAGE_SECRET },
    });
  }
  async put(key: string, data: Buffer) {
    await this.client.send(
      new this.sdk.PutObjectCommand({ Bucket: env.STORAGE_BUCKET, Key: key, Body: data, ContentType: 'application/octet-stream', ServerSideEncryption: 'AES256', ACL: 'private' }),
    );
  }
  async get(key: string) {
    const r = await this.client.send(new this.sdk.GetObjectCommand({ Bucket: env.STORAGE_BUCKET, Key: key }));
    const bytes = await r.Body.transformToByteArray();
    return Buffer.from(bytes);
  }
  async remove(key: string) {
    await this.client.send(new this.sdk.DeleteObjectCommand({ Bucket: env.STORAGE_BUCKET, Key: key }));
  }
}

let driver: StorageDriver | null = null;
function getDriver(): StorageDriver {
  if (driver) return driver;
  if (env.STORAGE_DRIVER === 's3') {
    if (!env.STORAGE_BUCKET || !env.STORAGE_ACCESS_KEY || !env.STORAGE_SECRET) throw new Error('S3 storage selected but STORAGE_BUCKET / STORAGE_ACCESS_KEY / STORAGE_SECRET are missing');
    driver = new S3Driver();
  } else {
    driver = new LocalDriver(env.STORAGE_LOCAL_DIR);
  }
  return driver;
}

export const storage = {
  driverName: () => getDriver().name,
  async putEncrypted(prefix: string, plain: Buffer) {
    const now = new Date();
    const key = `${prefix}/${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, '0')}/${randomToken(16)}.bin`;
    await getDriver().put(key, encryptBuffer(plain));
    return { key, driver: getDriver().name };
  },
  async getDecrypted(key: string) {
    return decryptBuffer(await getDriver().get(key));
  },
  async remove(key: string) {
    await getDriver().remove(key);
  },
};
