import type { Server as HttpServer } from 'http';
import { Server, Socket } from 'socket.io';
import { env } from '../config/env';
import { _verifyAccessToken } from '../middleware/auth';
import { User, SOSAlert } from '../models';
import { realtime } from '../services/realtime';
import { recordLocation } from '../services/location';
import { canViewPreciseLocation } from '../services/access';
import { canChat } from '../services/access';
import { convKey } from '../controllers/messages.controller';
import { logger } from '../utils/logger';
import type { AuthUser } from '../types/express';

type AuthedSocket = Socket & { data: { user: AuthUser } };

export function createSocketServer(http: HttpServer) {
  const io = new Server(http, {
    cors: { origin: env.CORS_ORIGINS, credentials: true },
    maxHttpBufferSize: 1e5, // small payloads only; files go through the HTTP API
    pingInterval: 20000,
  });

  // JWT authentication on connect.
  io.use(async (socket, next) => {
    try {
      const token = (socket.handshake.auth?.token as string) || '';
      const p = _verifyAccessToken(token);
      const u = await User.findById(p.sub).select('name role verified isDemo status').lean<any>();
      if (!u || u.status !== 'active') return next(new Error('unauthorized'));
      socket.data.user = { id: String(u._id), role: u.role, name: u.name, verified: !!u.verified, isDemo: !!u.isDemo };
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (raw) => {
    const socket = raw as AuthedSocket;
    const me = socket.data.user;
    socket.join(`user:${me.id}`);

    /** Live location from the woman's device (throttled client-side). */
    let lastLoc = 0;
    socket.on('location:update', async (p: any, ack?: (r: any) => void) => {
      const now = Date.now();
      if (now - lastLoc < 2000) return ack?.({ ok: false, reason: 'throttled' });
      lastLoc = now;
      const lat = Number(p?.lat);
      const lng = Number(p?.lng);
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return ack?.({ ok: false, reason: 'invalid' });
      try {
        const r = await recordLocation(me.id, { lat, lng, accuracy: Number(p.accuracy) || undefined, battery: Number(p.battery) || undefined, speed: Number(p.speed) || undefined, heading: Number(p.heading) || undefined });
        ack?.({ ok: r.recorded });
      } catch (e: any) {
        logger.warn('socket location error', { err: e.message });
        ack?.({ ok: false });
      }
    });

    /** Subscribe to someone's live location — authorised per request. */
    socket.on('location:watch', async (p: any, ack?: (r: any) => void) => {
      const ownerId = String(p?.userId || '');
      if (!ownerId || !(await canViewPreciseLocation(me, ownerId))) return ack?.({ ok: false, error: 'forbidden' });
      socket.join(`loc:${ownerId}`);
      ack?.({ ok: true });
    });
    socket.on('location:unwatch', (p: any) => socket.leave(`loc:${String(p?.userId || '')}`));

    /** Join an SOS room (owner, linked contacts, accepted responders). */
    socket.on('sos:join', async (p: any, ack?: (r: any) => void) => {
      const alert = await SOSAlert.findById(String(p?.sosId || '')).select('user responders status').lean<any>();
      if (!alert) return ack?.({ ok: false });
      const isOwner = String(alert.user) === me.id;
      if (!isOwner && !(await canViewPreciseLocation(me, String(alert.user)))) return ack?.({ ok: false, error: 'forbidden' });
      socket.join(`sos:${alert._id}`);
      socket.join(`loc:${alert.user}`);
      ack?.({ ok: true });
    });

    /** Typing indicators for chat (messages themselves go through REST for validation + persistence). */
    socket.on('chat:typing', async (p: any) => {
      const to = String(p?.to || '');
      if (!to) return;
      if (!(await canChat(me, to))) return;
      io.to(`user:${to}`).emit('chat:typing', { from: me.id, key: convKey(me.id, to) });
    });

    /** Responders share their position so nearby matching stays fresh (only when responder mode is on). */
    socket.on('responder:location', async (p: any) => {
      if (me.role !== 'responder' || !me.verified) return;
      const lat = Number(p?.lat);
      const lng = Number(p?.lng);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
      const { Responder } = await import('../models');
      await Responder.updateOne({ user: me.id, active: true }, { location: { type: 'Point', coordinates: [lng, lat] }, locationUpdatedAt: new Date() });
    });
  });

  realtime.attach(io);
  return io;
}
