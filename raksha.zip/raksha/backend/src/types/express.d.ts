import type { Role } from '../config/roles';

export interface AuthUser {
  id: string;
  role: Role;
  name: string;
  verified: boolean;
  isDemo: boolean;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

export {};
