import crypto from 'crypto';
import { env } from '../config/env';

/** AES-256-GCM. Output layout: [12-byte IV][16-byte auth tag][ciphertext]. */
export function encryptBuffer(plain: Buffer, key: Buffer = env.ENCRYPTION_KEY): Buffer {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(plain), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]);
}

export function decryptBuffer(blob: Buffer, key: Buffer = env.ENCRYPTION_KEY): Buffer {
  const iv = blob.subarray(0, 12);
  const tag = blob.subarray(12, 28);
  const data = blob.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]);
}

/** Field-level encryption for short strings (e.g. medical notes). */
export function encryptString(s: string): string {
  return encryptBuffer(Buffer.from(s, 'utf8')).toString('base64');
}
export function decryptString(s: string): string {
  try {
    return decryptBuffer(Buffer.from(s, 'base64')).toString('utf8');
  } catch {
    return '';
  }
}

export const sha256 = (data: Buffer | string) => crypto.createHash('sha256').update(data).digest('hex');
export const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('hex');
export const randomCode = (digits = 6) => {
  const n = crypto.randomInt(0, 10 ** digits);
  return n.toString().padStart(digits, '0');
};

export function hmacSha256(secret: string, payload: string) {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function safeEqual(a: string, b: string) {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}
