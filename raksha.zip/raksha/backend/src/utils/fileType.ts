/**
 * Validate uploads by inspecting magic bytes rather than trusting the client-supplied MIME type.
 */
export type EvidenceKind = 'image' | 'video' | 'audio' | 'document';

interface Detected {
  mime: string;
  ext: string;
  kind: EvidenceKind;
}

const startsWith = (b: Buffer, sig: number[], offset = 0) => sig.every((v, i) => b[offset + i] === v);

export function detectFileType(buf: Buffer): Detected | null {
  if (buf.length < 12) return null;
  if (startsWith(buf, [0xff, 0xd8, 0xff])) return { mime: 'image/jpeg', ext: 'jpg', kind: 'image' };
  if (startsWith(buf, [0x89, 0x50, 0x4e, 0x47])) return { mime: 'image/png', ext: 'png', kind: 'image' };
  if (startsWith(buf, [0x47, 0x49, 0x46, 0x38])) return { mime: 'image/gif', ext: 'gif', kind: 'image' };
  if (startsWith(buf, [0x52, 0x49, 0x46, 0x46]) && buf.toString('ascii', 8, 12) === 'WEBP') return { mime: 'image/webp', ext: 'webp', kind: 'image' };
  if (startsWith(buf, [0x52, 0x49, 0x46, 0x46]) && buf.toString('ascii', 8, 12) === 'WAVE') return { mime: 'audio/wav', ext: 'wav', kind: 'audio' };
  if (startsWith(buf, [0x25, 0x50, 0x44, 0x46])) return { mime: 'application/pdf', ext: 'pdf', kind: 'document' };
  if (startsWith(buf, [0x1a, 0x45, 0xdf, 0xa3])) return { mime: 'video/webm', ext: 'webm', kind: 'video' };
  if (startsWith(buf, [0x4f, 0x67, 0x67, 0x53])) return { mime: 'audio/ogg', ext: 'ogg', kind: 'audio' };
  if (startsWith(buf, [0x49, 0x44, 0x33]) || (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0)) return { mime: 'audio/mpeg', ext: 'mp3', kind: 'audio' };
  if (buf.toString('ascii', 4, 8) === 'ftyp') {
    const brand = buf.toString('ascii', 8, 12);
    if (['M4A ', 'M4B '].includes(brand)) return { mime: 'audio/mp4', ext: 'm4a', kind: 'audio' };
    if (brand === 'qt  ') return { mime: 'video/quicktime', ext: 'mov', kind: 'video' };
    if (['heic', 'heix', 'mif1'].includes(brand)) return { mime: 'image/heic', ext: 'heic', kind: 'image' };
    return { mime: 'video/mp4', ext: 'mp4', kind: 'video' };
  }
  // DOCX/XLSX are ZIP containers. We only accept them as documents.
  if (startsWith(buf, [0x50, 0x4b, 0x03, 0x04])) return { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', ext: 'docx', kind: 'document' };
  return null;
}

export const ALLOWED_KINDS: EvidenceKind[] = ['image', 'video', 'audio', 'document'];
