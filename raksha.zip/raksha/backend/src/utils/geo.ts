export type LngLat = [number, number];

export interface GeoPoint {
  type: 'Point';
  coordinates: LngLat;
}

export const toPoint = (lat: number, lng: number): GeoPoint => ({ type: 'Point', coordinates: [lng, lat] });

/**
 * Approximate a location to a ~1.1 km grid (2 decimal places) so that
 * unaccepted responders and admins never see a precise position.
 */
export function approximate(lat: number, lng: number, decimals = 2) {
  const f = 10 ** decimals;
  return { lat: Math.round(lat * f) / f, lng: Math.round(lng * f) / f, precision: decimals === 2 ? '~1 km' : `${decimals}dp` };
}

export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

export const mapsLink = (lat: number, lng: number) => `https://maps.google.com/?q=${lat.toFixed(6)},${lng.toFixed(6)}`;
