import { NextFunction, Request, RequestHandler, Response } from 'express';

export class AppError extends Error {
  status: number;
  code: string;
  details?: unknown;
  constructor(status: number, message: string, code = 'ERROR', details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
  static badRequest(m = 'Bad request', details?: unknown) { return new AppError(400, m, 'BAD_REQUEST', details); }
  static unauthorized(m = 'Authentication required') { return new AppError(401, m, 'UNAUTHORIZED'); }
  static forbidden(m = 'You do not have permission to perform this action') { return new AppError(403, m, 'FORBIDDEN'); }
  static notFound(m = 'Not found') { return new AppError(404, m, 'NOT_FOUND'); }
  static conflict(m = 'Conflict') { return new AppError(409, m, 'CONFLICT'); }
  static unavailable(m = 'Service not configured') { return new AppError(503, m, 'SERVICE_UNAVAILABLE'); }
}

export function ok(res: Response, data: unknown = {}, message = 'OK', status = 200) {
  return res.status(status).json({ success: true, message, data });
}

export function created(res: Response, data: unknown = {}, message = 'Created') {
  return ok(res, data, message, 201);
}

export const asyncHandler =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => {
    fn(req, res, next).catch(next);
  };

export function paginate(req: Request, defLimit = 20, maxLimit = 100) {
  const page = Math.max(1, parseInt(String(req.query.page || '1'), 10) || 1);
  const limit = Math.min(maxLimit, Math.max(1, parseInt(String(req.query.limit || defLimit), 10) || defLimit));
  return { page, limit, skip: (page - 1) * limit };
}

export function escapeRegex(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
