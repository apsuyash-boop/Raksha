import { z } from 'zod';
import { Types } from 'mongoose';
import { CASE_TYPES, LANGUAGES } from '../config/roles';

export const objectId = z.string().refine((v) => Types.ObjectId.isValid(v), 'Invalid id');
export const lat = z.coerce.number().min(-90).max(90);
export const lng = z.coerce.number().min(-180).max(180);
export const phone = z
  .string()
  .trim()
  .regex(/^\+?[0-9\s-]{8,16}$/, 'Enter a valid phone number')
  .transform((s) => s.replace(/[\s-]/g, ''));
export const email = z.string().trim().toLowerCase().email('Enter a valid email');
export const password = z
  .string()
  .min(8, 'Use at least 8 characters')
  .max(128)
  .regex(/[A-Za-z]/, 'Include at least one letter')
  .regex(/[0-9]/, 'Include at least one number');
export const pin = z.string().regex(/^\d{4,6}$/, 'PIN must be 4–6 digits');
export const language = z.enum(LANGUAGES);
export const caseType = z.enum(CASE_TYPES);
export const shortText = (max = 200) => z.string().trim().max(max);
