import { describe, expect, it } from 'vitest';
import { api, makeLawyer, makeUser } from './helpers';
import { Lawyer, User, Verification } from '../src/models';

describe('Professional verification', () => {
  it('3. a non-admin cannot verify professionals', async () => {
    const lawyer = await makeLawyer(false);
    const v = await Verification.create({ user: lawyer.user._id, role: 'lawyer', status: 'pending' });
    const user = await makeUser();
    const otherLawyer = await makeLawyer(true);
    for (const actor of [user, lawyer, otherLawyer]) {
      await api().post(`/api/admin/verifications/${v._id}/decision`).set(actor.auth).send({ decision: 'approved' }).expect(403);
    }
    expect((await User.findById(lawyer.user._id).lean<any>()).verified).toBe(false);

    // A professional cannot self-verify by editing their profile.
    await api().put('/api/lawyers/me/profile').set(lawyer.auth).send({ displayName: 'Adv. Test', verified: true }).expect(200);
    expect((await Lawyer.findOne({ user: lawyer.user._id }).lean<any>()).verified).toBe(false);

    const admin = await makeUser('admin');
    await api().post(`/api/admin/verifications/${v._id}/decision`).set(admin.auth).send({ decision: 'approved', note: 'Bar council ID checked' }).expect(200);
    expect((await User.findById(lawyer.user._id).lean<any>()).verified).toBe(true);
    expect((await Lawyer.findOne({ user: lawyer.user._id }).lean<any>()).verified).toBe(true);
  });

  it('non-admins cannot reach any admin endpoint', async () => {
    const u = await makeUser();
    await api().get('/api/admin/stats').set(u.auth).expect(403);
    await api().get('/api/admin/users').set(u.auth).expect(403);
    await api().get('/api/admin/stats').expect(401);
  });
});
