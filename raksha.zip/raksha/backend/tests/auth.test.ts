import { describe, expect, it } from 'vitest';
import { api, makeUser } from './helpers';

describe('Authentication', () => {
  it('registers, logs in, refreshes and returns the current user', async () => {
    const reg = await api()
      .post('/api/auth/register')
      .send({ name: 'Asha Verma', email: 'asha@test.local', password: 'Secure1234', acceptTerms: true, emergencyContacts: [{ name: 'Mom', phone: '+910000000001' }] })
      .expect(201);
    expect(reg.body.success).toBe(true);
    expect(reg.body.data.accessToken).toBeTruthy();
    expect(reg.body.data.user.passwordHash).toBeUndefined();
    const cookie = reg.headers['set-cookie'];
    expect(String(cookie)).toMatch(/raksha_rt=.*HttpOnly/i);

    const login = await api().post('/api/auth/login').send({ identifier: 'asha@test.local', password: 'Secure1234' }).expect(200);
    const me = await api().get('/api/auth/me').set('Authorization', `Bearer ${login.body.data.accessToken}`).expect(200);
    expect(me.body.data.user.email).toBe('asha@test.local');
    expect(me.body.data.emergencyContactsCount).toBe(1);

    const refreshed = await api().post('/api/auth/refresh').set('Cookie', login.headers['set-cookie']).expect(200);
    expect(refreshed.body.data.accessToken).toBeTruthy();
    // Rotation: the old refresh token can no longer be used.
    await api().post('/api/auth/refresh').set('Cookie', login.headers['set-cookie']).expect(401);
  });

  it('stores passwords hashed, never in plain text', async () => {
    await api().post('/api/auth/register').send({ name: 'Plain Check', email: 'plain@test.local', password: 'Secure1234', acceptTerms: true }).expect(201);
    const { User } = await import('../src/models');
    const u = await User.findOne({ email: 'plain@test.local' }).select('+passwordHash').lean<any>();
    expect(u.passwordHash).not.toContain('Secure1234');
    expect(u.passwordHash).toMatch(/^\$2[aby]\$/);
  });

  it('rejects weak passwords and wrong credentials', async () => {
    const weak = await api().post('/api/auth/register').send({ name: 'Weak', email: 'weak@test.local', password: 'short', acceptTerms: true }).expect(422);
    expect(weak.body.error.code).toBe('VALIDATION_ERROR');
    await makeUser('user', { email: 'x@test.local' });
    await api().post('/api/auth/login').send({ identifier: 'x@test.local', password: 'WrongPass1' }).expect(401);
  });

  it('does not allow self-registration as admin', async () => {
    await api().post('/api/auth/register').send({ name: 'Sneaky', email: 'admin@test.local', password: 'Secure1234', role: 'admin', acceptTerms: true }).expect(422);
  });

  it('rejects requests without a valid token', async () => {
    await api().get('/api/auth/me').expect(401);
    await api().get('/api/auth/me').set('Authorization', 'Bearer not-a-token').expect(401);
  });

  it('does not reveal whether an account exists on forgot-password', async () => {
    const a = await api().post('/api/auth/forgot-password').send({ identifier: 'nobody@test.local' }).expect(200);
    expect(a.body.message).toMatch(/If an account exists/);
  });

  it('health endpoint reports database status', async () => {
    const r = await api().get('/api/health').expect(200);
    expect(r.body.data.database).toBe('connected');
  });
});
