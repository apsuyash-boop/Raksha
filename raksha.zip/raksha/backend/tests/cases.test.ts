import { describe, expect, it } from 'vitest';
import { api, makeLawyer, makeUser } from './helpers';

describe('Case management', () => {
  it('2. an unauthorised user cannot access another user’s case', async () => {
    const owner = await makeUser();
    const stranger = await makeUser();
    const lawyer = await makeLawyer();
    const c = await api().post('/api/cases').set(owner.auth).send({ type: 'dowry', title: 'Dowry harassment', description: 'Details' }).expect(201);
    const id = c.body.data.case._id;
    await api().get(`/api/cases/${id}`).set(stranger.auth).expect(403);
    await api().patch(`/api/cases/${id}`).set(stranger.auth).send({ status: 'closed' }).expect(403);
    await api().get(`/api/cases/${id}`).set(lawyer.auth).expect(403);
    await api().post(`/api/cases/${id}/notes`).set(stranger.auth).send({ text: 'hi' }).expect(403);
  });

  it('runs the request → accept flow and gives the lawyer access only after acceptance', async () => {
    const owner = await makeUser();
    const lawyer = await makeLawyer();
    const c = await api().post('/api/cases').set(owner.auth).send({ type: 'domestic_violence', title: 'DV case', description: 'Private details here' }).expect(201);
    const id = c.body.data.case._id;

    const match = await api().post('/api/match').set(owner.auth).send({ caseType: 'domestic_violence', city: 'Bhopal', state: 'Madhya Pradesh', language: 'en' }).expect(200);
    expect(match.body.data.lawyers[0].profile._id).toBe(String(lawyer.profile._id));
    expect(match.body.data.lawyers[0].profile.barCouncilId).toBeUndefined();

    await api().post(`/api/cases/${id}/requests`).set(owner.auth).send({ providerType: 'lawyer', providerId: String(lawyer.profile._id) }).expect(200);
    const limited = await api().get(`/api/cases/${id}`).set(lawyer.auth).expect(200);
    expect(limited.body.data.case.access).toBe('requested');
    expect(limited.body.data.case.notes).toBeUndefined();

    const reqId = limited.body.data.case.requests[0]._id;
    await api().post(`/api/cases/${id}/requests/${reqId}/respond`).set(lawyer.auth).send({ action: 'accept' }).expect(200);
    const full = await api().get(`/api/cases/${id}`).set(lawyer.auth).expect(200);
    expect(full.body.data.case.access).toBe('assigned');

    await api().post(`/api/cases/${id}/hearings`).set(lawyer.auth).send({ date: new Date(Date.now() + 86400000).toISOString(), court: 'Family Court', purpose: 'First hearing' }).expect(201);
    const mine = await api().get(`/api/cases/${id}`).set(owner.auth).expect(200);
    expect(mine.body.data.case.hearings).toHaveLength(1);
  });

  it('an unverified lawyer is never matched and cannot accept requests', async () => {
    const owner = await makeUser();
    await makeLawyer(false);
    const match = await api().post('/api/match').set(owner.auth).send({ caseType: 'domestic_violence', city: 'Bhopal' }).expect(200);
    expect(match.body.data.lawyers).toHaveLength(0);
  });

  it('complaints are never marked as police-confirmed when submitted by the user', async () => {
    const owner = await makeUser();
    const c = await api()
      .post('/api/complaints')
      .set(owner.auth)
      .send({ incident: { type: 'harassment', description: 'Someone followed me home from the bus stop for a week and threatened me.' } })
      .expect(201);
    const id = c.body.data.complaint._id;
    expect(c.body.data.complaint.draftText).toContain('Station House Officer');
    // Online integration is not configured → honest 503, not a fake success.
    await api().post(`/api/complaints/${id}/submit`).set(owner.auth).send({ method: 'integration' }).expect(503);
    const s = await api().post(`/api/complaints/${id}/submit`).set(owner.auth).send({ method: 'printed_in_person' }).expect(200);
    expect(s.body.data.complaint.submission.confirmedByAuthority).toBe(false);
    const reg = await api().post(`/api/complaints/${id}/status`).set(owner.auth).send({ status: 'registered', firNumber: '123/2026' }).expect(200);
    expect(reg.body.data.complaint.firSource).toBe('self_reported');
  });
});
