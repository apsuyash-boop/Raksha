import { describe, expect, it } from 'vitest';
import { api, makeLawyer, makeUser, PNG } from './helpers';
import { AuditLog, Case, Evidence } from '../src/models';
import { sha256 } from '../src/utils/crypto';

async function upload(auth: Record<string, string>, extra: Record<string, string> = {}) {
  let req = api().post('/api/evidence').set(auth).attach('files', PNG, 'photo.png');
  for (const [k, v] of Object.entries(extra)) req = req.field(k, v);
  const r = await req.expect(201);
  return r.body.data.items[0];
}

describe('Evidence vault access control', () => {
  it('stores evidence encrypted with a server-computed SHA-256 and never exposes the storage key', async () => {
    const a = await makeUser();
    const item = await upload(a.auth, { title: 'Injury photo', lat: '23.25', lng: '77.41' });
    expect(item.sha256).toBe(sha256(PNG));
    expect(item.storageKey).toBeUndefined();
    const dl = await api().get(`/api/evidence/${item._id}/download`).set(a.auth).expect(200);
    expect(Buffer.from(dl.body).equals(PNG)).toBe(true);
    expect(dl.headers['x-integrity-verified']).toBe('true');
  });

  it('rejects files whose content is not an allowed type, regardless of the extension', async () => {
    const a = await makeUser();
    await api().post('/api/evidence').set(a.auth).attach('files', Buffer.from('#!/bin/sh\necho evil\n'.repeat(5)), 'photo.png').expect(400);
  });

  it('1. an unauthorised user cannot access someone else’s evidence', async () => {
    const owner = await makeUser();
    const stranger = await makeUser();
    const item = await upload(owner.auth);
    await api().get(`/api/evidence/${item._id}`).set(stranger.auth).expect(403);
    await api().get(`/api/evidence/${item._id}/download`).set(stranger.auth).expect(403);
    await api().post('/api/evidence/package').set(stranger.auth).send({ ids: [item._id] }).expect(403);
    const denied = await AuditLog.countDocuments({ action: 'evidence.access_denied', targetId: item._id });
    expect(denied).toBeGreaterThan(0);
  });

  it('an unassigned lawyer cannot access evidence; the assigned lawyer can only with consent', async () => {
    const owner = await makeUser();
    const assigned = await makeLawyer();
    const other = await makeLawyer();
    const item = await upload(owner.auth);
    const c = await Case.create({ caseNumber: 'RK-T-1', user: owner.user._id, type: 'domestic_violence', title: 'Test case', lawyer: assigned.profile._id, evidence: [item._id] });
    await Evidence.updateOne({ _id: item._id }, { cases: [c._id] });

    await api().get(`/api/evidence/${item._id}/download`).set(other.auth).expect(403);
    await api().get(`/api/evidence/${item._id}/download`).set(assigned.auth).expect(200);

    await api().patch(`/api/cases/${c._id}`).set(owner.auth).send({ consent: { shareEvidenceWithAssigned: false } }).expect(200);
    await api().get(`/api/evidence/${item._id}/download`).set(assigned.auth).expect(403);
  });

  it('admins need a written justification, and their access appears in the owner’s access history', async () => {
    const owner = await makeUser();
    const admin = await makeUser('admin');
    const item = await upload(owner.auth);
    await api().get(`/api/evidence/${item._id}/download`).set(admin.auth).expect(403);
    await api().get(`/api/evidence/${item._id}/download?reason=${encodeURIComponent('Court order #123 requested copy')}`).set(admin.auth).expect(200);
    const hist = await api().get('/api/users/me/access-history').set(owner.auth).expect(200);
    expect(hist.body.data.logs.some((l: any) => l.action === 'evidence.download')).toBe(true);
    const meta = await api().get(`/api/evidence/${item._id}`).set(owner.auth).expect(200);
    expect(meta.body.data.item.accessLog.some((l: any) => l.action === 'download' && /admin/.test(l.reason))).toBe(true);
  });

  it('verifies integrity on demand', async () => {
    const owner = await makeUser();
    const item = await upload(owner.auth);
    const r = await api().post(`/api/evidence/${item._id}/verify`).set(owner.auth).expect(200);
    expect(r.body.data.match).toBe(true);
  });
});
