import bcrypt from 'bcryptjs';
import supertest from 'supertest';
import { createApp } from '../src/app';
import { signAccessToken } from '../src/middleware/auth';
import { EmergencyContact, Lawyer, Responder, User } from '../src/models';
import { toPoint } from '../src/utils/geo';

export const app = createApp();
export const api = () => supertest(app);

let n = 0;
export async function makeUser(role = 'user', extra: Record<string, unknown> = {}) {
  n += 1;
  const u = await User.create({
    name: `Test ${role} ${n}`,
    email: `t${n}-${Date.now()}@test.local`,
    phone: `+9100${String(Date.now()).slice(-6)}${String(n).padStart(2, '0')}`,
    passwordHash: await bcrypt.hash('Password123', 4),
    safetyPinHash: await bcrypt.hash('1234', 4),
    role,
    verified: true,
    ...extra,
  });
  return { user: u, token: signAccessToken(u), auth: { Authorization: `Bearer ${signAccessToken(u)}` } };
}

export async function makeLawyer(verified = true) {
  const l = await makeUser('lawyer', { verified });
  const profile = await Lawyer.create({ user: l.user._id, displayName: l.user.name, specializations: ['domestic_violence'], languages: ['en'], city: 'Bhopal', state: 'Madhya Pradesh', verified });
  return { ...l, profile };
}

export async function makeResponder(lat: number, lng: number, extra: Record<string, unknown> = {}) {
  const r = await makeUser('responder', extra);
  await Responder.create({ user: r.user._id, verified: true, active: true, availability: 'always', location: toPoint(lat, lng) });
  return r;
}

export async function linkContact(ownerId: any, contactUser: any) {
  return EmergencyContact.create({ owner: ownerId, name: contactUser.name, phone: contactUser.phone, linkedUser: contactUser._id, channels: { sms: true, app: true } });
}

/** Smallest valid PNG, used as an evidence upload. */
export const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
