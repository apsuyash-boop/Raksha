import { describe, expect, it } from 'vitest';
import crypto from 'crypto';
import { api, makeUser } from './helpers';
import { Campaign, Donation, Transaction } from '../src/models';

async function activeCampaign() {
  const b = await makeUser();
  return Campaign.create({ slug: `c-${Date.now()}`, beneficiary: b.user._id, title: 'Rent deposit support', story: 'x'.repeat(120), category: 'rent', goalAmount: 10000, status: 'active', kycVerified: true });
}

describe('Payments', () => {
  it('4. a payment cannot be marked successful from the frontend alone', async () => {
    const donor = await makeUser('donor');
    const c = await activeCampaign();
    const order = await api().post('/api/donations/order').set(donor.auth).send({ campaignId: String(c._id), amount: 500 }).expect(201);
    const { orderId, donationId } = order.body.data;

    // Forged "success" from the client with a made-up signature.
    const forged = crypto.createHmac('sha256', 'guessed-secret').update(`${orderId}|pay_fake123`).digest('hex');
    await api().post('/api/donations/verify').send({ orderId, paymentId: 'pay_fake123', signature: forged }).expect(400);

    expect((await Donation.findById(donationId).lean<any>()).status).toBe('failed');
    expect((await Campaign.findById(c._id).lean<any>()).raisedAmount).toBe(0);
    expect(await Transaction.countDocuments({ orderId, status: 'captured' })).toBe(0);
  });

  it('there is no endpoint that lets a client set a donation to paid', async () => {
    const donor = await makeUser('donor');
    const c = await activeCampaign();
    const order = await api().post('/api/donations/order').set(donor.auth).send({ campaignId: String(c._id), amount: 500 }).expect(201);
    await api().patch(`/api/donations/${order.body.data.donationId}`).set(donor.auth).send({ status: 'paid' }).expect(404);
    await api().post('/api/donations/order').set(donor.auth).send({ campaignId: String(c._id), amount: 500, status: 'paid' }).expect(201);
    expect(await Donation.countDocuments({ status: 'paid' })).toBe(0);
  });

  it('records success only after server-side signature verification (demo gateway)', async () => {
    const c = await activeCampaign();
    const order = await api().post('/api/donations/order').send({ campaignId: String(c._id), amount: 1000, donorName: 'Guest' }).expect(201);
    const paid = await api().post('/api/payments/mock/pay').send({ orderId: order.body.data.orderId }).expect(200);
    const v = await api().post('/api/donations/verify').send(paid.body.data).expect(200);
    expect(v.body.data.receipt.receiptNumber).toMatch(/^RCPT-/);
    expect(v.body.data.receipt.isDemo).toBe(true);
    expect((await Campaign.findById(c._id).lean<any>()).raisedAmount).toBe(1000);
    // Replaying the same verification is idempotent.
    await api().post('/api/donations/verify').send(paid.body.data).expect(200);
    expect((await Campaign.findById(c._id).lean<any>()).raisedAmount).toBe(1000);
  });

  it('transparency figures exclude demo transactions', async () => {
    const r = await api().get('/api/transparency').expect(200);
    expect(r.body.data.live.totalDonations).toBe(0);
  });
});
