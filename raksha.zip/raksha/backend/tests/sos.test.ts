import { afterEach, describe, expect, it, vi } from 'vitest';
import { api, linkContact, makeResponder, makeUser } from './helpers';
import { emergencyTransport } from '../src/services/emergency';
import { env } from '../src/config/env';
import { SOSAlert } from '../src/models';

const BHOPAL = { lat: 23.2599, lng: 77.4126 };

afterEach(() => {
  vi.restoreAllMocks();
  (env as any).EMERGENCY_API_URL = '';
  (env as any).EMERGENCY_API_KEY = '';
});

describe('SOS workflow', () => {
  it('requires deliberate confirmation', async () => {
    const w = await makeUser();
    await api().post('/api/sos').set(w.auth).send({ ...BHOPAL }).expect(422);
  });

  it('5. a demo SOS can never contact real emergency services — even when the integration is configured', async () => {
    (env as any).EMERGENCY_API_URL = 'https://emergency.example.invalid/api';
    (env as any).EMERGENCY_API_KEY = 'configured-key';
    const spy = vi.spyOn(emergencyTransport, 'post').mockResolvedValue({ confirmed: true, reference: 'REAL-123' });
    const fetchSpy = vi.spyOn(globalThis, 'fetch');

    const w = await makeUser('user', { isDemo: true });
    const contact = await makeUser('emergency_contact', { isDemo: true });
    await linkContact(w.user._id, contact.user);

    const r = await api().post('/api/sos').set(w.auth).send({ confirm: true, ...BHOPAL, accuracy: 12 }).expect(201);
    const alert = r.body.data.alert;
    expect(alert.isDemo).toBe(true);
    expect(alert.emergencyService.status).toBe('simulated');
    expect(spy).not.toHaveBeenCalled();
    expect(fetchSpy).not.toHaveBeenCalled(); // no SMS/WhatsApp/email provider calls either
    expect(alert.contactDeliveries.every((d: any) => d.status === 'simulated')).toBe(true);
    expect(alert.timeline.map((t: any) => t.step)).toEqual(expect.arrayContaining(['activated', 'contacts_alerted', 'responders_notified', 'emergency_service']));
  });

  it('a "practice" SOS from a real account is also simulated', async () => {
    (env as any).EMERGENCY_API_URL = 'https://emergency.example.invalid/api';
    (env as any).EMERGENCY_API_KEY = 'configured-key';
    const spy = vi.spyOn(emergencyTransport, 'post');
    const w = await makeUser();
    const r = await api().post('/api/sos').set(w.auth).send({ confirm: true, simulate: true, ...BHOPAL }).expect(201);
    expect(r.body.data.alert.emergencyService.status).toBe('simulated');
    expect(spy).not.toHaveBeenCalled();
  });

  it('never claims police were contacted when the integration is not configured', async () => {
    const w = await makeUser();
    const r = await api().post('/api/sos').set(w.auth).send({ confirm: true, ...BHOPAL }).expect(201);
    expect(r.body.data.alert.emergencyService.status).toBe('not_configured');
    const contacts = r.body.data.alert.timeline.find((t: any) => t.step === 'contacts_alerted');
    expect(contacts.label).toMatch(/No emergency contacts/);
  });

  it('cancelling requires the correct safety PIN and is logged', async () => {
    const w = await makeUser('user', { isDemo: true });
    const r = await api().post('/api/sos').set(w.auth).send({ confirm: true, ...BHOPAL }).expect(201);
    const id = r.body.data.alert._id;
    await api().post(`/api/sos/${id}/cancel`).set(w.auth).send({ pin: '9999' }).expect(400);
    expect((await SOSAlert.findById(id).lean<any>()).status).toBe('active');
    const ok = await api().post(`/api/sos/${id}/cancel`).set(w.auth).send({ pin: '1234' }).expect(200);
    expect(ok.body.data.alert.status).toBe('cancelled');
    expect(ok.body.data.alert.timeline.some((t: any) => t.step === 'cancelled')).toBe(true);
  });

  it('6. sensitive location data is protected', async () => {
    const w = await makeUser('user', { isDemo: true });
    const contact = await makeUser('emergency_contact', { isDemo: true });
    const stranger = await makeUser();
    const admin = await makeUser('admin');
    const responder = await makeResponder(BHOPAL.lat + 0.005, BHOPAL.lng + 0.005, { isDemo: true });
    await linkContact(w.user._id, contact.user);

    // Before any SOS/share, even linked contacts cannot see her location.
    await api().get(`/api/location/user/${w.user._id}/latest`).set(contact.auth).expect(403);

    const r = await api().post('/api/sos').set(w.auth).send({ confirm: true, lat: 23.259912, lng: 77.412634 }).expect(201);
    const id = r.body.data.alert._id;
    expect(r.body.data.alert.responders).toHaveLength(1);

    // Strangers: denied everywhere.
    await api().get(`/api/location/user/${w.user._id}/latest`).set(stranger.auth).expect(403);
    await api().get(`/api/sos/${id}`).set(stranger.auth).expect(403);

    // Linked emergency contact: precise location during the active SOS.
    const c = await api().get(`/api/location/user/${w.user._id}/latest`).set(contact.auth).expect(200);
    expect(c.body.data.location.lat).toBeCloseTo(23.259912, 5);

    // Responder: approximate only until they accept.
    const before = await api().get(`/api/sos/${id}`).set(responder.auth).expect(200);
    expect(before.body.data.alert.location.precise).toBe(false);
    expect(before.body.data.alert.location.lat).toBe(23.26);
    expect(before.body.data.alert.person).toBeNull();
    await api().post(`/api/sos/${id}/respond`).set(responder.auth).send({ action: 'accept' }).expect(200);
    const after = await api().get(`/api/sos/${id}`).set(responder.auth).expect(200);
    expect(after.body.data.alert.location.precise).toBe(true);

    // Admin: approximate only.
    const adm = await api().get('/api/admin/sos').set(admin.auth).expect(200);
    expect(adm.body.data.items[0].location.lat).toBe(23.26);
    const admOne = await api().get(`/api/sos/${id}`).set(admin.auth).expect(200);
    expect(admOne.body.data.alert.location.precision).toBe('~1 km');

    // Public tracking: an invalid token reveals nothing.
    await api().get('/api/location/track/not-a-real-token').expect(404);

    // After resolution, contacts lose access.
    await api().post(`/api/sos/${id}/resolve`).set(w.auth).send({}).expect(400);
    await api().post(`/api/sos/${id}/resolve`).set(w.auth).send({ pin: '1234' }).expect(200);
    await api().get(`/api/location/user/${w.user._id}/latest`).set(contact.auth).expect(403);
  });

  it('demo SOS only reaches demo responders, never real ones', async () => {
    const real = await makeResponder(BHOPAL.lat, BHOPAL.lng + 0.002);
    const w = await makeUser('user', { isDemo: true });
    const r = await api().post('/api/sos').set(w.auth).send({ confirm: true, ...BHOPAL }).expect(201);
    expect(r.body.data.alert.responders.map((x: any) => String(x.user))).not.toContain(String(real.user._id));
  });
});
