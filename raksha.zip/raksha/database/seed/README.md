# Reference seed data

- `schemes.json` — government schemes. `criteria` contains only rules taken from the official source; anything else is shown to users as "check details". Review `officialUrl` pages before each release and update via the Admin → Schemes editor or this file.
- `rights.json` — rights-library articles. Each article has `translations.<language>` (`en`, `hi` included). Add another language by adding a key such as `mr` or `ta` with `title`, `summary`, `keyPoints[]` and `body` (markdown-lite: `## heading`, `- bullet`, blank line between paragraphs).

Loaded by `npm run seed` (backend/src/seed/index.ts), which upserts by `slug` and recreates demo data.
