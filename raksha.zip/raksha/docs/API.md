# Raksha REST API

Base URL: `/api`. All responses use one envelope:

```json
{ "success": true, "message": "Human readable message", "data": { } }
```

Errors:

```json
{ "success": false, "message": "Please check the highlighted fields", "error": { "code": "VALIDATION_ERROR", "details": [{ "field": "email", "message": "Enter a valid email" }] } }
```

| Status | Meaning |
|---|---|
| 200 / 201 | Success / created |
| 400 | Bad request (e.g. wrong PIN, invalid id) |
| 401 | Not authenticated / session expired |
| 403 | Authenticated but not allowed (role, ownership, consent, verification) |
| 404 | Not found |
| 409 | Conflict (duplicate, state already changed) |
| 413 | Upload too large |
| 422 | Validation error |
| 429 | Rate limited |
| 503 | External service not configured (e.g. police integration) — never a fake success |

**Authentication.** `Authorization: Bearer <accessToken>` (15 min JWT). The refresh token is an `httpOnly` cookie (`raksha_rt`, path `/api/auth`) rotated on every refresh. Cookie endpoints (`/auth/refresh`, `/auth/logout`) also require an allowed `Origin` and the header `X-Requested-With: raksha-web` (CSRF protection).

Legend: 🔓 public · 🔑 any signed-in user · 👩 woman/user role · 🛡 verified professional of that role · 👑 admin

---

## Health & config
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/health` | 🔓 | Server + database status (`200` or `503`) |
| GET | `/config` | 🔓 | Demo mode flag and which integrations are configured (no secrets) |

## Auth — `/api/auth`
| Method | Path | Auth | Body / notes |
|---|---|---|---|
| POST | `/register` | 🔓 | `name, email?, phone?, password, role, age?, state?, city?, language, safetyPin?, emergencyContacts?[], medical?, shareMedicalInfoInSOS?, acceptTerms:true`. Admin role cannot be self-assigned. Returns `accessToken`, `user`, sets refresh cookie, sends verification code |
| POST | `/login` | 🔓 | `identifier` (email or phone), `password` |
| POST | `/refresh` | cookie | Rotates refresh token, returns new access token. Reuse of a revoked token revokes all sessions |
| POST | `/logout` | cookie | Revokes current session |
| POST | `/forgot-password` | 🔓 | `identifier`. Same response whether or not the account exists |
| POST | `/reset-password` | 🔓 | `token, password`. Revokes all sessions |
| POST | `/otp/request` | 🔓 | `identifier` — one-time login code |
| POST | `/otp/verify` | 🔓 | `identifier, code` |
| POST | `/demo-login` | 🔓 | `role` — only when `DEMO_MODE=true` |
| GET | `/me` | 🔑 | Current user, `hasSafetyPin`, `emergencyContactsCount`, `demoMode` |
| POST | `/verify/request` | 🔑 | `channel: email|phone` |
| POST | `/verify/confirm` | 🔑 | `channel, code` |
| GET | `/sessions` | 🔑 | Active sessions |
| DELETE | `/sessions/:id` | 🔑 | Revoke one |
| POST | `/sessions/revoke-all` | 🔑 | Sign out everywhere |

> In development, when no email/SMS provider is configured, OTP and reset endpoints include `devCode` / `devResetUrl` so the flow can be tested. This never happens when `NODE_ENV=production`.

## Users & privacy — `/api/users`
| Method | Path | Auth | Description |
|---|---|---|---|
| PATCH | `/me` | 🔑 | Profile fields |
| PATCH | `/me/privacy` | 🔑 | `shareLocationWithContacts, allowNearbyResponders, shareMedicalInfoInSOS, autoRecordEvidenceOnSOS, showInCommunityAs, notificationPrefs{}` |
| PUT | `/me/safety-pin` | 🔑 | `pin, currentPassword` |
| GET / PUT | `/me/medical` | 🔑 | Encrypted medical & safety info |
| PUT | `/me/password` | 🔑 | `currentPassword, newPassword` |
| GET | `/me/access-history` | 🔑 | Who accessed my evidence / case / SOS / location |
| GET | `/me/export` | 🔑 | Full data export (JSON) |
| DELETE | `/me` | 🔑 | `password, confirm:"DELETE"` — deletes personal data & evidence files |
| POST / DELETE | `/:id/block` | 🔑 | Block / unblock a user |
| GET | `/me/protecting` | 🔑 | (Emergency contacts) people who listed me + active SOS |

## Emergency contacts — `/api/contacts`
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/` | 🔑 | List (max 10) |
| POST | `/` | 🔑 | `name, relation?, phone?, email?, channels{sms,whatsapp,email,app}, priority?, canViewLiveLocation?`. Auto-links to an existing Raksha account |
| PATCH | `/:id` | 🔑 | Update |
| DELETE | `/:id` | 🔑 | Remove |
| GET | `/protecting` | 🔑 | Same as `/users/me/protecting` |

## SOS — `/api/sos`
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/` | 🔑 | **Activate.** `confirm:true` (required), `lat?, lng?, accuracy?, message?, trigger?, simulate?`. Runs in parallel: alert contacts (SMS/WhatsApp/email/app), notify verified responders within `SOS_RESPONDER_RADIUS_KM` (approximate location only), emergency-service workflow, starts live-location sharing. Returns alert with per-channel delivery status and `trackUrl`. Demo users and `simulate:true` are always simulated. Idempotent while an SOS is active |
| GET | `/active` | 🔑 | My active SOS |
| GET | `/history` | 🔑 | My SOS log |
| GET | `/:id` | 🔑 | Owner: full. Linked contact during active SOS: location + timeline (+ medical if she allowed). Responder: approximate until accepted. Admin: approximate |
| POST | `/:id/cancel` | 🔑 | `pin` (or `password` if no PIN) — false alarm. Contacts are told she is safe. Failed attempts are logged |
| POST | `/:id/resolve` | 🔑 | `pin`/`password`, `note?` |
| POST | `/:id/recording` | 🔑 | `kind: audio|video, state: started|stopped|denied` (timeline) |
| GET | `/responder/inbox` | 🛡 responder | SOS requests sent to me |
| POST | `/:id/respond` | 🛡 responder | `action: accept|decline|arrived|complete, report?` |
| GET | `/demo-outbox` | 🔑 demo/admin | Messages that *would* have been sent in demo mode |

`emergencyService.status` is one of `simulated` (demo), `not_configured`, `pending`, `confirmed` (only when the integration explicitly confirms), `failed`.

## Live location — `/api/location`
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/` | 🔑 | `lat, lng, accuracy?, speed?, heading?, battery?`. Stored **only** while a share or SOS is active. (Socket: `location:update`) |
| POST | `/share` | 🔑 | `durationMinutes (5–1440), contactIds?, reason?` — time-boxed sharing; contacts get a private tracking link |
| POST | `/share/:id/stop` | 🔑 | Stop (not allowed for the share that belongs to an active SOS) |
| GET | `/shares/active` | 🔑 | My active shares |
| GET | `/history?sos=` | 🔑 | My location history |
| GET | `/user/:userId/latest` | 🔑 | Precise location — only the owner, linked contacts while sharing/SOS is active, or accepted responders |
| GET | `/track/:token` | 🔓 token | Public tracking page data; works only while sharing is active; every view is logged |

## Evidence vault — `/api/evidence`
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/` | 🔑 | `multipart/form-data` — `files[]` (≤10, ≤`MAX_UPLOAD_MB`), `title?, description?, category?, capturedAt?, lat?, lng?, accuracy?, sosId?, caseId?`. Magic-byte type check, optional ClamAV scan, SHA-256, AES-256-GCM encryption |
| GET | `/` | 🔑 | My items (`category`, `caseId`, `sosId` filters) |
| GET | `/:id` | 🔑 | Metadata (+ access log & shares for the owner) |
| GET | `/:id/download` | 🔑 | Decrypted file. Headers `X-Evidence-SHA256`, `X-Integrity-Verified`. Admins must pass `?reason=` (≥10 chars) |
| POST | `/:id/verify` | 🔑 | Re-hash and compare |
| PATCH | `/:id` | 🔑 owner | `title?, description?, caseIds?` |
| POST | `/:id/share` | 🔑 owner | `userId` — verified professionals only |
| DELETE | `/:id/share/:userId` | 🔑 owner | Revoke |
| DELETE | `/:id` | 🔑 owner | Permanent delete |
| POST | `/package` | 🔑 | `ids[]` — ZIP with original files + `manifest.json` (hashes, timestamps, GPS, chain of custody) |

Access rule: owner · explicit share · assigned lawyer/NGO on a linked case **with the owner's consent** · verified police officer the complaint was shared with · admin with written justification. Everything is audit-logged.

## Cases — `/api/cases`
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/` | 🔑 | `type, title, description?, urgency, city?, state?, language?, budget?, sosId?` |
| GET | `/` | 🔑 | Woman: my cases. Lawyer/NGO: `{assigned, requests}`. Admin: `?all=true` |
| GET | `/:id` | 🔑 | Owner / assigned / requested (summary only) / admin |
| PATCH | `/:id` | 🔑 | Owner: title, description, urgency, consent. Assigned: status |
| GET | `/:id/participants` | 🔑 | People you can message about this case |
| POST | `/:id/requests` | 🔑 owner | `providerType: lawyer|ngo, providerId, service?, message?` |
| POST | `/:id/requests/:reqId/respond` | 🛡 lawyer/ngo | `action: accept|reject` |
| POST | `/:id/notes` | 🔑 | `text, visibility: shared|professional_only` |
| POST | `/:id/hearings` | 🔑 | `date, court?, purpose?` (reminders sent 24 h before) |
| POST | `/:id/dates` | 🔑 | `date, label` |
| POST | `/:id/documents` | 🔑 | `title, body?, evidenceId?` |
| POST | `/:id/review` | 🔑 owner | `target: lawyer|ngo, rating 1–5, text?` |

## Professionals
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/lawyers`, `/ngos`, `/counsellors` | 🔓 | Verified only. Filters: `q, city, state, language, specialization, service, free, category` |
| GET | `/lawyers/:id` (etc.) | 🔓 | Public profile (no registration numbers) |
| GET / PUT | `/lawyers/me/profile` (also `/ngos`, `/counsellors`) | role | Own profile. `verified` can never be self-set |
| POST | `/lawyers/me/verification` (etc.) | role | `details{}, evidenceIds[]` |
| GET / PUT | `/responders/me` | responder | Profile, responder mode on/off, location |
| POST | `/responders/me/verification` | responder | Request verification |
| POST | `/verification/:role` | police / lender | Request verification |
| POST | `/match` | 🔑 | `caseType, state?, city?, language?, budget, urgency, service?, include` → ranked `lawyers[]`, `ngos[]` with score and reasons |

## Complaints — `/api/complaints`
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/` | 🔑 | `incident{type, date?, time?, place?, city?, state?, description, accused[], witnesses[], injuries?, previousComplaints?}, policeStation?, caseId?, evidenceIds[]` → structured draft |
| GET | `/` | 🔑 | Mine |
| GET | `/:id` | 🔑 | Owner / assigned case professional / shared police officer / admin |
| PATCH | `/:id` | 🔑 owner | Edit while `draft`/`ready_for_submission` |
| POST | `/:id/ready` | 🔑 owner | Mark ready |
| POST | `/:id/submit` | 🔑 owner | `method: printed_in_person|via_ngo|online_portal_self|integration`. `integration` returns **503** when no police API is configured |
| POST | `/:id/status` | 🔑 | `status, note?, firNumber?`. Owner updates are labelled *self-reported*; verified police updates are *confirmed by police* |
| POST | `/:id/share-police` | 🔑 owner | `policeUserId` |
| GET | `/police/officers` | 🔑 | Verified officers |
| GET | `/police/inbox` | 🛡 police | Complaints shared with me |

Statuses: `draft → ready_for_submission → submitted → under_review → registered → investigation → court_proceeding → closed`.

## Rights & schemes
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/rights?category=&q=&lang=` | 🔓 | Library (translations per language, falls back to English) |
| GET | `/rights/:slug?lang=` | 🔓 | Article |
| GET | `/schemes?q=&state=&category=` | 🔓 | Active schemes |
| GET | `/schemes/:idOrSlug` | 🔓 | Scheme |
| POST | `/schemes/eligibility` | 🔓 | Profile → each scheme marked `likely_eligible`, `check_details` or `not_eligible`, with reasons. Never invents rules |
| POST | `/schemes/:id/apply` | 🔑 | Start tracking (creates document checklist) |
| GET | `/schemes/applications/mine` | 🔑 | My applications |
| PATCH / DELETE | `/schemes/applications/:id` | 🔑 | `status, applicationRef, notes, checklist` |

## Counselling — `/api/appointments`
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/` | 🔑 | `counsellorId, mode: chat|call|video, scheduledAt, topic?` |
| GET | `/` | 🔑 | Mine (user) or my clients (counsellor) |
| POST | `/:id/status` | 🔑 | `action: confirm|decline|complete|cancel|reschedule, scheduledAt?, meetingUrl?, notes?` |

## Community — `/api/community`
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/posts?type=&tag=&q=` | 🔓 | Published posts (blocked authors hidden) |
| GET | `/posts/mine` | 🔑 | My posts incl. pending |
| GET | `/posts/:id` | 🔓 | Post + comments |
| POST | `/posts` | 🔑 | `type, title, body, tags[], anonymous, language`. Auto-moderation may hold it for review |
| DELETE | `/posts/:id` | 🔑 author/admin | Remove |
| POST | `/posts/:id/comments` | 🔑 | `body, anonymous` |
| POST | `/posts/:id/react` | 🔑 | `type: support|heart|strength` (toggle) |
| POST | `/reports` | 🔑 | `targetType, targetId, reason, details?` (3 reports auto-hide a post) |

Anonymous content never includes author identity in any API response — including to moderators.

## Financial — campaigns, donations, payments, loans
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/campaigns?status=active|completed&category=` | 🔓 | Public campaigns |
| GET | `/campaigns/:slug` | 🔓 | Campaign + recent support |
| POST | `/campaigns` | 👩 | Create (goes to KYC verification) |
| GET | `/campaigns/mine` | 🔑 | Mine |
| POST | `/campaigns/:id/utilization` | 👑 | `amount, purpose, paidTo` — records a disbursement |
| GET | `/donations/config` | 🔓 | Active gateway (`razorpay` / `mock`) and public key id |
| POST | `/donations/order` | 🔓/🔑 | `campaignId? | generalFund, amount, anonymous, message?, donorName?, donorEmail?` → gateway order |
| POST | `/donations/verify` | 🔓/🔑 | `orderId, paymentId, signature` → **server-side HMAC verification**, then transaction captured, campaign updated, receipt issued. Idempotent |
| POST | `/payments/mock/pay` | 🔓 | DEMO only: simulates the gateway authorising a mock order (signature made with a server-only secret) |
| POST | `/payments/webhook` | Razorpay | `X-Razorpay-Signature` verified against the raw body |
| GET | `/donations/mine`, `/donations/:id/receipt` | 🔑 | My donations / receipt |
| POST | `/loans` | 👩 | `amount, purpose, tenureMonths, monthlyIncome?, description?, consentToShareWithLenders:true` |
| GET | `/loans/mine` | 🔑 | Mine with offers |
| POST | `/loans/:id/offers/:offerId/accept` | 🔑 | Accept an offer (identity then shared with that lender only) |
| POST | `/loans/:id/withdraw` | 🔑 | Withdraw |
| GET | `/loans/market` | 🛡 lender | Anonymised requests |
| POST | `/loans/:id/offers` | 🛡 lender | `annualInterestRate (0–36), processingFee, tenureMonths, terms, regulatoryId` |
| GET | `/transparency` | 🔓 | Live totals (demo excluded): donations, distributed, fees, campaigns, by category, monthly |

There is **no** endpoint that lets a client mark a payment or donation as paid.

## Messages & notifications
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/messages/conversations` | 🔑 | Conversation list with unread counts |
| GET | `/messages/with/:userId?before=` | 🔑 | Thread (50 per page) + `canReply` |
| POST | `/messages` | 🔑 | `to, text?, evidenceIds?, caseId?` — only between connected people (case, appointment, emergency contact, accepted responder, admin); not if blocked |
| POST | `/messages/with/:userId/read` | 🔑 | Mark read (emits `message:read`) |
| GET | `/notifications?unread=true` | 🔑 | Latest 100 + unread count |
| POST | `/notifications/:id/read`, `/notifications/read-all` | 🔑 | Mark read |

## Admin — `/api/admin` (👑 only)
`GET /stats` · `GET /users?q=&role=&status=` · `PATCH /users/:id {status, role}` · `GET /professionals/:kind` · `GET /verifications?status=` · `POST /verifications/:id/decision {decision: approved|rejected|more_info, note}` · `GET /sos` (approximate locations) · `GET /complaints` · `GET /appointments` · `GET /evidence/access-log` · `GET /evidence/stats` · `GET /audit?action=` · `GET /moderation` · `POST /moderation/posts/:id {action: publish|remove|feature|unfeature}` · `POST /moderation/comments/:id` · `POST /reports/:id {status}` · `GET /finance` · `GET/POST /schemes`, `PUT /schemes/:id` · `GET /settings`, `PUT /settings/:key`

## Socket.io events
Connect with `auth: { token: <accessToken> }`. Server joins you to `user:<id>`.

| Direction | Event | Payload |
|---|---|---|
| → server | `location:update` | `{lat, lng, accuracy?, battery?}` (throttled 2 s; stored only during share/SOS) |
| → server | `location:watch` / `location:unwatch` | `{userId}` — authorised per request |
| → server | `sos:join` | `{sosId}` |
| → server | `chat:typing` | `{to}` |
| → server | `responder:location` | `{lat, lng}` (verified responders in responder mode) |
| ← client | `notification` | Notification document |
| ← client | `sos:update` | Owner's SOS view |
| ← client | `sos:contact-alert` | `{sosId, name, isDemo}` |
| ← client | `sos:nearby` | `{sosId, distanceKm, approxLocation, isDemo}` |
| ← client | `sos:ended` | `{sosId, kind}` |
| ← client | `location:update` | `{userId, lat, lng, accuracy, battery, at, sosId}` |
| ← client | `message:new`, `message:read`, `chat:typing` | Chat events |
