# Raksha architecture

```
┌──────────────────────────── Clients ────────────────────────────┐
│ React PWA (Vite, TS, Tailwind)  ·  installable · offline SOS page │
│ Women · Contacts · Responders · Lawyers · NGOs · Counsellors ·   │
│ Police · Donors · Lenders · Admins (role-based dashboards)        │
└───────────────┬───────────────────────────────┬──────────────────┘
          HTTPS REST (JSON)                 WebSocket (Socket.io)
┌───────────────▼───────────────────────────────▼──────────────────┐
│ Node.js + Express API (TypeScript)                                │
│  middleware: helmet · CORS allow-list · rate limits · mongo-sanitize│
│              zod validation · JWT auth · role & verification checks│
│              CSRF guard (cookie endpoints) · central error handler │
│  controllers → services                                            │
│   sos ─ messaging (SMS/WhatsApp/email) ─ emergency (112/police)    │
│   location ─ realtime (socket bus) ─ notify                        │
│   access (authorization rules) ─ audit                             │
│   storage (AES-256-GCM, local or S3) ─ scanner (ClamAV)            │
│   matching ─ schemeEligibility ─ complaintDraft ─ moderation       │
│   payments (Razorpay / demo mock) ─ scheduler (reminders)          │
└───────────────┬───────────────────────────────┬──────────────────┘
          MongoDB (Mongoose)              Private object storage
     2dsphere geo indexes, TTL           (encrypted blobs only, never
     indexes for sessions/OTPs)           exposed via public URLs)
```

## Key design decisions

### Honest integrations
Every external dependency sits behind a service with an explicit outcome:
`sent` · `simulated` (demo) · `not_configured` · `pending` · `confirmed` · `failed`.
The UI shows these statuses verbatim. Raksha never displays "police notified", "FIR filed" or "payment successful" unless the integration (or a verified official) confirmed it.

### SOS pipeline
1. Client: 3-second press-and-hold → 3-second cancellable countdown → `POST /api/sos {confirm:true}`.
2. Server creates the `SOSAlert`, a `LocationShare` (tracking token) and the first `LocationEvent`.
3. In parallel (`Promise.allSettled`): contact alerts on each enabled channel, `$nearSphere` query for verified active responders (demo alerts only reach demo responders), and the emergency-service dispatcher.
4. Each outcome is written to the alert's `timeline` and `contactDeliveries`; `contactsAlertedAt − createdAt` feeds the "< 60 s" metric in the admin dashboard.
5. Client starts segmented audio/video recording (20 s self-contained files) and streams location over Socket.io every ~5 s.
6. Cancel / resolve requires the safety PIN (or password). Contacts and responders are informed.

### Location privacy
Stored only during an active SOS or a time-boxed share. Precise coordinates are visible to the owner, linked emergency contacts (with permission, only while active) and responders who accepted. Responders before acceptance and admins get coordinates rounded to ~1 km. Socket room membership (`loc:<userId>`) is authorised on every join.

### Evidence integrity
`upload → magic-byte type check → ClamAV (optional) → SHA-256 of plaintext → AES-256-GCM (random IV, auth tag) → private storage`. Downloads decrypt in memory, re-verify the hash, set `X-Integrity-Verified`, and log the access in both the item's `accessLog` (chain of custody) and the global `AuditLog` (visible to the owner under "Who accessed my information"). Packages include a manifest with hashes for court use.

### Authorization model
`services/access.ts` centralises rules: `caseAccess`, `evidenceAccess`, `canChat`, `canViewPreciseLocation`. Routes add `authorize(role)` and `requireVerified` for professional actions. Professionals can never set their own `verified` flag; only `POST /api/admin/verifications/:id/decision` can.

### Sessions
Short-lived access JWT (memory only on the client) + rotating refresh token in an `httpOnly` cookie. Only SHA-256 hashes of refresh tokens are stored; reuse of a revoked token revokes all of a user's sessions.

### Payments
`order → gateway checkout → POST /donations/verify` (HMAC-SHA256 of `order_id|payment_id` with the secret) `→ transaction captured → campaign totals → receipt`. Webhooks are verified against the raw body. In demo mode a mock gateway signs with a process-local secret the client never sees, so the same verification path is exercised.

### Data model (MongoDB collections)
`users, sessions, otps, emergencycontacts, responders, sosalerts, locationevents, locationshares, evidences, cases, complaints, lawyers, ngos, counsellors, appointments, schemes, schemeapplications, campaigns, donations, transactions, loanrequests, messages, notifications, communityposts, comments, reports, verifications, auditlogs, settings, rightsarticles`

Indexes cover user ids, case numbers, geo (`2dsphere` on responders, SOS alerts, location events, professionals), SOS status + time, professional matching (`verified, specializations, state, city, languages`), scheme search (text + `active, level, states, category`), and TTL expiry for sessions and OTPs.

### Internationalisation
UI strings live in `frontend/src/i18n/<lang>.ts` (English and Hindi included; missing keys fall back to English). Rights articles store `translations.<lang>` in the database, so adding Marathi, Bengali, Tamil, etc. is a content task, not a code change.

### Scaling notes
- Socket.io: add the Redis adapter for multiple API instances.
- Run the reminder scheduler on one instance (`RUN_SCHEDULER=false` on the others) or move it to a job queue.
- Use `STORAGE_DRIVER=s3` with a private bucket (SSE enabled) and an S3-compatible provider in India region for data residency.
- Put the API behind HTTPS (Render/Railway/ALB terminate TLS); `trust proxy` is enabled for correct client IPs in rate limits and logs.
