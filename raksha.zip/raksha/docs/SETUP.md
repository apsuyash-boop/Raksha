# Setup, testing and deployment

## Prerequisites
- Node.js **20 or 22** and npm 10
- MongoDB 6+ running locally **or** a MongoDB Atlas connection string
- (Optional) Docker Desktop for the one-command stack

## 1. Local installation

```bash
# from the project root
npm install                 # installs the root helper (concurrently)
npm run install:all         # installs backend + frontend dependencies

cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

For local development you can leave the secrets blank: the server generates temporary JWT secrets and uses a development-only encryption key. **Set real values before any shared or production deployment** (see below).

## 2. Database

Start MongoDB locally (`mongod`), or use Docker:

```bash
docker run -d --name raksha-mongo -p 27017:27017 mongo:7
```

Or set `DATABASE_URL` in `backend/.env` to your Atlas string, e.g.
`mongodb+srv://USER:PASS@cluster0.xxxxx.mongodb.net/raksha?retryWrites=true&w=majority`.

Collections and indexes are created automatically on first start.

## 3. Seed reference and demo data

```bash
npm run seed           # schemes, rights library, settings + demo accounts (safe to re-run)
npm run seed:fresh     # DROPS the database first (refused when NODE_ENV=production)
```

Demo accounts (password `RakshaDemo@2026`; Priya's safety PIN `2580`):

| Role | Email |
|---|---|
| Woman | priya.demo@raksha.app |
| Emergency contact | contact.demo@raksha.app |
| Lawyer | lawyer.demo@raksha.app |
| NGO | ngo.demo@raksha.app |
| Counsellor | counsellor.demo@raksha.app |
| Responder | responder.demo@raksha.app |
| Police | police.demo@raksha.app |
| Donor | donor.demo@raksha.app |
| Lender | lender.demo@raksha.app |
| Admin | admin.demo@raksha.app |

With `DEMO_MODE=true` the login page also shows one-click demo buttons. All demo data is flagged `isDemo`, labelled in the UI, and excluded from live transparency figures. **Demo SOS never contacts real people or emergency services** (enforced on the server and covered by tests).

## 4. Run

```bash
npm run dev            # API on :5000 and web app on :5173 together
# or separately
npm run dev:backend
npm run dev:frontend
```

Open http://localhost:5173. Vite proxies `/api` and `/socket.io` to the backend, so cookies and websockets work same-origin.

Geolocation, camera and microphone need a secure context: `localhost` is fine; on a phone over your LAN use HTTPS (e.g. `npx localtunnel --port 5173` or a reverse proxy).

## 5. Tests

```bash
npm test               # = cd backend && npm test   (Vitest + Supertest + in-memory MongoDB)
```

`mongodb-memory-server` downloads a MongoDB binary on first run (needs internet once). Suites:

| File | Covers |
|---|---|
| `auth.test.ts` | register/login/refresh rotation, password hashing, weak passwords, no self-assigned admin, account-enumeration-safe reset, health endpoint |
| `evidence.test.ts` | encryption + hash, magic-byte validation, **unauthorised users cannot access evidence**, consent-gated lawyer access, admin justification + access history, integrity check |
| `cases.test.ts` | **unauthorised users cannot access another user's case**, request → accept flow, unverified lawyers never matched, complaints never marked police-confirmed by the user |
| `admin.test.ts` | **non-admins cannot verify professionals**, professionals cannot self-verify, admin-only routes |
| `payments.test.ts` | **payment cannot be marked successful from the frontend**, no client-side "paid" endpoint, verified flow + idempotency, demo excluded from transparency |
| `sos.test.ts` | deliberate confirmation, **demo SOS cannot contact real emergency services (even when configured)**, honest "not configured", PIN-protected cancel/resolve, **sensitive location protection** (strangers, contacts, responders before/after accept, admins, tracking tokens), demo SOS never reaches real responders |

Type checks: `npm run typecheck` (both apps).

## 6. Production configuration checklist

Backend environment (see `backend/.env.example` for every variable):

- `NODE_ENV=production`
- `DATABASE_URL` — Atlas connection string (enable IP allow-list / VPC peering)
- `JWT_SECRET`, `JWT_REFRESH_SECRET` — ≥ 32 random chars each (server refuses to start without them)
- `ENCRYPTION_KEY` — 64 hex chars; store in a secrets manager and back it up (lost key = unreadable evidence)
- `APP_URL` — public frontend URL; `CORS_ORIGINS` — exact frontend origin(s)
- `COOKIE_SECURE=true`; `COOKIE_SAMESITE=none` if the frontend and API are on different sites (e.g. Vercel + Render), `lax` if same site
- `DEMO_MODE=false` (default in production)
- `STORAGE_DRIVER=s3` + bucket credentials (private bucket, block public access)
- Providers you actually have: SMS, WhatsApp, SMTP, Razorpay (+ webhook secret), ClamAV, emergency/police APIs

Frontend environment: `VITE_API_URL=https://api.your-domain` (and optionally `VITE_SOCKET_URL`).

## 7. Deployment

### Frontend → Vercel or Netlify
- Root directory: `frontend`, build command `npm run build`, output `dist`
- Env: `VITE_API_URL`
- `vercel.json` / `netlify.toml` already include SPA rewrites, `sw.js` no-cache and security headers.

### Backend → Render / Railway / AWS
- **Render**: use `render.yaml` (root dir `backend`, build `npm install --include=dev && npm run build`, start `npm start`, health check `/api/health`). Add the secret env vars in the dashboard. Run the seed once from a Render shell: `node dist/seed/index.js` (set `SEED_DIR=../database/seed`).
- **Railway**: new service from the repo, root `backend`, same build/start commands.
- **AWS** (ECS/App Runner/Elastic Beanstalk): build the `backend/Dockerfile` (the compose file shows how the `database` folder is passed as an extra build context), expose port 5000, health check `/api/health`, put it behind an ALB with an ACM certificate.

### HTTPS
TLS is terminated by the platform (Vercel/Netlify/Render/Railway/ALB). The API sets HSTS in production, uses `secure` cookies, and trusts the proxy's `X-Forwarded-*` headers. Never expose the API over plain HTTP in production.

### CORS
`CORS_ORIGINS` is an explicit allow-list; requests from other origins get no CORS headers, and cookie endpoints additionally require an allowed `Origin` plus the `X-Requested-With: raksha-web` header.

### Docker (all-in-one)
```bash
cp backend/.env.example backend/.env   # set JWT_SECRET, JWT_REFRESH_SECRET, ENCRYPTION_KEY (production mode)
docker compose up --build              # http://localhost:8080
docker compose exec backend node dist/seed/index.js
```
nginx serves the PWA and proxies `/api` and `/socket.io` to the API container.

### Razorpay webhook
Point a webhook for `payment.captured` to `https://api.your-domain/api/payments/webhook` with `RAZORPAY_WEBHOOK_SECRET`.

### Health check
`GET /api/health` → `200 {status:"ok", database:"connected", uptimeSeconds, version}` or `503` when the database is unreachable.
