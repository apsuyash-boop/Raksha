import { lazy, ReactNode, Suspense } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { AppLayout } from '@/layouts/AppLayout';
import { PublicLayout } from '@/layouts/PublicLayout';
import { Spinner } from '@/components/ui';
import { ROLE_HOME } from '@/utils/format';
import type { Role } from '@/types';

const Landing = lazy(() => import('@/pages/Landing'));
const Auth = lazy(() => import('@/pages/Auth'));
const Dashboard = lazy(() => import('@/pages/Dashboard'));
const SOS = lazy(() => import('@/pages/SOS'));
const Contacts = lazy(() => import('@/pages/EmergencyContacts'));
const EvidencePage = lazy(() => import('@/pages/Evidence'));
const Rights = lazy(() => import('@/pages/Rights'));
const LegalHelp = lazy(() => import('@/pages/LegalHelp'));
const Cases = lazy(() => import('@/pages/Cases'));
const Complaints = lazy(() => import('@/pages/Complaints'));
const Schemes = lazy(() => import('@/pages/Schemes'));
const Counselling = lazy(() => import('@/pages/Counselling'));
const Community = lazy(() => import('@/pages/Community'));
const Finance = lazy(() => import('@/pages/Finance'));
const Messages = lazy(() => import('@/pages/Messages'));
const Notifications = lazy(() => import('@/pages/Notifications'));
const Settings = lazy(() => import('@/pages/Settings'));
const Legal = lazy(() => import('@/pages/LegalPages'));
const Track = lazy(() => import('@/pages/Track'));
const Guardian = lazy(() => import('@/pages/Guardian'));
const Professional = lazy(() => import('@/pages/dashboards/Professional'));
const Responder = lazy(() => import('@/pages/dashboards/Responder'));
const Admin = lazy(() => import('@/pages/dashboards/Admin'));
const Partners = lazy(() => import('@/pages/dashboards/Partners'));

function Protected({ children, roles }: { children: ReactNode; roles?: Role[] }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <Spinner className="min-h-[60vh]" />;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />;
  if (roles && !roles.includes(user.role)) return <Navigate to={ROLE_HOME[user.role] || '/dashboard'} replace />;
  return <>{children}</>;
}

function GuestOnly({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner className="min-h-[60vh]" />;
  if (user) return <Navigate to={ROLE_HOME[user.role] || '/dashboard'} replace />;
  return <>{children}</>;
}

/** Public pages render inside the app shell when signed in, and the marketing shell otherwise. */
function Adaptive() {
  const { user, loading } = useAuth();
  if (loading) return <Spinner className="min-h-[60vh]" />;
  return user ? <AppLayout /> : <PublicLayout />;
}

function NotFound() {
  return (
    <div className="mx-auto max-w-md px-6 py-24 text-center">
      <p className="font-display text-6xl font-semibold text-rk-600">404</p>
      <p className="mt-3 text-lg font-semibold">This page does not exist.</p>
      <p className="mt-1 text-ink-mute">In an emergency, call 112 or Women Helpline 181.</p>
      <a href="/" className="mt-6 inline-block font-semibold text-rk-700 underline">
        Go home
      </a>
    </div>
  );
}

const W: Role[] = ['user'];

export default function App() {
  return (
    <Suspense fallback={<Spinner className="min-h-screen" />}>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Landing />} />
          <Route path="/privacy" element={<Legal kind="privacy" />} />
          <Route path="/terms" element={<Legal kind="terms" />} />
          <Route path="/partners" element={<Partners />} />
        </Route>
        <Route path="/login" element={<GuestOnly><Auth mode="login" /></GuestOnly>} />
        <Route path="/register" element={<GuestOnly><Auth mode="register" /></GuestOnly>} />
        <Route path="/forgot-password" element={<Auth mode="forgot" />} />
        <Route path="/reset-password" element={<Auth mode="reset" />} />
        <Route path="/track/:token" element={<Track />} />

        <Route element={<Adaptive />}>
          <Route path="/rights" element={<Rights />} />
          <Route path="/rights/:slug" element={<Rights />} />
          <Route path="/schemes" element={<Schemes />} />
          <Route path="/community" element={<Community />} />
          <Route path="/community/:id" element={<Community />} />
          <Route path="/campaigns" element={<Finance view="campaigns" />} />
          <Route path="/campaigns/:slug" element={<Finance view="campaign" />} />
          <Route path="/donate" element={<Finance view="donate" />} />
          <Route path="/transparency" element={<Finance view="transparency" />} />
        </Route>

        <Route element={<Protected><AppLayout /></Protected>}>
          <Route path="/dashboard" element={<Protected roles={W}><Dashboard /></Protected>} />
          <Route path="/sos" element={<Protected roles={W}><SOS /></Protected>} />
          <Route path="/emergency-contacts" element={<Protected roles={W}><Contacts /></Protected>} />
          <Route path="/evidence" element={<Protected roles={W}><EvidencePage /></Protected>} />
          <Route path="/legal-help" element={<Protected roles={W}><LegalHelp /></Protected>} />
          <Route path="/lawyers" element={<Protected roles={W}><LegalHelp initialTab="lawyers" /></Protected>} />
          <Route path="/ngos" element={<Protected roles={W}><LegalHelp initialTab="ngos" /></Protected>} />
          <Route path="/cases" element={<Cases />} />
          <Route path="/cases/:id" element={<Cases />} />
          <Route path="/complaints" element={<Complaints />} />
          <Route path="/complaints/new" element={<Protected roles={W}><Complaints /></Protected>} />
          <Route path="/complaints/:id" element={<Complaints />} />
          <Route path="/counselling" element={<Protected roles={W}><Counselling /></Protected>} />
          <Route path="/financial-help" element={<Protected roles={W}><Finance view="help" /></Protected>} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/guardian" element={<Guardian />} />
          <Route path="/guardian/sos/:sosId" element={<Guardian />} />
          <Route path="/guardian/live/:userId" element={<Guardian />} />
          <Route path="/lawyer/dashboard" element={<Protected roles={['lawyer']}><Professional kind="lawyer" /></Protected>} />
          <Route path="/ngo/dashboard" element={<Protected roles={['ngo']}><Professional kind="ngo" /></Protected>} />
          <Route path="/counsellor/dashboard" element={<Protected roles={['counsellor']}><Professional kind="counsellor" /></Protected>} />
          <Route path="/police/dashboard" element={<Protected roles={['police']}><Professional kind="police" /></Protected>} />
          <Route path="/lender/dashboard" element={<Protected roles={['lender']}><Professional kind="lender" /></Protected>} />
          <Route path="/responder/dashboard" element={<Protected roles={['responder']}><Responder /></Protected>} />
          <Route path="/admin/dashboard" element={<Protected roles={['admin']}><Admin /></Protected>} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
