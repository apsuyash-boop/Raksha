import axios, { AxiosError, AxiosRequestConfig } from 'axios';

export const API_BASE = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

let accessToken: string | null = null;
let onAuthLost: (() => void) | null = null;
let onToken: ((t: string | null) => void) | null = null;

export const tokenStore = {
  get: () => accessToken,
  set: (t: string | null) => {
    accessToken = t;
    onToken?.(t);
  },
  onLost: (fn: () => void) => (onAuthLost = fn),
  onChange: (fn: (t: string | null) => void) => (onToken = fn),
};

export const api = axios.create({
  baseURL: `${API_BASE}/api`,
  withCredentials: true,
  timeout: 30000,
  headers: { 'X-Requested-With': 'raksha-web' },
});

api.interceptors.request.use((cfg) => {
  if (accessToken) cfg.headers.Authorization = `Bearer ${accessToken}`;
  return cfg;
});

let refreshing: Promise<string | null> | null = null;

export async function refreshAccessToken(): Promise<string | null> {
  if (!refreshing) {
    refreshing = axios
      .post(`${API_BASE}/api/auth/refresh`, {}, { withCredentials: true, headers: { 'X-Requested-With': 'raksha-web' } })
      .then((r) => {
        tokenStore.set(r.data.data.accessToken);
        return r.data.data.accessToken as string;
      })
      .catch(() => {
        tokenStore.set(null);
        return null;
      })
      .finally(() => {
        setTimeout(() => (refreshing = null), 0);
      });
  }
  return refreshing;
}

api.interceptors.response.use(
  (r) => r,
  async (error: AxiosError) => {
    const cfg = error.config as AxiosRequestConfig & { _retry?: boolean };
    const url = cfg?.url || '';
    if (error.response?.status === 401 && !cfg?._retry && !url.includes('/auth/')) {
      cfg._retry = true;
      const t = await refreshAccessToken();
      if (t) return api(cfg);
      onAuthLost?.();
    }
    return Promise.reject(error);
  },
);

export interface ApiErrorShape {
  message: string;
  code?: string;
  fields?: Record<string, string>;
  status?: number;
}

export function apiError(e: unknown): ApiErrorShape {
  const err = e as AxiosError<any>;
  if (!err?.isAxiosError) return { message: (e as Error)?.message || 'Something went wrong' };
  if (!err.response) return { message: navigator.onLine ? 'Cannot reach Raksha servers. Please try again.' : 'You are offline.', code: 'NETWORK' };
  const body = err.response.data || {};
  const fields: Record<string, string> = {};
  for (const d of body?.error?.details || []) if (d?.field) fields[d.field] = d.message;
  return { message: body.message || 'Something went wrong', code: body?.error?.code, fields, status: err.response.status };
}

/** Unwraps the { success, message, data } envelope. */
export async function get<T = any>(url: string, params?: Record<string, unknown>): Promise<T> {
  const r = await api.get(url, { params });
  return r.data.data as T;
}
export async function post<T = any>(url: string, body?: unknown): Promise<T & { _message?: string }> {
  const r = await api.post(url, body);
  return Object.assign({}, r.data.data, { _message: r.data.message });
}
export async function put<T = any>(url: string, body?: unknown): Promise<T & { _message?: string }> {
  const r = await api.put(url, body);
  return Object.assign({}, r.data.data, { _message: r.data.message });
}
export async function patch<T = any>(url: string, body?: unknown): Promise<T & { _message?: string }> {
  const r = await api.patch(url, body);
  return Object.assign({}, r.data.data, { _message: r.data.message });
}
export async function del<T = any>(url: string, body?: unknown): Promise<T & { _message?: string }> {
  const r = await api.delete(url, { data: body });
  return Object.assign({}, r.data.data, { _message: r.data.message });
}

/** Authenticated file download (evidence is never served from public URLs). */
export async function downloadFile(url: string, fallbackName: string, params?: Record<string, unknown>, method: 'get' | 'post' = 'get', body?: unknown) {
  const r = method === 'get' ? await api.get(url, { params, responseType: 'blob' }) : await api.post(url, body, { responseType: 'blob' });
  const cd = String(r.headers['content-disposition'] || '');
  const name = /filename="?([^"]+)"?/.exec(cd)?.[1] || fallbackName;
  const href = URL.createObjectURL(r.data);
  const a = document.createElement('a');
  a.href = href;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(href), 5000);
}

export async function blobUrl(url: string, params?: Record<string, unknown>) {
  const r = await api.get(url, { params, responseType: 'blob' });
  return URL.createObjectURL(r.data);
}
