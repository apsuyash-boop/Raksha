import { Link } from 'react-router-dom';
import { cn } from '@/utils/format';

export function LogoMark({ className }: { className?: string }) {
  // A shield formed by two hands meeting — protection and support.
  return (
    <svg viewBox="0 0 40 40" className={cn('h-9 w-9', className)} aria-hidden>
      <defs>
        <linearGradient id="rkg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#DC3D5A" />
          <stop offset="1" stopColor="#7A1328" />
        </linearGradient>
      </defs>
      <path d="M20 3 6 8.5v9.8C6 27.4 12 34.6 20 37c8-2.4 14-9.6 14-18.7V8.5L20 3Z" fill="url(#rkg)" />
      <path d="M13.5 21.5c2.2-3.6 4.4-5.4 6.5-5.4s4.3 1.8 6.5 5.4M20 16.1V28" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" fill="none" />
      <circle cx="20" cy="12" r="2.2" fill="#fff" />
    </svg>
  );
}

export function Logo({ to = '/', light = false }: { to?: string; light?: boolean }) {
  return (
    <Link to={to} className="flex items-center gap-2.5" aria-label="Raksha home">
      <LogoMark />
      <span className={cn('font-display text-[22px] font-semibold tracking-tight', light ? 'text-white' : 'text-ink')}>Raksha</span>
    </Link>
  );
}
