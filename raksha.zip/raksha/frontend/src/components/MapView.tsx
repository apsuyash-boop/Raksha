import { Fragment, useEffect } from 'react';
import { Circle, CircleMarker, MapContainer, Polyline, TileLayer, Tooltip, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const TILE = import.meta.env.VITE_MAP_TILE_URL || 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const ATTR = import.meta.env.VITE_MAP_ATTRIBUTION || '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

export interface MapPoint {
  lat: number;
  lng: number;
  label?: string;
  tone?: 'rk' | 'safe' | 'ink';
  accuracy?: number;
  approximate?: boolean;
}

function Recenter({ lat, lng, zoom }: { lat: number; lng: number; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView([lat, lng], map.getZoom() < 10 ? zoom : map.getZoom(), { animate: true });
  }, [lat, lng, zoom, map]);
  return null;
}

const COLORS = { rk: '#B4233C', safe: '#2F7D5B', ink: '#1F1A1C' };

export function MapView({ points, path, height = 300, zoom = 15, follow = true }: { points: MapPoint[]; path?: Array<[number, number]>; height?: number; zoom?: number; follow?: boolean }) {
  const main = points[0];
  if (!main) {
    return (
      <div className="grid place-items-center rounded-2xl border border-dashed border-sand-300 bg-sand-100 text-sm text-ink-mute" style={{ height }}>
        Waiting for location…
      </div>
    );
  }
  return (
    <div className="overflow-hidden rounded-2xl border border-sand-200" style={{ height }}>
      <MapContainer center={[main.lat, main.lng]} zoom={zoom} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false} attributionControl>
        <TileLayer url={TILE} attribution={ATTR} />
        {follow && <Recenter lat={main.lat} lng={main.lng} zoom={zoom} />}
        {path && path.length > 1 && <Polyline positions={path} pathOptions={{ color: '#B4233C', weight: 3, opacity: 0.6, dashArray: '4 6' }} />}
        {points.map((p, i) => (
          <Fragment key={i}>
            {!!(p.accuracy || p.approximate) && <Circle center={[p.lat, p.lng]} radius={p.approximate ? 1100 : Math.min(p.accuracy || 0, 500)} pathOptions={{ color: COLORS[p.tone || 'rk'], weight: 1, fillOpacity: 0.08 }} />}
            {!p.approximate && (
              <CircleMarker center={[p.lat, p.lng]} radius={9} pathOptions={{ color: '#fff', weight: 3, fillColor: COLORS[p.tone || 'rk'], fillOpacity: 1 }}>
                {p.label && <Tooltip direction="top" offset={[0, -8]} permanent={i === 0}>{p.label}</Tooltip>}
              </CircleMarker>
            )}
          </Fragment>
        ))}
      </MapContainer>
    </div>
  );
}
