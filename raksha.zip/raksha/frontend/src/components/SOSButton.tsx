import { useCallback, useEffect, useRef, useState } from 'react';
import { cn } from '@/utils/format';
import { useI18n } from '@/contexts/I18nContext';

/**
 * Deliberate activation: press-and-hold for HOLD_MS, then a short COUNTDOWN that can still be stopped.
 * Keyboard: hold Space/Enter. This prevents pocket presses while staying fast in a real emergency.
 */
const HOLD_MS = 3000;
const COUNTDOWN = 3;

export function SOSButton({ onActivate, disabled, size = 'lg', label }: { onActivate: () => void; disabled?: boolean; size?: 'md' | 'lg'; label?: string }) {
  const { t } = useI18n();
  const [progress, setProgress] = useState(0);
  const [count, setCount] = useState<number | null>(null);
  const start = useRef<number | null>(null);
  const raf = useRef<number | null>(null);
  const timer = useRef<number | null>(null);

  const reset = useCallback(() => {
    start.current = null;
    if (raf.current) cancelAnimationFrame(raf.current);
    setProgress(0);
  }, []);

  const tick = useCallback(() => {
    if (start.current == null) return;
    const p = Math.min(1, (performance.now() - start.current) / HOLD_MS);
    setProgress(p);
    if (p >= 1) {
      start.current = null;
      try {
        navigator.vibrate?.(200);
      } catch {
        /* ignore */
      }
      setCount(COUNTDOWN);
      return;
    }
    raf.current = requestAnimationFrame(tick);
  }, []);

  const down = useCallback(() => {
    if (disabled || count !== null) return;
    start.current = performance.now();
    raf.current = requestAnimationFrame(tick);
  }, [disabled, count, tick]);

  const up = useCallback(() => {
    if (start.current != null) reset();
  }, [reset]);

  useEffect(() => {
    if (count === null) return;
    if (count === 0) {
      setCount(null);
      setProgress(0);
      onActivate();
      return;
    }
    timer.current = window.setTimeout(() => setCount((c) => (c == null ? null : c - 1)), 1000);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [count, onActivate]);

  const abort = () => {
    if (timer.current) clearTimeout(timer.current);
    setCount(null);
    reset();
  };

  const dim = size === 'lg' ? 'h-56 w-56 sm:h-64 sm:w-64' : 'h-40 w-40';
  const R = 47;
  const C = 2 * Math.PI * R;

  return (
    <div className="flex flex-col items-center">
      <div className={cn('relative grid place-items-center', dim)}>
        {!disabled && count === null && progress === 0 && (
          <>
            <span className="absolute inset-4 rounded-full bg-rk-500/30 animate-pulse-ring" aria-hidden />
            <span className="absolute inset-4 rounded-full bg-rk-500/20 animate-pulse-ring [animation-delay:1.1s]" aria-hidden />
          </>
        )}
        <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90" aria-hidden>
          <circle cx="50" cy="50" r={R} fill="none" stroke="rgba(180,35,60,.12)" strokeWidth="3" />
          <circle cx="50" cy="50" r={R} fill="none" stroke="#B4233C" strokeWidth="3.5" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - (count !== null ? 1 : progress))} />
        </svg>
        <button
          type="button"
          disabled={disabled}
          onPointerDown={(e) => {
            (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
            down();
          }}
          onPointerUp={up}
          onPointerCancel={up}
          onPointerLeave={up}
          onKeyDown={(e) => {
            if ((e.key === ' ' || e.key === 'Enter') && !e.repeat) {
              e.preventDefault();
              down();
            }
          }}
          onKeyUp={(e) => (e.key === ' ' || e.key === 'Enter') && up()}
          onContextMenu={(e) => e.preventDefault()}
          aria-label={`${label || 'SOS'} — ${t('sos.hold')}`}
          className={cn(
            'relative grid touch-none select-none place-items-center rounded-full bg-gradient-to-b from-rk-500 to-rk-700 text-white shadow-sos transition-transform',
            size === 'lg' ? 'h-44 w-44 sm:h-52 sm:w-52' : 'h-32 w-32',
            progress > 0 && 'scale-[.97]',
            disabled && 'opacity-60',
          )}
        >
          <span className="pointer-events-none flex flex-col items-center">
            <span className={cn('font-display font-bold tracking-wide', size === 'lg' ? 'text-5xl' : 'text-4xl')}>{count !== null ? count : 'SOS'}</span>
            <span className="mt-1 max-w-[9rem] text-center text-xs font-medium text-white/85">{count !== null ? t('sos.countdown', { n: count }) : progress > 0 ? t('sos.holding') : t('sos.hold')}</span>
          </span>
        </button>
      </div>
      {count !== null && (
        <button onClick={abort} className="mt-4 rounded-full border-2 border-ink bg-white px-6 py-3 text-base font-bold text-ink shadow-card">
          {t('sos.cancelCountdown')}
        </button>
      )}
    </div>
  );
}
