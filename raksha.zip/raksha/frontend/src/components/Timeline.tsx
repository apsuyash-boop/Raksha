import { ReactNode } from 'react';
import { Check } from 'lucide-react';
import { cn, fmtDate, fmtTime } from '@/utils/format';

export interface Step {
  key: string;
  label: ReactNode;
  detail?: ReactNode;
  at?: string;
  state: 'done' | 'current' | 'pending' | 'warn';
}

export function Timeline({ steps, timeOnly }: { steps: Step[]; timeOnly?: boolean }) {
  return (
    <ol className="relative">
      {steps.map((s, i) => (
        <li key={s.key + i} className="relative flex gap-4 pb-5 last:pb-0">
          {i < steps.length - 1 && <span className={cn('absolute left-[13px] top-7 h-[calc(100%-20px)] w-0.5', s.state === 'done' ? 'bg-rk-300' : 'bg-sand-200')} aria-hidden />}
          <span
            className={cn(
              'relative z-[1] mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full border-2',
              s.state === 'done' && 'border-rk-600 bg-rk-600 text-white',
              s.state === 'current' && 'border-rk-600 bg-white text-rk-600',
              s.state === 'pending' && 'border-sand-300 bg-white text-sand-300',
              s.state === 'warn' && 'border-warn-500 bg-warn-50 text-warn-700',
            )}
          >
            {s.state === 'done' ? <Check className="h-3.5 w-3.5" strokeWidth={3} /> : s.state === 'current' ? <span className="h-2 w-2 animate-pulse rounded-full bg-rk-600" /> : <span className="h-1.5 w-1.5 rounded-full bg-current" />}
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-baseline justify-between gap-x-3">
              <p className={cn('text-[15px] font-semibold', s.state === 'pending' ? 'text-ink-mute' : 'text-ink')}>{s.label}</p>
              {s.at && <time className="text-xs tabular-nums text-ink-mute">{timeOnly ? fmtTime(s.at) : fmtDate(s.at, true)}</time>}
            </div>
            {s.detail && <div className="mt-0.5 text-sm text-ink-mute">{s.detail}</div>}
          </div>
        </li>
      ))}
    </ol>
  );
}
