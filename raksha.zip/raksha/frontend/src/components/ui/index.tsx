import { ButtonHTMLAttributes, forwardRef, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes, useEffect, useId, useRef } from 'react';
import { AlertTriangle, Inbox, Loader2, RefreshCw, X } from 'lucide-react';
import { cn, initials } from '@/utils/format';

/* -------------------------------- Button -------------------------------- */
type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'safe' | 'outline';
const VARIANTS: Record<Variant, string> = {
  primary: 'bg-rk-600 text-white hover:bg-rk-700 shadow-sm shadow-rk-900/10',
  secondary: 'bg-rk-50 text-rk-700 hover:bg-rk-100',
  outline: 'border border-sand-300 bg-white text-ink hover:border-rk-300 hover:text-rk-700',
  ghost: 'text-ink-soft hover:bg-sand-100 hover:text-ink',
  danger: 'bg-rk-700 text-white hover:bg-rk-800',
  safe: 'bg-safe-500 text-white hover:bg-safe-600',
};
const SIZES = { sm: 'h-9 px-3 text-sm gap-1.5', md: 'h-11 px-5 text-[15px] gap-2', lg: 'h-14 px-6 text-base gap-2.5' };

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: keyof typeof SIZES;
  loading?: boolean;
  icon?: ReactNode;
}
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(({ variant = 'primary', size = 'md', loading, icon, className, children, disabled, ...p }, ref) => (
  <button
    ref={ref}
    className={cn('inline-flex select-none items-center justify-center rounded-xl font-semibold transition active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-55', VARIANTS[variant], SIZES[size], className)}
    disabled={disabled || loading}
    aria-busy={loading || undefined}
    {...p}
  >
    {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : icon}
    {children}
  </button>
));
Button.displayName = 'Button';

/* --------------------------------- Card --------------------------------- */
export function Card({ className, children, ...p }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('card', className)} {...p}>
      {children}
    </div>
  );
}
export function CardHeader({ title, subtitle, action, icon }: { title: ReactNode; subtitle?: ReactNode; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-sand-200 px-5 py-4">
      <div className="flex items-start gap-3">
        {icon && <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-rk-50 text-rk-600">{icon}</div>}
        <div>
          <h3 className="font-sans text-[15px] font-semibold text-ink">{title}</h3>
          {subtitle && <p className="mt-0.5 text-sm text-ink-mute">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

/* --------------------------------- Field -------------------------------- */
export function Field({ label, error, hint, children, htmlFor, required }: { label?: ReactNode; error?: string; hint?: ReactNode; children: ReactNode; htmlFor?: string; required?: boolean }) {
  return (
    <div>
      {label && (
        <label className="label" htmlFor={htmlFor}>
          {label}
          {required && <span className="text-rk-600"> *</span>}
        </label>
      )}
      {children}
      {error ? (
        <p className="mt-1.5 text-sm text-rk-700" role="alert">
          {error}
        </p>
      ) : hint ? (
        <p className="mt-1.5 text-xs text-ink-mute">{hint}</p>
      ) : null}
    </div>
  );
}

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement> & { label?: string; error?: string; hint?: ReactNode }>(({ label, error, hint, className, id, required, ...p }, ref) => {
  const auto = useId();
  const iid = id || auto;
  return (
    <Field label={label} error={error} hint={hint} htmlFor={iid} required={required}>
      <input ref={ref} id={iid} className={cn('input', error && 'border-rk-500', className)} aria-invalid={!!error || undefined} required={required} {...p} />
    </Field>
  );
});
Input.displayName = 'Input';

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string; error?: string; hint?: ReactNode }>(({ label, error, hint, className, id, required, ...p }, ref) => {
  const auto = useId();
  const iid = id || auto;
  return (
    <Field label={label} error={error} hint={hint} htmlFor={iid} required={required}>
      <textarea ref={ref} id={iid} className={cn('input min-h-[110px] resize-y', error && 'border-rk-500', className)} aria-invalid={!!error || undefined} required={required} {...p} />
    </Field>
  );
});
Textarea.displayName = 'Textarea';

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement> & { label?: string; error?: string; options: Array<[string, string]>; placeholder?: string }>(
  ({ label, error, options, placeholder, className, id, required, ...p }, ref) => {
    const auto = useId();
    const iid = id || auto;
    return (
      <Field label={label} error={error} htmlFor={iid} required={required}>
        <select ref={ref} id={iid} className={cn('input appearance-none bg-[length:16px] bg-[right_12px_center] bg-no-repeat pr-9', className)} style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236F6669' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")" }} required={required} {...p}>
          {placeholder !== undefined && <option value="">{placeholder}</option>}
          {options.map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </select>
      </Field>
    );
  },
);
Select.displayName = 'Select';

export function Switch({ checked, onChange, label, description, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; description?: ReactNode; disabled?: boolean }) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div>
        <label htmlFor={id} className="text-[15px] font-medium text-ink">
          {label}
        </label>
        {description && <p className="mt-0.5 text-sm text-ink-mute">{description}</p>}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={cn('relative mt-0.5 h-7 w-12 shrink-0 rounded-full transition disabled:opacity-50', checked ? 'bg-rk-600' : 'bg-sand-300')}
      >
        <span className={cn('absolute top-1 h-5 w-5 rounded-full bg-white shadow transition', checked ? 'left-6' : 'left-1')} />
      </button>
    </div>
  );
}

/* --------------------------------- Badge -------------------------------- */
const TONES = {
  neutral: 'bg-sand-100 text-ink-soft border-sand-200',
  rk: 'bg-rk-50 text-rk-700 border-rk-100',
  safe: 'bg-safe-50 text-safe-700 border-safe-100',
  warn: 'bg-warn-50 text-warn-700 border-amber-100',
  blue: 'bg-sky-50 text-sky-800 border-sky-100',
  violet: 'bg-violet-50 text-violet-800 border-violet-100',
  dark: 'bg-ink text-white border-ink',
};
export function Badge({ tone = 'neutral', children, className, icon }: { tone?: keyof typeof TONES; children: ReactNode; className?: string; icon?: ReactNode }) {
  return <span className={cn('inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-semibold', TONES[tone], className)}>{icon}{children}</span>;
}

export function DemoBadge() {
  return (
    <Badge tone="warn" className="uppercase tracking-wide">
      Demo
    </Badge>
  );
}

/* -------------------------------- Avatar -------------------------------- */
export function Avatar({ name, color, size = 40 }: { name?: string; color?: string; size?: number }) {
  return (
    <div className="grid shrink-0 place-items-center rounded-full font-semibold text-white" style={{ width: size, height: size, background: color || '#B4233C', fontSize: size * 0.38 }} aria-hidden>
      {initials(name)}
    </div>
  );
}

/* --------------------------------- States ------------------------------- */
export function Spinner({ className, label = 'Loading' }: { className?: string; label?: string }) {
  return (
    <div className={cn('flex items-center justify-center py-10 text-ink-mute', className)} role="status">
      <Loader2 className="h-6 w-6 animate-spin text-rk-500" aria-hidden />
      <span className="sr-only">{label}</span>
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-xl bg-sand-200/70', className)} />;
}

export function EmptyState({ icon, title, body, action }: { icon?: ReactNode; title: string; body?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <div className="mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-rk-50 text-rk-500">{icon || <Inbox className="h-6 w-6" />}</div>
      <p className="font-display text-lg font-semibold text-ink">{title}</p>
      {body && <p className="mt-1.5 max-w-sm text-sm text-ink-mute">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center px-6 py-10 text-center" role="alert">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-warn-50 text-warn-700">
        <AlertTriangle className="h-5 w-5" />
      </div>
      <p className="font-medium text-ink">{message || 'We could not load this right now.'}</p>
      {onRetry && (
        <Button variant="outline" size="sm" className="mt-4" onClick={onRetry} icon={<RefreshCw className="h-4 w-4" />}>
          Try again
        </Button>
      )}
    </div>
  );
}

/** Wraps a react-query result with loading / error / empty states. */
export function QueryState({ q, empty, children, isEmpty }: { q: { isLoading: boolean; isError: boolean; error?: any; refetch: () => void }; empty?: ReactNode; isEmpty?: boolean; children: ReactNode }) {
  if (q.isLoading) return <Spinner />;
  if (q.isError) return <ErrorState message={q.error?.response?.data?.message} onRetry={() => q.refetch()} />;
  if (isEmpty) return <>{empty}</>;
  return <>{children}</>;
}

/* --------------------------------- Modal -------------------------------- */
export function Modal({ open, onClose, title, children, footer, size = 'md' }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; footer?: ReactNode; size?: 'sm' | 'md' | 'lg' }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    setTimeout(() => ref.current?.querySelector<HTMLElement>('input,select,textarea,button:not([data-close])')?.focus(), 30);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      prev?.focus?.();
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[1000] flex items-end justify-center bg-ink/40 p-0 backdrop-blur-[2px] sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : undefined} className={cn('max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white shadow-lift animate-fade-up sm:rounded-3xl', size === 'sm' ? 'sm:max-w-md' : size === 'lg' ? 'sm:max-w-3xl' : 'sm:max-w-xl')}>
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-sand-200 bg-white/95 px-5 py-4 backdrop-blur">
          <h2 className="font-display text-lg font-semibold">{title}</h2>
          <button data-close onClick={onClose} className="rounded-lg p-1.5 text-ink-mute hover:bg-sand-100" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="px-5 py-5">{children}</div>
        {footer && <div className="sticky bottom-0 flex justify-end gap-2 border-t border-sand-200 bg-white px-5 py-4">{footer}</div>}
      </div>
    </div>
  );
}

/* --------------------------------- Tabs --------------------------------- */
export function Tabs<T extends string>({ value, onChange, tabs, className }: { value: T; onChange: (v: T) => void; tabs: Array<[T, ReactNode]>; className?: string }) {
  return (
    <div role="tablist" className={cn('flex gap-1 overflow-x-auto rounded-xl bg-sand-100 p-1', className)}>
      {tabs.map(([v, l]) => (
        <button key={v} role="tab" aria-selected={value === v} onClick={() => onChange(v)} className={cn('whitespace-nowrap rounded-lg px-3.5 py-2 text-sm font-semibold transition', value === v ? 'bg-white text-ink shadow-sm' : 'text-ink-mute hover:text-ink')}>
          {l}
        </button>
      ))}
    </div>
  );
}

export function Progress({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn('h-2 overflow-hidden rounded-full bg-sand-200', className)} role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full bg-gradient-to-r from-rk-500 to-rk-700 transition-all" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

export function PageHeader({ title, subtitle, action, eyebrow }: { title: ReactNode; subtitle?: ReactNode; action?: ReactNode; eyebrow?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && <p className="mb-1 text-xs font-semibold uppercase tracking-[.14em] text-rk-600">{eyebrow}</p>}
        <h1 className="text-2xl font-semibold sm:text-[28px]">{title}</h1>
        {subtitle && <p className="mt-1.5 max-w-2xl text-[15px] text-ink-mute">{subtitle}</p>}
      </div>
      {action && <div className="flex shrink-0 flex-wrap gap-2">{action}</div>}
    </div>
  );
}

export function Stat({ label, value, hint, icon, tone = 'rk' }: { label: string; value: ReactNode; hint?: ReactNode; icon?: ReactNode; tone?: 'rk' | 'safe' | 'ink' }) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-ink-mute">{label}</p>
        {icon && <div className={cn('grid h-8 w-8 place-items-center rounded-lg', tone === 'safe' ? 'bg-safe-50 text-safe-600' : tone === 'ink' ? 'bg-sand-100 text-ink' : 'bg-rk-50 text-rk-600')}>{icon}</div>}
      </div>
      <p className="mt-2 font-display text-2xl font-semibold text-ink">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-ink-mute">{hint}</p>}
    </Card>
  );
}
