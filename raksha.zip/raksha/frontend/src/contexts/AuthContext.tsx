import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { api, get, post, refreshAccessToken, tokenStore } from '@/api/client';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  loading: boolean;
  hasSafetyPin: boolean;
  demoMode: boolean;
  login: (identifier: string, password: string) => Promise<User>;
  loginWithSession: (data: { accessToken: string; user: User }) => Promise<User>;
  demoLogin: (role: string) => Promise<User>;
  logout: () => Promise<void>;
  refreshMe: () => Promise<void>;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasSafetyPin, setHasSafetyPin] = useState(false);
  const [demoMode, setDemoMode] = useState(false);

  const refreshMe = useCallback(async () => {
    const d = await get<{ user: User; hasSafetyPin: boolean; demoMode: boolean }>('/auth/me');
    setUser(d.user);
    setHasSafetyPin(d.hasSafetyPin);
    setDemoMode(d.demoMode);
    if (d.user?.language) document.documentElement.lang = d.user.language === 'hi' ? 'hi' : 'en';
  }, []);

  useEffect(() => {
    tokenStore.onLost(() => {
      setUser(null);
      qc.clear();
    });
    (async () => {
      try {
        const t = await refreshAccessToken();
        if (t) await refreshMe();
      } catch {
        /* not signed in */
      } finally {
        setLoading(false);
      }
    })();
  }, [qc, refreshMe]);

  const loginWithSession = useCallback(
    async (data: { accessToken: string; user: User }) => {
      tokenStore.set(data.accessToken);
      setUser(data.user);
      await refreshMe().catch(() => undefined);
      return data.user;
    },
    [refreshMe],
  );

  const login = useCallback(async (identifier: string, password: string) => loginWithSession(await post('/auth/login', { identifier, password })), [loginWithSession]);
  const demoLogin = useCallback(async (role: string) => loginWithSession(await post('/auth/demo-login', { role })), [loginWithSession]);

  const logout = useCallback(async () => {
    await api.post('/auth/logout').catch(() => undefined);
    tokenStore.set(null);
    setUser(null);
    qc.clear();
    try {
      localStorage.removeItem('rk_offline_contacts');
    } catch {
      /* ignore */
    }
  }, [qc]);

  const value = useMemo(() => ({ user, loading, hasSafetyPin, demoMode, login, loginWithSession, demoLogin, logout, refreshMe }), [user, loading, hasSafetyPin, demoMode, login, loginWithSession, demoLogin, logout, refreshMe]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth outside AuthProvider');
  return c;
}
