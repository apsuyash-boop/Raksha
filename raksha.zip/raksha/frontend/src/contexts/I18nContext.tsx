import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from 'react';
import { en } from '@/i18n/en';
import { hi } from '@/i18n/hi';

/**
 * Lightweight i18n. Add a language by creating src/i18n/<code>.ts with the same keys
 * and registering it in DICTS. Missing keys fall back to English.
 */
const DICTS: Record<string, Partial<Record<string, string>>> = { en, hi };
export const UI_LANGUAGES: Array<[string, string]> = [
  ['en', 'English'],
  ['hi', 'हिन्दी'],
];

interface I18n {
  lang: string;
  setLang: (l: string) => void;
  t: (key: keyof typeof en | string, vars?: Record<string, string | number>) => string;
}
const Ctx = createContext<I18n | null>(null);

function initial() {
  try {
    return localStorage.getItem('rk_lang') || (navigator.language?.startsWith('hi') ? 'hi' : 'en');
  } catch {
    return 'en';
  }
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState(initial);
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);
  const setLang = useCallback((l: string) => {
    setLangState(DICTS[l] ? l : 'en');
    try {
      localStorage.setItem('rk_lang', l);
    } catch {
      /* ignore */
    }
  }, []);
  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => {
      let s = DICTS[lang]?.[key] ?? en[key as keyof typeof en] ?? key;
      if (vars) for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, String(v));
      return s;
    },
    [lang],
  );
  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useI18n outside provider');
  return c;
}
