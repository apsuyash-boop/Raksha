import { createContext, ReactNode, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { tokenStore } from '@/api/client';
import { useAuth } from './AuthContext';

const Ctx = createContext<Socket | null>(null);

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || import.meta.env.VITE_API_URL || undefined;

function systemNotify(title: string, body?: string) {
  try {
    if ('Notification' in window && Notification.permission === 'granted' && document.hidden) new Notification(title, { body, icon: '/icons/icon-192.png' });
  } catch {
    /* unsupported */
  }
}

export function SocketProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [socket, setSocket] = useState<Socket | null>(null);

  useEffect(() => {
    if (!user) return;
    const opts = { auth: (cb: (d: object) => void) => cb({ token: tokenStore.get() }), transports: ['websocket', 'polling'], reconnectionDelayMax: 8000 };
    const s = SOCKET_URL ? io(SOCKET_URL, opts) : io(opts);
    s.on('notification', (n: any) => {
      qc.invalidateQueries({ queryKey: ['notifications'] });
      if (n.priority === 'critical') {
        toast.error(n.title, { description: n.body, duration: 20000 });
        try {
          navigator.vibrate?.([300, 120, 300, 120, 600]);
        } catch {
          /* ignore */
        }
      } else toast(n.title, { description: n.body });
      systemNotify(n.title, n.body);
    });
    s.on('sos:update', () => qc.invalidateQueries({ queryKey: ['sos'] }));
    s.on('sos:contact-alert', () => qc.invalidateQueries({ queryKey: ['protecting'] }));
    s.on('sos:nearby', () => qc.invalidateQueries({ queryKey: ['responder-inbox'] }));
    s.on('message:new', () => qc.invalidateQueries({ queryKey: ['conversations'] }));
    s.on('connect_error', async (err) => {
      if (err.message === 'unauthorized') {
        // Token may have expired; the API client refreshes it, then we retry.
        setTimeout(() => s.connect(), 3000);
      }
    });
    setSocket(s);
    return () => {
      s.disconnect();
      setSocket(null);
    };
  }, [user?._id, qc]); // eslint-disable-line react-hooks/exhaustive-deps

  return <Ctx.Provider value={socket}>{children}</Ctx.Provider>;
}

export const useSocket = () => useContext(Ctx);
