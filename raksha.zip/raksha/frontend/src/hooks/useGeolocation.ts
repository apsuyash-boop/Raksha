import { useCallback, useEffect, useRef, useState } from 'react';

export interface Position {
  lat: number;
  lng: number;
  accuracy?: number;
  speed?: number | null;
  heading?: number | null;
  at: number;
}

export type GeoStatus = 'idle' | 'prompt' | 'watching' | 'denied' | 'unavailable' | 'error';

export function getCurrentPosition(timeout = 8000): Promise<Position | null> {
  return new Promise((resolve) => {
    if (!('geolocation' in navigator)) return resolve(null);
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy, speed: p.coords.speed, heading: p.coords.heading, at: p.timestamp }),
      () => resolve(null),
      { enableHighAccuracy: true, timeout, maximumAge: 15000 },
    );
  });
}

/** Continuous high-accuracy location while `active` is true. */
export function useGeolocation(active: boolean, onUpdate?: (p: Position) => void) {
  const [pos, setPos] = useState<Position | null>(null);
  const [status, setStatus] = useState<GeoStatus>('idle');
  const cb = useRef(onUpdate);
  cb.current = onUpdate;

  useEffect(() => {
    if (!active) {
      setStatus('idle');
      return;
    }
    if (!('geolocation' in navigator)) {
      setStatus('unavailable');
      return;
    }
    setStatus('prompt');
    const id = navigator.geolocation.watchPosition(
      (p) => {
        const next = { lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy, speed: p.coords.speed, heading: p.coords.heading, at: p.timestamp };
        setPos(next);
        setStatus('watching');
        cb.current?.(next);
      },
      (err) => setStatus(err.code === err.PERMISSION_DENIED ? 'denied' : 'error'),
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, [active]);

  return { pos, status };
}

export function useBattery() {
  const [level, setLevel] = useState<number | undefined>();
  const read = useCallback(async () => {
    try {
      const b: any = await (navigator as any).getBattery?.();
      if (b) setLevel(Math.round(b.level * 100));
    } catch {
      /* unsupported */
    }
  }, []);
  useEffect(() => {
    read();
    const t = setInterval(read, 60000);
    return () => clearInterval(t);
  }, [read]);
  return level;
}
