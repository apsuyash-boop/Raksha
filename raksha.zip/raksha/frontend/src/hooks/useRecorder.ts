import { useCallback, useEffect, useRef, useState } from 'react';

export type RecorderState = 'idle' | 'requesting' | 'recording' | 'denied' | 'unsupported' | 'error';

/**
 * Records audio/video in self-contained segments (default 20 s). Each finished segment is a complete,
 * playable file handed to `onSegment` — so evidence is uploaded progressively and survives even if the
 * phone is taken away mid-emergency.
 */
export function useSegmentRecorder(onSegment: (blob: Blob, meta: { kind: 'audio' | 'video'; startedAt: Date; mime: string }) => void, segmentMs = 20000) {
  const [state, setState] = useState<RecorderState>('idle');
  const [kind, setKind] = useState<'audio' | 'video'>('audio');
  const [segments, setSegments] = useState(0);
  const streamRef = useRef<MediaStream | null>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<number | null>(null);
  const runningRef = useRef(false);
  const cb = useRef(onSegment);
  cb.current = onSegment;

  const pickMime = (k: 'audio' | 'video') => {
    const opts = k === 'video' ? ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'] : ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'];
    return opts.find((m) => (window as any).MediaRecorder?.isTypeSupported?.(m)) || '';
  };

  const startSegment = useCallback((k: 'audio' | 'video') => {
    const stream = streamRef.current;
    if (!stream || !runningRef.current) return;
    const mime = pickMime(k);
    const chunks: BlobPart[] = [];
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    const startedAt = new Date();
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    rec.onstop = () => {
      if (chunks.length) {
        const blob = new Blob(chunks, { type: rec.mimeType || mime || (k === 'video' ? 'video/webm' : 'audio/webm') });
        setSegments((n) => n + 1);
        cb.current(blob, { kind: k, startedAt, mime: blob.type });
      }
      if (runningRef.current) startSegment(k);
    };
    rec.start();
    recRef.current = rec;
    timerRef.current = window.setTimeout(() => rec.state === 'recording' && rec.stop(), segmentMs);
  }, [segmentMs]);

  const start = useCallback(
    async (k: 'audio' | 'video' = 'audio') => {
      if (!('MediaRecorder' in window) || !navigator.mediaDevices?.getUserMedia) {
        setState('unsupported');
        return false;
      }
      setState('requesting');
      try {
        const stream = await navigator.mediaDevices.getUserMedia(k === 'video' ? { audio: true, video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } } } : { audio: true });
        streamRef.current = stream;
        runningRef.current = true;
        setKind(k);
        setState('recording');
        startSegment(k);
        return true;
      } catch (e: any) {
        setState(e?.name === 'NotAllowedError' ? 'denied' : 'error');
        return false;
      }
    },
    [startSegment],
  );

  const stop = useCallback(() => {
    runningRef.current = false;
    if (timerRef.current) clearTimeout(timerRef.current);
    if (recRef.current?.state === 'recording') recRef.current.stop();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setState('idle');
  }, []);

  useEffect(() => () => stop(), [stop]);

  return { state, kind, segments, start, stop, stream: streamRef };
}
