import { ReactNode, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Bell, BookOpen, Briefcase, FileLock2, Gavel, HandCoins, HeartHandshake, Home, Landmark, LayoutDashboard, LogOut, Menu, MessageCircle, Phone, Scale,
  Settings, ShieldAlert, ShieldCheck, Siren, Users, UsersRound, X, Wallet, Radar, Eye,
} from 'lucide-react';
import { get } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n, UI_LANGUAGES } from '@/contexts/I18nContext';
import { Logo } from '@/components/Brand';
import { Avatar, Badge } from '@/components/ui';
import { cn, ROLE_LABEL } from '@/utils/format';

interface NavItem {
  to: string;
  label: string;
  icon: ReactNode;
}

function useNav(): NavItem[] {
  const { user } = useAuth();
  const { t } = useI18n();
  const I = (C: any) => <C className="h-[18px] w-[18px]" aria-hidden />;
  const common = {
    messages: { to: '/messages', label: t('nav.messages'), icon: I(MessageCircle) },
    notifications: { to: '/notifications', label: t('nav.notifications'), icon: I(Bell) },
    community: { to: '/community', label: t('nav.community'), icon: I(UsersRound) },
    settings: { to: '/settings', label: t('nav.settings'), icon: I(Settings) },
  };
  switch (user?.role) {
    case 'lawyer':
      return [{ to: '/lawyer/dashboard', label: t('nav.dashboard'), icon: I(LayoutDashboard) }, common.messages, common.notifications, { to: '/rights', label: t('nav.rights'), icon: I(BookOpen) }, common.community, common.settings];
    case 'ngo':
      return [{ to: '/ngo/dashboard', label: t('nav.dashboard'), icon: I(LayoutDashboard) }, common.messages, common.notifications, common.community, common.settings];
    case 'counsellor':
      return [{ to: '/counsellor/dashboard', label: t('nav.dashboard'), icon: I(LayoutDashboard) }, common.messages, common.notifications, common.community, common.settings];
    case 'responder':
      return [{ to: '/responder/dashboard', label: t('nav.dashboard'), icon: I(Radar) }, common.messages, common.notifications, common.settings];
    case 'police':
      return [{ to: '/police/dashboard', label: t('nav.dashboard'), icon: I(ShieldCheck) }, common.notifications, common.settings];
    case 'lender':
      return [{ to: '/lender/dashboard', label: t('nav.dashboard'), icon: I(Landmark) }, common.notifications, { to: '/transparency', label: 'Transparency', icon: I(Eye) }, common.settings];
    case 'donor':
      return [{ to: '/donate', label: 'Donate', icon: I(HandCoins) }, { to: '/campaigns', label: 'Campaigns', icon: I(HeartHandshake) }, { to: '/transparency', label: 'Transparency', icon: I(Eye) }, common.notifications, common.community, common.settings];
    case 'emergency_contact':
      return [{ to: '/guardian', label: 'People I protect', icon: I(ShieldCheck) }, common.messages, common.notifications, { to: '/rights', label: t('nav.rights'), icon: I(BookOpen) }, common.settings];
    case 'admin':
      return [{ to: '/admin/dashboard', label: 'Admin', icon: I(LayoutDashboard) }, common.notifications, common.community, { to: '/transparency', label: 'Transparency', icon: I(Eye) }, common.settings];
    default:
      return [
        { to: '/dashboard', label: t('nav.home'), icon: I(Home) },
        { to: '/sos', label: t('nav.sos'), icon: I(Siren) },
        { to: '/evidence', label: t('nav.evidence'), icon: I(FileLock2) },
        { to: '/rights', label: t('nav.rights'), icon: I(BookOpen) },
        { to: '/legal-help', label: t('nav.legal'), icon: I(Scale) },
        { to: '/cases', label: t('nav.cases'), icon: I(Gavel) },
        { to: '/schemes', label: t('nav.schemes'), icon: I(Landmark) },
        { to: '/counselling', label: t('nav.counselling'), icon: I(HeartHandshake) },
        { to: '/financial-help', label: t('nav.financial'), icon: I(Wallet) },
        common.community,
        common.messages,
        common.notifications,
        { to: '/emergency-contacts', label: t('nav.contacts'), icon: I(Users) },
        common.settings,
      ];
  }
}

function SideNav({ items, onNavigate, unread }: { items: NavItem[]; onNavigate?: () => void; unread: number }) {
  return (
    <nav aria-label="Main" className="space-y-0.5">
      {items.map((i) => (
        <NavLink
          key={i.to}
          to={i.to}
          onClick={onNavigate}
          className={({ isActive }) =>
            cn('flex items-center gap-3 rounded-xl px-3 py-2.5 text-[14.5px] font-medium transition', isActive ? 'bg-rk-50 text-rk-700' : 'text-ink-soft hover:bg-sand-100 hover:text-ink', i.to === '/sos' && !isActive && 'text-rk-700')
          }
        >
          {i.icon}
          <span className="flex-1">{i.label}</span>
          {i.to === '/notifications' && unread > 0 && <span className="rounded-full bg-rk-600 px-1.5 text-[11px] font-bold text-white">{unread > 99 ? '99+' : unread}</span>}
        </NavLink>
      ))}
    </nav>
  );
}

export function AppLayout() {
  const { user, logout, demoMode } = useAuth();
  const { lang, setLang, t } = useI18n();
  const items = useNav();
  const nav = useNavigate();
  const loc = useLocation();
  const [drawer, setDrawer] = useState(false);
  const isWoman = user?.role === 'user';

  const notifs = useQuery({ queryKey: ['notifications', 'count'], queryFn: () => get<{ unread: number }>('/notifications', { unread: true }), refetchInterval: 60000, enabled: !!user });
  const activeSos = useQuery({ queryKey: ['sos', 'active'], queryFn: () => get<{ alert: any }>('/sos/active'), enabled: isWoman, refetchInterval: 30000 });
  const contacts = useQuery({ queryKey: ['contacts'], queryFn: () => get<{ contacts: any[] }>('/contacts'), enabled: isWoman, staleTime: 300000 });

  // Cache contact numbers on THIS device only, for the offline SMS fallback page.
  useEffect(() => {
    if (!contacts.data) return;
    try {
      localStorage.setItem('rk_offline_contacts', JSON.stringify(contacts.data.contacts.filter((c) => c.phone).map((c) => ({ name: c.name, phone: c.phone }))));
    } catch {
      /* storage blocked */
    }
  }, [contacts.data]);

  useEffect(() => setDrawer(false), [loc.pathname]);

  const unread = notifs.data?.unread || 0;
  const sosActive = !!activeSos.data?.alert;

  return (
    <div className="min-h-screen bg-sand-50">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[2000] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:shadow">
        Skip to content
      </a>

      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[264px] flex-col border-r border-sand-200 bg-white lg:flex">
        <div className="px-5 pb-4 pt-5">
          <Logo to={items[0]?.to || '/'} />
        </div>
        {isWoman && (
          <div className="px-4 pb-3">
            <Link to="/sos" className={cn('flex items-center justify-center gap-2 rounded-2xl py-3 font-bold text-white shadow-sm transition', sosActive ? 'animate-pulse bg-rk-700' : 'bg-gradient-to-b from-rk-500 to-rk-700 hover:brightness-110')}>
              <ShieldAlert className="h-5 w-5" /> {sosActive ? t('sos.active') : 'SOS'}
            </Link>
          </div>
        )}
        <div className="flex-1 overflow-y-auto px-3 pb-4">
          <SideNav items={items} unread={unread} />
        </div>
        <div className="border-t border-sand-200 p-4">
          <div className="flex items-center gap-3">
            <Avatar name={user?.name} color={user?.avatarColor} size={36} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{user?.name}</p>
              <p className="truncate text-xs text-ink-mute">{ROLE_LABEL[user?.role || 'user']}{user && !user.verified && ' · awaiting verification'}</p>
            </div>
            <button onClick={async () => { await logout(); nav('/'); }} className="rounded-lg p-2 text-ink-mute hover:bg-sand-100 hover:text-ink" aria-label={t('nav.logout')}>
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-sand-200 bg-white/90 backdrop-blur lg:ml-[264px]">
        <div className="flex h-14 items-center gap-3 px-4 sm:px-6">
          <button className="rounded-lg p-2 lg:hidden" onClick={() => setDrawer(true)} aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </button>
          <div className="lg:hidden">
            <Logo to={items[0]?.to || '/'} />
          </div>
          <div className="ml-auto flex items-center gap-2">
            {(demoMode || user?.isDemo) && <Badge tone="warn">Demo mode — SOS & payments simulated</Badge>}
            <select value={lang} onChange={(e) => setLang(e.target.value)} className="hidden rounded-lg border border-sand-200 bg-white px-2 py-1.5 text-sm sm:block" aria-label="Language">
              {UI_LANGUAGES.map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </select>
            <a href="tel:112" className="hidden items-center gap-1.5 rounded-lg border border-rk-200 px-2.5 py-1.5 text-sm font-semibold text-rk-700 hover:bg-rk-50 sm:flex">
              <Phone className="h-4 w-4" /> 112
            </a>
            <Link to="/notifications" className="relative rounded-lg p-2 text-ink-soft hover:bg-sand-100" aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}>
              <Bell className="h-5 w-5" />
              {unread > 0 && <span className="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-rk-600 ring-2 ring-white" />}
            </Link>
          </div>
        </div>
        {sosActive && loc.pathname !== '/sos' && (
          <Link to="/sos" className="flex items-center justify-center gap-2 bg-rk-700 px-4 py-2 text-sm font-semibold text-white">
            <Siren className="h-4 w-4 animate-pulse" /> {t('sos.active')} — {activeSos.data?.alert?.isDemo ? 'demo (simulated)' : 'tap to view'}
          </Link>
        )}
      </header>

      {/* Mobile drawer */}
      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 bg-ink/40" onClick={() => setDrawer(false)} />
          <div className="absolute inset-y-0 left-0 flex w-[85%] max-w-xs flex-col bg-white shadow-lift animate-fade-up">
            <div className="flex items-center justify-between px-5 py-4">
              <Logo to={items[0]?.to} />
              <button onClick={() => setDrawer(false)} className="rounded-lg p-2" aria-label="Close menu">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-3">
              <SideNav items={items} unread={unread} onNavigate={() => setDrawer(false)} />
            </div>
            <div className="space-y-3 border-t border-sand-200 p-4">
              <select value={lang} onChange={(e) => setLang(e.target.value)} className="input py-2" aria-label="Language">
                {UI_LANGUAGES.map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </select>
              <button onClick={async () => { await logout(); nav('/'); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium text-ink-soft hover:bg-sand-100">
                <LogOut className="h-4 w-4" /> {t('nav.logout')}
              </button>
            </div>
          </div>
        </div>
      )}

      <main id="main" className={cn('px-4 py-6 sm:px-6 lg:ml-[264px] lg:px-10 lg:py-8', isWoman ? 'pb-28 lg:pb-10' : 'pb-10')}>
        <div className="mx-auto max-w-6xl">
          <Outlet />
        </div>
      </main>

      {/* Mobile bottom nav with central SOS for women */}
      {isWoman && (
        <nav className="pb-safe fixed inset-x-0 bottom-0 z-30 border-t border-sand-200 bg-white/95 backdrop-blur lg:hidden" aria-label="Quick">
          <div className="mx-auto grid max-w-md grid-cols-5 items-end px-2 pt-1.5">
            {[
              { to: '/dashboard', label: t('nav.home'), icon: <Home className="h-5 w-5" /> },
              { to: '/cases', label: 'Cases', icon: <Briefcase className="h-5 w-5" /> },
              null,
              { to: '/messages', label: 'Chat', icon: <MessageCircle className="h-5 w-5" /> },
              { to: '/evidence', label: 'Vault', icon: <FileLock2 className="h-5 w-5" /> },
            ].map((i, idx) =>
              i ? (
                <NavLink key={i.to} to={i.to} className={({ isActive }) => cn('flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[11px] font-semibold', isActive ? 'text-rk-700' : 'text-ink-mute')}>
                  {i.icon}
                  {i.label}
                </NavLink>
              ) : (
                <Link key={idx} to="/sos" className="-mt-7 flex flex-col items-center" aria-label="SOS">
                  <span className={cn('grid h-16 w-16 place-items-center rounded-full border-4 border-white bg-gradient-to-b from-rk-500 to-rk-700 font-display text-lg font-bold text-white shadow-sos', sosActive && 'animate-pulse')}>SOS</span>
                </Link>
              ),
            )}
          </div>
        </nav>
      )}
    </div>
  );
}
