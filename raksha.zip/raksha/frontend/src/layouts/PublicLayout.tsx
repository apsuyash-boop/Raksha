import { useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { Menu, Phone, X } from 'lucide-react';
import { Logo } from '@/components/Brand';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n, UI_LANGUAGES } from '@/contexts/I18nContext';
import { Button } from '@/components/ui';
import { cn, ROLE_HOME } from '@/utils/format';

const LINKS: Array<[string, string]> = [
  ['/rights', 'Know your rights'],
  ['/schemes', 'Schemes'],
  ['/campaigns', 'Campaigns'],
  ['/community', 'Community'],
  ['/transparency', 'Transparency'],
];

export function PublicLayout() {
  const { user } = useAuth();
  const { lang, setLang, t } = useI18n();
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen bg-sand-50">
      <header className="sticky top-0 z-40 border-b border-sand-200/70 bg-sand-50/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-4 sm:px-6">
          <Logo />
          <nav className="hidden items-center gap-1 md:flex" aria-label="Public">
            {LINKS.map(([to, l]) => (
              <NavLink key={to} to={to} className={({ isActive }) => cn('rounded-lg px-3 py-2 text-sm font-medium', isActive ? 'text-rk-700' : 'text-ink-soft hover:text-ink')}>
                {l}
              </NavLink>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <select value={lang} onChange={(e) => setLang(e.target.value)} className="hidden rounded-lg border border-sand-200 bg-white px-2 py-1.5 text-sm sm:block" aria-label="Language">
              {UI_LANGUAGES.map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </select>
            {user ? (
              <Link to={ROLE_HOME[user.role] || '/dashboard'}>
                <Button size="sm">Open dashboard</Button>
              </Link>
            ) : (
              <>
                <Link to="/login" className="hidden px-2 text-sm font-semibold text-ink-soft hover:text-ink sm:block">
                  {t('auth.login')}
                </Link>
                <Link to="/register">
                  <Button size="sm">{t('auth.getStarted')}</Button>
                </Link>
              </>
            )}
            <button className="rounded-lg p-2 md:hidden" onClick={() => setOpen(!open)} aria-label="Menu" aria-expanded={open}>
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
        {open && (
          <nav className="border-t border-sand-200 bg-white px-4 py-3 md:hidden">
            {LINKS.map(([to, l]) => (
              <Link key={to} to={to} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2.5 font-medium text-ink-soft">
                {l}
              </Link>
            ))}
            {!user && (
              <Link to="/login" onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2.5 font-medium text-ink-soft">
                {t('auth.login')}
              </Link>
            )}
          </nav>
        )}
      </header>
      <Outlet />
      <footer className="border-t border-sand-200 bg-white">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-4">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-3 max-w-sm text-sm text-ink-mute">A women's safety, legal aid and empowerment platform. {t('brand.tagline')}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <a href="tel:112" className="chip">
                <Phone className="h-3.5 w-3.5" /> Emergency 112
              </a>
              <a href="tel:181" className="chip">
                <Phone className="h-3.5 w-3.5" /> Women Helpline 181
              </a>
              <a href="tel:1930" className="chip">
                <Phone className="h-3.5 w-3.5" /> Cyber crime 1930
              </a>
            </div>
          </div>
          <div>
            <p className="text-sm font-semibold">Platform</p>
            <ul className="mt-3 space-y-2 text-sm text-ink-mute">
              <li><Link to="/rights" className="hover:text-ink">Rights library</Link></li>
              <li><Link to="/schemes" className="hover:text-ink">Scheme finder</Link></li>
              <li><Link to="/campaigns" className="hover:text-ink">Support a woman</Link></li>
              <li><Link to="/partners" className="hover:text-ink">Become a partner</Link></li>
            </ul>
          </div>
          <div>
            <p className="text-sm font-semibold">Trust</p>
            <ul className="mt-3 space-y-2 text-sm text-ink-mute">
              <li><Link to="/privacy" className="hover:text-ink">Privacy policy</Link></li>
              <li><Link to="/terms" className="hover:text-ink">Terms of service</Link></li>
              <li><Link to="/transparency" className="hover:text-ink">Financial transparency</Link></li>
            </ul>
          </div>
        </div>
        <p className="border-t border-sand-200 py-5 text-center text-xs text-ink-mute">© {new Date().getFullYear()} Raksha. Information on this site is educational and not a substitute for professional legal advice.</p>
      </footer>
    </div>
  );
}
