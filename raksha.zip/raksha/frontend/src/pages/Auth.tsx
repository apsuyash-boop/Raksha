import { FormEvent, useState } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import { ArrowLeft, Eye, EyeOff, KeyRound, Plus, ShieldCheck, Trash2 } from 'lucide-react';
import { apiError, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { Logo } from '@/components/Brand';
import { Button, Input, Select } from '@/components/ui';
import { cn, INDIAN_STATES, LANGS, ROLE_HOME, ROLE_LABEL } from '@/utils/format';

type Mode = 'login' | 'register' | 'forgot' | 'reset';

function Shell({ children, title, subtitle }: { children: React.ReactNode; title: string; subtitle?: string }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.05fr]">
      <div className="relative hidden overflow-hidden bg-gradient-to-br from-rk-700 via-rk-800 to-rk-900 p-12 text-white lg:flex lg:flex-col">
        <div className="grain absolute inset-0 opacity-30" aria-hidden />
        <div className="relative">
          <Logo light />
        </div>
        <div className="relative mt-auto max-w-md">
          <p className="font-display text-4xl font-semibold leading-tight text-white">One button. Total protection. Lifelong support.</p>
          <ul className="mt-8 space-y-3 text-white/80">
            {['Your data is encrypted and only shared with your consent', 'Cancel any accidental SOS with your secret PIN', 'Verified lawyers, NGOs and counsellors only'].map((s) => (
              <li key={s} className="flex items-start gap-3">
                <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-rk-200" /> {s}
              </li>
            ))}
          </ul>
          <p className="mt-10 text-sm text-white/60">In immediate danger? Call 112 · Women Helpline 181</p>
        </div>
      </div>
      <div className="flex flex-col px-5 py-8 sm:px-10">
        <div className="flex items-center justify-between lg:hidden">
          <Logo />
        </div>
        <div className="mx-auto my-auto w-full max-w-md py-10">
          <h1 className="text-3xl font-semibold">{title}</h1>
          {subtitle && <p className="mt-2 text-ink-mute">{subtitle}</p>}
          <div className="mt-8">{children}</div>
        </div>
      </div>
    </div>
  );
}

const DEMO_ROLES: Array<[string, string]> = [
  ['user', 'Woman (Priya)'],
  ['emergency_contact', 'Emergency contact'],
  ['lawyer', 'Lawyer'],
  ['ngo', 'NGO'],
  ['counsellor', 'Counsellor'],
  ['responder', 'Responder'],
  ['police', 'Police'],
  ['donor', 'Donor'],
  ['lender', 'Lender'],
  ['admin', 'Admin'],
];

function Login() {
  const { login, loginWithSession, demoLogin } = useAuth();
  const nav = useNavigate();
  const loc = useLocation() as any;
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [otpMode, setOtpMode] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const go = (role: string) => nav(loc.state?.from || ROLE_HOME[role] || '/dashboard', { replace: true });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr('');
    try {
      if (otpMode) {
        if (!otpSent) {
          const r = await post<{ devCode?: string }>('/auth/otp/request', { identifier });
          setOtpSent(true);
          toast.success('If an account exists, we sent a 6-digit code.');
          if (r.devCode) toast.info(`Development only — your code is ${r.devCode} (no SMS/email provider configured)`, { duration: 15000 });
        } else {
          const u = await loginWithSession(await post('/auth/otp/verify', { identifier, code }));
          go(u.role);
        }
      } else {
        const u = await login(identifier, password);
        go(u.role);
      }
    } catch (e2) {
      setErr(apiError(e2).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Shell title="Welcome back" subtitle="Log in with your email or phone number.">
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Input label="Email or phone" autoComplete="username" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required />
        {!otpMode ? (
          <div className="relative">
            <Input label="Password" type={show ? 'text' : 'password'} autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-[38px] p-1 text-ink-mute" aria-label={show ? 'Hide password' : 'Show password'}>
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        ) : (
          otpSent && <Input label="6-digit code" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} required />
        )}
        {err && (
          <p className="rounded-xl bg-rk-50 px-3 py-2 text-sm text-rk-800" role="alert">
            {err}
          </p>
        )}
        <Button type="submit" className="w-full" size="lg" loading={busy}>
          {otpMode ? (otpSent ? 'Verify & log in' : 'Send login code') : 'Log in'}
        </Button>
        <div className="flex items-center justify-between text-sm">
          <button type="button" className="font-semibold text-rk-700" onClick={() => { setOtpMode(!otpMode); setOtpSent(false); setErr(''); }}>
            {otpMode ? 'Use password instead' : 'Log in with a one-time code'}
          </button>
          <Link to="/forgot-password" className="text-ink-mute hover:text-ink">
            Forgot password?
          </Link>
        </div>
      </form>
      <p className="mt-8 text-center text-sm text-ink-mute">
        New to Raksha?{' '}
        <Link to="/register" className="font-semibold text-rk-700">
          Create an account
        </Link>
      </p>

      <div className="mt-10 rounded-2xl border border-dashed border-warn-500/40 bg-warn-50/60 p-4">
        <p className="text-sm font-semibold text-warn-700">Demo accounts (presentation mode)</p>
        <p className="mt-0.5 text-xs text-ink-mute">Available only when the server runs with DEMO_MODE. Demo SOS and payments are simulated and never contact real services.</p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {DEMO_ROLES.map(([r, l]) => (
            <button
              key={r}
              className="chip py-1 text-xs"
              onClick={async () => {
                try {
                  const u = await demoLogin(r);
                  go(u.role);
                } catch (e) {
                  toast.error(apiError(e).message);
                }
              }}
            >
              {l}
            </button>
          ))}
        </div>
      </div>
    </Shell>
  );
}

interface ContactDraft {
  name: string;
  phone: string;
  relation: string;
}

function Register() {
  const [params] = useSearchParams();
  const { loginWithSession } = useAuth();
  const nav = useNavigate();
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [f, setF] = useState({
    role: params.get('role') || 'user',
    name: '',
    email: '',
    phone: '',
    password: '',
    age: '',
    state: '',
    city: '',
    language: 'en',
    safetyPin: '',
    bloodGroup: '',
    allergies: '',
    shareMedicalInfoInSOS: false,
    acceptTerms: false,
  });
  const [contacts, setContacts] = useState<ContactDraft[]>([{ name: '', phone: '', relation: '' }]);
  const set = (k: keyof typeof f) => (e: any) => setF({ ...f, [k]: e?.target ? (e.target.type === 'checkbox' ? e.target.checked : e.target.value) : e });
  const isWoman = f.role === 'user';
  const steps = isWoman ? ['Account', 'About you', 'Safety setup'] : ['Account', 'About you'];

  const next = (e: FormEvent) => {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (step === 0) {
      if (f.name.trim().length < 2) er.name = 'Please enter your name';
      if (!f.email && !f.phone) er.email = 'Add an email or phone number';
      if (f.password.length < 8 || !/[A-Za-z]/.test(f.password) || !/\d/.test(f.password)) er.password = 'At least 8 characters with a letter and a number';
    }
    if (step === steps.length - 1 && !f.acceptTerms) er.acceptTerms = 'Please accept to continue';
    if (isWoman && step === 2 && f.safetyPin && !/^\d{4,6}$/.test(f.safetyPin)) er.safetyPin = 'PIN must be 4–6 digits';
    setErrors(er);
    if (Object.keys(er).length) return;
    if (step < steps.length - 1) setStep(step + 1);
    else submit();
  };

  const submit = async () => {
    setBusy(true);
    try {
      const body: any = {
        role: f.role,
        name: f.name,
        email: f.email || undefined,
        phone: f.phone || undefined,
        password: f.password,
        age: f.age ? Number(f.age) : undefined,
        state: f.state || undefined,
        city: f.city || undefined,
        language: f.language,
        acceptTerms: true,
      };
      if (isWoman) {
        body.safetyPin = f.safetyPin || undefined;
        body.emergencyContacts = contacts.filter((c) => c.name && c.phone).map((c) => ({ name: c.name, phone: c.phone, relation: c.relation || undefined }));
        if (f.bloodGroup || f.allergies) body.medical = { bloodGroup: f.bloodGroup || undefined, allergies: f.allergies || undefined };
        body.shareMedicalInfoInSOS = f.shareMedicalInfoInSOS;
      }
      const r = await post<any>('/auth/register', body);
      await loginWithSession(r);
      toast.success('Welcome to Raksha');
      if (r.verification?.devCode) toast.info(`Development only — verification code: ${r.verification.devCode}`, { duration: 15000 });
      nav(ROLE_HOME[f.role] || '/dashboard', { replace: true });
    } catch (e) {
      const a = apiError(e);
      setErrors(a.fields || {});
      toast.error(a.message);
      if (a.fields && (a.fields.email || a.fields.password || a.fields.name || a.fields.phone)) setStep(0);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Shell title="Create your Raksha account" subtitle="We only ask for what we need. You control what is shared.">
      <ol className="mb-6 flex gap-2" aria-label="Progress">
        {steps.map((s, i) => (
          <li key={s} className="flex-1">
            <div className={cn('h-1.5 rounded-full', i <= step ? 'bg-rk-600' : 'bg-sand-200')} />
            <p className={cn('mt-1.5 text-xs font-semibold', i === step ? 'text-rk-700' : 'text-ink-mute')}>{s}</p>
          </li>
        ))}
      </ol>
      <form onSubmit={next} className="space-y-4" noValidate>
        {step === 0 && (
          <>
            <Select label="I am joining as" value={f.role} onChange={set('role')} options={Object.entries(ROLE_LABEL).filter(([k]) => k !== 'admin') as Array<[string, string]>} />
            {['lawyer', 'ngo', 'counsellor', 'responder', 'police', 'lender'].includes(f.role) && (
              <p className="rounded-xl bg-sand-100 px-3 py-2 text-sm text-ink-soft">Professional accounts are reviewed by our team before they can receive cases or appear in search.</p>
            )}
            <Input label={f.role === 'ngo' ? 'Organisation / contact name' : 'Full name'} value={f.name} onChange={set('name')} error={errors.name} autoComplete="name" required />
            <div className="grid gap-4 sm:grid-cols-2">
              <Input label="Email" type="email" value={f.email} onChange={set('email')} error={errors.email} autoComplete="email" />
              <Input label="Phone" type="tel" value={f.phone} onChange={set('phone')} error={errors.phone} placeholder="+91 98xxxxxxxx" autoComplete="tel" />
            </div>
            <Input label="Password" type="password" value={f.password} onChange={set('password')} error={errors.password} hint="At least 8 characters, with a letter and a number" autoComplete="new-password" required />
          </>
        )}
        {step === 1 && (
          <>
            <div className="grid gap-4 sm:grid-cols-2">
              {isWoman && <Input label="Age" type="number" min={13} max={120} value={f.age} onChange={set('age')} />}
              <Select label="Preferred language" value={f.language} onChange={set('language')} options={LANGS} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Select label="State" value={f.state} onChange={set('state')} options={INDIAN_STATES.map((s) => [s, s])} placeholder="Select state" />
              <Input label="City" value={f.city} onChange={set('city')} autoComplete="address-level2" />
            </div>
          </>
        )}
        {step === 2 && isWoman && (
          <>
            <div>
              <p className="label">Emergency contacts</p>
              <p className="-mt-1 mb-3 text-xs text-ink-mute">They will receive your location if you press SOS. You can add more later.</p>
              <div className="space-y-3">
                {contacts.map((c, i) => (
                  <div key={i} className="grid grid-cols-[1fr_1fr_auto] gap-2">
                    <input className="input" placeholder="Name" value={c.name} onChange={(e) => setContacts(contacts.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} aria-label={`Contact ${i + 1} name`} />
                    <input className="input" placeholder="Phone" type="tel" value={c.phone} onChange={(e) => setContacts(contacts.map((x, j) => (j === i ? { ...x, phone: e.target.value } : x)))} aria-label={`Contact ${i + 1} phone`} />
                    <button type="button" onClick={() => setContacts(contacts.filter((_, j) => j !== i))} className="rounded-xl px-2 text-ink-mute hover:bg-sand-100" aria-label="Remove contact">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
              {contacts.length < 5 && (
                <button type="button" onClick={() => setContacts([...contacts, { name: '', phone: '', relation: '' }])} className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-rk-700">
                  <Plus className="h-4 w-4" /> Add contact
                </button>
              )}
            </div>
            <Input label="Safety PIN (to cancel a false alarm)" type="password" inputMode="numeric" maxLength={6} value={f.safetyPin} onChange={set('safetyPin')} error={errors.safetyPin} hint="4–6 digits. Use something only you know." />
            <details className="rounded-xl border border-sand-200 p-3">
              <summary className="cursor-pointer text-sm font-semibold">Optional medical & safety information</summary>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <Input label="Blood group" value={f.bloodGroup} onChange={set('bloodGroup')} maxLength={5} />
                <Input label="Allergies" value={f.allergies} onChange={set('allergies')} />
              </div>
              <label className="mt-3 flex items-start gap-2 text-sm">
                <input type="checkbox" checked={f.shareMedicalInfoInSOS} onChange={set('shareMedicalInfoInSOS')} className="mt-1 accent-rk-600" />
                Share this with my emergency contacts during an SOS. Stored encrypted.
              </label>
            </details>
          </>
        )}
        {step === steps.length - 1 && (
          <label className="flex items-start gap-2 text-sm text-ink-soft">
            <input type="checkbox" checked={f.acceptTerms} onChange={set('acceptTerms')} className="mt-1 accent-rk-600" />
            <span>
              I agree to the{' '}
              <Link to="/terms" target="_blank" className="font-semibold text-rk-700 underline">
                Terms
              </Link>{' '}
              and{' '}
              <Link to="/privacy" target="_blank" className="font-semibold text-rk-700 underline">
                Privacy Policy
              </Link>
              .
              {errors.acceptTerms && <span className="block text-rk-700">{errors.acceptTerms}</span>}
            </span>
          </label>
        )}
        <div className="flex gap-2 pt-2">
          {step > 0 && (
            <Button type="button" variant="outline" onClick={() => setStep(step - 1)} icon={<ArrowLeft className="h-4 w-4" />}>
              Back
            </Button>
          )}
          <Button type="submit" className="flex-1" size="lg" loading={busy}>
            {step < steps.length - 1 ? 'Continue' : 'Create account'}
          </Button>
        </div>
      </form>
      <p className="mt-8 text-center text-sm text-ink-mute">
        Already have an account?{' '}
        <Link to="/login" className="font-semibold text-rk-700">
          Log in
        </Link>
      </p>
    </Shell>
  );
}

function Forgot() {
  const [identifier, setIdentifier] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [dev, setDev] = useState<string | undefined>();
  return (
    <Shell title="Reset your password" subtitle="We will send a reset link to your email or phone.">
      {done ? (
        <div className="rounded-2xl bg-safe-50 p-5 text-safe-700">
          <p className="font-semibold">{done}</p>
          {dev && (
            <p className="mt-2 break-all text-sm">
              Development only (no email/SMS provider configured):{' '}
              <a className="font-semibold underline" href={dev}>
                open reset link
              </a>
            </p>
          )}
        </div>
      ) : (
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            try {
              const r = await post<{ devResetUrl?: string }>('/auth/forgot-password', { identifier });
              setDone(r._message || 'Check your inbox.');
              setDev(r.devResetUrl);
            } catch (e2) {
              toast.error(apiError(e2).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <Input label="Email or phone" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required />
          <Button type="submit" className="w-full" size="lg" loading={busy} icon={<KeyRound className="h-4 w-4" />}>
            Send reset link
          </Button>
        </form>
      )}
      <Link to="/login" className="mt-6 inline-flex items-center gap-1 text-sm font-semibold text-rk-700">
        <ArrowLeft className="h-4 w-4" /> Back to login
      </Link>
    </Shell>
  );
}

function Reset() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  return (
    <Shell title="Choose a new password">
      <form
        className="space-y-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setErr('');
          try {
            await post('/auth/reset-password', { token: params.get('token'), password });
            toast.success('Password updated. Please log in.');
            nav('/login');
          } catch (e2) {
            const a = apiError(e2);
            setErr(a.fields?.password || a.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <Input label="New password" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} error={err} hint="At least 8 characters with a letter and a number" required />
        <Button type="submit" className="w-full" size="lg" loading={busy}>
          Update password
        </Button>
      </form>
    </Shell>
  );
}

export default function Auth({ mode }: { mode: Mode }) {
  if (mode === 'register') return <Register />;
  if (mode === 'forgot') return <Forgot />;
  if (mode === 'reset') return <Reset />;
  return <Login />;
}
