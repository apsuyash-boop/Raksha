import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ArrowLeft, Briefcase, CalendarPlus, FileText, Gavel, MessageCircle, Plus, Scale, ShieldCheck, Star, StickyNote } from 'lucide-react';
import { apiError, get, patch, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { Badge, Button, Card, CardHeader, EmptyState, Input, Modal, PageHeader, QueryState, Select, Switch, Textarea } from '@/components/ui';
import { Timeline } from '@/components/Timeline';
import { CASE_TYPES, cn, fmtDate, humanize, timeAgo } from '@/utils/format';
import type { CaseItem } from '@/types';

const STATUS_TONE: Record<string, any> = { open: 'neutral', seeking_help: 'warn', in_progress: 'blue', complaint_filed: 'violet', in_court: 'violet', resolved: 'safe', closed: 'neutral' };
const STAGES = ['open', 'seeking_help', 'in_progress', 'complaint_filed', 'in_court', 'resolved'];

export default function Cases() {
  const { id } = useParams();
  return id ? <CaseDetail id={id} /> : <CaseList />;
}

function CaseList() {
  const { user } = useAuth();
  const nav = useNavigate();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['cases'], queryFn: () => get<{ cases?: CaseItem[]; assigned?: CaseItem[]; requests?: CaseItem[] }>('/cases') });
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ type: 'domestic_violence', title: '', description: '', urgency: 'medium' });
  const create = useMutation({
    mutationFn: () => post<{ case: CaseItem }>('/cases', { ...f, city: user?.city, state: user?.state, language: user?.language }),
    onSuccess: (d) => {
      qc.invalidateQueries({ queryKey: ['cases'] });
      nav(`/cases/${d.case._id}`);
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const cases = q.data?.cases || q.data?.assigned || [];
  const isWoman = user?.role === 'user';

  return (
    <div>
      <PageHeader
        eyebrow="Case management"
        title={isWoman ? 'Cases & complaints' : 'Cases'}
        subtitle={isWoman ? 'Everything about each legal matter in one place — your team, evidence, complaints, hearings and timeline.' : 'Cases assigned to you.'}
        action={
          isWoman && (
            <>
              <Link to="/complaints">
                <Button variant="outline" icon={<FileText className="h-4 w-4" />}>Complaints</Button>
              </Link>
              <Button icon={<Plus className="h-4 w-4" />} onClick={() => setOpen(true)}>New case</Button>
            </>
          )
        }
      />
      <QueryState q={q} isEmpty={!cases.length} empty={<Card><EmptyState icon={<Briefcase className="h-6 w-6" />} title="No cases yet" body={isWoman ? 'Create a case to organise evidence, get matched with a lawyer or NGO, and track progress.' : 'Accepted requests will appear here.'} action={isWoman ? <Button onClick={() => setOpen(true)}>Create a case</Button> : undefined} /></Card>}>
        <div className="grid gap-4 md:grid-cols-2">
          {cases.map((c) => (
            <Link key={c._id} to={`/cases/${c._id}`} className="card p-5 transition hover:-translate-y-0.5 hover:shadow-lift">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-ink-mute">{c.caseNumber}</p>
                  <p className="mt-1 truncate text-lg font-semibold">{c.title}</p>
                </div>
                <Badge tone={STATUS_TONE[c.status]}>{humanize(c.status)}</Badge>
              </div>
              <p className="mt-2 text-sm text-ink-mute">{humanize(c.type)} · updated {timeAgo(c.updatedAt)}</p>
              <div className="mt-4 flex gap-1">
                {STAGES.map((s, i) => (
                  <span key={s} className={cn('h-1.5 flex-1 rounded-full', i <= Math.max(0, STAGES.indexOf(c.status)) || c.status === 'closed' ? 'bg-rk-500' : 'bg-sand-200')} />
                ))}
              </div>
            </Link>
          ))}
        </div>
      </QueryState>
      <Modal open={open} onClose={() => setOpen(false)} title="New case" footer={<><Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button loading={create.isPending} onClick={() => create.mutate()} disabled={f.title.length < 3}>Create case</Button></>}>
        <div className="space-y-4">
          <Select label="Type" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} options={CASE_TYPES as any} />
          <Input label="Title" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="A short name only you and your team will see" />
          <Textarea label="What happened? (optional)" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          <Select label="Urgency" value={f.urgency} onChange={(e) => setF({ ...f, urgency: e.target.value })} options={[['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['emergency', 'Emergency']]} />
        </div>
      </Modal>
    </div>
  );
}

function CaseDetail({ id }: { id: string }) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const q = useQuery({ queryKey: ['case', id], queryFn: () => get<{ case: CaseItem }>(`/cases/${id}`) });
  const participants = useQuery({ queryKey: ['case-participants', id], queryFn: () => get<{ participants: any[] }>(`/cases/${id}/participants`), enabled: q.data?.case.access !== 'requested' });
  const c = q.data?.case;
  const isOwner = c?.access === 'owner';
  const isPro = c?.access === 'assigned' || c?.access === 'admin';
  const [modal, setModal] = useState<null | 'hearing' | 'note' | 'doc' | 'date' | 'review'>(null);
  const [f, setF] = useState<any>({});
  const refresh = () => qc.invalidateQueries({ queryKey: ['case', id] });

  const act = useMutation({
    mutationFn: ({ url, body, method = 'post' }: { url: string; body: any; method?: 'post' | 'patch' }) => (method === 'patch' ? patch(url, body) : post(url, body)),
    onSuccess: (r) => {
      toast.success(r._message || 'Saved');
      setModal(null);
      setF({});
      refresh();
    },
    onError: (e) => toast.error(apiError(e).message),
  });

  return (
    <div>
      <Link to="/cases" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-rk-700">
        <ArrowLeft className="h-4 w-4" /> All cases
      </Link>
      <QueryState q={q}>
        {c && (
          <div className="space-y-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-sm font-semibold text-ink-mute">{c.caseNumber} · {humanize(c.type)}</p>
                <h1 className="mt-1 text-2xl font-semibold sm:text-3xl">{c.title}</h1>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Badge tone={STATUS_TONE[c.status]}>{humanize(c.status)}</Badge>
                  <Badge tone={c.urgency === 'emergency' || c.urgency === 'high' ? 'rk' : 'neutral'}>{humanize(c.urgency)} urgency</Badge>
                  {c.access === 'requested' && <Badge tone="warn">Request pending your decision</Badge>}
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {isOwner && (
                  <>
                    <Link to={`/complaints/new?caseId=${c._id}`}>
                      <Button variant="outline" icon={<FileText className="h-4 w-4" />}>Draft complaint</Button>
                    </Link>
                    {!c.lawyer && (
                      <Link to="/legal-help">
                        <Button icon={<Scale className="h-4 w-4" />}>Find lawyer / NGO</Button>
                      </Link>
                    )}
                  </>
                )}
                {isPro && (
                  <Select aria-label="Update status" value={c.status} onChange={(e) => act.mutate({ url: `/cases/${id}`, body: { status: e.target.value }, method: 'patch' })} options={['in_progress', 'complaint_filed', 'in_court', 'resolved', 'closed'].map((s) => [s, `Status: ${humanize(s)}`])} className="w-auto" />
                )}
              </div>
            </div>

            {c.access === 'requested' && <RequestDecision c={c} onDone={refresh} />}

            <div className="grid gap-6 lg:grid-cols-3">
              <div className="space-y-6 lg:col-span-2">
                {c.description && (
                  <Card className="p-5">
                    <p className="text-sm font-semibold text-ink-mute">Summary</p>
                    <p className="mt-1 whitespace-pre-line text-[15px]">{c.description}</p>
                  </Card>
                )}
                {c.access !== 'requested' && (
                  <>
                    <Card>
                      <CardHeader title="Hearings & important dates" icon={<CalendarPlus className="h-4 w-4" />} action={<div className="flex gap-1"><Button size="sm" variant="ghost" onClick={() => setModal('date')}>+ Date</Button><Button size="sm" variant="secondary" onClick={() => setModal('hearing')}>+ Hearing</Button></div>} />
                      <ul className="divide-y divide-sand-200">
                        {[...(c.hearings || []).map((h) => ({ ...h, kind: 'Hearing', label: h.purpose || 'Hearing', sub: h.court })), ...(c.importantDates || []).map((d) => ({ ...d, kind: 'Date', sub: '' }))]
                          .sort((a, b) => +new Date(a.date) - +new Date(b.date))
                          .map((h: any) => (
                            <li key={h._id} className="flex items-center gap-4 px-5 py-3">
                              <div className={cn('grid h-12 w-12 shrink-0 place-items-center rounded-xl text-center', new Date(h.date) < new Date() ? 'bg-sand-100 text-ink-mute' : 'bg-violet-50 text-violet-800')}>
                                <div>
                                  <p className="text-[10px] font-bold uppercase">{new Date(h.date).toLocaleString('en-IN', { month: 'short' })}</p>
                                  <p className="font-display text-lg font-semibold leading-none">{new Date(h.date).getDate()}</p>
                                </div>
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="font-semibold">{h.label}</p>
                                <p className="text-sm text-ink-mute">{h.kind}{h.sub ? ` · ${h.sub}` : ''} · {fmtDate(h.date, true)}</p>
                              </div>
                            </li>
                          ))}
                        {!c.hearings?.length && !c.importantDates?.length && <li className="px-5 py-6 text-sm text-ink-mute">No dates yet. You'll get reminders before each hearing.</li>}
                      </ul>
                    </Card>

                    <Card>
                      <CardHeader title="Notes" icon={<StickyNote className="h-4 w-4" />} action={<Button size="sm" variant="secondary" onClick={() => setModal('note')}>Add note</Button>} />
                      <ul className="space-y-3 p-5">
                        {(c.notes || []).slice().reverse().map((n) => (
                          <li key={n._id} className="rounded-xl bg-sand-50 p-3">
                            <p className="whitespace-pre-line text-sm">{n.text}</p>
                            <p className="mt-1.5 text-xs text-ink-mute">
                              {n.author?.name} · {timeAgo(n.at)} {n.visibility === 'professional_only' && <Badge tone="violet">Professionals only</Badge>}
                            </p>
                          </li>
                        ))}
                        {!c.notes?.length && <p className="text-sm text-ink-mute">No notes yet.</p>}
                      </ul>
                    </Card>

                    <Card>
                      <CardHeader title="Documents & evidence" icon={<FileText className="h-4 w-4" />} action={isPro ? <Button size="sm" variant="secondary" onClick={() => setModal('doc')}>Prepare document</Button> : <Link to="/evidence" className="text-sm font-semibold text-rk-700">Evidence Vault</Link>} />
                      <div className="space-y-4 p-5">
                        {(c.documents || []).map((d) => (
                          <details key={d._id} className="rounded-xl border border-sand-200 p-3">
                            <summary className="cursor-pointer font-semibold">{d.title} <span className="text-xs font-normal text-ink-mute">· {fmtDate(d.at)}</span></summary>
                            {d.body && <pre className="mt-2 whitespace-pre-wrap font-sans text-sm text-ink-soft">{d.body}</pre>}
                          </details>
                        ))}
                        <div>
                          <p className="text-sm font-semibold">Evidence ({c.evidence?.length || 0})</p>
                          {!isOwner && c.consent && !c.consent.shareEvidenceWithAssigned && <p className="text-sm text-ink-mute">The client has not shared evidence for this case.</p>}
                          <ul className="mt-2 space-y-1.5">
                            {(c.evidence || []).map((e: any) => (
                              <li key={e._id} className="flex items-center justify-between rounded-lg bg-sand-50 px-3 py-2 text-sm">
                                <span className="truncate">{e.title} <span className="text-ink-mute">· {e.evidenceId}</span></span>
                                <span className="font-mono text-[11px] text-ink-mute">{e.sha256?.slice(0, 10)}…</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        {(c.complaints || []).length > 0 && (
                          <div>
                            <p className="text-sm font-semibold">Complaints</p>
                            <ul className="mt-2 space-y-1.5">
                              {(c.complaints || []).map((cm: any) => (
                                <li key={cm._id}>
                                  <Link to={`/complaints/${cm._id}`} className="flex items-center justify-between rounded-lg bg-sand-50 px-3 py-2 text-sm hover:bg-sand-100">
                                    <span>{cm.complaintNumber}{cm.firNumber && ` · FIR ${cm.firNumber}`}</span>
                                    <Badge tone="blue">{humanize(cm.status)}</Badge>
                                  </Link>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </Card>
                  </>
                )}
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader title="Your team" icon={<Gavel className="h-4 w-4" />} />
                  <div className="space-y-3 p-5">
                    {c.lawyer && <TeamRow label="Lawyer" name={c.lawyer.displayName} />}
                    {c.ngo && <TeamRow label="NGO" name={c.ngo.name} sub={c.ngo.helpline && `Helpline ${c.ngo.helpline}`} />}
                    {!isOwner && c.user && <TeamRow label="Client" name={c.user.name} sub={c.user.phone} />}
                    {(participants.data?.participants || []).map((p) => (
                      <Link key={p._id} to={`/messages?with=${p._id}`}>
                        <Button size="sm" variant="outline" className="w-full" icon={<MessageCircle className="h-4 w-4" />}>Message {p.name.split(' (')[0]}</Button>
                      </Link>
                    ))}
                    {!c.lawyer && !c.ngo && isOwner && <p className="text-sm text-ink-mute">No one assigned yet.</p>}
                    {(c.requests || []).filter((r) => r.status === 'pending').length > 0 && isOwner && (
                      <p className="text-sm text-warn-700">{(c.requests || []).filter((r) => r.status === 'pending').length} request(s) awaiting response</p>
                    )}
                    {isOwner && (c.lawyer || c.ngo) && (
                      <Button size="sm" variant="ghost" icon={<Star className="h-4 w-4" />} onClick={() => setModal('review')}>
                        Leave a review
                      </Button>
                    )}
                  </div>
                </Card>
                {isOwner && c.consent && (
                  <Card>
                    <CardHeader title="Consent & sharing" icon={<ShieldCheck className="h-4 w-4" />} />
                    <div className="divide-y divide-sand-200 px-5">
                      <Switch checked={c.consent.shareEvidenceWithAssigned} onChange={(v) => act.mutate({ url: `/cases/${id}`, body: { consent: { shareEvidenceWithAssigned: v } }, method: 'patch' })} label="Share linked evidence with my lawyer/NGO" />
                      <Switch checked={c.consent.shareContactWithAssigned} onChange={(v) => act.mutate({ url: `/cases/${id}`, body: { consent: { shareContactWithAssigned: v } }, method: 'patch' })} label="Share my phone & email" />
                    </div>
                  </Card>
                )}
                <Card>
                  <CardHeader title="Case timeline" />
                  <div className="max-h-[480px] overflow-y-auto p-5">
                    <Timeline steps={(c.timeline || []).slice().reverse().map((t, i) => ({ key: t._id || String(i), label: t.label, detail: t.by?.name, at: t.at, state: (i === 0 ? 'current' : 'done') as 'current' | 'done' }))} />
                  </div>
                </Card>
              </div>
            </div>
          </div>
        )}
      </QueryState>

      <Modal open={modal === 'hearing'} onClose={() => setModal(null)} title="Add hearing" footer={<Button loading={act.isPending} onClick={() => act.mutate({ url: `/cases/${id}/hearings`, body: f })}>Save</Button>}>
        <div className="space-y-4">
          <Input label="Date & time" type="datetime-local" onChange={(e) => setF({ ...f, date: new Date(e.target.value).toISOString() })} />
          <Input label="Court" onChange={(e) => setF({ ...f, court: e.target.value })} />
          <Input label="Purpose" onChange={(e) => setF({ ...f, purpose: e.target.value })} />
        </div>
      </Modal>
      <Modal open={modal === 'date'} onClose={() => setModal(null)} title="Add important date" footer={<Button loading={act.isPending} onClick={() => act.mutate({ url: `/cases/${id}/dates`, body: f })}>Save</Button>}>
        <div className="space-y-4">
          <Input label="Date" type="datetime-local" onChange={(e) => setF({ ...f, date: new Date(e.target.value).toISOString() })} />
          <Input label="What is it?" onChange={(e) => setF({ ...f, label: e.target.value })} />
        </div>
      </Modal>
      <Modal open={modal === 'note'} onClose={() => setModal(null)} title="Add note" footer={<Button loading={act.isPending} onClick={() => act.mutate({ url: `/cases/${id}/notes`, body: { text: f.text, visibility: f.visibility || 'shared' } })}>Save</Button>}>
        <div className="space-y-4">
          <Textarea label="Note" onChange={(e) => setF({ ...f, text: e.target.value })} />
          {isPro && <Select label="Visible to" value={f.visibility || 'shared'} onChange={(e) => setF({ ...f, visibility: e.target.value })} options={[['shared', 'Client and team'], ['professional_only', 'Professionals only']]} />}
        </div>
      </Modal>
      <Modal open={modal === 'doc'} onClose={() => setModal(null)} title="Prepare document" size="lg" footer={<Button loading={act.isPending} onClick={() => act.mutate({ url: `/cases/${id}/documents`, body: f })}>Save document</Button>}>
        <div className="space-y-4">
          <Input label="Title" onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="e.g. Application under Section 12, PWDVA" />
          <Textarea label="Content" className="min-h-[260px] font-mono text-sm" onChange={(e) => setF({ ...f, body: e.target.value })} />
        </div>
      </Modal>
      <Modal open={modal === 'review'} onClose={() => setModal(null)} title="Review your support" footer={<Button loading={act.isPending} onClick={() => act.mutate({ url: `/cases/${id}/review`, body: { target: f.target || (c?.lawyer ? 'lawyer' : 'ngo'), rating: Number(f.rating || 5), text: f.text } })}>Submit</Button>}>
        <div className="space-y-4">
          <Select label="For" value={f.target || (c?.lawyer ? 'lawyer' : 'ngo')} onChange={(e) => setF({ ...f, target: e.target.value })} options={[...(c?.lawyer ? [['lawyer', 'Lawyer']] : []), ...(c?.ngo ? [['ngo', 'NGO']] : [])] as any} />
          <Select label="Rating" value={f.rating || '5'} onChange={(e) => setF({ ...f, rating: e.target.value })} options={[['5', '★★★★★'], ['4', '★★★★'], ['3', '★★★'], ['2', '★★'], ['1', '★']]} />
          <Textarea label="Comments (optional)" onChange={(e) => setF({ ...f, text: e.target.value })} />
        </div>
      </Modal>
      {user?.role === 'admin' && null}
    </div>
  );
}

function TeamRow({ label, name, sub }: { label: string; name: string; sub?: string }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-ink-mute">{label}</p>
      <p className="font-semibold">{name}</p>
      {sub && <p className="text-sm text-ink-mute">{sub}</p>}
    </div>
  );
}

function RequestDecision({ c, onDone }: { c: CaseItem; onDone: () => void }) {
  const req = (c.requests || [])[0];
  const respond = useMutation({
    mutationFn: (action: 'accept' | 'reject') => post(`/cases/${c._id}/requests/${req._id}/respond`, { action }),
    onSuccess: (r) => {
      toast.success(r._message);
      onDone();
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  if (!req) return null;
  return (
    <Card className="border-warn-500/30 bg-warn-50 p-5">
      <p className="font-semibold">This person has asked for your help.</p>
      <p className="mt-1 text-sm text-ink-soft">{req.message || 'No message.'} {c.location?.city && `· ${c.location.city}`} {c.language && `· prefers ${c.language.toUpperCase()}`} {c.budget && `· budget: ${c.budget}`}</p>
      <div className="mt-3 flex gap-2">
        <Button onClick={() => respond.mutate('accept')} loading={respond.isPending}>Accept case</Button>
        <Button variant="outline" onClick={() => respond.mutate('reject')}>Decline</Button>
      </div>
    </Card>
  );
}
