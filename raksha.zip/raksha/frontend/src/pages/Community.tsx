import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ArrowLeft, BadgeCheck, EyeOff, Flag, HandHeart, Heart, MessageSquare, PenLine, Search, Sparkles, Trash2, Zap } from 'lucide-react';
import { apiError, del, get, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { Avatar, Badge, Button, Card, EmptyState, Input, Modal, QueryState, Select, Switch, Textarea } from '@/components/ui';
import { cn, humanize, timeAgo } from '@/utils/format';

const TYPES: Array<[string, string]> = [
  ['', 'All'],
  ['story', 'Survivor stories'],
  ['article', 'Articles'],
  ['discussion', 'Discussions'],
  ['question', 'Questions'],
];
const REACTIONS = [
  ['support', 'Support', HandHeart],
  ['heart', 'Love', Heart],
  ['strength', 'Strength', Zap],
] as const;

function AuthorLine({ a, at }: { a: any; at: string }) {
  return (
    <div className="flex items-center gap-2.5">
      {a.anonymous ? (
        <span className="grid h-8 w-8 place-items-center rounded-full bg-sand-200 text-ink-mute"><EyeOff className="h-4 w-4" /></span>
      ) : (
        <Avatar name={a.name} color={a.avatarColor} size={32} />
      )}
      <div className="text-sm">
        <span className="font-semibold">{a.name}</span> {a.verified && <BadgeCheck className="inline h-3.5 w-3.5 text-safe-600" aria-label="Verified professional" />}
        {a.role && !a.anonymous && ['lawyer', 'ngo', 'counsellor'].includes(a.role) && <span className="text-ink-mute"> · {humanize(a.role)}</span>}
        <span className="block text-xs text-ink-mute">{timeAgo(at)}</span>
      </div>
    </div>
  );
}

function ReportButton({ type, id }: { type: string; id: string }) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState('harassment');
  const [details, setDetails] = useState('');
  const m = useMutation({ mutationFn: () => post('/community/reports', { targetType: type, targetId: id, reason, details: details || undefined }), onSuccess: (r) => { toast.success(r._message); setOpen(false); }, onError: (e) => toast.error(apiError(e).message) });
  if (!user) return null;
  return (
    <>
      <button onClick={() => setOpen(true)} className="inline-flex items-center gap-1 text-xs text-ink-mute hover:text-rk-700" aria-label="Report">
        <Flag className="h-3.5 w-3.5" /> Report
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="Report content" size="sm" footer={<Button loading={m.isPending} onClick={() => m.mutate()}>Send report</Button>}>
        <div className="space-y-4">
          <Select label="Reason" value={reason} onChange={(e) => setReason(e.target.value)} options={[['harassment', 'Harassment'], ['hate', 'Hate'], ['privacy', 'Reveals private information'], ['self_harm', 'Someone may be at risk'], ['spam', 'Spam'], ['misinformation', 'Misinformation'], ['other', 'Other']]} />
          <Textarea label="Details (optional)" value={details} onChange={(e) => setDetails(e.target.value)} className="min-h-[80px]" />
        </div>
      </Modal>
    </>
  );
}

function Reactions({ post: p }: { post: any }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [counts, setCounts] = useState(p.reactionCounts || {});
  const [mine, setMine] = useState<string | undefined>(p.myReaction);
  const m = useMutation({
    mutationFn: (type: string) => post<{ reactionCounts: any; myReaction: string | null }>(`/community/posts/${p._id}/react`, { type }),
    onSuccess: (r) => {
      setCounts(r.reactionCounts);
      setMine(r.myReaction || undefined);
      qc.invalidateQueries({ queryKey: ['posts'] });
    },
  });
  return (
    <div className="flex gap-1.5">
      {REACTIONS.map(([k, l, I]) => (
        <button key={k} disabled={!user} onClick={(e) => { e.preventDefault(); m.mutate(k); }} className={cn('inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-semibold transition', mine === k ? 'border-rk-300 bg-rk-50 text-rk-700' : 'border-sand-200 text-ink-mute hover:border-rk-200')} aria-pressed={mine === k} aria-label={l}>
          <I className="h-3.5 w-3.5" /> {counts[k] || 0}
        </button>
      ))}
    </div>
  );
}

export default function Community() {
  const { id } = useParams();
  return id ? <PostView id={id} /> : <Feed />;
}

function Feed() {
  const { user } = useAuth();
  const [type, setType] = useState('');
  const [q, setQ] = useState('');
  const [write, setWrite] = useState(false);
  const feed = useQuery({ queryKey: ['posts', type, q], queryFn: () => get<{ items: any[] }>('/community/posts', { type: type || undefined, q: q || undefined }) });
  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-0">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">Community</p>
          <h1 className="mt-2 text-3xl font-semibold">You are not alone</h1>
          <p className="mt-2 max-w-xl text-ink-mute">Stories, questions and articles from women and verified professionals. Post anonymously if you wish — your identity is never shown.</p>
        </div>
        {user ? <Button icon={<PenLine className="h-4 w-4" />} onClick={() => setWrite(true)}>Write</Button> : <Link to="/login"><Button variant="outline">Log in to post</Button></Link>}
      </div>
      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
          <input className="input pl-10" placeholder="Search posts" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {TYPES.map(([v, l]) => <button key={v} className={cn('chip whitespace-nowrap', type === v && 'chip-active')} onClick={() => setType(v)}>{l}</button>)}
      </div>
      <div className="mt-6 space-y-4">
        <QueryState q={feed} isEmpty={!feed.data?.items.length} empty={<EmptyState icon={<MessageSquare className="h-6 w-6" />} title="No posts yet" body="Be the first to share." />}>
          {(feed.data?.items || []).map((p) => (
            <Link key={p._id} to={`/community/${p._id}`} className="card block p-5 transition hover:shadow-lift">
              <div className="flex items-start justify-between gap-3">
                <AuthorLine a={p.author} at={p.createdAt} />
                <div className="flex gap-1.5">
                  {p.featured && <Badge tone="warn" icon={<Sparkles className="h-3 w-3" />}>Featured</Badge>}
                  <Badge tone={p.type === 'story' ? 'rk' : p.type === 'article' ? 'violet' : 'neutral'}>{humanize(p.type)}</Badge>
                </div>
              </div>
              <h2 className="mt-3 text-xl font-semibold">{p.title}</h2>
              <p className="mt-1.5 line-clamp-3 text-[15px] text-ink-soft">{p.body}</p>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <Reactions post={p} />
                <span className="flex items-center gap-1 text-sm text-ink-mute"><MessageSquare className="h-4 w-4" /> {p.commentsCount}</span>
              </div>
            </Link>
          ))}
        </QueryState>
      </div>
      {write && <WriteModal onClose={() => setWrite(false)} />}
    </div>
  );
}

function WriteModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const nav = useNavigate();
  const [f, setF] = useState({ type: 'discussion', title: '', body: '', tags: '', anonymous: false });
  const m = useMutation({
    mutationFn: () => post<{ post: any }>('/community/posts', { ...f, tags: f.tags.split(',').map((t) => t.trim()).filter(Boolean).slice(0, 8) }),
    onSuccess: (r) => {
      toast.success(r._message);
      qc.invalidateQueries({ queryKey: ['posts'] });
      onClose();
      if (r.post.status === 'published') nav(`/community/${r.post._id}`);
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <Modal open onClose={onClose} title="Share with the community" size="lg" footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button loading={m.isPending} onClick={() => m.mutate()} disabled={f.title.length < 5 || f.body.length < 20}>Post</Button></>}>
      <div className="space-y-4">
        <Select label="Type" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} options={TYPES.slice(1)} />
        <Input label="Title" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        <Textarea label="Your post" value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} className="min-h-[200px]" hint="Avoid names, phone numbers or addresses — posts with identifying details are held for review to protect you." />
        <Input label="Tags (comma separated)" value={f.tags} onChange={(e) => setF({ ...f, tags: e.target.value })} placeholder="dowry, hope, legal" />
        <div className="rounded-xl border border-sand-200 px-4">
          <Switch checked={f.anonymous} onChange={(v) => setF({ ...f, anonymous: v })} label="Post anonymously" description="Your name and profile are never shown. Moderators cannot see who you are either." />
        </div>
      </div>
    </Modal>
  );
}

function PostView({ id }: { id: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const nav = useNavigate();
  const q = useQuery({ queryKey: ['post', id], queryFn: () => get<{ post: any; comments: any[] }>(`/community/posts/${id}`) });
  const [body, setBody] = useState('');
  const [anon, setAnon] = useState(false);
  const comment = useMutation({
    mutationFn: () => post(`/community/posts/${id}/comments`, { body, anonymous: anon }),
    onSuccess: (r) => {
      toast.success(r._message);
      setBody('');
      qc.invalidateQueries({ queryKey: ['post', id] });
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const remove = useMutation({ mutationFn: () => del(`/community/posts/${id}`), onSuccess: () => { toast.success('Post removed'); nav('/community'); } });
  const p = q.data?.post;
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-0">
      <Link to="/community" className="mb-5 inline-flex items-center gap-1 text-sm font-semibold text-rk-700"><ArrowLeft className="h-4 w-4" /> Community</Link>
      <QueryState q={q}>
        {p && (
          <>
            <article className="card p-6 sm:p-8">
              <div className="flex items-start justify-between gap-3">
                <AuthorLine a={p.author} at={p.createdAt} />
                <Badge>{humanize(p.type)}</Badge>
              </div>
              {p.status !== 'published' && <p className="mt-4 rounded-xl bg-warn-50 p-3 text-sm text-warn-700">This post is {humanize(p.status).toLowerCase()} and only visible to you.</p>}
              <h1 className="mt-5 text-3xl font-semibold">{p.title}</h1>
              <div className="mt-4 whitespace-pre-line text-[16px] leading-relaxed text-ink-soft">{p.body}</div>
              <div className="mt-4 flex flex-wrap gap-1.5">{(p.tags || []).map((t: string) => <Badge key={t}>#{t}</Badge>)}</div>
              <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-sand-200 pt-4">
                <Reactions post={p} />
                <div className="flex items-center gap-3">
                  <ReportButton type="post" id={p._id} />
                  {p.isMine && <button onClick={() => confirm('Remove this post?') && remove.mutate()} className="inline-flex items-center gap-1 text-xs text-ink-mute hover:text-rk-700"><Trash2 className="h-3.5 w-3.5" /> Remove</button>}
                </div>
              </div>
            </article>
            <section className="mt-6">
              <h2 className="mb-3 font-sans text-lg font-semibold">Replies ({q.data?.comments.length})</h2>
              <div className="space-y-3">
                {(q.data?.comments || []).map((c) => (
                  <Card key={c._id} className="p-4">
                    <div className="flex items-start justify-between">
                      <AuthorLine a={c.author} at={c.createdAt} />
                      <ReportButton type="comment" id={c._id} />
                    </div>
                    <p className="mt-2 whitespace-pre-line text-[15px] text-ink-soft">{c.body}</p>
                  </Card>
                ))}
              </div>
              {user ? (
                <Card className="mt-4 p-4">
                  <Textarea placeholder="Write a kind, supportive reply…" value={body} onChange={(e) => setBody(e.target.value)} className="min-h-[90px]" aria-label="Reply" />
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                    <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-rk-600" checked={anon} onChange={(e) => setAnon(e.target.checked)} /> Reply anonymously</label>
                    <Button onClick={() => comment.mutate()} loading={comment.isPending} disabled={body.trim().length < 2}>Reply</Button>
                  </div>
                </Card>
              ) : (
                <p className="mt-4 text-sm text-ink-mute"><Link to="/login" className="font-semibold text-rk-700">Log in</Link> to reply.</p>
              )}
            </section>
          </>
        )}
      </QueryState>
    </div>
  );
}
