import { useState } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { AlertTriangle, ArrowLeft, Check, FileText, Plus, Printer, Send, ShieldCheck, Trash2 } from 'lucide-react';
import { apiError, get, patch, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { Badge, Button, Card, CardHeader, EmptyState, Input, Modal, PageHeader, QueryState, Select, Textarea } from '@/components/ui';
import { Timeline } from '@/components/Timeline';
import { CASE_TYPES, cn, fmtDate, humanize } from '@/utils/format';

const FLOW = ['draft', 'ready_for_submission', 'submitted', 'under_review', 'registered', 'investigation', 'court_proceeding', 'closed'];
const LABEL: Record<string, string> = {
  draft: 'Draft',
  ready_for_submission: 'Ready for submission',
  submitted: 'Submitted',
  under_review: 'Under review',
  registered: 'FIR / complaint registered',
  investigation: 'Investigation',
  court_proceeding: 'Court proceeding',
  closed: 'Closed',
};

export default function Complaints() {
  const { id } = useParams();
  const { pathname } = useLocation();
  if (pathname.endsWith('/new')) return <Wizard />;
  if (id) return <Detail id={id} />;
  return <List />;
}

function List() {
  const q = useQuery({ queryKey: ['complaints'], queryFn: () => get<{ complaints: any[] }>('/complaints') });
  const items = q.data?.complaints || [];
  return (
    <div>
      <PageHeader eyebrow="Police & court" title="Complaints" subtitle="Describe what happened in your own words. Raksha structures it into a complaint draft, attaches your evidence and helps you track progress." action={<Link to="/complaints/new"><Button icon={<Plus className="h-4 w-4" />}>New complaint</Button></Link>} />
      <QueryState q={q} isEmpty={!items.length} empty={<Card><EmptyState icon={<FileText className="h-6 w-6" />} title="No complaints yet" body="You stay in control: nothing is sent anywhere until you choose how to submit it." action={<Link to="/complaints/new"><Button>Start a complaint</Button></Link>} /></Card>}>
        <div className="grid gap-4 md:grid-cols-2">
          {items.map((c) => (
            <Link key={c._id} to={`/complaints/${c._id}`} className="card p-5 hover:shadow-lift">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-xs font-semibold text-ink-mute">{c.complaintNumber}</p>
                  <p className="mt-1 font-semibold">{humanize(c.incident?.type)} {c.incident?.place && `· ${c.incident.place}`}</p>
                </div>
                <Badge tone={c.status === 'registered' ? 'safe' : c.status === 'draft' ? 'neutral' : 'blue'}>{LABEL[c.status]}</Badge>
              </div>
              <p className="mt-2 text-sm text-ink-mute">Updated {fmtDate(c.updatedAt)} {c.firNumber && `· FIR ${c.firNumber} (${c.firSource === 'police_official' ? 'confirmed by police' : 'self-reported'})`}</p>
            </Link>
          ))}
        </div>
      </QueryState>
    </div>
  );
}

function Wizard() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const [step, setStep] = useState(0);
  const evidence = useQuery({ queryKey: ['evidence', 'all'], queryFn: () => get<{ items: any[] }>('/evidence') });
  const cases = useQuery({ queryKey: ['cases'], queryFn: () => get<{ cases: any[] }>('/cases') });
  const [inc, setInc] = useState<any>({ type: 'domestic_violence', date: '', time: '', place: '', city: user?.city || '', state: user?.state || '', description: '', injuries: '', previousComplaints: '', accused: [{ name: '', relation: '' }] });
  const [caseId, setCaseId] = useState(params.get('caseId') || '');
  const [station, setStation] = useState('');
  const [evIds, setEvIds] = useState<string[]>([]);
  const create = useMutation({
    mutationFn: () =>
      post<{ complaint: any }>('/complaints', {
        caseId: caseId || undefined,
        policeStation: station || undefined,
        evidenceIds: evIds,
        incident: { ...inc, date: inc.date || undefined, accused: inc.accused.filter((a: any) => a.name) },
      }),
    onSuccess: (d) => {
      toast.success('Draft generated — please review it carefully');
      nav(`/complaints/${d.complaint._id}`);
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const steps = ['Describe', 'People & details', 'Attach evidence'];
  return (
    <div className="mx-auto max-w-3xl">
      <Link to="/complaints" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-rk-700"><ArrowLeft className="h-4 w-4" /> Complaints</Link>
      <PageHeader title="New complaint" subtitle="Take your time. You can save and edit the draft before doing anything with it." />
      <ol className="mb-6 flex gap-2">
        {steps.map((s, i) => (
          <li key={s} className="flex-1">
            <div className={cn('h-1.5 rounded-full', i <= step ? 'bg-rk-600' : 'bg-sand-200')} />
            <p className={cn('mt-1.5 text-xs font-semibold', i === step ? 'text-rk-700' : 'text-ink-mute')}>{i + 1}. {s}</p>
          </li>
        ))}
      </ol>
      <Card className="space-y-4 p-6">
        {step === 0 && (
          <>
            <Select label="What kind of incident?" value={inc.type} onChange={(e) => setInc({ ...inc, type: e.target.value })} options={CASE_TYPES as any} />
            <div className="grid gap-4 sm:grid-cols-2">
              <Input label="Date" type="date" value={inc.date} onChange={(e) => setInc({ ...inc, date: e.target.value })} />
              <Input label="Approximate time" value={inc.time} onChange={(e) => setInc({ ...inc, time: e.target.value })} placeholder="e.g. 9:30 PM" />
            </div>
            <Input label="Where did it happen?" value={inc.place} onChange={(e) => setInc({ ...inc, place: e.target.value })} />
            <Textarea label="What happened, in your own words" value={inc.description} onChange={(e) => setInc({ ...inc, description: e.target.value })} className="min-h-[200px]" hint="Include what was said or done, by whom, and anything you are afraid of. Write in any language." required />
          </>
        )}
        {step === 1 && (
          <>
            <p className="label">Person(s) responsible</p>
            {inc.accused.map((a: any, i: number) => (
              <div key={i} className="grid grid-cols-[1fr_1fr_auto] gap-2">
                <input className="input" placeholder="Name or description" value={a.name} onChange={(e) => setInc({ ...inc, accused: inc.accused.map((x: any, j: number) => (j === i ? { ...x, name: e.target.value } : x)) })} />
                <input className="input" placeholder="Relation (husband, boss…)" value={a.relation} onChange={(e) => setInc({ ...inc, accused: inc.accused.map((x: any, j: number) => (j === i ? { ...x, relation: e.target.value } : x)) })} />
                <button className="px-2 text-ink-mute" onClick={() => setInc({ ...inc, accused: inc.accused.filter((_: any, j: number) => j !== i) })} aria-label="Remove"><Trash2 className="h-4 w-4" /></button>
              </div>
            ))}
            <button className="text-sm font-semibold text-rk-700" onClick={() => setInc({ ...inc, accused: [...inc.accused, { name: '', relation: '' }] })}>+ Add person</button>
            <Textarea label="Injuries or medical treatment (optional)" value={inc.injuries} onChange={(e) => setInc({ ...inc, injuries: e.target.value })} className="min-h-[70px]" />
            <Textarea label="Previous incidents or complaints (optional)" value={inc.previousComplaints} onChange={(e) => setInc({ ...inc, previousComplaints: e.target.value })} className="min-h-[70px]" />
            <div className="grid gap-4 sm:grid-cols-2">
              <Input label="City" value={inc.city} onChange={(e) => setInc({ ...inc, city: e.target.value })} />
              <Input label="Police station (if known)" value={station} onChange={(e) => setStation(e.target.value)} />
            </div>
            <Select label="Link to a case" value={caseId} onChange={(e) => setCaseId(e.target.value)} options={(cases.data?.cases || []).map((c) => [c._id, `${c.caseNumber} — ${c.title}`])} placeholder="None" />
          </>
        )}
        {step === 2 && (
          <>
            <p className="text-sm text-ink-mute">Selected items are listed in the complaint with their evidence ID and SHA-256 fingerprint.</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {(evidence.data?.items || []).map((e) => (
                <label key={e._id} className={cn('flex cursor-pointer items-center gap-3 rounded-xl border p-3 text-sm', evIds.includes(e._id) ? 'border-rk-500 bg-rk-50' : 'border-sand-200')}>
                  <input type="checkbox" className="accent-rk-600" checked={evIds.includes(e._id)} onChange={() => setEvIds(evIds.includes(e._id) ? evIds.filter((x) => x !== e._id) : [...evIds, e._id])} />
                  <span className="truncate">{e.title}</span>
                </label>
              ))}
              {!evidence.data?.items.length && <p className="text-sm text-ink-mute">No evidence in your vault yet. <Link to="/evidence" className="font-semibold text-rk-700 underline">Add some</Link></p>}
            </div>
          </>
        )}
        <div className="flex gap-2 pt-2">
          {step > 0 && <Button variant="outline" onClick={() => setStep(step - 1)}>Back</Button>}
          {step < 2 ? (
            <Button className="flex-1" onClick={() => (step === 0 && inc.description.trim().length < 20 ? toast.error('Please describe what happened (at least a few sentences)') : setStep(step + 1))}>Continue</Button>
          ) : (
            <Button className="flex-1" loading={create.isPending} onClick={() => create.mutate()} icon={<FileText className="h-4 w-4" />}>Generate complaint draft</Button>
          )}
        </div>
      </Card>
    </div>
  );
}

function Detail({ id }: { id: string }) {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['complaint', id], queryFn: () => get<{ complaint: any; access: string }>(`/complaints/${id}`) });
  const officers = useQuery({ queryKey: ['officers'], queryFn: () => get<{ officers: any[] }>('/complaints/police/officers'), enabled: q.data?.access === 'owner' });
  const c = q.data?.complaint;
  const isOwner = q.data?.access === 'owner';
  const [draft, setDraft] = useState<string | null>(null);
  const [submitOpen, setSubmitOpen] = useState(false);
  const [statusOpen, setStatusOpen] = useState(false);
  const [st, setSt] = useState<any>({ status: 'under_review' });
  const refresh = () => qc.invalidateQueries({ queryKey: ['complaint', id] });
  const m = useMutation({
    mutationFn: ({ url, body, method = 'post' }: { url: string; body?: any; method?: string }) => (method === 'patch' ? patch(url, body) : post(url, body)),
    onSuccess: (r) => {
      toast.success(r._message || 'Saved');
      setSubmitOpen(false);
      setStatusOpen(false);
      setDraft(null);
      refresh();
    },
    onError: (e) => toast.error(apiError(e).message, { duration: 8000 }),
  });

  const print = () => {
    const w = window.open('', '_blank');
    if (!w) return;
    const esc = (s: string) => s.replace(/[&<>]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[ch] as string);
    w.document.write(`<html><head><title>${c.complaintNumber}</title><style>body{font:14px/1.6 Georgia,serif;max-width:720px;margin:40px auto;padding:0 24px;color:#111}pre{white-space:pre-wrap;font:inherit}.meta{font:12px sans-serif;color:#555;border-top:1px solid #ccc;margin-top:32px;padding-top:8px}</style></head><body><pre>${esc(c.draftText || '')}</pre><p class="meta">Prepared with Raksha · Reference ${c.complaintNumber} · ${new Date().toLocaleString('en-IN')}</p></body></html>`);
    w.document.close();
    w.focus();
    w.print();
  };

  return (
    <div>
      <Link to="/complaints" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-rk-700"><ArrowLeft className="h-4 w-4" /> Complaints</Link>
      <QueryState q={q}>
        {c && (
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="space-y-6 lg:col-span-2">
              <div>
                <p className="text-sm font-semibold text-ink-mute">{c.complaintNumber}</p>
                <h1 className="mt-1 text-2xl font-semibold">{humanize(c.incident?.type)} complaint</h1>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Badge tone="blue">{LABEL[c.status]}</Badge>
                  {c.submission?.method !== 'none' && <Badge tone={c.submission?.confirmedByAuthority ? 'safe' : 'warn'}>{c.submission?.confirmedByAuthority ? 'Confirmed by authority' : 'Self-reported submission'}</Badge>}
                  {c.firNumber && <Badge tone="safe">FIR {c.firNumber} · {c.firSource === 'police_official' ? 'confirmed by police' : 'self-reported'}</Badge>}
                </div>
              </div>
              <Card>
                <CardHeader title="Complaint draft" subtitle="Review every word. Edit anything that is not exactly right." icon={<FileText className="h-4 w-4" />} action={<Button size="sm" variant="outline" icon={<Printer className="h-4 w-4" />} onClick={print}>Print / PDF</Button>} />
                <div className="p-5">
                  {draft !== null ? (
                    <>
                      <textarea className="input min-h-[420px] font-mono text-[13px]" value={draft} onChange={(e) => setDraft(e.target.value)} aria-label="Complaint draft" />
                      <div className="mt-3 flex gap-2">
                        <Button onClick={() => m.mutate({ url: `/complaints/${id}`, body: { draftText: draft }, method: 'patch' })} loading={m.isPending}>Save changes</Button>
                        <Button variant="ghost" onClick={() => setDraft(null)}>Cancel</Button>
                      </div>
                    </>
                  ) : (
                    <>
                      <pre className="max-h-[520px] overflow-y-auto whitespace-pre-wrap rounded-xl bg-sand-50 p-5 font-display text-[14.5px] leading-relaxed text-ink">{c.draftText}</pre>
                      {isOwner && ['draft', 'ready_for_submission'].includes(c.status) && (
                        <div className="mt-3 flex flex-wrap gap-2">
                          <Button variant="outline" onClick={() => setDraft(c.draftText)}>Edit text</Button>
                          {c.status === 'draft' && <Button variant="secondary" icon={<Check className="h-4 w-4" />} onClick={() => m.mutate({ url: `/complaints/${id}/ready` })}>Mark ready</Button>}
                          <Button icon={<Send className="h-4 w-4" />} onClick={() => setSubmitOpen(true)}>Submit</Button>
                        </div>
                      )}
                    </>
                  )}
                </div>
              </Card>
              <p className="flex items-start gap-2 text-sm text-ink-mute">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> This draft is generated from your words to help you. It is not legal advice and is not filed anywhere unless you submit it. Police registration is shown as confirmed only when a verified official or a connected police system confirms it.
              </p>
            </div>
            <div className="space-y-6">
              <Card>
                <CardHeader title="Progress" action={!isOwner || ['submitted', 'under_review', 'registered', 'investigation', 'court_proceeding'].includes(c.status) ? <Button size="sm" variant="secondary" onClick={() => setStatusOpen(true)}>Update</Button> : undefined} />
                <div className="p-5">
                  <Timeline
                    steps={FLOW.map((s) => {
                      const h = [...(c.statusHistory || [])].reverse().find((x: any) => x.status === s);
                      const idx = FLOW.indexOf(c.status);
                      return { key: s, label: LABEL[s], at: h?.at, detail: h ? `${h.note || ''}${h.source && h.source !== 'user' ? ` (${humanize(h.source)})` : ''}` : undefined, state: (FLOW.indexOf(s) < idx ? 'done' : s === c.status ? 'current' : 'pending') as 'done' | 'current' | 'pending' };
                    })}
                  />
                </div>
              </Card>
              <Card>
                <CardHeader title="Attached evidence" />
                <ul className="space-y-1.5 p-5 text-sm">
                  {(c.evidence || []).map((e: any) => (
                    <li key={e._id} className="rounded-lg bg-sand-50 px-3 py-2">
                      <p className="font-medium">{e.title}</p>
                      <p className="font-mono text-[11px] text-ink-mute">{e.evidenceId} · {e.sha256.slice(0, 16)}…</p>
                    </li>
                  ))}
                  {!c.evidence?.length && <p className="text-ink-mute">None attached.</p>}
                </ul>
              </Card>
              {isOwner && (officers.data?.officers || []).length > 0 && (
                <Card>
                  <CardHeader title="Share with a verified officer" icon={<ShieldCheck className="h-4 w-4" />} subtitle="Optional. They can then confirm registration and update status." />
                  <div className="space-y-2 p-5">
                    {(officers.data?.officers || []).map((o) => (
                      <div key={o._id} className="flex items-center justify-between gap-2 text-sm">
                        <span>{o.name} <span className="text-ink-mute">· {o.city}</span></span>
                        <Button size="sm" variant="outline" disabled={(c.sharedWithPolice || []).includes(o._id)} onClick={() => m.mutate({ url: `/complaints/${id}/share-police`, body: { policeUserId: o._id } })}>
                          {(c.sharedWithPolice || []).includes(o._id) ? 'Shared' : 'Share'}
                        </Button>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          </div>
        )}
      </QueryState>

      <Modal open={submitOpen} onClose={() => setSubmitOpen(false)} title="How will you submit it?">
        <div className="space-y-3">
          {[
            ['printed_in_person', 'I will take a printed copy to the police station', 'Print it, sign it and ask for a free copy of the FIR or a receipt.'],
            ['via_ngo', 'An NGO volunteer is helping me submit it', 'Your NGO can accompany you to the station.'],
            ['online_portal_self', "I submitted it on my state police's citizen portal", 'Enter the reference number later in the status update.'],
            ['integration', 'Submit online through Raksha', 'Works only where a police integration is configured. If not available, we will tell you.'],
          ].map(([v, t, d]) => (
            <button key={v} onClick={() => m.mutate({ url: `/complaints/${id}/submit`, body: { method: v } })} className="w-full rounded-2xl border border-sand-200 p-4 text-left hover:border-rk-300 hover:bg-rk-50/40" disabled={m.isPending}>
              <p className="font-semibold">{t}</p>
              <p className="text-sm text-ink-mute">{d}</p>
            </button>
          ))}
        </div>
      </Modal>
      <Modal open={statusOpen} onClose={() => setStatusOpen(false)} title="Update status" footer={<Button loading={m.isPending} onClick={() => m.mutate({ url: `/complaints/${id}/status`, body: st })}>Save</Button>}>
        <div className="space-y-4">
          <Select label="Status" value={st.status} onChange={(e) => setSt({ ...st, status: e.target.value })} options={FLOW.slice(3).map((s) => [s, LABEL[s]])} />
          {st.status === 'registered' && <Input label="FIR / complaint number" value={st.firNumber || ''} onChange={(e) => setSt({ ...st, firNumber: e.target.value })} />}
          <Textarea label="Note" value={st.note || ''} onChange={(e) => setSt({ ...st, note: e.target.value })} className="min-h-[80px]" />
          {isOwner && <p className="text-xs text-ink-mute">Updates you make are labelled "self-reported".</p>}
        </div>
      </Modal>
    </div>
  );
}
