import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { BadgeCheck, Briefcase, HeartHandshake, MessageCircle, Phone, Scale, Star, Video } from 'lucide-react';
import { apiError, get, post } from '@/api/client';
import { Avatar, Badge, Button, Card, CardHeader, Input, Modal, PageHeader, QueryState, Select, Tabs, Textarea } from '@/components/ui';
import { cn, fmtDate, humanize, inr } from '@/utils/format';

const CATS: Array<['', string] | ['emotional' | 'legal' | 'career_money', string]> = [
  ['', 'All'],
  ['emotional', 'Emotional'],
  ['legal', 'Legal advice'],
  ['career_money', 'Career & money'],
];
const MODE_ICON = { chat: MessageCircle, call: Phone, video: Video };
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function Counselling() {
  const qc = useQueryClient();
  const [tab, setTab] = useState<'browse' | 'mine'>('browse');
  const [cat, setCat] = useState('');
  const [free, setFree] = useState(false);
  const [book, setBook] = useState<any>(null);
  const list = useQuery({ queryKey: ['counsellors', cat, free], queryFn: () => get<{ items: any[] }>('/counsellors', { category: cat || undefined, free: free || undefined }) });
  const appts = useQuery({ queryKey: ['appointments'], queryFn: () => get<{ appointments: any[] }>('/appointments') });
  const cancel = useMutation({
    mutationFn: (id: string) => post(`/appointments/${id}/status`, { action: 'cancel' }),
    onSuccess: () => {
      toast.success('Appointment cancelled');
      qc.invalidateQueries({ queryKey: ['appointments'] });
    },
  });

  return (
    <div>
      <PageHeader eyebrow="Counselling" title="Talk to someone who understands" subtitle="Certified counsellors by chat, call or video — for emotional support, a first legal consultation, or career and money guidance. Confidential, in your language." />
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <Tabs value={tab} onChange={setTab} tabs={[['browse', 'Find a counsellor'], ['mine', `My sessions (${appts.data?.appointments.length ?? 0})`]]} />
        <a href="tel:14416" className="chip">
          <Phone className="h-3.5 w-3.5" /> Tele-MANAS 14416 (24×7, free)
        </a>
      </div>

      {tab === 'browse' ? (
        <>
          <div className="mb-4 flex flex-wrap gap-2">
            {CATS.map(([v, l]) => (
              <button key={v} className={cn('chip', cat === v && 'chip-active')} onClick={() => setCat(v)}>
                {v === 'emotional' && <HeartHandshake className="h-3.5 w-3.5" />}
                {v === 'legal' && <Scale className="h-3.5 w-3.5" />}
                {v === 'career_money' && <Briefcase className="h-3.5 w-3.5" />}
                {l}
              </button>
            ))}
            <button className={cn('chip', free && 'chip-active')} onClick={() => setFree(!free)}>Free sessions</button>
          </div>
          <QueryState q={list} isEmpty={!list.data?.items.length} empty={<Card className="p-8 text-center text-ink-mute">No counsellors match these filters.</Card>}>
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {(list.data?.items || []).map((c) => (
                <Card key={c._id} className="flex flex-col p-5">
                  <div className="flex items-start gap-3">
                    <Avatar name={c.displayName} color={c.user?.avatarColor || '#6D28D9'} size={48} />
                    <div>
                      <p className="font-semibold leading-snug">{c.displayName}</p>
                      <p className="flex items-center gap-1 text-sm text-ink-mute">
                        <BadgeCheck className="h-3.5 w-3.5 text-safe-600" /> {c.qualification}
                      </p>
                    </div>
                  </div>
                  <p className="mt-3 line-clamp-2 text-sm text-ink-soft">{c.bio}</p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <Badge tone="violet">{humanize(c.category)}</Badge>
                    {(c.specializations || []).slice(0, 3).map((s: string) => <Badge key={s}>{humanize(s)}</Badge>)}
                  </div>
                  <div className="mt-3 flex items-center justify-between text-sm">
                    <span className="flex gap-1.5 text-ink-mute">
                      {(c.modes || []).map((m: 'chat' | 'call' | 'video') => {
                        const I = MODE_ICON[m];
                        return <I key={m} className="h-4 w-4" aria-label={m} />;
                      })}
                      <span>· {(c.languages || []).join(', ').toUpperCase()}</span>
                    </span>
                    <span className="font-semibold">{c.freeSessions || !c.price ? <span className="text-safe-600">Free</span> : `${inr(c.price)}/session`}</span>
                  </div>
                  {c.rating > 0 && <p className="mt-1 flex items-center gap-1 text-xs text-ink-mute"><Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {c.rating}</p>}
                  <Button className="mt-4" onClick={() => setBook(c)}>Book a session</Button>
                </Card>
              ))}
            </div>
          </QueryState>
        </>
      ) : (
        <QueryState q={appts} isEmpty={!appts.data?.appointments.length} empty={<Card className="p-8 text-center text-ink-mute">No sessions yet.</Card>}>
          <div className="space-y-3">
            {(appts.data?.appointments || []).map((a) => {
              const I = MODE_ICON[a.mode as 'chat'] || MessageCircle;
              const upcoming = new Date(a.scheduledAt) > new Date(Date.now() - 3600e3) && ['requested', 'confirmed'].includes(a.status);
              return (
                <Card key={a._id} className="flex flex-wrap items-center gap-4 p-4">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-violet-50 text-violet-700"><I className="h-5 w-5" /></span>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{a.counsellor?.displayName}</p>
                    <p className="text-sm text-ink-mute">{fmtDate(a.scheduledAt, true)} · {a.mode}{a.topic ? ` · ${a.topic}` : ''}</p>
                  </div>
                  <Badge tone={a.status === 'confirmed' ? 'safe' : a.status === 'requested' ? 'warn' : 'neutral'}>{a.status}</Badge>
                  {upcoming && a.status === 'confirmed' && a.mode === 'video' && a.meetingUrl && (
                    <a href={a.meetingUrl} target="_blank" rel="noreferrer"><Button size="sm" icon={<Video className="h-4 w-4" />}>Join</Button></a>
                  )}
                  {upcoming && a.mode === 'chat' && a.counsellorUser && <Link to={`/messages?with=${a.counsellorUser}`}><Button size="sm" variant="secondary">Open chat</Button></Link>}
                  {upcoming && <Button size="sm" variant="ghost" onClick={() => cancel.mutate(a._id)}>Cancel</Button>}
                </Card>
              );
            })}
          </div>
        </QueryState>
      )}
      {book && <BookModal c={book} onClose={() => setBook(null)} onDone={() => { qc.invalidateQueries({ queryKey: ['appointments'] }); setTab('mine'); }} />}
    </div>
  );
}

function BookModal({ c, onClose, onDone }: { c: any; onClose: () => void; onDone: () => void }) {
  const [mode, setMode] = useState(c.modes?.[0] || 'chat');
  const [when, setWhen] = useState('');
  const [topic, setTopic] = useState('');
  const m = useMutation({
    mutationFn: () => post('/appointments', { counsellorId: c._id, mode, scheduledAt: new Date(when).toISOString(), topic: topic || undefined }),
    onSuccess: (r) => {
      toast.success(r._message);
      onDone();
      onClose();
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <Modal open onClose={onClose} title={`Book with ${c.displayName}`} footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button loading={m.isPending} disabled={!when} onClick={() => m.mutate()}>Request session</Button></>}>
      <div className="space-y-4">
        <Select label="How would you like to talk?" value={mode} onChange={(e) => setMode(e.target.value)} options={(c.modes || ['chat']).map((x: string) => [x, humanize(x)])} />
        <Input label="Preferred date & time" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} min={new Date().toISOString().slice(0, 16)} />
        {(c.weeklySlots || []).length > 0 && (
          <p className="text-xs text-ink-mute">Usually available: {Array.from(new Set((c.weeklySlots || []).map((s: any) => `${DAYS[s.day]} ${s.from}–${s.to}`))).slice(0, 4).join(' · ')}</p>
        )}
        <Textarea label="What would you like to talk about? (optional, private)" value={topic} onChange={(e) => setTopic(e.target.value)} className="min-h-[80px]" />
        <p className="text-xs text-ink-mute">{c.freeSessions || !c.price ? 'This session is free.' : `Fee: ${inr(c.price)} — pay the counsellor directly after confirmation.`} You will get a reminder before the session.</p>
      </div>
    </Modal>
  );
}
