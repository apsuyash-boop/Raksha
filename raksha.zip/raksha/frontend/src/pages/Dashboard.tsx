import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowRight, Bell, CalendarClock, FileLock2, Gavel, HeartHandshake, Landmark, MapPin, Scale, ShieldCheck, Siren, UserPlus, Wallet, BookOpen } from 'lucide-react';
import { get } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Badge, Button, Card, CardHeader, EmptyState, Progress, Skeleton } from '@/components/ui';
import { cn, fmtDate, humanize, inr, timeAgo } from '@/utils/format';

export default function Dashboard() {
  const { user, hasSafetyPin } = useAuth();
  const { t } = useI18n();
  const sos = useQuery({ queryKey: ['sos', 'active'], queryFn: () => get<{ alert: any }>('/sos/active') });
  const shares = useQuery({ queryKey: ['shares'], queryFn: () => get<{ shares: any[] }>('/location/shares/active') });
  const contacts = useQuery({ queryKey: ['contacts'], queryFn: () => get<{ contacts: any[] }>('/contacts') });
  const cases = useQuery({ queryKey: ['cases'], queryFn: () => get<{ cases: any[] }>('/cases') });
  const appts = useQuery({ queryKey: ['appointments'], queryFn: () => get<{ appointments: any[] }>('/appointments') });
  const apps = useQuery({ queryKey: ['scheme-apps'], queryFn: () => get<{ applications: any[] }>('/schemes/applications/mine') });
  const camps = useQuery({ queryKey: ['my-campaigns'], queryFn: () => get<{ campaigns: any[] }>('/campaigns/mine') });
  const notifs = useQuery({ queryKey: ['notifications'], queryFn: () => get<{ items: any[] }>('/notifications') });

  const active = sos.data?.alert;
  const sharing = (shares.data?.shares || []).find((s) => s.reason !== 'sos');
  const openCases = (cases.data?.cases || []).filter((c) => !['resolved', 'closed'].includes(c.status));
  const hearings = openCases.flatMap((c) => (c.hearings || []).filter((h: any) => new Date(h.date) > new Date()).map((h: any) => ({ ...h, caseId: c._id, caseTitle: c.title }))).sort((a, b) => +new Date(a.date) - +new Date(b.date));
  const upcomingAppts = (appts.data?.appointments || []).filter((a) => ['requested', 'confirmed'].includes(a.status) && new Date(a.scheduledAt) > new Date(Date.now() - 3600e3)).sort((a, b) => +new Date(a.scheduledAt) - +new Date(b.scheduledAt));
  const assigned = openCases.filter((c) => c.lawyer || c.ngo);
  const nContacts = contacts.data?.contacts.length ?? 0;

  const status = active
    ? { tone: 'sos', title: t('status.sos'), body: active.isDemo ? 'Demo SOS (simulated) is running.' : 'Your contacts have been alerted. Stay where it is safe.', icon: <Siren className="h-6 w-6" /> }
    : sharing
      ? { tone: 'share', title: t('status.sharing'), body: `Until ${new Date(sharing.expiresAt).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}`, icon: <MapPin className="h-6 w-6" /> }
      : { tone: 'safe', title: t('status.safe'), body: 'No active alerts. Raksha is ready if you need it.', icon: <ShieldCheck className="h-6 w-6" /> };

  const setup = [
    { done: nContacts > 0, label: 'Add emergency contacts', to: '/emergency-contacts' },
    { done: hasSafetyPin, label: 'Set a safety PIN', to: '/settings#safety' },
    { done: !!user?.emailVerified || !!user?.phoneVerified, label: 'Verify your email or phone', to: '/settings#account' },
  ];
  const setupPct = (setup.filter((s) => s.done).length / setup.length) * 100;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-sm text-ink-mute">{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
          <h1 className="text-2xl font-semibold sm:text-3xl">Namaste, {user?.name.split(' ')[0]}</h1>
        </div>
        <Link to="/sos" className="hidden sm:block">
          <Button icon={<Siren className="h-4 w-4" />}>Open SOS</Button>
        </Link>
      </div>

      {/* Safety status */}
      <div
        className={cn(
          'relative overflow-hidden rounded-3xl p-6 sm:p-7',
          status.tone === 'sos' && 'bg-gradient-to-br from-rk-600 to-rk-800 text-white',
          status.tone === 'share' && 'bg-gradient-to-br from-amber-50 to-white ring-1 ring-amber-200',
          status.tone === 'safe' && 'bg-gradient-to-br from-safe-50 to-white ring-1 ring-safe-100',
        )}
        role="status"
      >
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className={cn('grid h-14 w-14 place-items-center rounded-2xl', status.tone === 'sos' ? 'bg-white/15' : status.tone === 'share' ? 'bg-amber-100 text-warn-700' : 'bg-safe-100 text-safe-600')}>{status.icon}</div>
            <div>
              <p className={cn('text-xs font-semibold uppercase tracking-[.14em]', status.tone === 'sos' ? 'text-white/70' : 'text-ink-mute')}>Current safety status</p>
              <p className="font-display text-2xl font-semibold" style={status.tone === 'sos' ? { color: 'white' } : undefined}>
                {status.title}
              </p>
              <p className={cn('text-sm', status.tone === 'sos' ? 'text-white/80' : 'text-ink-mute')}>{status.body}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {active ? (
              <Link to="/sos">
                <Button className="bg-white text-rk-800 hover:bg-rk-50">View SOS</Button>
              </Link>
            ) : (
              <>
                <Link to="/sos?share=1">
                  <Button variant="outline" icon={<MapPin className="h-4 w-4" />}>
                    Share live location
                  </Button>
                </Link>
                <Link to="/sos">
                  <Button icon={<Siren className="h-4 w-4" />}>SOS</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>

      {setupPct < 100 && (
        <Card className="p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="font-semibold">Finish your safety setup</p>
            <span className="text-sm text-ink-mute">{Math.round(setupPct)}%</span>
          </div>
          <Progress value={setupPct} className="mt-3" />
          <div className="mt-4 flex flex-wrap gap-2">
            {setup
              .filter((s) => !s.done)
              .map((s) => (
                <Link key={s.label} to={s.to} className="chip">
                  <UserPlus className="h-3.5 w-3.5" /> {s.label}
                </Link>
              ))}
          </div>
        </Card>
      )}

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { to: '/evidence', icon: FileLock2, label: 'Save evidence' },
          { to: '/legal-help', icon: Scale, label: 'Find a lawyer' },
          { to: '/complaints/new', icon: Gavel, label: 'Draft a complaint' },
          { to: '/rights', icon: BookOpen, label: 'Know your rights' },
        ].map(({ to, icon: I, label }) => (
          <Link key={to} to={to} className="card flex items-center gap-3 p-4 transition hover:-translate-y-0.5 hover:shadow-lift">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-rk-50 text-rk-600">
              <I className="h-5 w-5" />
            </span>
            <span className="text-sm font-semibold">{label}</span>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader title="Active cases" icon={<Gavel className="h-4 w-4" />} action={<Link to="/cases" className="text-sm font-semibold text-rk-700">{t('common.viewAll')}</Link>} />
            {cases.isLoading ? (
              <div className="space-y-3 p-5">
                <Skeleton className="h-16" />
                <Skeleton className="h-16" />
              </div>
            ) : openCases.length ? (
              <ul className="divide-y divide-sand-200">
                {openCases.slice(0, 4).map((c) => (
                  <li key={c._id}>
                    <Link to={`/cases/${c._id}`} className="flex items-center justify-between gap-3 px-5 py-4 hover:bg-sand-50">
                      <div className="min-w-0">
                        <p className="truncate font-semibold">{c.title}</p>
                        <p className="text-sm text-ink-mute">
                          {c.caseNumber} · {humanize(c.type)}
                          {c.lawyer?.displayName && ` · ${c.lawyer.displayName}`}
                        </p>
                      </div>
                      <Badge tone={c.status === 'in_court' ? 'violet' : c.status === 'seeking_help' ? 'warn' : 'blue'}>{humanize(c.status)}</Badge>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState title="No open cases" body="When you're ready, Raksha can match you with a verified lawyer or NGO." action={<Link to="/legal-help"><Button size="sm">Get legal help</Button></Link>} />
            )}
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader title="Upcoming hearings" icon={<CalendarClock className="h-4 w-4" />} />
              <div className="p-5">
                {hearings.length ? (
                  <ul className="space-y-3">
                    {hearings.slice(0, 3).map((h) => (
                      <li key={h._id} className="flex gap-3">
                        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-violet-50 text-center text-violet-800">
                          <div>
                            <p className="text-[10px] font-bold uppercase">{new Date(h.date).toLocaleString('en-IN', { month: 'short' })}</p>
                            <p className="font-display text-lg font-semibold leading-none">{new Date(h.date).getDate()}</p>
                          </div>
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold">{h.purpose || 'Hearing'}</p>
                          <p className="truncate text-sm text-ink-mute">{h.court} · {timeAgo(h.date)}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-ink-mute">No hearings scheduled.</p>
                )}
              </div>
            </Card>
            <Card>
              <CardHeader title="Your support team" icon={<Scale className="h-4 w-4" />} />
              <div className="p-5">
                {assigned.length ? (
                  <ul className="space-y-3">
                    {assigned.slice(0, 3).flatMap((c) => [
                      c.lawyer && (
                        <li key={c._id + 'l'} className="flex items-center justify-between gap-2">
                          <div>
                            <p className="font-semibold">{c.lawyer.displayName}</p>
                            <p className="text-xs text-ink-mute">Lawyer · {c.caseNumber}</p>
                          </div>
                          <Badge tone="safe">Assigned</Badge>
                        </li>
                      ),
                      c.ngo && (
                        <li key={c._id + 'n'} className="flex items-center justify-between gap-2">
                          <div>
                            <p className="font-semibold">{c.ngo.name}</p>
                            <p className="text-xs text-ink-mute">NGO · {c.caseNumber}</p>
                          </div>
                          <Badge tone="safe">Assigned</Badge>
                        </li>
                      ),
                    ])}
                  </ul>
                ) : (
                  <p className="text-sm text-ink-mute">No lawyer or NGO assigned yet.</p>
                )}
              </div>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader title="Counselling" icon={<HeartHandshake className="h-4 w-4" />} action={<Link to="/counselling" className="text-sm font-semibold text-rk-700">Book</Link>} />
              <div className="p-5">
                {upcomingAppts.length ? (
                  upcomingAppts.slice(0, 2).map((a) => (
                    <div key={a._id} className="mb-3 flex items-center justify-between last:mb-0">
                      <div>
                        <p className="font-semibold">{a.counsellor?.displayName}</p>
                        <p className="text-sm text-ink-mute">
                          {fmtDate(a.scheduledAt, true)} · {a.mode}
                        </p>
                      </div>
                      <Badge tone={a.status === 'confirmed' ? 'safe' : 'warn'}>{a.status}</Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-ink-mute">No upcoming sessions. Talking helps — many counsellors offer free sessions.</p>
                )}
              </div>
            </Card>
            <Card>
              <CardHeader title="Scheme applications" icon={<Landmark className="h-4 w-4" />} action={<Link to="/schemes" className="text-sm font-semibold text-rk-700">Find</Link>} />
              <div className="p-5">
                {(apps.data?.applications || []).length ? (
                  (apps.data?.applications || []).slice(0, 3).map((a) => (
                    <div key={a._id} className="mb-3 flex items-center justify-between gap-2 last:mb-0">
                      <p className="truncate text-sm font-semibold">{a.scheme?.name}</p>
                      <Badge tone={a.status === 'approved' || a.status === 'benefit_received' ? 'safe' : 'blue'}>{humanize(a.status)}</Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-ink-mute">Check which government schemes you may qualify for.</p>
                )}
              </div>
            </Card>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader title="Recent alerts" icon={<Bell className="h-4 w-4" />} action={<Link to="/notifications" className="text-sm font-semibold text-rk-700">All</Link>} />
            <ul className="divide-y divide-sand-200">
              {(notifs.data?.items || []).slice(0, 6).map((n) => (
                <li key={n._id} className="px-5 py-3">
                  <Link to={n.link || '/notifications'} className="block">
                    <p className={cn('text-sm', n.read ? 'text-ink-soft' : 'font-semibold')}>{n.title}</p>
                    <p className="text-xs text-ink-mute">{timeAgo(n.createdAt)}</p>
                  </Link>
                </li>
              ))}
              {!notifs.isLoading && !(notifs.data?.items || []).length && <li className="px-5 py-6 text-sm text-ink-mute">You're all caught up.</li>}
            </ul>
          </Card>
          <Card>
            <CardHeader title="Financial campaigns" icon={<Wallet className="h-4 w-4" />} action={<Link to="/financial-help" className="text-sm font-semibold text-rk-700">Open</Link>} />
            <div className="space-y-4 p-5">
              {(camps.data?.campaigns || []).length ? (
                (camps.data?.campaigns || []).map((c) => (
                  <div key={c._id}>
                    <div className="flex justify-between text-sm">
                      <p className="truncate font-semibold">{c.title}</p>
                    </div>
                    <Progress value={(c.raisedAmount / c.goalAmount) * 100} className="mt-2" />
                    <p className="mt-1 text-xs text-ink-mute">
                      {inr(c.raisedAmount)} of {inr(c.goalAmount)} · {humanize(c.status)}
                    </p>
                  </div>
                ))
              ) : (
                <p className="text-sm text-ink-mute">Need help with rent, legal fees or medical costs? Start a verified campaign.</p>
              )}
            </div>
          </Card>
          <Link to="/emergency-contacts" className="card flex items-center justify-between p-5 hover:shadow-lift">
            <div>
              <p className="font-semibold">Emergency contacts</p>
              <p className="text-sm text-ink-mute">{nContacts} saved</p>
            </div>
            <ArrowRight className="h-5 w-5 text-ink-mute" />
          </Link>
        </div>
      </div>
    </div>
  );
}
