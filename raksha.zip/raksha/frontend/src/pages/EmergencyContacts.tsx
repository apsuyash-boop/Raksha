import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Link2, Mail, MessageCircle, Pencil, Phone, Plus, Smartphone, Trash2, Users } from 'lucide-react';
import { apiError, del, get, patch, post } from '@/api/client';
import { Avatar, Badge, Button, Card, EmptyState, Input, Modal, PageHeader, QueryState, Switch } from '@/components/ui';
import type { Contact } from '@/types';

const EMPTY = { name: '', relation: '', phone: '', email: '', channels: { sms: true, whatsapp: false, email: true, app: true }, canViewLiveLocation: true };

export default function EmergencyContacts() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['contacts'], queryFn: () => get<{ contacts: Contact[] }>('/contacts') });
  const [editing, setEditing] = useState<Contact | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const save = useMutation({
    mutationFn: () => {
      const body = { ...form, phone: form.phone || undefined, email: form.email || undefined, relation: form.relation || undefined };
      return editing ? patch(`/contacts/${editing._id}`, body) : post('/contacts', body);
    },
    onSuccess: (r) => {
      toast.success(r._message || 'Saved');
      setOpen(false);
      qc.invalidateQueries({ queryKey: ['contacts'] });
    },
    onError: (e) => {
      const a = apiError(e);
      setErrors(a.fields || {});
      toast.error(a.message);
    },
  });
  const remove = useMutation({
    mutationFn: (id: string) => del(`/contacts/${id}`),
    onSuccess: () => {
      toast.success('Contact removed');
      qc.invalidateQueries({ queryKey: ['contacts'] });
    },
  });

  const openNew = () => {
    setEditing(null);
    setForm(EMPTY);
    setErrors({});
    setOpen(true);
  };
  const openEdit = (c: Contact) => {
    setEditing(c);
    setForm({ name: c.name, relation: c.relation || '', phone: c.phone || '', email: c.email || '', channels: c.channels, canViewLiveLocation: c.canViewLiveLocation });
    setErrors({});
    setOpen(true);
  };
  const contacts = q.data?.contacts || [];

  return (
    <div>
      <PageHeader
        eyebrow="Safety"
        title="Emergency contacts"
        subtitle="These people are alerted with your location when you press SOS. If they also use Raksha, they get app alerts and can follow your live location during an emergency."
        action={<Button onClick={openNew} icon={<Plus className="h-4 w-4" />} disabled={contacts.length >= 10}>Add contact</Button>}
      />
      <QueryState q={q} isEmpty={!contacts.length} empty={<Card><EmptyState icon={<Users className="h-6 w-6" />} title="No emergency contacts yet" body="Add at least two people you trust — family, friends or neighbours." action={<Button onClick={openNew}>Add your first contact</Button>} /></Card>}>
        <div className="grid gap-4 md:grid-cols-2">
          {contacts.map((c, i) => (
            <Card key={c._id} className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <Avatar name={c.name} color={['#B4233C', '#7C3AED', '#0E7490', '#B45309'][i % 4]} />
                  <div>
                    <p className="font-semibold">{c.name}</p>
                    <p className="text-sm text-ink-mute">{c.relation || 'Contact'} · Priority {c.priority}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(c)} className="rounded-lg p-2 text-ink-mute hover:bg-sand-100" aria-label={`Edit ${c.name}`}>
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button onClick={() => confirm(`Remove ${c.name}?`) && remove.mutate(c._id)} className="rounded-lg p-2 text-ink-mute hover:bg-rk-50 hover:text-rk-700" aria-label={`Remove ${c.name}`}>
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <div className="mt-4 space-y-1.5 text-sm text-ink-soft">
                {c.phone && <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-ink-mute" /> {c.phone}</p>}
                {c.email && <p className="flex items-center gap-2"><Mail className="h-4 w-4 text-ink-mute" /> {c.email}</p>}
              </div>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {c.channels.sms && <Badge icon={<Smartphone className="h-3 w-3" />}>SMS</Badge>}
                {c.channels.whatsapp && <Badge icon={<MessageCircle className="h-3 w-3" />}>WhatsApp</Badge>}
                {c.channels.email && <Badge icon={<Mail className="h-3 w-3" />}>Email</Badge>}
                {c.linkedUser ? <Badge tone="safe" icon={<Link2 className="h-3 w-3" />}>On Raksha · app alerts</Badge> : <Badge tone="neutral">Gets a tracking link</Badge>}
                {c.canViewLiveLocation && <Badge tone="blue">Live location in SOS</Badge>}
              </div>
            </Card>
          ))}
        </div>
      </QueryState>
      <p className="mt-6 text-sm text-ink-mute">
        Tip: SMS/WhatsApp delivery depends on the providers configured by the Raksha operator. Each SOS shows exactly which alerts were delivered, simulated or not configured.
      </p>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? 'Edit contact' : 'Add emergency contact'}
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button loading={save.isPending} onClick={() => save.mutate()}>Save contact</Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} error={errors.name} required />
            <Input label="Relation" value={form.relation} onChange={(e) => setForm({ ...form, relation: e.target.value })} placeholder="Mother, friend…" />
            <Input label="Phone" type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} error={errors.phone} placeholder="+91…" />
            <Input label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} error={errors.email} />
          </div>
          <div className="divide-y divide-sand-200 rounded-xl border border-sand-200 px-4">
            <Switch checked={form.channels.sms} onChange={(v) => setForm({ ...form, channels: { ...form.channels, sms: v } })} label="SMS" />
            <Switch checked={form.channels.whatsapp} onChange={(v) => setForm({ ...form, channels: { ...form.channels, whatsapp: v } })} label="WhatsApp" />
            <Switch checked={form.channels.email} onChange={(v) => setForm({ ...form, channels: { ...form.channels, email: v } })} label="Email" />
            <Switch checked={form.canViewLiveLocation} onChange={(v) => setForm({ ...form, canViewLiveLocation: v })} label="Can see my live location during SOS" description="Only while an SOS or location share is active." />
          </div>
        </div>
      </Modal>
    </div>
  );
}
