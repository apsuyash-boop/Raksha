import { useEffect, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Download, FileAudio, FileImage, FileText, FileVideo, Fingerprint, History, Lock, MapPin, Package, ShieldCheck, Trash2, Upload, X } from 'lucide-react';
import { api, apiError, blobUrl, del, downloadFile, get, post } from '@/api/client';
import { getCurrentPosition } from '@/hooks/useGeolocation';
import { Badge, Button, Card, EmptyState, Input, Modal, PageHeader, QueryState, Select, Tabs, Textarea } from '@/components/ui';
import { bytes, cn, fmtDate, humanize } from '@/utils/format';
import type { Evidence } from '@/types';

const ICON = { image: FileImage, video: FileVideo, audio: FileAudio, document: FileText };
const CATEGORIES: Array<[string, string]> = [
  ['photo', 'Photo'],
  ['video', 'Video'],
  ['audio', 'Audio'],
  ['document', 'Document'],
  ['medical_report', 'Medical report'],
  ['screenshot', 'Screenshot'],
  ['complaint_document', 'Complaint document'],
  ['other', 'Other'],
];

export default function EvidencePage() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState('all');
  const q = useQuery({ queryKey: ['evidence', filter], queryFn: () => get<{ items: Evidence[]; total: number }>('/evidence', filter === 'all' ? {} : { category: filter }) });
  const cases = useQuery({ queryKey: ['cases'], queryFn: () => get<{ cases: any[] }>('/cases') });
  const [uploadOpen, setUploadOpen] = useState(false);
  const [detail, setDetail] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const items = q.data?.items || [];

  return (
    <div>
      <PageHeader
        eyebrow="Secure"
        title="Evidence Vault"
        subtitle="Photos, recordings, documents and medical reports — encrypted, timestamped and fingerprinted with SHA-256 so you can prove nothing was changed."
        action={
          <>
            {selected.length > 0 && (
              <Button variant="outline" icon={<Package className="h-4 w-4" />} onClick={() => downloadFile('/evidence/package', 'raksha-evidence.zip', undefined, 'post', { ids: selected }).catch((e) => toast.error(apiError(e).message))}>
                Download package ({selected.length})
              </Button>
            )}
            <Button icon={<Upload className="h-4 w-4" />} onClick={() => setUploadOpen(true)}>
              Add evidence
            </Button>
          </>
        }
      />
      <div className="mb-5 flex flex-wrap items-center gap-3 rounded-2xl border border-safe-100 bg-safe-50 px-4 py-3 text-sm text-safe-700">
        <Lock className="h-4 w-4" /> Files are encrypted at rest (AES-256-GCM) and never available through public links. Only you — and people you explicitly authorise — can open them.
      </div>
      <Tabs value={filter} onChange={setFilter} tabs={[['all', 'All'], ['sos_recording', 'SOS recordings'], ['photo', 'Photos'], ['medical_report', 'Medical'], ['document', 'Documents'], ['audio', 'Audio'], ['video', 'Video']]} className="mb-5" />
      <QueryState q={q} isEmpty={!items.length} empty={<Card><EmptyState icon={<Lock className="h-6 w-6" />} title="Your vault is empty" body="Add photos of injuries, threatening messages, medical reports or recordings. SOS recordings are saved here automatically." action={<Button onClick={() => setUploadOpen(true)}>Add evidence</Button>} /></Card>}>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((e) => {
            const I = ICON[e.kind] || FileText;
            const checked = selected.includes(e._id);
            return (
              <Card key={e._id} className={cn('group relative p-4 transition hover:shadow-lift', checked && 'ring-2 ring-rk-500')}>
                <label className="absolute right-3 top-3">
                  <input type="checkbox" className="h-4 w-4 accent-rk-600" checked={checked} onChange={() => setSelected(checked ? selected.filter((x) => x !== e._id) : [...selected, e._id])} aria-label={`Select ${e.title}`} />
                </label>
                <button onClick={() => setDetail(e._id)} className="block w-full text-left">
                  <div className="flex items-start gap-3 pr-6">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-rk-50 text-rk-600">
                      <I className="h-5 w-5" />
                    </span>
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{e.title}</p>
                      <p className="text-xs text-ink-mute">
                        {e.evidenceId} · {bytes(e.size)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <Badge>{humanize(e.category)}</Badge>
                    {e.gps && <Badge tone="blue" icon={<MapPin className="h-3 w-3" />}>GPS</Badge>}
                    <Badge tone={e.verificationStatus === 'disputed' ? 'rk' : 'safe'} icon={<Fingerprint className="h-3 w-3" />}>{e.verificationStatus === 'disputed' ? 'Hash mismatch' : 'Hashed'}</Badge>
                  </div>
                  <p className="mt-3 text-xs text-ink-mute">Captured {fmtDate(e.capturedAt || e.uploadedAt, true)}</p>
                </button>
              </Card>
            );
          })}
        </div>
      </QueryState>

      <UploadModal open={uploadOpen} onClose={() => setUploadOpen(false)} cases={cases.data?.cases || []} onDone={() => qc.invalidateQueries({ queryKey: ['evidence'] })} />
      {detail && <DetailModal id={detail} onClose={() => setDetail(null)} cases={cases.data?.cases || []} />}
    </div>
  );
}

function UploadModal({ open, onClose, cases, onDone }: { open: boolean; onClose: () => void; cases: any[]; onDone: () => void }) {
  const [files, setFiles] = useState<File[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [caseId, setCaseId] = useState('');
  const [capturedAt, setCapturedAt] = useState('');
  const [withGps, setWithGps] = useState(false);
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  const submit = async () => {
    if (!files.length) return;
    setBusy(true);
    try {
      const fd = new FormData();
      files.forEach((f) => fd.append('files', f));
      if (title) fd.append('title', title);
      if (description) fd.append('description', description);
      if (category) fd.append('category', category);
      if (caseId) fd.append('caseId', caseId);
      if (capturedAt) fd.append('capturedAt', new Date(capturedAt).toISOString());
      if (withGps) {
        const p = await getCurrentPosition();
        if (p) {
          fd.append('lat', String(p.lat));
          fd.append('lng', String(p.lng));
          if (p.accuracy) fd.append('accuracy', String(p.accuracy));
        }
      }
      const r = await api.post('/evidence', fd, { onUploadProgress: (e) => setProgress(Math.round(((e.loaded || 0) / (e.total || 1)) * 100)) });
      toast.success(r.data.message);
      onDone();
      setFiles([]);
      setTitle('');
      setDescription('');
      onClose();
    } catch (e) {
      toast.error(apiError(e).message);
    } finally {
      setBusy(false);
      setProgress(0);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Add evidence" footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button onClick={submit} loading={busy} disabled={!files.length}>{busy ? `Encrypting & uploading ${progress}%` : 'Save to vault'}</Button></>}>
      <div className="space-y-4">
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            setFiles([...files, ...Array.from(e.dataTransfer.files)].slice(0, 10));
          }}
          className="grid place-items-center rounded-2xl border-2 border-dashed border-sand-300 bg-sand-50 px-4 py-8 text-center"
        >
          <Upload className="h-7 w-7 text-rk-500" />
          <p className="mt-2 font-semibold">Drop files here or</p>
          <Button variant="secondary" size="sm" className="mt-2" onClick={() => input.current?.click()}>
            Choose files
          </Button>
          <input ref={input} type="file" multiple hidden accept="image/*,video/*,audio/*,application/pdf,.docx" capture={undefined} onChange={(e) => setFiles([...files, ...Array.from(e.target.files || [])].slice(0, 10))} />
          <p className="mt-2 text-xs text-ink-mute">Images, video, audio, PDF or DOCX · up to 10 files · 50 MB each</p>
        </div>
        {files.length > 0 && (
          <ul className="space-y-1.5">
            {files.map((f, i) => (
              <li key={i} className="flex items-center justify-between rounded-lg bg-sand-100 px-3 py-2 text-sm">
                <span className="truncate">{f.name}</span>
                <span className="flex items-center gap-2 text-ink-mute">
                  {bytes(f.size)}
                  <button onClick={() => setFiles(files.filter((_, j) => j !== i))} aria-label={`Remove ${f.name}`}>
                    <X className="h-4 w-4" />
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
        <Input label="Title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Bruise on arm, 12 March" />
        <Textarea label="Notes (private)" value={description} onChange={(e) => setDescription(e.target.value)} className="min-h-[80px]" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Select label="Type" value={category} onChange={(e) => setCategory(e.target.value)} options={CATEGORIES} placeholder="Detect automatically" />
          <Select label="Attach to case" value={caseId} onChange={(e) => setCaseId(e.target.value)} options={cases.map((c) => [c._id, `${c.caseNumber} — ${c.title}`])} placeholder="None" />
          <Input label="When was it captured?" type="datetime-local" value={capturedAt} onChange={(e) => setCapturedAt(e.target.value)} />
          <label className="mt-7 flex items-center gap-2 text-sm">
            <input type="checkbox" className="accent-rk-600" checked={withGps} onChange={(e) => setWithGps(e.target.checked)} /> Add my current GPS location
          </label>
        </div>
      </div>
    </Modal>
  );
}

function DetailModal({ id, onClose, cases }: { id: string; onClose: () => void; cases: any[] }) {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['evidence-item', id], queryFn: () => get<{ item: Evidence }>(`/evidence/${id}`) });
  const [preview, setPreview] = useState<string | null>(null);
  const [tab, setTab] = useState<'details' | 'access'>('details');
  const e = q.data?.item;

  useEffect(() => {
    let url: string | null = null;
    if (e && ['image', 'audio', 'video'].includes(e.kind) && e.size < 30 * 1024 * 1024) {
      blobUrl(`/evidence/${id}/download`, { inline: 1 })
        .then((u) => {
          url = u;
          setPreview(u);
        })
        .catch(() => undefined);
    }
    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [e?._id]); // eslint-disable-line react-hooks/exhaustive-deps

  const verify = useMutation({ mutationFn: () => post<{ match: boolean }>(`/evidence/${id}/verify`), onSuccess: (r) => (r.match ? toast.success(r._message) : toast.error(r._message)) });
  const remove = useMutation({
    mutationFn: () => del(`/evidence/${id}`),
    onSuccess: () => {
      toast.success('Deleted');
      qc.invalidateQueries({ queryKey: ['evidence'] });
      onClose();
    },
  });
  const attach = useMutation({
    mutationFn: (caseIds: string[]) => api.patch(`/evidence/${id}`, { caseIds }),
    onSuccess: () => {
      toast.success('Case links updated');
      qc.invalidateQueries({ queryKey: ['evidence-item', id] });
    },
  });

  return (
    <Modal open onClose={onClose} title={e?.title || 'Evidence'} size="lg">
      <QueryState q={q}>
        {e && (
          <div className="space-y-5">
            {preview && (
              <div className="overflow-hidden rounded-2xl bg-ink/5">
                {e.kind === 'image' && <img src={preview} alt={e.title} className="max-h-80 w-full object-contain" />}
                {e.kind === 'audio' && <audio src={preview} controls className="w-full p-3" />}
                {e.kind === 'video' && <video src={preview} controls className="max-h-80 w-full" />}
              </div>
            )}
            <Tabs value={tab} onChange={setTab} tabs={[['details', 'Details'], ['access', `Access history (${e.accessLog?.length || 0})`]]} />
            {tab === 'details' ? (
              <>
                <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
                  {[
                    ['Evidence ID', e.evidenceId],
                    ['Type', `${humanize(e.category)} · ${e.mimeType}`],
                    ['Captured', fmtDate(e.capturedAt, true)],
                    ['Uploaded', fmtDate(e.uploadedAt, true)],
                    ['Size', bytes(e.size)],
                    ['GPS', e.gps ? `${e.gps.lat.toFixed(5)}, ${e.gps.lng.toFixed(5)}${e.gps.accuracy ? ` (±${Math.round(e.gps.accuracy)} m)` : ''}` : '—'],
                    ['Malware scan', humanize(e.scanStatus)],
                    ['Verification', humanize(e.verificationStatus)],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <dt className="text-ink-mute">{k}</dt>
                      <dd className="font-medium">{v}</dd>
                    </div>
                  ))}
                  <div className="sm:col-span-2">
                    <dt className="text-ink-mute">SHA-256 fingerprint</dt>
                    <dd className="break-all font-mono text-xs">{e.sha256}</dd>
                  </div>
                </dl>
                {e.description && <p className="rounded-xl bg-sand-100 p-3 text-sm">{e.description}</p>}
                <div>
                  <p className="label">Linked cases (assigned lawyers/NGOs can view it if you allow evidence sharing on that case)</p>
                  <div className="flex flex-wrap gap-2">
                    {cases.map((c) => {
                      const on = (e.cases || []).includes(c._id);
                      return (
                        <button key={c._id} className={cn('chip', on && 'chip-active')} aria-pressed={on} onClick={() => attach.mutate(on ? (e.cases || []).filter((x) => x !== c._id) : [...(e.cases || []), c._id])}>
                          {c.caseNumber}
                        </button>
                      );
                    })}
                    {!cases.length && <span className="text-sm text-ink-mute">No cases yet.</span>}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 border-t border-sand-200 pt-4">
                  <Button variant="outline" icon={<Download className="h-4 w-4" />} onClick={() => downloadFile(`/evidence/${id}/download`, e.evidenceId)}>
                    Download
                  </Button>
                  <Button variant="outline" icon={<ShieldCheck className="h-4 w-4" />} loading={verify.isPending} onClick={() => verify.mutate()}>
                    Verify integrity
                  </Button>
                  <Button variant="ghost" className="ml-auto text-rk-700" icon={<Trash2 className="h-4 w-4" />} onClick={() => confirm('Delete permanently? This cannot be undone.') && remove.mutate()}>
                    Delete
                  </Button>
                </div>
              </>
            ) : (
              <ul className="space-y-2">
                {(e.accessLog || [])
                  .slice()
                  .reverse()
                  .map((l, i) => (
                    <li key={i} className="flex items-start gap-3 rounded-xl bg-sand-50 px-3 py-2 text-sm">
                      <History className="mt-0.5 h-4 w-4 text-ink-mute" />
                      <div>
                        <p>
                          <span className="font-semibold">{l.user?.name || 'You'}</span> <span className="text-ink-mute">({l.role})</span> — {humanize(l.action)}
                        </p>
                        {l.reason && <p className="text-xs text-ink-mute">{l.reason}</p>}
                        <p className="text-xs text-ink-mute">{fmtDate(l.at, true)}</p>
                      </div>
                    </li>
                  ))}
              </ul>
            )}
          </div>
        )}
      </QueryState>
    </Modal>
  );
}
