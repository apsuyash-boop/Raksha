import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ArrowLeft, BadgeCheck, HandCoins, HeartHandshake, Landmark, MapPin, PiggyBank, Plus, Printer, ReceiptText, ShieldCheck, Users } from 'lucide-react';
import { apiError, get, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { Badge, Button, Card, CardHeader, EmptyState, Input, Modal, PageHeader, Progress, QueryState, Select, Stat, Tabs, Textarea } from '@/components/ui';
import { cn, fmtDate, humanize, inr, timeAgo } from '@/utils/format';

type View = 'campaigns' | 'campaign' | 'donate' | 'transparency' | 'help';

export default function Finance({ view }: { view: View }) {
  if (view === 'campaign') return <CampaignDetail />;
  if (view === 'transparency') return <Transparency />;
  if (view === 'help') return <FinancialHelp />;
  if (view === 'donate') return <Donate />;
  return <Campaigns />;
}

/* ------------------------------ checkout ------------------------------ */
function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement('script');
    s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

function DonateModal({ campaign, onClose }: { campaign?: any; onClose: () => void }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [amount, setAmount] = useState(500);
  const [anonymous, setAnonymous] = useState(false);
  const [message, setMessage] = useState('');
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [mockOrder, setMockOrder] = useState<any>(null);
  const [receipt, setReceipt] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const verify = async (payload: { orderId: string; paymentId: string; signature: string }) => {
    const r = await post<{ receipt: any }>('/donations/verify', payload);
    setReceipt(r.receipt);
    qc.invalidateQueries({ queryKey: ['campaigns'] });
    qc.invalidateQueries({ queryKey: ['campaign'] });
    qc.invalidateQueries({ queryKey: ['my-donations'] });
  };

  const start = async () => {
    setBusy(true);
    try {
      const o = await post<any>('/donations/order', { campaignId: campaign?._id, generalFund: !campaign || undefined, amount, anonymous, message: message || undefined, donorName: name || undefined, donorEmail: email || undefined });
      if (o.gateway === 'mock') {
        setMockOrder(o);
      } else {
        if (!(await loadRazorpay())) throw new Error('Could not load the payment window. Check your connection.');
        const rz = new window.Razorpay({
          key: o.keyId,
          order_id: o.orderId,
          amount: o.amount,
          currency: o.currency,
          name: 'Raksha',
          description: campaign ? campaign.title : 'Raksha general fund',
          prefill: o.prefill,
          theme: { color: '#B4233C' },
          handler: (resp: any) => verify({ orderId: resp.razorpay_order_id, paymentId: resp.razorpay_payment_id, signature: resp.razorpay_signature }).catch((e) => toast.error(apiError(e).message)),
        });
        rz.open();
      }
    } catch (e) {
      toast.error(apiError(e).message);
    } finally {
      setBusy(false);
    }
  };

  const payMock = async () => {
    setBusy(true);
    try {
      const auth = await post<any>('/payments/mock/pay', { orderId: mockOrder.orderId });
      await verify({ orderId: auth.orderId, paymentId: auth.paymentId, signature: auth.signature });
      setMockOrder(null);
    } catch (e) {
      toast.error(apiError(e).message);
    } finally {
      setBusy(false);
    }
  };

  if (receipt) return <ReceiptModal receipt={receipt} onClose={onClose} />;

  return (
    <Modal open onClose={onClose} title={campaign ? `Support: ${campaign.title}` : 'Donate to the Raksha fund'} footer={mockOrder ? <><Button variant="ghost" onClick={() => setMockOrder(null)}>Back</Button><Button loading={busy} onClick={payMock}>Simulate successful payment</Button></> : <><Button variant="ghost" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={start} disabled={amount < 10}>Donate {inr(amount)}</Button></>}>
      {mockOrder ? (
        <div className="space-y-3">
          <p className="rounded-xl bg-warn-50 p-4 text-sm text-warn-700"><strong>Demo payment gateway.</strong> No real money will move. This simulates the payment provider authorising the payment; the server still verifies the signature before recording anything.</p>
          <p className="text-sm text-ink-mute">Order {mockOrder.orderId} · {inr(mockOrder.amount / 100)}</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-4 gap-2">
            {[250, 500, 1000, 2500].map((a) => <button key={a} className={cn('chip justify-center', amount === a && 'chip-active')} onClick={() => setAmount(a)}>{inr(a)}</button>)}
          </div>
          <Input label="Amount (₹)" type="number" min={10} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
          {!user && (
            <div className="grid gap-3 sm:grid-cols-2">
              <Input label="Your name" value={name} onChange={(e) => setName(e.target.value)} />
              <Input label="Email for receipt" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
          )}
          <Textarea label="Message of support (optional)" value={message} onChange={(e) => setMessage(e.target.value)} className="min-h-[70px]" maxLength={300} />
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-rk-600" checked={anonymous} onChange={(e) => setAnonymous(e.target.checked)} /> Donate anonymously</label>
          <p className="flex items-start gap-2 text-xs text-ink-mute"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" /> Payments are processed by a secure gateway and confirmed only after server-side signature verification. Where possible, funds are paid directly to lawyers, landlords or hospitals.</p>
        </div>
      )}
    </Modal>
  );
}

function ReceiptModal({ receipt, onClose }: { receipt: any; onClose: () => void }) {
  return (
    <Modal open onClose={onClose} title="Thank you!" size="sm" footer={<Button variant="outline" icon={<Printer className="h-4 w-4" />} onClick={() => window.print()}>Print receipt</Button>}>
      <div className="space-y-2 text-sm">
        {receipt.isDemo && <Badge tone="warn">Demo receipt — no real payment</Badge>}
        <p className="font-display text-3xl font-semibold text-rk-700">{inr(receipt.amount)}</p>
        {[
          ['Receipt', receipt.receiptNumber],
          ['Payment ID', receipt.paymentId],
          ['Order ID', receipt.orderId],
          ['Date', fmtDate(receipt.date, true)],
          ['Donor', receipt.donorName || 'Anonymous'],
          ['Platform fee', inr(receipt.platformFee)],
        ].map(([k, v]) => <p key={k} className="flex justify-between gap-3"><span className="text-ink-mute">{k}</span><span className="font-mono text-xs">{v}</span></p>)}
        <p className="pt-2 text-ink-soft">{receipt.note}</p>
      </div>
    </Modal>
  );
}

/* ------------------------------ campaigns ------------------------------ */
function CampaignCard({ c }: { c: any }) {
  return (
    <Link to={`/campaigns/${c.slug}`} className="card flex flex-col p-5 transition hover:-translate-y-0.5 hover:shadow-lift">
      <div className="flex flex-wrap gap-1.5">
        <Badge tone="rk">{humanize(c.category)}</Badge>
        {c.kycVerified && <Badge tone="safe" icon={<BadgeCheck className="h-3 w-3" />}>KYC verified</Badge>}
        {c.isDemo && <Badge tone="warn">Demo</Badge>}
      </div>
      <p className="mt-3 text-lg font-semibold leading-snug">{c.title}</p>
      <p className="mt-1 flex items-center gap-1 text-sm text-ink-mute"><MapPin className="h-3.5 w-3.5" /> {c.displayName}{c.city ? ` · ${c.city}` : ''}</p>
      <p className="mt-2 line-clamp-2 text-sm text-ink-soft">{c.story}</p>
      <div className="mt-auto pt-4">
        <Progress value={(c.raisedAmount / c.goalAmount) * 100} />
        <p className="mt-2 flex justify-between text-sm"><span className="font-semibold">{inr(c.raisedAmount)}</span><span className="text-ink-mute">of {inr(c.goalAmount)}</span></p>
      </div>
    </Link>
  );
}

function Campaigns() {
  const [status, setStatus] = useState<'active' | 'completed'>('active');
  const q = useQuery({ queryKey: ['campaigns', status], queryFn: () => get<{ items: any[] }>('/campaigns', { status }) });
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-0">
      <PageHeader eyebrow="Crowdfunding" title="Help a woman rebuild her life" subtitle="Every campaign is KYC-verified. Funds are paid directly to lawyers, landlords or hospitals wherever possible, and every rupee disbursed is published." action={<Link to="/transparency"><Button variant="outline">See fund utilisation</Button></Link>} />
      <Tabs value={status} onChange={setStatus} tabs={[['active', 'Active'], ['completed', 'Completed']]} className="mb-5 w-fit" />
      <QueryState q={q} isEmpty={!q.data?.items.length} empty={<Card><EmptyState icon={<HeartHandshake className="h-6 w-6" />} title="No campaigns here yet" /></Card>}>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{(q.data?.items || []).map((c) => <CampaignCard key={c._id} c={c} />)}</div>
      </QueryState>
    </div>
  );
}

function CampaignDetail() {
  const { slug } = useParams();
  const [donate, setDonate] = useState(false);
  const q = useQuery({ queryKey: ['campaign', slug], queryFn: () => get<{ campaign: any; recentDonations: any[] }>(`/campaigns/${slug}`) });
  const c = q.data?.campaign;
  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-0">
      <Link to="/campaigns" className="mb-5 inline-flex items-center gap-1 text-sm font-semibold text-rk-700"><ArrowLeft className="h-4 w-4" /> Campaigns</Link>
      <QueryState q={q}>
        {c && (
          <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
            <div>
              <div className="flex flex-wrap gap-1.5">
                <Badge tone="rk">{humanize(c.category)}</Badge>
                {c.kycVerified && <Badge tone="safe" icon={<BadgeCheck className="h-3 w-3" />}>KYC verified</Badge>}
                {c.isDemo && <Badge tone="warn">Demo data</Badge>}
              </div>
              <h1 className="mt-3 text-3xl font-semibold">{c.title}</h1>
              <p className="mt-2 text-ink-mute">{c.displayName}{c.city ? ` · ${c.city}, ${c.state}` : ''} · started {timeAgo(c.createdAt)}</p>
              <div className="mt-6 whitespace-pre-line text-[16px] leading-relaxed text-ink-soft">{c.story}</div>
              {c.payeeType && <p className="mt-6 rounded-xl bg-safe-50 p-4 text-sm text-safe-700">Funds are paid directly to the {c.payeeType} after verification.</p>}
              {(c.utilization || []).length > 0 && (
                <Card className="mt-6">
                  <CardHeader title="How funds were used" icon={<ReceiptText className="h-4 w-4" />} />
                  <ul className="divide-y divide-sand-200">{c.utilization.map((u: any, i: number) => <li key={i} className="flex justify-between gap-3 px-5 py-3 text-sm"><span>{u.purpose} <span className="text-ink-mute">→ {u.paidTo}</span></span><span className="font-semibold">{inr(u.amount)}</span></li>)}</ul>
                </Card>
              )}
            </div>
            <div className="space-y-4">
              <Card className="sticky top-20 p-5">
                <p className="font-display text-3xl font-semibold">{inr(c.raisedAmount)}</p>
                <p className="text-sm text-ink-mute">raised of {inr(c.goalAmount)} goal</p>
                <Progress value={(c.raisedAmount / c.goalAmount) * 100} className="mt-3" />
                <p className="mt-2 flex items-center gap-1 text-sm text-ink-mute"><Users className="h-4 w-4" /> {c.donorsCount} donors · {inr(c.disbursedAmount)} disbursed</p>
                {c.status === 'active' ? <Button className="mt-4 w-full" size="lg" icon={<HandCoins className="h-5 w-5" />} onClick={() => setDonate(true)}>Donate</Button> : <Badge tone="safe" className="mt-4">Goal reached — thank you</Badge>}
              </Card>
              <Card>
                <CardHeader title="Recent support" />
                <ul className="space-y-3 p-5 text-sm">
                  {(q.data?.recentDonations || []).map((d, i) => <li key={i}><p className="flex justify-between"><span className="font-semibold">{d.name}</span><span>{inr(d.amount)}</span></p>{d.message && <p className="text-ink-mute">"{d.message}"</p>}</li>)}
                  {!q.data?.recentDonations.length && <p className="text-ink-mute">Be the first to support.</p>}
                </ul>
              </Card>
            </div>
          </div>
        )}
      </QueryState>
      {donate && c && <DonateModal campaign={c} onClose={() => setDonate(false)} />}
    </div>
  );
}

function Donate() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const camps = useQuery({ queryKey: ['campaigns', 'active'], queryFn: () => get<{ items: any[] }>('/campaigns', { status: 'active' }) });
  const mine = useQuery({ queryKey: ['my-donations'], queryFn: () => get<{ items: any[] }>('/donations/mine'), enabled: !!user });
  const [receipt, setReceipt] = useState<any>(null);
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-0">
      <PageHeader eyebrow="Donate" title="Stand with women who are rebuilding" subtitle="Give to a specific verified woman's campaign, or to the Raksha fund that pays for emergency shelter, legal fees and counselling." action={<Button icon={<HandCoins className="h-4 w-4" />} onClick={() => setOpen(true)}>Give to the Raksha fund</Button>} />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{(camps.data?.items || []).map((c) => <CampaignCard key={c._id} c={c} />)}</div>
      {user && (
        <Card className="mt-8">
          <CardHeader title="Your donations" icon={<ReceiptText className="h-4 w-4" />} />
          <ul className="divide-y divide-sand-200">
            {(mine.data?.items || []).map((d) => (
              <li key={d._id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-sm">
                <span>{d.campaign?.title || 'Raksha fund'} · {fmtDate(d.createdAt)}</span>
                <span className="flex items-center gap-2">
                  <span className="font-semibold">{inr(d.amount)}</span>
                  <Badge tone={d.status === 'paid' ? 'safe' : d.status === 'failed' ? 'rk' : 'neutral'}>{d.status}</Badge>
                  {d.status === 'paid' && <button className="text-xs font-semibold text-rk-700 underline" onClick={async () => setReceipt((await get<{ receipt: any }>(`/donations/${d._id}/receipt`)).receipt)}>Receipt</button>}
                </span>
              </li>
            ))}
            {!mine.data?.items.length && <li className="px-5 py-6 text-sm text-ink-mute">No donations yet.</li>}
          </ul>
        </Card>
      )}
      {open && <DonateModal onClose={() => setOpen(false)} />}
      {receipt && <ReceiptModal receipt={receipt} onClose={() => setReceipt(null)} />}
    </div>
  );
}

function Transparency() {
  const q = useQuery({ queryKey: ['transparency'], queryFn: () => get<any>('/transparency') });
  const d = q.data;
  const monthly = (() => {
    const map: Record<string, any> = {};
    for (const r of d?.live.monthly || []) {
      map[r._id.m] = map[r._id.m] || { month: r._id.m, donations: 0, disbursed: 0 };
      if (r._id.t === 'donation') map[r._id.m].donations = r.total;
      else map[r._id.m].disbursed = r.total;
    }
    return Object.values(map);
  })();
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-0">
      <PageHeader eyebrow="Financial transparency" title="Every rupee, accounted for" subtitle="Figures are computed live from verified payment transactions and recorded disbursements. Demo and test data are excluded." />
      <QueryState q={q}>
        {d && (
          <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Stat label="Total donations" value={inr(d.live.totalDonations)} hint={`${d.live.donationsCount} verified payments`} icon={<HandCoins className="h-4 w-4" />} />
              <Stat label="Amount distributed" value={inr(d.live.amountDistributed)} icon={<PiggyBank className="h-4 w-4" />} tone="safe" />
              <Stat label="Fund utilisation" value={d.live.totalDonations ? `${Math.round((d.live.amountDistributed / d.live.totalDonations) * 100)}%` : '—'} hint="distributed ÷ donated" icon={<Landmark className="h-4 w-4" />} tone="ink" />
              <Stat label="Active campaigns" value={d.live.activeCampaigns} icon={<HeartHandshake className="h-4 w-4" />} />
              <Stat label="Completed campaigns" value={d.live.completedCampaigns} icon={<BadgeCheck className="h-4 w-4" />} tone="safe" />
              <Stat label="Platform fees" value={inr(d.live.platformFees)} hint={`${d.platformFeePercent}% optional fee`} icon={<ReceiptText className="h-4 w-4" />} tone="ink" />
            </div>
            <Card>
              <CardHeader title="Donations vs. disbursements by month" />
              <div className="h-72 p-4">
                {monthly.length ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthly}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#EEE6E0" vertical={false} />
                      <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                      <Tooltip formatter={(v: any) => inr(Number(v))} />
                      <Bar dataKey="donations" name="Donations" fill="#B4233C" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="disbursed" name="Disbursed" fill="#2F7D5B" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="grid h-full place-items-center text-sm text-ink-mute">No live transactions yet.</div>
                )}
              </div>
            </Card>
            <Card>
              <CardHeader title="By category" />
              <table className="w-full text-sm">
                <thead className="text-left text-ink-mute"><tr><th className="px-5 py-2 font-medium">Category</th><th className="px-5 py-2 font-medium">Campaigns</th><th className="px-5 py-2 font-medium">Raised</th><th className="px-5 py-2 font-medium">Disbursed</th></tr></thead>
                <tbody className="divide-y divide-sand-200">
                  {(d.live.byCategory || []).map((r: any) => <tr key={r._id}><td className="px-5 py-2.5">{humanize(r._id)}</td><td className="px-5 py-2.5">{r.count}</td><td className="px-5 py-2.5">{inr(r.raised)}</td><td className="px-5 py-2.5">{inr(r.disbursed)}</td></tr>)}
                  {!d.live.byCategory?.length && <tr><td colSpan={4} className="px-5 py-6 text-ink-mute">No live campaigns yet.</td></tr>}
                </tbody>
              </table>
            </Card>
            {d.demo.donationsCount > 0 && <p className="text-sm text-ink-mute">Demo data present but excluded above: {d.demo.donationsCount} simulated donations totalling {inr(d.demo.totalDonations)}.</p>}
            <p className="text-sm text-ink-mute">{d.note}</p>
          </div>
        )}
      </QueryState>
    </div>
  );
}

/* --------------------------- woman's financial help --------------------------- */
function FinancialHelp() {
  const qc = useQueryClient();
  const [tab, setTab] = useState<'campaigns' | 'loans'>('campaigns');
  const [newCamp, setNewCamp] = useState(false);
  const [newLoan, setNewLoan] = useState(false);
  const camps = useQuery({ queryKey: ['my-campaigns'], queryFn: () => get<{ campaigns: any[] }>('/campaigns/mine') });
  const loans = useQuery({ queryKey: ['my-loans'], queryFn: () => get<{ loans: any[] }>('/loans/mine') });
  const accept = useMutation({
    mutationFn: ({ id, offerId }: { id: string; offerId: string }) => post(`/loans/${id}/offers/${offerId}/accept`),
    onSuccess: (r) => { toast.success(r._message); qc.invalidateQueries({ queryKey: ['my-loans'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <div>
      <PageHeader eyebrow="Financial help" title="Money should not keep you trapped" subtitle="Raise funds for legal fees, rent, shelter or medical costs from verified donors — or request an interest-free or low-interest micro-loan from registered lending partners." />
      <Tabs value={tab} onChange={setTab} tabs={[['campaigns', 'Crowdfunding'], ['loans', 'Micro-loans']]} className="mb-6 w-fit" />
      {tab === 'campaigns' ? (
        <div className="space-y-4">
          <div className="flex justify-end"><Button icon={<Plus className="h-4 w-4" />} onClick={() => setNewCamp(true)}>Start a campaign</Button></div>
          <QueryState q={camps} isEmpty={!camps.data?.campaigns.length} empty={<Card><EmptyState icon={<HeartHandshake className="h-6 w-6" />} title="No campaigns yet" body="Your campaign goes live after a quick KYC verification. You can use a pseudonym publicly." /></Card>}>
            {(camps.data?.campaigns || []).map((c) => (
              <Card key={c._id} className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div><p className="font-semibold">{c.title}</p><p className="text-sm text-ink-mute">{humanize(c.category)} · public name "{c.displayName}"</p></div>
                  <Badge tone={c.status === 'active' ? 'safe' : c.status === 'pending_verification' ? 'warn' : 'neutral'}>{humanize(c.status)}</Badge>
                </div>
                <Progress value={(c.raisedAmount / c.goalAmount) * 100} className="mt-4" />
                <p className="mt-2 text-sm text-ink-mute">{inr(c.raisedAmount)} raised of {inr(c.goalAmount)} · {inr(c.disbursedAmount)} disbursed</p>
                {c.status === 'active' && <Link to={`/campaigns/${c.slug}`} className="mt-2 inline-block text-sm font-semibold text-rk-700 underline">View public page</Link>}
              </Card>
            ))}
          </QueryState>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="max-w-xl text-sm text-ink-mute">Raksha does not lend money. Requests are shown — without your name — only to lending partners registered with the appropriate regulator. Your contact details are shared only with the partner whose offer you accept.</p>
            <Button icon={<Plus className="h-4 w-4" />} onClick={() => setNewLoan(true)}>Request a micro-loan</Button>
          </div>
          <QueryState q={loans} isEmpty={!loans.data?.loans.length} empty={<Card className="p-8 text-center text-ink-mute">No loan requests yet.</Card>}>
            {(loans.data?.loans || []).map((l) => (
              <Card key={l._id}>
                <CardHeader title={`${inr(l.amount)} · ${humanize(l.purpose)}`} subtitle={`${l.tenureMonths} months · requested ${fmtDate(l.createdAt)}`} action={<Badge tone={l.status === 'offer_accepted' ? 'safe' : 'blue'}>{humanize(l.status)}</Badge>} />
                <div className="space-y-3 p-5">
                  {(l.offers || []).map((o: any) => (
                    <div key={o._id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-sand-200 p-4">
                      <div>
                        <p className="font-semibold">{o.lenderName} <span className="text-xs font-normal text-ink-mute">· Reg. {o.regulatoryId}</span></p>
                        <p className="text-sm">{o.annualInterestRate === 0 ? <span className="font-semibold text-safe-600">Interest-free</span> : `${o.annualInterestRate}% p.a.`} · {o.tenureMonths} months · processing fee {inr(o.processingFee)}</p>
                        <p className="mt-1 text-sm text-ink-mute">{o.terms}</p>
                      </div>
                      {o.status === 'offered' && l.status !== 'offer_accepted' ? <Button size="sm" onClick={() => accept.mutate({ id: l._id, offerId: o._id })}>Accept offer</Button> : <Badge tone={o.status === 'accepted' ? 'safe' : 'neutral'}>{o.status}</Badge>}
                    </div>
                  ))}
                  {!l.offers?.length && <p className="text-sm text-ink-mute">Waiting for offers from registered partners.</p>}
                </div>
              </Card>
            ))}
          </QueryState>
        </div>
      )}
      {newCamp && <NewCampaign onClose={() => setNewCamp(false)} />}
      {newLoan && <NewLoan onClose={() => setNewLoan(false)} />}
    </div>
  );
}

function NewCampaign({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [f, setF] = useState<any>({ title: '', story: '', category: 'rent', goalAmount: 20000, displayName: user ? `${user.name.split(' ')[0][0]}., ${user.city || ''}` : '', payeeType: 'landlord', payeeName: '' });
  const m = useMutation({
    mutationFn: () => post('/campaigns', { title: f.title, story: f.story, category: f.category, goalAmount: Number(f.goalAmount), displayName: f.displayName, city: user?.city, state: user?.state, payee: f.payeeName ? { type: f.payeeType, name: f.payeeName } : undefined }),
    onSuccess: (r) => { toast.success(r._message); qc.invalidateQueries({ queryKey: ['my-campaigns'] }); onClose(); },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <Modal open onClose={onClose} title="Start a campaign" size="lg" footer={<Button loading={m.isPending} onClick={() => m.mutate()}>Submit for verification</Button>}>
      <div className="space-y-4">
        <Input label="Title" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="e.g. Rent deposit for a safe new home" />
        <div className="grid gap-4 sm:grid-cols-3">
          <Select label="For" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} options={[['legal_fees', 'Legal fees'], ['rent', 'Rent'], ['shelter', 'Shelter'], ['medical', 'Medical'], ['recovery', 'Recovery'], ['education', 'Education'], ['livelihood', 'Livelihood']]} />
          <Input label="Goal (₹)" type="number" value={f.goalAmount} onChange={(e) => setF({ ...f, goalAmount: e.target.value })} />
          <Input label="Public name" value={f.displayName} onChange={(e) => setF({ ...f, displayName: e.target.value })} hint="A pseudonym is fine" />
        </div>
        <Textarea label="Your story" value={f.story} onChange={(e) => setF({ ...f, story: e.target.value })} className="min-h-[180px]" hint="At least 100 characters. Don't include addresses or phone numbers." />
        <div className="grid gap-4 sm:grid-cols-2">
          <Select label="Pay funds directly to" value={f.payeeType} onChange={(e) => setF({ ...f, payeeType: e.target.value })} options={[['landlord', 'Landlord'], ['lawyer', 'Lawyer'], ['hospital', 'Hospital'], ['ngo', 'NGO'], ['beneficiary', 'Me']]} />
          <Input label="Payee name" value={f.payeeName} onChange={(e) => setF({ ...f, payeeName: e.target.value })} />
        </div>
      </div>
    </Modal>
  );
}

function NewLoan({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const [f, setF] = useState<any>({ amount: 20000, purpose: 'rent_deposit', tenureMonths: 12, monthlyIncome: '', description: '', consent: false });
  const m = useMutation({
    mutationFn: () => post('/loans', { amount: Number(f.amount), purpose: f.purpose, tenureMonths: Number(f.tenureMonths), monthlyIncome: f.monthlyIncome ? Number(f.monthlyIncome) : undefined, description: f.description || undefined, consentToShareWithLenders: f.consent }),
    onSuccess: (r) => { toast.success(r._message); qc.invalidateQueries({ queryKey: ['my-loans'] }); onClose(); },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <Modal open onClose={onClose} title="Request a micro-loan" footer={<Button loading={m.isPending} disabled={!f.consent} onClick={() => m.mutate()}>Submit request</Button>}>
      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Input label="Amount (₹)" type="number" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
          <Select label="Tenure" value={String(f.tenureMonths)} onChange={(e) => setF({ ...f, tenureMonths: e.target.value })} options={[['6', '6 months'], ['12', '12 months'], ['18', '18 months'], ['24', '24 months'], ['36', '36 months']]} />
          <Select label="Purpose" value={f.purpose} onChange={(e) => setF({ ...f, purpose: e.target.value })} options={[['rent_deposit', 'Rent deposit'], ['legal_fees', 'Legal fees'], ['small_business', 'Small business'], ['education', 'Education'], ['medical', 'Medical'], ['relocation', 'Relocation'], ['other', 'Other']]} />
          <Input label="Monthly income (₹, optional)" type="number" value={f.monthlyIncome} onChange={(e) => setF({ ...f, monthlyIncome: e.target.value })} />
        </div>
        <Textarea label="Tell lenders a little more (optional)" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} className="min-h-[80px]" />
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1 accent-rk-600" checked={f.consent} onChange={(e) => setF({ ...f, consent: e.target.checked })} /> I consent to sharing this request (without my name or contact details) with Raksha's registered lending partners.</label>
        <p className="text-xs text-ink-mute">Always read the partner's full terms. Never pay anyone an "advance fee" to get a loan.</p>
      </div>
    </Modal>
  );
}
