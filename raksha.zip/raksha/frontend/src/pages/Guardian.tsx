import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, HeartPulse, MapPin, Phone, ShieldCheck, Siren } from 'lucide-react';
import { get } from '@/api/client';
import { useSocket } from '@/contexts/SocketContext';
import { MapView } from '@/components/MapView';
import { Timeline } from '@/components/Timeline';
import { Avatar, Badge, Button, Card, CardHeader, EmptyState, PageHeader, QueryState } from '@/components/ui';
import { fmtDate, timeAgo } from '@/utils/format';

/** Dashboard for emergency contacts ("guardians"). */
export default function Guardian() {
  const { sosId, userId } = useParams();
  if (sosId) return <SosView sosId={sosId} />;
  if (userId) return <LiveView userId={userId} />;
  return <Overview />;
}

function Overview() {
  const q = useQuery({ queryKey: ['protecting'], queryFn: () => get<{ people: any[]; recent: any[] }>('/contacts/protecting'), refetchInterval: 20000 });
  return (
    <div>
      <PageHeader eyebrow="Emergency contact" title="People who trust you" subtitle="If someone below presses SOS, you'll get an alert here, by SMS/WhatsApp, and you can follow her live location." />
      <QueryState q={q} isEmpty={!q.data?.people.length} empty={<Card><EmptyState icon={<ShieldCheck className="h-6 w-6" />} title="No one has added you yet" body="When a Raksha user adds your phone or email as an emergency contact, she will appear here." /></Card>}>
        <div className="grid gap-4 md:grid-cols-2">
          {(q.data?.people || []).map((p) => (
            <Card key={p.contactId} className={p.activeSos ? 'border-rk-300 ring-2 ring-rk-500' : ''}>
              <div className="flex items-center gap-3 p-5">
                <Avatar name={p.person?.name} color={p.person?.avatarColor} size={48} />
                <div className="flex-1">
                  <p className="font-semibold">{p.person?.name}</p>
                  <p className="text-sm text-ink-mute">{p.person?.city}</p>
                </div>
                {p.activeSos ? <Badge tone="rk" icon={<Siren className="h-3 w-3" />}>{p.activeSos.isDemo ? 'Demo SOS' : 'SOS ACTIVE'}</Badge> : <Badge tone="safe">Safe</Badge>}
              </div>
              <div className="flex gap-2 border-t border-sand-200 px-5 py-3">
                {p.activeSos ? (
                  <Link to={`/guardian/sos/${p.activeSos._id}`} className="flex-1"><Button className="w-full" icon={<MapPin className="h-4 w-4" />}>Open live SOS</Button></Link>
                ) : (
                  <Link to={`/guardian/live/${p.person?._id}`} className="flex-1"><Button variant="outline" className="w-full">Live location (if shared)</Button></Link>
                )}
                <Link to={`/messages?with=${p.person?._id}`}><Button variant="ghost">Message</Button></Link>
              </div>
            </Card>
          ))}
        </div>
      </QueryState>
      {(q.data?.recent || []).length > 0 && (
        <Card className="mt-6">
          <CardHeader title="Recent SOS activity" />
          <ul className="divide-y divide-sand-200">
            {q.data!.recent.map((r) => <li key={r._id} className="flex justify-between px-5 py-3 text-sm"><span>{fmtDate(r.createdAt, true)}</span><span className="flex gap-1.5">{r.isDemo && <Badge tone="warn">Demo</Badge>}<Badge>{r.status}</Badge></span></li>)}
          </ul>
        </Card>
      )}
    </div>
  );
}

function useLiveLocation(userId?: string, initial?: { lat: number; lng: number; accuracy?: number } | null) {
  const socket = useSocket();
  const [loc, setLoc] = useState(initial || null);
  const [path, setPath] = useState<Array<[number, number]>>([]);
  useEffect(() => setLoc(initial || null), [initial?.lat, initial?.lng]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!socket || !userId) return;
    socket.emit('location:watch', { userId });
    const on = (p: any) => {
      if (p.userId !== userId) return;
      setLoc({ lat: p.lat, lng: p.lng, accuracy: p.accuracy });
      setPath((x) => [...x.slice(-199), [p.lat, p.lng]]);
    };
    socket.on('location:update', on);
    return () => {
      socket.off('location:update', on);
      socket.emit('location:unwatch', { userId });
    };
  }, [socket, userId]);
  return { loc, path };
}

function SosView({ sosId }: { sosId: string }) {
  const socket = useSocket();
  const q = useQuery({ queryKey: ['guardian-sos', sosId], queryFn: () => get<{ alert: any; view: string }>(`/sos/${sosId}`), refetchInterval: 10000 });
  const a = q.data?.alert;
  useEffect(() => {
    socket?.emit('sos:join', { sosId });
  }, [socket, sosId]);
  const coords = a?.location?.coordinates;
  const { loc, path } = useLiveLocation(a?.user, coords ? { lat: coords[1], lng: coords[0], accuracy: a?.accuracy } : null);
  return (
    <div>
      <Link to="/guardian" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-rk-700"><ArrowLeft className="h-4 w-4" /> Back</Link>
      <QueryState q={q}>
        {a && (
          <div className="space-y-6">
            <div className={a.status === 'active' ? 'rounded-3xl bg-gradient-to-br from-rk-600 to-rk-800 p-6 text-white' : 'rounded-3xl bg-safe-50 p-6 ring-1 ring-safe-100'}>
              <p className="text-sm font-semibold uppercase tracking-wider opacity-80">{a.isDemo ? 'Demo SOS (simulated)' : a.status === 'active' ? 'SOS active' : `SOS ${a.status}`}</p>
              <p className="mt-1 font-display text-3xl font-semibold" style={a.status === 'active' ? { color: 'white' } : undefined}>{a.person?.name || 'She'} {a.status === 'active' ? 'needs help' : 'is safe'}</p>
              <p className="mt-1 text-sm opacity-80">Started {timeAgo(a.createdAt)}{a.message ? ` · "${a.message}"` : ''}</p>
              {a.status === 'active' && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {a.person?.phone && <a href={`tel:${a.person.phone}`}><Button className="bg-white text-rk-800 hover:bg-rk-50" icon={<Phone className="h-4 w-4" />}>Call her</Button></a>}
                  {!a.isDemo && <a href="tel:112"><Button variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20 hover:text-white">Call 112</Button></a>}
                </div>
              )}
            </div>
            <div className="grid gap-6 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <CardHeader title="Live location" icon={<MapPin className="h-4 w-4" />} />
                <div className="p-4"><MapView points={loc ? [{ lat: loc.lat, lng: loc.lng, accuracy: loc.accuracy, label: a.person?.name?.split(' ')[0] }] : []} path={path} height={360} /></div>
              </Card>
              <div className="space-y-6">
                <Card>
                  <CardHeader title="Timeline" />
                  <div className="p-5"><Timeline steps={(a.timeline || []).map((t: any, i: number) => ({ key: String(i), label: t.label, at: t.at, state: 'done' as const }))} timeOnly /></div>
                </Card>
                {a.medical && Object.values(a.medical).some(Boolean) && (
                  <Card>
                    <CardHeader title="Medical information she chose to share" icon={<HeartPulse className="h-4 w-4" />} />
                    <dl className="space-y-1 p-5 text-sm">{Object.entries(a.medical).filter(([, v]) => v).map(([k, v]) => <div key={k} className="flex justify-between gap-2"><dt className="text-ink-mute">{k}</dt><dd className="font-medium">{String(v)}</dd></div>)}</dl>
                  </Card>
                )}
              </div>
            </div>
          </div>
        )}
      </QueryState>
    </div>
  );
}

function LiveView({ userId }: { userId: string }) {
  const q = useQuery({ queryKey: ['latest-loc', userId], queryFn: () => get<{ person: any; location: any }>(`/location/user/${userId}/latest`), refetchInterval: 15000, retry: false });
  const { loc, path } = useLiveLocation(userId, q.data?.location || null);
  return (
    <div>
      <Link to="/guardian" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-rk-700"><ArrowLeft className="h-4 w-4" /> Back</Link>
      <QueryState q={q}>
        <PageHeader title={`${q.data?.person?.name || ''} — live location`} subtitle={q.data?.location ? `Updated ${timeAgo(q.data.location.at)}` : 'No location yet'} />
        <MapView points={loc ? [{ lat: loc.lat, lng: loc.lng, accuracy: loc.accuracy, label: q.data?.person?.name?.split(' ')[0] }] : []} path={path} height={420} />
      </QueryState>
      {q.isError && <p className="mt-4 text-sm text-ink-mute">She is not sharing her location with you right now.</p>}
    </div>
  );
}
