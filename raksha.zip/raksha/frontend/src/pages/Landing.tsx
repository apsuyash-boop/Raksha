import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight, BadgeCheck, BookOpen, Camera, ChevronRight, EyeOff, FileWarning, Gavel, HandCoins, HeartHandshake, KeyRound, Landmark, Lock, MapPin,
  MessageSquareWarning, Phone, Radio, Scale, ShieldCheck, Siren, Sparkles, Timer, UserCheck, Users, Wallet, Clock,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Button, Modal } from '@/components/ui';
import { ROLE_HOME } from '@/utils/format';

const PROBLEMS = [
  { icon: Timer, title: 'Slow emergency alerts', body: 'Calling for help takes time, and location is rarely shared.' },
  { icon: FileWarning, title: 'No evidence', body: 'Incidents go unrecorded, so cases are hard to prove.' },
  { icon: BookOpen, title: 'Low legal awareness', body: "Many women don't know their rights or the laws that protect them." },
  { icon: Users, title: 'Hard to reach lawyers & NGOs', body: 'Cost, distance and lack of trust keep help away.' },
  { icon: Landmark, title: 'Complex schemes & paperwork', body: 'Eligibility rules and forms are confusing.' },
  { icon: Wallet, title: 'Financial dependence', body: 'Without money, leaving an abusive home feels impossible.' },
];

const SERVICES = [
  { icon: Siren, title: 'One-tap SOS', body: 'Hold to alert contacts, nearby verified responders and configured emergency services.' },
  { icon: MapPin, title: 'Live location', body: 'Real-time location to the people you trust, with a timer you control.' },
  { icon: Radio, title: 'Live evidence', body: 'Audio and video recorded in segments and saved to an encrypted vault.' },
  { icon: BookOpen, title: 'Rights & stories', body: 'Laws explained simply, in Hindi and English. Share your story anonymously.' },
  { icon: Scale, title: 'Lawyer & NGO matching', body: 'Matched by case type, city, language and budget — including pro bono.' },
  { icon: Gavel, title: 'Police & court help', body: 'Guided complaint drafting, evidence attached, status and hearing tracking.' },
  { icon: Landmark, title: 'Government schemes', body: 'Check eligibility against official criteria and track applications.' },
  { icon: HeartHandshake, title: 'Counselling', body: 'Certified counsellors by chat, call or video — many sessions free.' },
  { icon: HandCoins, title: 'Financial aid', body: 'Verified crowdfunding, donations and registered lending partners.' },
];

const JOURNEY = ['Emergency', 'Evidence', 'Complaint', 'Legal Help', 'Counselling', 'Financial Support', 'Independence'];

const TRUST = [
  { icon: Lock, title: 'Encrypted data', body: 'Evidence, medical details and sessions are encrypted in transit and at rest.' },
  { icon: BadgeCheck, title: 'Verified partners', body: 'Lawyers, NGOs, counsellors and responders are vetted before they appear.' },
  { icon: EyeOff, title: 'Anonymous posting', body: 'Share your story without revealing who you are.' },
  { icon: KeyRound, title: 'False-alarm PIN', body: 'Cancel an accidental SOS with your secret PIN — contacts are told you are safe.' },
  { icon: UserCheck, title: 'Consent first', body: 'You decide who sees your evidence, location and case — and see who accessed it.' },
  { icon: MessageSquareWarning, title: 'Moderation', body: 'Abuse and fake profiles are auto-flagged, reported and reviewed by people.' },
];

export default function Landing() {
  const { user } = useAuth();
  const { t } = useI18n();
  const [help, setHelp] = useState(false);
  const navigate = useNavigate();
  const home = user ? ROLE_HOME[user.role] || '/dashboard' : '/register';

  return (
    <div>
      {/* ------------------------------ HERO ------------------------------ */}
      <section className="relative overflow-hidden">
        <div className="grain pointer-events-none absolute inset-0 opacity-70" aria-hidden />
        <div className="pointer-events-none absolute -right-40 -top-40 h-[520px] w-[520px] rounded-full bg-rk-200/40 blur-3xl" aria-hidden />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 pb-20 pt-12 sm:px-6 md:pt-20 lg:grid-cols-[1.1fr_.9fr]">
          <div className="animate-fade-up">
            <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-rk-100 bg-white px-3 py-1 text-xs font-semibold text-rk-700 shadow-sm">
              <ShieldCheck className="h-3.5 w-3.5" /> Women's safety · Legal aid · Empowerment
            </p>
            <h1 className="text-[40px] font-semibold leading-[1.05] sm:text-6xl">
              {t('hero.title').split('. ').map((s, i, a) => (
                <span key={i} className={i === 1 ? 'text-rk-600' : undefined}>
                  {s}
                  {i < a.length - 1 ? '. ' : ''}
                  {i === 0 && <br />}
                </span>
              ))}
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-soft">{t('hero.sub')}</p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => (user?.role === 'user' ? navigate('/sos') : setHelp(true))} className="group inline-flex h-14 items-center gap-3 rounded-2xl bg-gradient-to-b from-rk-500 to-rk-700 pl-2 pr-6 font-bold text-white shadow-sos transition hover:brightness-110">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/15">
                  <Siren className="h-5 w-5" />
                </span>
                {t('hero.cta.sos')}
              </button>
              <a href="#services">
                <Button variant="outline" size="lg" icon={<ArrowRight className="h-4 w-4" />} className="flex-row-reverse">
                  {t('hero.cta.explore')}
                </Button>
              </a>
            </div>
            <p className="mt-5 flex items-center gap-2 text-sm text-ink-mute">
              <Phone className="h-4 w-4" /> In immediate danger? Call <a className="font-semibold text-rk-700 underline" href="tel:112">112</a> · Women Helpline <a className="font-semibold text-rk-700 underline" href="tel:181">181</a>
            </p>
          </div>

          {/* Phone mockup */}
          <div className="relative mx-auto w-full max-w-[340px] animate-fade-up [animation-delay:.15s]" aria-hidden>
            <div className="rounded-[2.6rem] border border-sand-200 bg-white p-3 shadow-lift">
              <div className="rounded-[2rem] bg-gradient-to-b from-rk-50 to-white px-5 pb-6 pt-8">
                <div className="flex items-center justify-between text-xs font-semibold text-ink-mute">
                  <span>Raksha</span>
                  <span className="flex items-center gap-1 text-safe-600">
                    <span className="h-2 w-2 rounded-full bg-safe-500" /> You are safe
                  </span>
                </div>
                <div className="relative mx-auto my-8 grid h-40 w-40 place-items-center">
                  <span className="absolute inset-0 rounded-full bg-rk-500/25 animate-pulse-ring" />
                  <span className="grid h-32 w-32 place-items-center rounded-full bg-gradient-to-b from-rk-500 to-rk-700 font-display text-4xl font-bold text-white shadow-sos">SOS</span>
                </div>
                <p className="text-center text-xs text-ink-mute">Hold 3 seconds · cancel with your PIN</p>
                <div className="mt-6 space-y-2.5">
                  {[
                    ['Contacts alerted', 'SMS · WhatsApp · app'],
                    ['Responders notified', '3 verified, nearby'],
                    ['Evidence recording', 'Encrypted · SHA-256'],
                  ].map(([a, b], i) => (
                    <div key={a} className="flex items-center gap-3 rounded-xl bg-white px-3 py-2.5 shadow-card">
                      <span className="grid h-7 w-7 place-items-center rounded-full bg-rk-600 text-[11px] font-bold text-white">{i + 1}</span>
                      <div>
                        <p className="text-[13px] font-semibold">{a}</p>
                        <p className="text-[11px] text-ink-mute">{b}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="absolute -left-10 bottom-16 hidden rounded-2xl bg-white px-4 py-3 shadow-lift sm:block">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-mute">Target</p>
              <p className="font-display text-2xl font-semibold text-rk-700">&lt; 60 sec</p>
              <p className="text-[11px] text-ink-mute">SOS to contacts alerted</p>
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------ CONTEXT ------------------------------ */}
      <section className="border-y border-sand-200 bg-white">
        <div className="mx-auto grid max-w-6xl gap-6 px-4 py-10 sm:px-6 md:grid-cols-4">
          {[
            ['4.45 lakh', 'cases of crimes against women registered in 2022'],
            ['51', 'such FIRs filed every hour, on average'],
            ['29%', 'of married women aged 18–49 have faced spousal violence'],
            ['14%', 'of women who face violence ever seek help'],
          ].map(([n, l]) => (
            <div key={n}>
              <p className="font-display text-3xl font-semibold text-rk-700">{n}</p>
              <p className="mt-1 text-sm text-ink-mute">{l}</p>
            </div>
          ))}
          <p className="text-xs text-ink-mute md:col-span-4">Sources: NCRB, Crime in India 2022; NFHS-5 (2019–21).</p>
        </div>
      </section>

      {/* ------------------------------ PROBLEM ------------------------------ */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">The problem</p>
          <h2 className="mt-2 text-3xl font-semibold sm:text-4xl">Help exists, but it is scattered and slow</h2>
          <p className="mt-3 text-ink-mute">Most women never reach help: they lack a fast alert, proof of what happened, legal guidance and money to act.</p>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {PROBLEMS.map(({ icon: I, title, body }) => (
            <div key={title} className="card p-6 transition hover:-translate-y-0.5 hover:shadow-lift">
              <I className="h-6 w-6 text-rk-600" />
              <h3 className="mt-4 font-sans text-lg font-semibold">{title}</h3>
              <p className="mt-1.5 text-sm text-ink-mute">{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ------------------------------ SERVICES ------------------------------ */}
      <section id="services" className="scroll-mt-20 bg-ink py-20 text-white">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-300">The solution</p>
              <h2 className="mt-2 text-3xl font-semibold text-white sm:text-4xl">One platform for every step</h2>
            </div>
            <p className="max-w-sm text-white/65">Without Raksha, each step means a different app, office or person. With Raksha, it's one account.</p>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map(({ icon: I, title, body }, i) => (
              <div key={title} className="group rounded-2xl border border-white/10 bg-white/[.04] p-6 transition hover:border-rk-400/40 hover:bg-white/[.07]" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-rk-600/90 text-white transition group-hover:scale-105">
                    <I className="h-5 w-5" />
                  </span>
                  <span className="font-mono text-xs text-white/40">0{i + 1}</span>
                </div>
                <h3 className="mt-4 font-sans text-lg font-semibold text-white">{title}</h3>
                <p className="mt-1.5 text-sm text-white/65">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------ JOURNEY ------------------------------ */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">How Raksha works</p>
        <h2 className="mt-2 text-3xl font-semibold sm:text-4xl">From the first second to a new beginning</h2>
        <ol className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-7">
          {JOURNEY.map((s, i) => (
            <li key={s} className="relative">
              <div className="card flex h-full flex-col p-4">
                <span className="grid h-8 w-8 place-items-center rounded-full bg-rk-600 text-sm font-bold text-white">{i + 1}</span>
                <p className="mt-3 font-semibold leading-snug">{s}</p>
              </div>
              {i < JOURNEY.length - 1 && <ChevronRight className="absolute -right-3 top-1/2 z-10 hidden h-5 w-5 -translate-y-1/2 text-rk-300 lg:block" aria-hidden />}
            </li>
          ))}
        </ol>
        <div className="mt-8 rounded-2xl border border-rk-100 bg-rk-50/60 p-6">
          <p className="text-sm font-semibold text-rk-800">Priya's journey (illustrative)</p>
          <p className="mt-1 text-[15px] text-ink-soft">
            She presses SOS; family and nearby responders reach her. The recording is saved to her vault. Raksha drafts her complaint, an NGO lawyer takes her domestic-violence case, a counsellor helps her heal, a crowdfunded rent deposit gets her a safe home — and she applies for schemes and job training.
          </p>
        </div>
      </section>

      {/* ------------------------------ TRUST ------------------------------ */}
      <section className="border-y border-sand-200 bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">Trust & safety</p>
          <h2 className="mt-2 text-3xl font-semibold sm:text-4xl">Privacy and safety by design</h2>
          <div className="mt-10 grid gap-x-8 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
            {TRUST.map(({ icon: I, title, body }) => (
              <div key={title} className="flex gap-4">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-safe-50 text-safe-600">
                  <I className="h-5 w-5" />
                </span>
                <div>
                  <h3 className="font-sans font-semibold">{title}</h3>
                  <p className="mt-1 text-sm text-ink-mute">{body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------ IMPACT ------------------------------ */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">Impact targets</p>
            <h2 className="mt-2 text-3xl font-semibold sm:text-4xl">What we are building towards</h2>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-warn-500/30 bg-warn-50 px-3 py-1 text-xs font-semibold text-warn-700">
            <Sparkles className="h-3.5 w-3.5" /> Planning targets — not achieved results
          </span>
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            ['500+', 'verified lawyers, NGOs and counsellors', 'by Year 2'],
            ['< 60 sec', 'from SOS press to contacts alerted', 'design target'],
            ['10,000+', 'women helped with legal, scheme or financial support', 'by Year 3'],
          ].map(([n, l, w]) => (
            <div key={n} className="card relative overflow-hidden p-7">
              <span className="absolute right-4 top-4 rounded-full bg-sand-100 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-ink-mute">Target</span>
              <p className="font-display text-5xl font-semibold text-rk-700">{n}</p>
              <p className="mt-3 font-medium">{l}</p>
              <p className="mt-1 flex items-center gap-1 text-sm text-ink-mute">
                <Clock className="h-3.5 w-3.5" /> {w}
              </p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-sm text-ink-mute">
          Live figures from verified transactions are on our <Link to="/transparency" className="font-semibold text-rk-700 underline">transparency page</Link>.
        </p>
      </section>

      {/* ------------------------------ FINAL CTA ------------------------------ */}
      <section className="px-4 pb-20 sm:px-6">
        <div className="relative mx-auto max-w-6xl overflow-hidden rounded-4xl bg-gradient-to-br from-rk-700 via-rk-800 to-rk-900 px-6 py-14 text-center text-white sm:px-12">
          <div className="grain absolute inset-0 opacity-30" aria-hidden />
          <h2 className="relative mx-auto max-w-3xl text-3xl font-semibold text-white sm:text-[42px] sm:leading-tight">Help us make sure no woman faces danger, or justice, alone.</h2>
          <div className="relative mt-8 flex flex-wrap justify-center gap-3">
            <Link to={home}>
              <Button size="lg" className="bg-white text-rk-800 hover:bg-rk-50">
                Get Started
              </Button>
            </Link>
            <Link to="/partners">
              <Button size="lg" variant="outline" className="border-white/30 bg-white/10 text-white hover:border-white hover:bg-white/15 hover:text-white">
                Become a Partner
              </Button>
            </Link>
            <Link to="/register?role=lawyer">
              <Button size="lg" variant="outline" className="border-white/30 bg-white/10 text-white hover:border-white hover:bg-white/15 hover:text-white">
                Become a Lawyer/NGO
              </Button>
            </Link>
            <Link to="/donate">
              <Button size="lg" variant="outline" className="border-white/30 bg-white/10 text-white hover:border-white hover:bg-white/15 hover:text-white" icon={<HandCoins className="h-4 w-4" />}>
                Donate
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Modal open={help} onClose={() => setHelp(false)} title="Get help now" size="sm">
        <div className="space-y-3">
          <a href="tel:112" className="flex items-center gap-3 rounded-2xl bg-rk-600 p-4 text-white">
            <Phone className="h-6 w-6" />
            <div>
              <p className="text-lg font-bold">Call 112</p>
              <p className="text-sm text-white/80">National emergency number</p>
            </div>
          </a>
          <a href="tel:181" className="flex items-center gap-3 rounded-2xl border border-rk-200 p-4 text-rk-800">
            <Phone className="h-6 w-6" />
            <div>
              <p className="font-bold">Women Helpline 181</p>
              <p className="text-sm text-ink-mute">24×7 support and referrals</p>
            </div>
          </a>
          <div className="grid grid-cols-2 gap-2 pt-2">
            <Link to="/login" state={{ from: '/sos' }}>
              <Button variant="outline" className="w-full">
                Log in for SOS
              </Button>
            </Link>
            <Link to="/register">
              <Button className="w-full" icon={<Camera className="h-4 w-4" />}>
                Set up Raksha
              </Button>
            </Link>
          </div>
          <p className="text-xs text-ink-mute">Raksha SOS works after you sign in, so your emergency contacts can be alerted with your location.</p>
        </div>
      </Modal>
    </div>
  );
}
