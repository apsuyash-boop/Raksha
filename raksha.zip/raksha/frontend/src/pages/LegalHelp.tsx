import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { BadgeCheck, Building2, Clock, Gavel, Home, Languages, MapPin, Scale, Search, Sparkles, Star } from 'lucide-react';
import { apiError, get, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { Avatar, Badge, Button, Card, EmptyState, Modal, PageHeader, Select, Spinner, Tabs, Textarea } from '@/components/ui';
import { CASE_TYPES, cn, humanize, INDIAN_STATES, inr, LANGS } from '@/utils/format';

type Match = { type: 'lawyer' | 'ngo'; profile: any; score: number; reasons: string[] };

export default function LegalHelp({ initialTab = 'match' }: { initialTab?: 'match' | 'lawyers' | 'ngos' }) {
  const { user } = useAuth();
  const [tab, setTab] = useState<'match' | 'lawyers' | 'ngos'>(initialTab);
  const [form, setForm] = useState({ caseType: 'domestic_violence', state: user?.state || '', city: user?.city || '', language: user?.language || 'hi', budget: 'any', urgency: 'medium', service: '' });
  const [results, setResults] = useState<{ lawyers: Match[]; ngos: Match[] } | null>(null);
  const [requestFor, setRequestFor] = useState<Match | null>(null);

  const match = useMutation({
    mutationFn: () => post<{ lawyers: Match[]; ngos: Match[] }>('/match', { ...form, service: form.service || undefined, state: form.state || undefined, city: form.city || undefined }),
    onSuccess: setResults,
    onError: (e) => toast.error(apiError(e).message),
  });

  return (
    <div>
      <PageHeader eyebrow="Legal help" title="Find the right lawyer or NGO" subtitle="Tell us about your situation. We match you with verified professionals by case type, location, language, budget and availability — many offer free help." />
      <Tabs value={tab} onChange={setTab} tabs={[['match', 'Get matched'], ['lawyers', 'Browse lawyers'], ['ngos', 'Browse NGOs']]} className="mb-6 w-fit" />

      {tab === 'match' && (
        <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
          <Card className="h-fit p-5">
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                match.mutate();
              }}
            >
              <Select label="What kind of help?" value={form.caseType} onChange={(e) => setForm({ ...form, caseType: e.target.value })} options={CASE_TYPES as any} />
              <div className="grid grid-cols-2 gap-3">
                <Select label="State" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} options={INDIAN_STATES.map((s) => [s, s])} placeholder="Any" />
                <div>
                  <label className="label" htmlFor="city">City</label>
                  <input id="city" className="input" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                </div>
              </div>
              <Select label="Language" value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} options={LANGS} />
              <div className="grid grid-cols-2 gap-3">
                <Select label="Budget" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} options={[['any', 'Any'], ['free', 'Free only'], ['low', 'Low fee'], ['standard', 'Standard']]} />
                <Select label="Urgency" value={form.urgency} onChange={(e) => setForm({ ...form, urgency: e.target.value })} options={[['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['emergency', 'Emergency']]} />
              </div>
              <Select label="Service needed" value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} options={[['consultation', 'Legal consultation'], ['court_representation', 'Court representation'], ['drafting', 'Document drafting'], ['shelter', 'Shelter'], ['rescue', 'Rescue'], ['counselling', 'Counselling'], ['legal_aid', 'Free legal aid']]} placeholder="Any" />
              <Button type="submit" className="w-full" loading={match.isPending} icon={<Sparkles className="h-4 w-4" />}>
                Find matches
              </Button>
            </form>
          </Card>
          <div>
            {match.isPending ? (
              <Spinner />
            ) : !results ? (
              <Card>
                <EmptyState icon={<Scale className="h-6 w-6" />} title="Your matches will appear here" body="Only professionals verified by Raksha are shown. You choose whom to contact — nothing is shared until you send a request." />
              </Card>
            ) : (
              <div className="space-y-6">
                <section>
                  <h2 className="mb-3 font-sans text-lg font-semibold">Lawyers ({results.lawyers.length})</h2>
                  <div className="grid gap-4 xl:grid-cols-2">
                    {results.lawyers.map((m) => <MatchCard key={m.profile._id} m={m} onRequest={() => setRequestFor(m)} />)}
                    {!results.lawyers.length && <p className="text-sm text-ink-mute">No matching verified lawyers yet. Try widening location or budget.</p>}
                  </div>
                </section>
                <section>
                  <h2 className="mb-3 font-sans text-lg font-semibold">NGOs & support centres ({results.ngos.length})</h2>
                  <div className="grid gap-4 xl:grid-cols-2">
                    {results.ngos.map((m) => <MatchCard key={m.profile._id} m={m} onRequest={() => setRequestFor(m)} />)}
                    {!results.ngos.length && <p className="text-sm text-ink-mute">No matching NGOs. Call Women Helpline 181 to reach your nearest One Stop Centre.</p>}
                  </div>
                </section>
              </div>
            )}
          </div>
        </div>
      )}
      {tab === 'lawyers' && <Directory kind="lawyers" onRequest={(p) => setRequestFor({ type: 'lawyer', profile: p, score: 0, reasons: [] })} />}
      {tab === 'ngos' && <Directory kind="ngos" onRequest={(p) => setRequestFor({ type: 'ngo', profile: p, score: 0, reasons: [] })} />}

      {requestFor && <RequestModal m={requestFor} defaults={form} onClose={() => setRequestFor(null)} />}
    </div>
  );
}

function MatchCard({ m, onRequest }: { m: Match; onRequest: () => void }) {
  const p = m.profile;
  const name = p.displayName || p.name;
  return (
    <Card className="flex flex-col p-5">
      <div className="flex items-start gap-3">
        <Avatar name={name} color={p.user?.avatarColor || (m.type === 'lawyer' ? '#9F1239' : '#0E7490')} size={48} />
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <p className="font-semibold leading-snug">{name}</p>
            {m.score > 0 && <span className="shrink-0 rounded-full bg-rk-50 px-2 py-0.5 text-xs font-bold text-rk-700">{m.score}% match</span>}
          </div>
          <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-ink-mute">
            <span className="flex items-center gap-1"><BadgeCheck className="h-3.5 w-3.5 text-safe-600" /> Verified</span>
            <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {p.city}{p.state ? `, ${p.state}` : ''}</span>
            {p.rating > 0 && <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" /> {p.rating}</span>}
          </p>
        </div>
      </div>
      <p className="mt-3 line-clamp-2 text-sm text-ink-soft">{p.bio || p.about}</p>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {(p.specializations || p.focusAreas || []).slice(0, 4).map((s: string) => <Badge key={s}>{humanize(s)}</Badge>)}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-ink-mute">
        <span className="flex items-center gap-1"><Languages className="h-3.5 w-3.5" /> {(p.languages || []).join(', ').toUpperCase()}</span>
        <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {humanize(p.availability)}{p.is24x7 ? ' · 24×7' : ''}</span>
        {m.type === 'lawyer' ? (
          <span className="col-span-2 flex items-center gap-1"><Gavel className="h-3.5 w-3.5" /> {p.proBono || p.feeType === 'pro_bono' ? 'Pro bono (free)' : p.feeType === 'low_fee' ? `Low fee · consultation ${inr(p.consultationFee)}` : `Consultation ${inr(p.consultationFee)}`}{p.freeFirstConsultation ? ' · first consultation free' : ''}</span>
        ) : (
          <span className="col-span-2 flex items-center gap-1"><Home className="h-3.5 w-3.5" /> {(p.services || []).map(humanize).join(', ')}{p.shelterAvailable > 0 ? ` · ${p.shelterAvailable} shelter places` : ''}</span>
        )}
      </div>
      {m.reasons.length > 0 && (
        <ul className="mt-3 space-y-1 border-t border-sand-200 pt-3 text-xs text-safe-700">
          {m.reasons.slice(0, 3).map((r) => <li key={r}>✓ {r}</li>)}
        </ul>
      )}
      <Button className="mt-4" onClick={onRequest}>
        Request assistance
      </Button>
    </Card>
  );
}

function Directory({ kind, onRequest }: { kind: 'lawyers' | 'ngos'; onRequest: (p: any) => void }) {
  const [q, setQ] = useState('');
  const [free, setFree] = useState(false);
  const data = useQuery({ queryKey: ['dir', kind, q, free], queryFn: () => get<{ items: any[] }>(`/${kind}`, { q: q || undefined, free: free || undefined }) });
  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
          <input className="input pl-10" placeholder={`Search ${kind}`} value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {kind === 'lawyers' && <button className={cn('chip justify-center', free && 'chip-active')} onClick={() => setFree(!free)}>Pro bono only</button>}
      </div>
      {data.isLoading ? <Spinner /> : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {(data.data?.items || []).map((p) => <MatchCard key={p._id} m={{ type: kind === 'lawyers' ? 'lawyer' : 'ngo', profile: p, score: 0, reasons: [] }} onRequest={() => onRequest(p)} />)}
          {!data.data?.items.length && <p className="text-sm text-ink-mute">No results.</p>}
        </div>
      )}
    </div>
  );
}

function RequestModal({ m, defaults, onClose }: { m: Match; defaults: any; onClose: () => void }) {
  const qc = useQueryClient();
  const nav = useNavigate();
  const cases = useQuery({ queryKey: ['cases'], queryFn: () => get<{ cases: any[] }>('/cases') });
  const open = (cases.data?.cases || []).filter((c) => !['resolved', 'closed'].includes(c.status));
  const [caseId, setCaseId] = useState('new');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [message, setMessage] = useState('');
  const send = useMutation({
    mutationFn: async () => {
      let id = caseId;
      if (id === 'new') {
        const c = await post<{ case: any }>('/cases', { type: defaults.caseType, title: title || humanize(defaults.caseType), description, urgency: defaults.urgency, city: defaults.city || undefined, state: defaults.state || undefined, language: defaults.language, budget: defaults.budget });
        id = c.case._id;
      }
      await post(`/cases/${id}/requests`, { providerType: m.type, providerId: m.profile._id, message: message || undefined, service: defaults.service || undefined });
      return id;
    },
    onSuccess: (id) => {
      toast.success('Request sent. You will be notified when they respond.');
      qc.invalidateQueries({ queryKey: ['cases'] });
      onClose();
      nav(`/cases/${id}`);
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <Modal open onClose={onClose} title={`Request help from ${m.profile.displayName || m.profile.name}`} footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button loading={send.isPending} onClick={() => send.mutate()}>Send request</Button></>}>
      <div className="space-y-4">
        <Select label="Which case is this about?" value={caseId} onChange={(e) => setCaseId(e.target.value)} options={[['new', '+ Start a new case'], ...open.map((c) => [c._id, `${c.caseNumber} — ${c.title}`] as [string, string])]} />
        {caseId === 'new' && (
          <>
            <div>
              <label className="label" htmlFor="ct">Short title</label>
              <input id="ct" className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={humanize(defaults.caseType)} />
            </div>
            <Textarea label="What happened? (shared only with professionals you request)" value={description} onChange={(e) => setDescription(e.target.value)} />
          </>
        )}
        <Textarea label="Message (optional)" value={message} onChange={(e) => setMessage(e.target.value)} className="min-h-[80px]" />
        <p className="flex items-start gap-2 rounded-xl bg-sand-100 p-3 text-xs text-ink-soft">
          <Building2 className="mt-0.5 h-4 w-4 shrink-0" /> Before they accept, they only see the case summary. Your evidence and contact details are shared after acceptance, and only if you allow it in the case's consent settings.
        </p>
        {m.type === 'lawyer' && <Link to="/rights" className="text-xs font-semibold text-rk-700 underline">Read about your rights first</Link>}
      </div>
    </Modal>
  );
}
