const PRIVACY = [
  ['Who we are', 'Raksha is a women’s safety, legal aid and empowerment platform. This policy explains what we collect, why, and the control you have. It is written to align with India’s Digital Personal Data Protection Act, 2023. Operators deploying Raksha should have it reviewed by their own counsel.'],
  ['What we collect', 'Account details you provide (name, phone and/or email, age, state/city, preferred language); emergency contacts you add; optional medical and safety information (stored encrypted); location — only while an SOS or a location share is active; evidence you upload or record (stored encrypted); case, complaint, counselling, scheme and financial records you create; messages; and security logs.'],
  ['Why we use it', 'To send emergency alerts and live location to the people you choose; to match you with verified lawyers, NGOs and counsellors; to help you prepare complaints and track cases; to process donations and payments; to keep the platform safe through moderation and audit logs; and to meet legal obligations.'],
  ['Consent and control', 'You decide who sees your evidence, location and case. Professionals see your case summary only after you send a request, and your evidence and contact details only after they accept and you allow sharing. You can change privacy settings, revoke access, export your data or delete your account at any time from Settings.'],
  ['Location', 'Raksha does not track you in the background. Location is recorded only during an active SOS or a time-limited share you start. Precise location is visible only to you, your linked emergency contacts during that period, and responders who accept your SOS. Administrators only see an approximate area (about 1 km).'],
  ['Evidence', 'Files are encrypted with AES-256-GCM before storage, fingerprinted with SHA-256, and served only through authenticated, access-checked requests — never through public links. Every access is logged and visible to you.'],
  ['Who we share with', 'Only the people you choose (contacts, matched professionals, police officers you share a complaint with), and service providers needed to run the platform (SMS/email/WhatsApp, payments, hosting, storage) under confidentiality obligations. We do not sell personal data.'],
  ['Security', 'Encryption in transit (HTTPS) and at rest, hashed passwords, rotating sessions, rate limiting, role-based access and audit logs. No system is perfectly secure; please protect your password and safety PIN.'],
  ['Retention and deletion', 'We keep data while your account is active. When you delete your account we delete your personal data and evidence files, anonymise community posts, and keep only records we are legally required to retain (such as payment records) without your identity.'],
  ['Children', 'Users aged 13–17 should use Raksha with the involvement of a trusted adult. Emergency help is never refused.'],
  ['Contact', 'Questions or grievances can be sent to the grievance officer named by the platform operator.'],
];

const TERMS = [
  ['Emergency services', 'Raksha helps you alert people and services, but it is not a replacement for emergency services. In immediate danger, call 112. Delivery of alerts depends on your network, device permissions and the providers configured by the operator. Raksha shows the actual delivery status of every alert and never claims a service was contacted unless it confirmed receipt.'],
  ['Legal information', 'Rights library content and complaint drafts are educational aids, not legal advice. Please consult a qualified lawyer before acting.'],
  ['Verified professionals', 'Lawyers, NGOs, counsellors, responders, police officials and lenders are verified by Raksha administrators before they appear as verified. Verification reduces but does not eliminate risk; report any misconduct.'],
  ['Responsible use', 'Do not misuse SOS, harass others, post identifying information about others, impersonate anyone, or upload unlawful content. False SOS alerts can be cancelled with your PIN; deliberate misuse may lead to suspension.'],
  ['Donations and loans', 'Campaigns are KYC-verified before going live. Payments are processed by a regulated payment gateway. Raksha does not lend money; loan offers come from registered lending partners whose terms apply. Never pay an advance fee to obtain a loan.'],
  ['Community', 'Posts are moderated automatically and by people. Anonymous posting hides your identity from other users and moderators.'],
  ['Changes', 'We may update these terms and will notify you of material changes.'],
];

export default function LegalPages({ kind }: { kind: 'privacy' | 'terms' }) {
  const sections = kind === 'privacy' ? PRIVACY : TERMS;
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">Legal</p>
      <h1 className="mt-2 text-4xl font-semibold">{kind === 'privacy' ? 'Privacy Policy' : 'Terms of Service'}</h1>
      <p className="mt-2 text-sm text-ink-mute">Last updated {new Date().toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</p>
      <div className="mt-8 space-y-7">
        {sections.map(([h, b]) => (
          <section key={h}>
            <h2 className="font-sans text-lg font-semibold">{h}</h2>
            <p className="mt-1.5 leading-relaxed text-ink-soft">{b}</p>
          </section>
        ))}
      </div>
    </div>
  );
}
