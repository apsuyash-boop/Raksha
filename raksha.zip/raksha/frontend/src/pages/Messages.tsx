import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ArrowLeft, BadgeCheck, Ban, Check, CheckCheck, Flag, Lock, MessageCircle, Paperclip, Send } from 'lucide-react';
import { apiError, get, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { useSocket } from '@/contexts/SocketContext';
import { Avatar, Button, Card, EmptyState, Modal, PageHeader, Spinner } from '@/components/ui';
import { cn, humanize, timeAgo } from '@/utils/format';

export default function Messages() {
  const [params, setParams] = useSearchParams();
  const active = params.get('with');
  const convs = useQuery({ queryKey: ['conversations'], queryFn: () => get<{ conversations: any[] }>('/messages/conversations'), refetchInterval: 30000 });
  return (
    <div>
      <PageHeader eyebrow="Secure chat" title="Messages" subtitle="You can message people connected to your case, counselling session or SOS. Chats are private and access-controlled." />
      <Card className="grid h-[calc(100vh-230px)] min-h-[480px] overflow-hidden md:grid-cols-[300px_1fr]">
        <aside className={cn('border-r border-sand-200', active && 'hidden md:block')}>
          <div className="h-full overflow-y-auto">
            {convs.isLoading ? <Spinner /> : (convs.data?.conversations || []).length ? (
              <ul>
                {convs.data!.conversations.map((c) => (
                  <li key={c.key}>
                    <button onClick={() => setParams({ with: c.with?.id })} className={cn('flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-sand-50', active === String(c.with?.id) && 'bg-rk-50')}>
                      <Avatar name={c.with?.name} color={c.with?.avatarColor} size={40} />
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1 truncate text-sm font-semibold">{c.with?.name} {c.with?.verified && c.with?.role !== 'user' && <BadgeCheck className="h-3.5 w-3.5 shrink-0 text-safe-600" />}</p>
                        <p className="truncate text-xs text-ink-mute">{c.last.fromMe ? 'You: ' : ''}{c.last.text || (c.last.attachments ? '📎 Attachment' : '')}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[11px] text-ink-mute">{timeAgo(c.last.at)}</p>
                        {c.unread > 0 && <span className="mt-1 inline-block rounded-full bg-rk-600 px-1.5 text-[11px] font-bold text-white">{c.unread}</span>}
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState icon={<MessageCircle className="h-6 w-6" />} title="No conversations" body="When a lawyer, NGO or counsellor works with you, you can chat here." />
            )}
          </div>
        </aside>
        <section className={cn('flex min-h-0 flex-col', !active && 'hidden md:flex')}>
          {active ? <Thread userId={active} onBack={() => setParams({})} /> : <div className="grid flex-1 place-items-center text-sm text-ink-mute">Select a conversation</div>}
        </section>
      </Card>
    </div>
  );
}

function Thread({ userId, onBack }: { userId: string; onBack: () => void }) {
  const { user } = useAuth();
  const socket = useSocket();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['thread', userId], queryFn: () => get<{ messages: any[]; with: any; canReply: boolean }>(`/messages/with/${userId}`) });
  const evidence = useQuery({ queryKey: ['evidence', 'all'], queryFn: () => get<{ items: any[] }>('/evidence'), enabled: user?.role === 'user' });
  const [text, setText] = useState('');
  const [typing, setTyping] = useState(false);
  const [attach, setAttach] = useState<string[]>([]);
  const [pick, setPick] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const lastTyping = useRef(0);

  useEffect(() => {
    post(`/messages/with/${userId}/read`).then(() => qc.invalidateQueries({ queryKey: ['conversations'] })).catch(() => undefined);
  }, [userId, q.data?.messages.length, qc]);
  useEffect(() => end.current?.scrollIntoView({ behavior: 'smooth' }), [q.data?.messages.length]);
  useEffect(() => {
    if (!socket) return;
    const onNew = (m: any) => {
      if (String(m.from) === userId || String(m.to) === userId) qc.invalidateQueries({ queryKey: ['thread', userId] });
    };
    const onRead = (e: any) => e.by === userId && qc.invalidateQueries({ queryKey: ['thread', userId] });
    let t: number;
    const onTyping = (e: any) => {
      if (e.from !== userId) return;
      setTyping(true);
      clearTimeout(t);
      t = window.setTimeout(() => setTyping(false), 2500);
    };
    socket.on('message:new', onNew);
    socket.on('message:read', onRead);
    socket.on('chat:typing', onTyping);
    return () => {
      socket.off('message:new', onNew);
      socket.off('message:read', onRead);
      socket.off('chat:typing', onTyping);
    };
  }, [socket, userId, qc]);

  const send = useMutation({
    mutationFn: () => post('/messages', { to: userId, text: text.trim() || undefined, evidenceIds: attach.length ? attach : undefined }),
    onSuccess: () => {
      setText('');
      setAttach([]);
      qc.invalidateQueries({ queryKey: ['thread', userId] });
      qc.invalidateQueries({ queryKey: ['conversations'] });
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const block = useMutation({ mutationFn: () => post(`/users/${userId}/block`), onSuccess: () => { toast.success('User blocked'); onBack(); } });
  const report = useMutation({ mutationFn: () => post('/community/reports', { targetType: 'user', targetId: userId, reason: 'harassment' }), onSuccess: (r) => toast.success(r._message) });

  const other = q.data?.with;
  return (
    <>
      <header className="flex items-center gap-3 border-b border-sand-200 px-4 py-3">
        <button className="md:hidden" onClick={onBack} aria-label="Back"><ArrowLeft className="h-5 w-5" /></button>
        <Avatar name={other?.name} color={other?.avatarColor} size={36} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{other?.name}</p>
          <p className="text-xs text-ink-mute">{typing ? 'typing…' : other ? humanize(other.role) : ''}</p>
        </div>
        <button onClick={() => confirm('Report this user to moderators?') && report.mutate()} className="rounded-lg p-2 text-ink-mute hover:bg-sand-100" aria-label="Report user"><Flag className="h-4 w-4" /></button>
        <button onClick={() => confirm('Block this user? They will not be able to message you.') && block.mutate()} className="rounded-lg p-2 text-ink-mute hover:bg-sand-100" aria-label="Block user"><Ban className="h-4 w-4" /></button>
      </header>
      <div className="flex-1 space-y-2 overflow-y-auto bg-sand-50 px-4 py-4">
        <p className="mx-auto mb-3 flex w-fit items-center gap-1.5 rounded-full bg-white px-3 py-1 text-xs text-ink-mute shadow-sm"><Lock className="h-3 w-3" /> Only you and {other?.name?.split(' ')[0] || 'them'} can read this conversation</p>
        {q.isLoading && <Spinner />}
        {(q.data?.messages || []).map((m) => {
          const mine = String(m.from) === user?._id;
          return (
            <div key={m._id} className={cn('flex', mine ? 'justify-end' : 'justify-start')}>
              <div className={cn('max-w-[78%] rounded-2xl px-3.5 py-2 text-[15px] shadow-sm', mine ? 'rounded-br-md bg-rk-600 text-white' : 'rounded-bl-md bg-white text-ink')}>
                {m.text && <p className="whitespace-pre-wrap">{m.text}</p>}
                {(m.attachments || []).map((a: any) => <p key={a.evidence} className={cn('mt-1 flex items-center gap-1 text-xs', mine ? 'text-white/85' : 'text-ink-mute')}><Paperclip className="h-3 w-3" /> {a.name} (shared from Evidence Vault)</p>)}
                <p className={cn('mt-0.5 flex items-center justify-end gap-1 text-[10px]', mine ? 'text-white/70' : 'text-ink-mute')}>
                  {new Date(m.createdAt).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}
                  {mine && (m.readAt ? <CheckCheck className="h-3 w-3" aria-label="Read" /> : <Check className="h-3 w-3" aria-label="Sent" />)}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={end} />
      </div>
      {q.data?.canReply === false ? (
        <p className="border-t border-sand-200 px-4 py-3 text-center text-sm text-ink-mute">You can no longer reply to this conversation.</p>
      ) : (
        <form
          className="flex items-end gap-2 border-t border-sand-200 p-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (text.trim() || attach.length) send.mutate();
          }}
        >
          {user?.role === 'user' && (
            <button type="button" onClick={() => setPick(true)} className={cn('rounded-xl p-2.5 text-ink-mute hover:bg-sand-100', attach.length && 'text-rk-600')} aria-label="Attach evidence">
              <Paperclip className="h-5 w-5" />
            </button>
          )}
          <textarea
            rows={1}
            className="input max-h-32 min-h-[44px] flex-1 resize-none"
            placeholder={attach.length ? `${attach.length} attachment(s) — add a message` : 'Write a message…'}
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              if (socket && Date.now() - lastTyping.current > 1500) {
                lastTyping.current = Date.now();
                socket.emit('chat:typing', { to: userId });
              }
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (text.trim() || attach.length) send.mutate();
              }
            }}
            aria-label="Message"
          />
          <Button type="submit" loading={send.isPending} aria-label="Send" className="h-11 w-11 px-0"><Send className="h-4 w-4" /></Button>
        </form>
      )}
      <Modal open={pick} onClose={() => setPick(false)} title="Share from your Evidence Vault" footer={<Button onClick={() => setPick(false)}>Done</Button>}>
        <p className="mb-3 text-sm text-ink-mute">The recipient gets access to the selected files. You can revoke it later from the vault.</p>
        <div className="space-y-2">
          {(evidence.data?.items || []).map((e) => (
            <label key={e._id} className="flex items-center gap-2 rounded-lg border border-sand-200 p-2.5 text-sm">
              <input type="checkbox" className="accent-rk-600" checked={attach.includes(e._id)} onChange={() => setAttach(attach.includes(e._id) ? attach.filter((x) => x !== e._id) : [...attach, e._id].slice(0, 5))} />
              {e.title}
            </label>
          ))}
        </div>
      </Modal>
    </>
  );
}
