import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Bell, BellRing, CalendarClock, CheckCheck, FileText, Gavel, HandCoins, Landmark, MessageCircle, ShieldCheck, Siren } from 'lucide-react';
import { get, post } from '@/api/client';
import { Badge, Button, Card, EmptyState, PageHeader, QueryState } from '@/components/ui';
import { cn, timeAgo } from '@/utils/format';

const ICON: Record<string, any> = {
  sos: Siren,
  sos_update: Siren,
  emergency_contact: ShieldCheck,
  case_request: Gavel,
  case_accepted: Gavel,
  case_update: Gavel,
  message: MessageCircle,
  appointment: CalendarClock,
  appointment_reminder: CalendarClock,
  complaint_update: FileText,
  hearing_reminder: CalendarClock,
  scheme_update: Landmark,
  donation: HandCoins,
  campaign: HandCoins,
  loan: HandCoins,
  verification: ShieldCheck,
};

export default function Notifications() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['notifications'], queryFn: () => get<{ items: any[]; unread: number }>('/notifications') });
  const readAll = useMutation({ mutationFn: () => post('/notifications/read-all'), onSuccess: () => qc.invalidateQueries({ queryKey: ['notifications'] }) });
  const read = useMutation({ mutationFn: (id: string) => post(`/notifications/${id}/read`), onSuccess: () => qc.invalidateQueries({ queryKey: ['notifications'] }) });
  const canPush = typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default';
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title="Notifications"
        subtitle={q.data ? `${q.data.unread} unread` : undefined}
        action={
          <>
            {canPush && <Button variant="outline" icon={<BellRing className="h-4 w-4" />} onClick={() => Notification.requestPermission()}>Enable device alerts</Button>}
            <Button variant="ghost" icon={<CheckCheck className="h-4 w-4" />} onClick={() => readAll.mutate()}>Mark all read</Button>
          </>
        }
      />
      <QueryState q={q} isEmpty={!q.data?.items.length} empty={<Card><EmptyState icon={<Bell className="h-6 w-6" />} title="Nothing yet" body="SOS updates, case activity, reminders and messages will appear here." /></Card>}>
        <Card>
          <ul className="divide-y divide-sand-200">
            {(q.data?.items || []).map((n) => {
              const I = ICON[n.type] || Bell;
              return (
                <li key={n._id}>
                  <Link to={n.link || '#'} onClick={() => !n.read && read.mutate(n._id)} className={cn('flex gap-3 px-5 py-4 hover:bg-sand-50', !n.read && 'bg-rk-50/40')}>
                    <span className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl', n.priority === 'critical' ? 'bg-rk-600 text-white' : 'bg-sand-100 text-ink-soft')}><I className="h-5 w-5" /></span>
                    <div className="min-w-0 flex-1">
                      <p className={cn('text-[15px]', !n.read && 'font-semibold')}>{n.title}</p>
                      {n.body && <p className="text-sm text-ink-mute">{n.body}</p>}
                      <p className="mt-1 flex items-center gap-2 text-xs text-ink-mute">
                        {timeAgo(n.createdAt)}
                        {(n.deliveries || []).filter((d: any) => d.channel !== 'in_app').map((d: any, i: number) => <Badge key={i} tone={d.status === 'sent' ? 'safe' : 'neutral'} className="text-[10px]">{d.channel}: {d.status}</Badge>)}
                      </p>
                    </div>
                    {!n.read && <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-rk-600" aria-label="Unread" />}
                  </Link>
                </li>
              );
            })}
          </ul>
        </Card>
      </QueryState>
    </div>
  );
}
