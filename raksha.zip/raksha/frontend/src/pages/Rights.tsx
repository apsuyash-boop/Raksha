import { Fragment, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Bookmark, BookmarkCheck, BookOpen, Clock, ExternalLink, Phone, Search } from 'lucide-react';
import { get } from '@/api/client';
import { useI18n } from '@/contexts/I18nContext';
import { Badge, Button, Card, EmptyState, QueryState } from '@/components/ui';
import { cn, humanize } from '@/utils/format';

const CATS: Array<[string, string]> = [
  ['', 'All topics'],
  ['domestic_violence', 'Domestic violence'],
  ['dowry', 'Dowry'],
  ['workplace_harassment', 'Workplace harassment'],
  ['divorce', 'Divorce'],
  ['maintenance', 'Maintenance'],
  ['child_custody', 'Child custody'],
  ['womens_protection', "Women's protection"],
];

function useBookmarks() {
  const [b, setB] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('rk_bookmarks') || '[]');
    } catch {
      return [];
    }
  });
  const toggle = (slug: string) => {
    const next = b.includes(slug) ? b.filter((x) => x !== slug) : [...b, slug];
    setB(next);
    try {
      localStorage.setItem('rk_bookmarks', JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };
  return { bookmarks: b, toggle };
}

/** Minimal, safe renderer for the library's markdown-lite (## headings, - bullets, paragraphs). No HTML is injected. */
function Body({ text }: { text: string }) {
  const blocks = text.split(/\n\n+/);
  return (
    <div className="prose-rk">
      {blocks.map((b, i) => {
        if (b.startsWith('## ')) return <h2 key={i}>{b.slice(3)}</h2>;
        const lines = b.split('\n');
        if (lines[0].startsWith('## '))
          return (
            <Fragment key={i}>
              <h2>{lines[0].slice(3)}</h2>
              {lines.slice(1).every((l) => l.startsWith('- ')) ? (
                <ul>{lines.slice(1).map((l, j) => <li key={j}>{l.slice(2)}</li>)}</ul>
              ) : (
                <p>{lines.slice(1).join(' ')}</p>
              )}
            </Fragment>
          );
        if (lines.every((l) => l.startsWith('- '))) return <ul key={i}>{lines.map((l, j) => <li key={j}>{l.slice(2)}</li>)}</ul>;
        return <p key={i}>{b}</p>;
      })}
    </div>
  );
}

function Article({ slug }: { slug: string }) {
  const { lang, t } = useI18n();
  const [viewLang, setViewLang] = useState(lang);
  useEffect(() => setViewLang(lang), [lang]);
  const { bookmarks, toggle } = useBookmarks();
  const q = useQuery({ queryKey: ['right', slug, viewLang], queryFn: () => get<{ article: any }>(`/rights/${slug}`, { lang: viewLang }) });
  const a = q.data?.article;
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-0">
      <Link to="/rights" className="mb-6 inline-flex items-center gap-1 text-sm font-semibold text-rk-700">
        <ArrowLeft className="h-4 w-4" /> Rights library
      </Link>
      <QueryState q={q}>
        {a && (
          <article>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="rk">{humanize(a.category)}</Badge>
              <span className="flex items-center gap-1 text-sm text-ink-mute">
                <Clock className="h-3.5 w-3.5" /> {a.readMinutes} min read
              </span>
              <div className="ml-auto flex gap-1.5">
                {a.availableLanguages.map((l: string) => (
                  <button key={l} onClick={() => setViewLang(l)} className={cn('chip py-1 text-xs', a.lang === l && 'chip-active')}>
                    {l === 'hi' ? 'हिन्दी' : l === 'en' ? 'English' : l}
                  </button>
                ))}
                <button onClick={() => toggle(slug)} className="chip py-1 text-xs" aria-pressed={bookmarks.includes(slug)}>
                  {bookmarks.includes(slug) ? <BookmarkCheck className="h-3.5 w-3.5 text-rk-600" /> : <Bookmark className="h-3.5 w-3.5" />} {bookmarks.includes(slug) ? 'Saved' : 'Save'}
                </button>
              </div>
            </div>
            <h1 className={cn('mt-4 text-3xl font-semibold sm:text-4xl', a.lang === 'hi' && 'font-deva')}>{a.title}</h1>
            <p className="mt-3 text-lg text-ink-soft">{a.summary}</p>
            <Card className="mt-6 border-rk-100 bg-rk-50/50 p-5">
              <p className="text-sm font-semibold text-rk-800">Key points</p>
              <ul className="mt-2 space-y-1.5 text-[15px] text-ink-soft">
                {(a.keyPoints || []).map((k: string) => (
                  <li key={k} className="flex gap-2">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-rk-500" /> {k}
                  </li>
                ))}
              </ul>
            </Card>
            <div className="mt-6">
              <Body text={a.body || ''} />
            </div>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              <Card className="p-5">
                <p className="text-sm font-semibold">Laws referenced</p>
                <ul className="mt-2 space-y-1 text-sm text-ink-mute">{(a.laws || []).map((l: string) => <li key={l}>{l}</li>)}</ul>
              </Card>
              <Card className="p-5">
                <p className="text-sm font-semibold">Helplines</p>
                <ul className="mt-2 space-y-1.5 text-sm">
                  {(a.helplines || []).map((h: any) => (
                    <li key={h.name} className="flex items-center gap-2">
                      <Phone className="h-3.5 w-3.5 text-rk-600" /> {h.name}: {/^\d+$/.test(h.number) ? <a href={`tel:${h.number}`} className="font-semibold text-rk-700">{h.number}</a> : <span className="font-semibold">{h.number}</span>}
                    </li>
                  ))}
                </ul>
              </Card>
            </div>
            {(a.sources || []).length > 0 && (
              <p className="mt-6 text-sm text-ink-mute">
                Sources:{' '}
                {a.sources.map((s: any, i: number) => (
                  <a key={s.url} href={s.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-0.5 underline">
                    {s.title}
                    <ExternalLink className="h-3 w-3" />
                    {i < a.sources.length - 1 ? ', ' : ''}
                  </a>
                ))}
              </p>
            )}
            <p className="mt-8 rounded-xl bg-sand-100 p-4 text-sm text-ink-soft">{t('disclaimer.legal')}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Link to="/legal-help">
                <Button>Talk to a verified lawyer</Button>
              </Link>
              <Link to="/counselling">
                <Button variant="outline">Free legal-advice session</Button>
              </Link>
            </div>
          </article>
        )}
      </QueryState>
    </div>
  );
}

export default function Rights() {
  const { slug } = useParams();
  const { lang, t } = useI18n();
  const [cat, setCat] = useState('');
  const [query, setQuery] = useState('');
  const [onlySaved, setOnlySaved] = useState(false);
  const { bookmarks } = useBookmarks();
  const q = useQuery({ queryKey: ['rights', cat, query, lang], queryFn: () => get<{ items: any[]; disclaimer: string }>('/rights', { category: cat || undefined, q: query || undefined, lang }) });
  if (slug) return <Article slug={slug} />;
  const items = (q.data?.items || []).filter((a) => !onlySaved || bookmarks.includes(a.slug));

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-0">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">Rights library</p>
        <h1 className="mt-2 text-3xl font-semibold sm:text-4xl">Know your rights, in simple words</h1>
        <p className="mt-3 text-ink-mute">The laws that protect you — explained clearly in English and Hindi. Built to support more Indian languages.</p>
      </div>
      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
          <input className="input pl-10" placeholder="Search e.g. 'stridhan', 'POSH', 'maintenance'" value={query} onChange={(e) => setQuery(e.target.value)} aria-label={t('common.search')} />
        </div>
        <button className={cn('chip justify-center', onlySaved && 'chip-active')} onClick={() => setOnlySaved(!onlySaved)} aria-pressed={onlySaved}>
          <Bookmark className="h-4 w-4" /> Saved ({bookmarks.length})
        </button>
      </div>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {CATS.map(([v, l]) => (
          <button key={v} className={cn('chip whitespace-nowrap', cat === v && 'chip-active')} onClick={() => setCat(v)}>
            {l}
          </button>
        ))}
      </div>
      <div className="mt-6">
        <QueryState q={q} isEmpty={!items.length} empty={<EmptyState icon={<BookOpen className="h-6 w-6" />} title="Nothing found" body="Try another word or topic." />}>
          <div className="grid gap-4 md:grid-cols-2">
            {items.map((a) => (
              <Link key={a.slug} to={`/rights/${a.slug}`} className="card group flex flex-col p-6 transition hover:-translate-y-0.5 hover:shadow-lift">
                <div className="flex items-center gap-2">
                  <Badge tone="rk">{humanize(a.category)}</Badge>
                  {bookmarks.includes(a.slug) && <BookmarkCheck className="h-4 w-4 text-rk-600" />}
                  <span className="ml-auto text-xs text-ink-mute">{a.readMinutes} min</span>
                </div>
                <h2 className={cn('mt-3 text-xl font-semibold group-hover:text-rk-700', a.lang === 'hi' && 'font-deva')}>{a.title}</h2>
                <p className="mt-2 line-clamp-3 text-sm text-ink-mute">{a.summary}</p>
                <p className="mt-auto pt-4 text-xs text-ink-mute">{(a.laws || [])[0]}</p>
              </Link>
            ))}
          </div>
        </QueryState>
      </div>
      <p className="mt-8 rounded-xl bg-sand-100 p-4 text-sm text-ink-soft">{t('disclaimer.legal')}</p>
    </div>
  );
}
