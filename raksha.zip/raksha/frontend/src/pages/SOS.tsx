import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { AlertTriangle, Camera, CheckCircle2, Clock, History, Mic, MicOff, MapPin, MessageSquare, Phone, Radio, ShieldCheck, Square, Video, Wifi, WifiOff } from 'lucide-react';
import { api, apiError, get, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { useSocket } from '@/contexts/SocketContext';
import { useI18n } from '@/contexts/I18nContext';
import { getCurrentPosition, useBattery, useGeolocation } from '@/hooks/useGeolocation';
import { useSegmentRecorder } from '@/hooks/useRecorder';
import { SOSButton } from '@/components/SOSButton';
import { MapView } from '@/components/MapView';
import { Step, Timeline } from '@/components/Timeline';
import { Badge, Button, Card, CardHeader, Input, Modal, Select, Spinner, Switch, Textarea } from '@/components/ui';
import { cn, fmtDate, humanize, timeAgo } from '@/utils/format';
import type { SOSAlert } from '@/types';

const DELIVERY_LABEL: Record<string, { label: string; tone: 'safe' | 'warn' | 'rk' | 'neutral' }> = {
  sent: { label: 'Delivered to provider', tone: 'safe' },
  simulated: { label: 'Simulated (demo)', tone: 'warn' },
  not_configured: { label: 'Channel not configured', tone: 'neutral' },
  failed: { label: 'Failed', tone: 'rk' },
  skipped: { label: 'Skipped', tone: 'neutral' },
};

const EMERGENCY_LABEL: Record<string, string> = {
  confirmed: 'Emergency services confirmed receipt',
  pending: 'Sent to emergency services — awaiting confirmation',
  simulated: 'Demo — emergency services were NOT contacted',
  not_configured: 'Emergency-service integration not configured — call 112 yourself if you can',
  failed: 'Could not reach emergency services integration — call 112',
};

function buildSteps(a: SOSAlert, recording: boolean): Step[] {
  const find = (s: string) => a.timeline.find((t) => t.step === s);
  const end = find('cancelled') || find('resolved');
  const steps: Step[] = [
    { key: 'activated', label: 'SOS Activated', at: find('activated')?.at, state: 'done', detail: a.isDemo ? 'Demo — simulated' : undefined },
    { key: 'contacts', label: 'Contacts Alerted', at: find('contacts_alerted')?.at, state: find('contacts_alerted') ? 'done' : 'current', detail: find('contacts_alerted')?.label },
    { key: 'responders', label: 'Responders Notified', at: find('responders_notified')?.at, state: find('responders_notified') ? 'done' : 'current', detail: find('responders_notified')?.label },
    {
      key: 'recording',
      label: 'Evidence Recording',
      at: find('recording_started')?.at,
      state: recording ? 'current' : find('recording_started') ? 'done' : a.status === 'active' ? 'pending' : 'pending',
      detail: recording ? 'Recording in 20-second encrypted segments' : find('recording_started') ? find('recording_started')?.label : 'Not started',
    },
    { key: 'end', label: end?.step === 'cancelled' ? 'Cancelled — marked safe' : 'Emergency Resolved', at: end?.at, state: end ? 'done' : 'pending' },
  ];
  return steps;
}

function smsFallbackHref(lat?: number, lng?: number) {
  let numbers: string[] = [];
  try {
    numbers = JSON.parse(localStorage.getItem('rk_offline_contacts') || '[]').map((c: any) => c.phone);
  } catch {
    /* ignore */
  }
  const body = `SOS! I need help.${lat != null ? ` My location: https://maps.google.com/?q=${lat},${lng}` : ''} — sent from Raksha`;
  const sep = /iPhone|iPad|iPod/.test(navigator.userAgent) ? '&' : '?';
  return `sms:${numbers.join(',')}${sep}body=${encodeURIComponent(body)}`;
}

export default function SOSPage() {
  const { user, hasSafetyPin } = useAuth();
  const { t } = useI18n();
  const socket = useSocket();
  const qc = useQueryClient();
  const [params] = useSearchParams();
  const [message, setMessage] = useState('');
  const [practice, setPractice] = useState(!!user?.isDemo);
  const [pinOpen, setPinOpen] = useState<null | 'cancel' | 'resolve'>(null);
  const [pin, setPin] = useState('');
  const [pinErr, setPinErr] = useState('');
  const [failed, setFailed] = useState<{ lat?: number; lng?: number } | null>(null);
  const [shareOpen, setShareOpen] = useState(params.get('share') === '1');
  const [path, setPath] = useState<Array<[number, number]>>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const battery = useBattery();

  const activeQ = useQuery({ queryKey: ['sos', 'active'], queryFn: () => get<{ alert: SOSAlert | null }>('/sos/active'), refetchInterval: (q) => (q.state.data?.alert ? 8000 : false) });
  const historyQ = useQuery({ queryKey: ['sos', 'history'], queryFn: () => get<{ items: SOSAlert[] }>('/sos/history') });
  const config = useQuery({ queryKey: ['config'], queryFn: () => get<any>('/config'), staleTime: Infinity });
  const contactsQ = useQuery({ queryKey: ['contacts'], queryFn: () => get<{ contacts: any[] }>('/contacts') });
  const sharesQ = useQuery({ queryKey: ['shares'], queryFn: () => get<{ shares: any[] }>('/location/shares/active') });
  const alert = activeQ.data?.alert || null;
  const manualShare = (sharesQ.data?.shares || []).find((s) => s.reason !== 'sos');
  const active = alert?.status === 'active';

  /* ---------------------------- evidence recording ---------------------------- */
  const lastPos = useRef<{ lat: number; lng: number; accuracy?: number } | null>(null);
  const sosIdRef = useRef<string | null>(null);
  useEffect(() => {
    if (alert?.status === 'active') sosIdRef.current = alert._id;
  }, [alert]);
  const onSegment = useCallback(
    async (blob: Blob, meta: { kind: 'audio' | 'video'; startedAt: Date }) => {
      const sosId = sosIdRef.current; // keeps the last SOS id so the final segment is still linked
      const fd = new FormData();
      const ext = blob.type.includes('mp4') ? 'mp4' : blob.type.includes('ogg') ? 'ogg' : 'webm';
      fd.append('files', blob, `sos-${meta.kind}-${meta.startedAt.toISOString()}.${ext}`);
      if (sosId) fd.append('sosId', sosId);
      fd.append('category', 'sos_recording');
      fd.append('title', `SOS ${meta.kind} — ${meta.startedAt.toLocaleTimeString('en-IN')}`);
      fd.append('capturedAt', meta.startedAt.toISOString());
      if (lastPos.current) {
        fd.append('lat', String(lastPos.current.lat));
        fd.append('lng', String(lastPos.current.lng));
        if (lastPos.current.accuracy) fd.append('accuracy', String(lastPos.current.accuracy));
      }
      try {
        await api.post('/evidence', fd);
      } catch {
        toast.error('A recording segment could not be uploaded. Recording continues.');
      }
    },
    [],
  );
  const rec = useSegmentRecorder(onSegment);

  useEffect(() => {
    if (videoRef.current) videoRef.current.srcObject = rec.kind === 'video' && rec.state === 'recording' ? rec.stream.current : null;
  }, [rec.state, rec.kind, rec.stream]);

  const startRecording = async (kind: 'audio' | 'video') => {
    if (rec.state === 'recording') rec.stop();
    const ok = await rec.start(kind);
    if (sosIdRef.current) post(`/sos/${sosIdRef.current}/recording`, { kind, state: ok ? 'started' : 'denied' }).catch(() => undefined);
    if (!ok) toast.error(`${kind === 'video' ? 'Camera' : 'Microphone'} permission was not granted.`);
  };

  // Stop recording automatically when the SOS ends.
  useEffect(() => {
    if (!active && rec.state === 'recording') rec.stop();
  }, [active]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ------------------------------- live location ------------------------------ */
  const lastSent = useRef(0);
  const geo = useGeolocation(active || !!manualShare, (p) => {
    lastPos.current = p;
    setPath((prev) => [...prev.slice(-199), [p.lat, p.lng]]);
    const now = Date.now();
    if (now - lastSent.current < 5000) return;
    lastSent.current = now;
    const payload = { lat: p.lat, lng: p.lng, accuracy: p.accuracy, battery };
    if (socket?.connected) socket.emit('location:update', payload);
    else post('/location', payload).catch(() => undefined);
  });

  /* ---------------------------------- actions --------------------------------- */
  const activate = useMutation({
    mutationFn: async () => {
      const pos = await getCurrentPosition(6000);
      lastPos.current = pos;
      try {
        return await post<{ alert: SOSAlert; trackUrl: string }>('/sos', { confirm: true, lat: pos?.lat, lng: pos?.lng, accuracy: pos?.accuracy, message: message || undefined, simulate: practice || undefined, trigger: 'button' });
      } catch (e) {
        setFailed({ lat: pos?.lat, lng: pos?.lng });
        throw e;
      }
    },
    onSuccess: (d) => {
      setFailed(null);
      sosIdRef.current = d.alert._id;
      qc.setQueryData(['sos', 'active'], { alert: d.alert });
      qc.invalidateQueries({ queryKey: ['sos'] });
      toast.success(d.alert.isDemo ? 'Demo SOS activated — nothing real was sent' : 'SOS activated. Your contacts are being alerted.');
      try {
        navigator.vibrate?.([200, 100, 200]);
      } catch {
        /* ignore */
      }
      if (user?.privacy?.autoRecordEvidenceOnSOS !== false) setTimeout(() => startRecording('audio'), 300);
    },
    onError: (e) => toast.error(apiError(e).message + ' — use the SMS fallback below or call 112.'),
  });

  const endSos = useMutation({
    mutationFn: () => post<{ alert: SOSAlert }>(`/sos/${alert!._id}/${pinOpen}`, hasSafetyPin ? { pin } : { password: pin }),
    onSuccess: (d) => {
      rec.stop();
      setPinOpen(null);
      setPin('');
      toast.success(d._message || 'You are marked safe');
      qc.invalidateQueries({ queryKey: ['sos'] });
    },
    onError: (e) => setPinErr(apiError(e).message),
  });

  const steps = useMemo(() => (alert ? buildSteps(alert, rec.state === 'recording') : []), [alert, rec.state]);
  const loc = alert?.location?.coordinates;
  const here = geo.pos || (loc ? { lat: loc[1], lng: loc[0], accuracy: alert?.accuracy } : null);

  if (activeQ.isLoading) return <Spinner className="min-h-[50vh]" />;

  return (
    <div className="space-y-6">
      {!active ? (
        <>
          <div className="text-center">
            <h1 className="text-2xl font-semibold sm:text-3xl">Emergency SOS</h1>
            <p className="mx-auto mt-2 max-w-md text-ink-mute">Press and hold the button. Your contacts get your location instantly; nearby verified responders are asked to help; evidence starts recording.</p>
          </div>

          <Card className="relative overflow-hidden px-5 py-8">
            <div className="grain pointer-events-none absolute inset-0 opacity-50" aria-hidden />
            <div className="relative flex flex-col items-center">
              <SOSButton onActivate={() => activate.mutate()} disabled={activate.isPending} />
              {activate.isPending && <p className="mt-4 text-sm font-semibold text-rk-700">Sending your SOS…</p>}
              <div className="mt-6 grid w-full max-w-md gap-3">
                <Textarea placeholder="Optional message (e.g. 'Near the bus stop, red car')" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={500} className="min-h-[70px]" aria-label="Optional SOS message" />
                <div className="rounded-xl border border-sand-200 bg-white/80 px-4">
                  <Switch checked={practice} onChange={setPractice} disabled={!!user?.isDemo} label={t('sos.practice')} description={user?.isDemo ? 'Demo accounts are always simulated.' : 'Test how SOS works without alerting anyone for real.'} />
                </div>
              </div>
              <div className="mt-5 flex flex-wrap justify-center gap-2 text-xs text-ink-mute">
                <span className="chip py-1">{(contactsQ.data?.contacts.length ?? 0) > 0 ? <CheckCircle2 className="h-3.5 w-3.5 text-safe-600" /> : <AlertTriangle className="h-3.5 w-3.5 text-warn-700" />} {contactsQ.data?.contacts.length ?? 0} emergency contacts</span>
                <span className="chip py-1">{hasSafetyPin ? <CheckCircle2 className="h-3.5 w-3.5 text-safe-600" /> : <AlertTriangle className="h-3.5 w-3.5 text-warn-700" />} Safety PIN {hasSafetyPin ? 'set' : 'not set'}</span>
                <span className="chip py-1">{navigator.onLine ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5 text-rk-600" />} {navigator.onLine ? 'Online' : 'Offline'}</span>
              </div>
              {!contactsQ.isLoading && !contactsQ.data?.contacts.length && (
                <Link to="/emergency-contacts" className="mt-3 text-sm font-semibold text-rk-700 underline">
                  Add an emergency contact so someone is alerted
                </Link>
              )}
            </div>
          </Card>

          {failed && (
            <Card className="border-rk-200 bg-rk-50 p-5">
              <p className="font-semibold text-rk-800">We could not reach Raksha servers.</p>
              <p className="mt-1 text-sm text-ink-soft">Send an SMS to your contacts directly, or call for help now.</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <a href={smsFallbackHref(failed.lat, failed.lng)}>
                  <Button icon={<MessageSquare className="h-4 w-4" />}>Send SOS by SMS</Button>
                </a>
                <a href="tel:112">
                  <Button variant="danger" icon={<Phone className="h-4 w-4" />}>Call 112</Button>
                </a>
              </div>
            </Card>
          )}

          <div className="grid gap-3 sm:grid-cols-2">
            <a href="tel:112" className="card flex items-center gap-3 p-4 hover:shadow-lift">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-rk-600 text-white">
                <Phone className="h-5 w-5" />
              </span>
              <div>
                <p className="font-semibold">{t('sos.call112')}</p>
                <p className="text-sm text-ink-mute">Police, ambulance, fire</p>
              </div>
            </a>
            <a href="tel:181" className="card flex items-center gap-3 p-4 hover:shadow-lift">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-rk-50 text-rk-700">
                <Phone className="h-5 w-5" />
              </span>
              <div>
                <p className="font-semibold">{t('sos.call181')}</p>
                <p className="text-sm text-ink-mute">24×7 support for women</p>
              </div>
            </a>
          </div>

          <LocationShareCard open={shareOpen} setOpen={setShareOpen} share={manualShare} contacts={contactsQ.data?.contacts || []} here={geo.pos} geoStatus={geo.status} path={path} />
        </>
      ) : (
        <>
          <div className={cn('rounded-3xl p-6 text-white', alert!.isDemo ? 'bg-gradient-to-br from-amber-600 to-rk-700' : 'bg-gradient-to-br from-rk-600 to-rk-800')} role="alert">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[.16em] text-white/75">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-white" /> {alert!.isDemo ? 'Demo SOS — simulated' : 'SOS active'}
                </p>
                <p className="mt-1 font-display text-3xl font-semibold" style={{ color: 'white' }}>
                  Help is being alerted
                </p>
                <p className="mt-1 text-sm text-white/80">Started {timeAgo(alert!.createdAt)} · Stay somewhere safe and keep your phone with you.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <a href="tel:112">
                  <Button className="bg-white text-rk-800 hover:bg-rk-50" icon={<Phone className="h-4 w-4" />}>
                    Call 112
                  </Button>
                </a>
                <Button variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20 hover:text-white" onClick={() => { setPinErr(''); setPinOpen('cancel'); }}>
                  {t('sos.cancel')}
                </Button>
              </div>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-5">
            <div className="space-y-6 lg:col-span-3">
              <Card>
                <CardHeader title="Live location" subtitle={geo.status === 'denied' ? 'Location permission denied — contacts got your last known position' : here ? `Accuracy ±${Math.round(here.accuracy || 0)} m${battery != null ? ` · Battery ${battery}%` : ''}` : 'Locating…'} icon={<MapPin className="h-4 w-4" />} />
                <div className="p-4">
                  <MapView points={here ? [{ lat: here.lat, lng: here.lng, accuracy: here.accuracy, label: 'You' }] : []} path={path} height={280} />
                </div>
              </Card>

              <Card>
                <CardHeader
                  title="Evidence"
                  subtitle={rec.state === 'recording' ? `Recording ${rec.kind} · ${rec.segments} segment(s) saved to your vault` : 'Audio/video is saved in encrypted 20-second segments'}
                  icon={<Radio className="h-4 w-4" />}
                  action={rec.state === 'recording' ? <Badge tone="rk" icon={<span className="h-1.5 w-1.5 animate-pulse rounded-full bg-rk-600" />}>REC</Badge> : undefined}
                />
                <div className="space-y-4 p-5">
                  {rec.kind === 'video' && rec.state === 'recording' && <video ref={videoRef} autoPlay muted playsInline className="aspect-video w-full rounded-xl bg-ink object-cover" />}
                  <div className="flex flex-wrap gap-2">
                    {rec.state === 'recording' ? (
                      <Button variant="outline" onClick={() => rec.stop()} icon={<Square className="h-4 w-4" />}>
                        Stop recording
                      </Button>
                    ) : (
                      <Button variant="secondary" onClick={() => startRecording('audio')} icon={<Mic className="h-4 w-4" />}>
                        Record audio
                      </Button>
                    )}
                    <Button variant="secondary" onClick={() => startRecording('video')} icon={<Video className="h-4 w-4" />} disabled={rec.state === 'recording' && rec.kind === 'video'}>
                      Record video
                    </Button>
                  </div>
                  {(rec.state === 'denied' || rec.state === 'unsupported') && (
                    <p className="flex items-center gap-2 text-sm text-warn-700">
                      <MicOff className="h-4 w-4" /> {rec.state === 'denied' ? 'Permission was denied. You can allow it in your browser settings.' : 'Recording is not supported on this browser.'}
                    </p>
                  )}
                  <div className="rounded-xl bg-sand-100 p-3 text-sm text-ink-soft">
                    <p className="flex items-center gap-2 font-semibold">
                      <Camera className="h-4 w-4" /> Live streaming to Instagram / YouTube / Facebook
                    </p>
                    <p className="mt-1 text-ink-mute">
                      {config.data?.integrations?.streaming
                        ? 'Streaming server configured. Linked platforms will receive your stream.'
                        : 'Not configured on this server. Recordings are still saved securely to your Evidence Vault.'}
                    </p>
                  </div>
                </div>
              </Card>
            </div>

            <div className="space-y-6 lg:col-span-2">
              <Card>
                <CardHeader title="SOS timeline" icon={<Clock className="h-4 w-4" />} />
                <div className="p-5">
                  <Timeline steps={steps} timeOnly />
                </div>
              </Card>
              <Card>
                <CardHeader title="Who was alerted" icon={<ShieldCheck className="h-4 w-4" />} />
                <div className="space-y-3 p-5 text-sm">
                  {(alert!.contactDeliveries || []).length ? (
                    alert!.contactDeliveries!.map((d, i) => (
                      <div key={i} className="flex items-center justify-between gap-2">
                        <span>
                          <span className="font-semibold">{d.name}</span> <span className="text-ink-mute">· {d.channel.toUpperCase()}</span>
                        </span>
                        <Badge tone={DELIVERY_LABEL[d.status]?.tone || 'neutral'}>{DELIVERY_LABEL[d.status]?.label || d.status}</Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-ink-mute">No contact alerts recorded. Add emergency contacts so someone is notified.</p>
                  )}
                  <div className="border-t border-sand-200 pt-3">
                    <p className="font-semibold">Nearby responders</p>
                    <p className="text-ink-mute">
                      {(alert!.responders || []).length ? `${alert!.responders!.length} notified · ${alert!.responders!.filter((r) => ['accepted', 'arrived'].includes(r.status)).length} on the way` : 'None available nearby'}
                    </p>
                  </div>
                  <div className="border-t border-sand-200 pt-3">
                    <p className="font-semibold">Emergency services</p>
                    <p className="text-ink-mute">{EMERGENCY_LABEL[alert!.emergencyService?.status || 'not_configured']}</p>
                  </div>
                </div>
              </Card>
              <Button variant="safe" size="lg" className="w-full" icon={<ShieldCheck className="h-5 w-5" />} onClick={() => { setPinErr(''); setPinOpen('resolve'); }}>
                {t('sos.safe')}
              </Button>
            </div>
          </div>
        </>
      )}

      <Card>
        <CardHeader title="SOS history" icon={<History className="h-4 w-4" />} subtitle="Every activation and cancellation is logged" />
        <ul className="divide-y divide-sand-200">
          {(historyQ.data?.items || []).slice(0, 8).map((h) => (
            <li key={h._id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-sm">
              <div>
                <p className="font-semibold">{fmtDate(h.createdAt, true)}</p>
                <p className="text-ink-mute">{h.timeline.find((x) => x.step === 'contacts_alerted')?.label || '—'}</p>
              </div>
              <div className="flex gap-1.5">
                {h.isDemo && <Badge tone="warn">Demo</Badge>}
                <Badge tone={h.status === 'active' ? 'rk' : h.status === 'cancelled' ? 'neutral' : 'safe'}>{humanize(h.status)}</Badge>
              </div>
            </li>
          ))}
          {!historyQ.isLoading && !historyQ.data?.items.length && <li className="px-5 py-6 text-sm text-ink-mute">No SOS activations yet.</li>}
        </ul>
      </Card>

      <Modal
        open={!!pinOpen}
        onClose={() => setPinOpen(null)}
        title={pinOpen === 'cancel' ? 'Cancel SOS' : 'Mark yourself safe'}
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setPinOpen(null)}>
              Keep SOS active
            </Button>
            <Button variant="safe" loading={endSos.isPending} onClick={() => endSos.mutate()} disabled={!pin}>
              Confirm I am safe
            </Button>
          </>
        }
      >
        <p className="mb-4 text-[15px] text-ink-soft">{t('sos.areYouSafe')}</p>
        <Input
          label={hasSafetyPin ? 'Safety PIN' : 'Password (no safety PIN set)'}
          type="password"
          inputMode={hasSafetyPin ? 'numeric' : undefined}
          autoComplete="off"
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          error={pinErr}
          onKeyDown={(e) => e.key === 'Enter' && pin && endSos.mutate()}
        />
        {user?.isDemo && <p className="mt-2 text-xs text-ink-mute">Demo PIN: 2580</p>}
      </Modal>
    </div>
  );
}

function LocationShareCard({ open, setOpen, share, contacts, here, geoStatus, path }: { open: boolean; setOpen: (v: boolean) => void; share: any; contacts: any[]; here: any; geoStatus: string; path: Array<[number, number]> }) {
  const qc = useQueryClient();
  const [minutes, setMinutes] = useState('60');
  const [selected, setSelected] = useState<string[]>([]);
  const [trackUrl, setTrackUrl] = useState<string | null>(null);
  useEffect(() => setSelected(contacts.map((c) => c._id)), [contacts]);

  const start = useMutation({
    mutationFn: async () => {
      const p = await getCurrentPosition(6000);
      return post<{ trackUrl: string; deliveries: any[] }>('/location/share', { durationMinutes: Number(minutes), contactIds: selected, lat: p?.lat, lng: p?.lng, reason: 'journey' });
    },
    onSuccess: (d) => {
      setTrackUrl(d.trackUrl);
      toast.success(`Sharing live location with ${selected.length} contact(s)`);
      qc.invalidateQueries({ queryKey: ['shares'] });
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const stop = useMutation({
    mutationFn: () => post(`/location/share/${share._id}/stop`),
    onSuccess: () => {
      toast.success('Location sharing stopped');
      setTrackUrl(null);
      qc.invalidateQueries({ queryKey: ['shares'] });
    },
    onError: (e) => toast.error(apiError(e).message),
  });

  const remaining = share ? Math.max(0, Math.round((new Date(share.expiresAt).getTime() - Date.now()) / 60000)) : 0;

  return (
    <Card>
      <CardHeader
        title="Share live location"
        subtitle="Walking home, in a cab, or meeting someone new? Let trusted people follow your journey."
        icon={<MapPin className="h-4 w-4" />}
        action={!share && !open ? <Button size="sm" variant="secondary" onClick={() => setOpen(true)}>Start</Button> : undefined}
      />
      {share ? (
        <div className="space-y-4 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <Badge tone="warn" icon={<span className="h-1.5 w-1.5 animate-pulse rounded-full bg-warn-500" />}>Sharing</Badge>
              <p className="mt-2 text-sm text-ink-mute">
                With {(share.sharedWith || []).map((c: any) => c.name).join(', ') || 'your contacts'} · {remaining} min left
              </p>
            </div>
            <Button variant="outline" onClick={() => stop.mutate()} loading={stop.isPending}>
              Stop sharing
            </Button>
          </div>
          {trackUrl && (
            <p className="break-all rounded-xl bg-sand-100 p-3 text-xs text-ink-soft">
              Tracking link sent to contacts: <span className="font-mono">{trackUrl}</span>
            </p>
          )}
          {geoStatus === 'denied' && <p className="text-sm text-warn-700">Location permission is blocked — updates cannot be sent.</p>}
          <MapView points={here ? [{ lat: here.lat, lng: here.lng, accuracy: here.accuracy, label: 'You' }] : []} path={path} height={240} />
        </div>
      ) : open ? (
        <div className="space-y-4 p-5">
          <Select label="For how long?" value={minutes} onChange={(e) => setMinutes(e.target.value)} options={[['15', '15 minutes'], ['30', '30 minutes'], ['60', '1 hour'], ['120', '2 hours'], ['240', '4 hours'], ['480', '8 hours']]} />
          <div>
            <p className="label">Share with</p>
            {contacts.length ? (
              <div className="flex flex-wrap gap-2">
                {contacts.map((c) => (
                  <button key={c._id} type="button" onClick={() => setSelected(selected.includes(c._id) ? selected.filter((x) => x !== c._id) : [...selected, c._id])} className={cn('chip', selected.includes(c._id) && 'chip-active')} aria-pressed={selected.includes(c._id)}>
                    {c.name}
                  </button>
                ))}
              </div>
            ) : (
              <Link to="/emergency-contacts" className="text-sm font-semibold text-rk-700 underline">
                Add emergency contacts first
              </Link>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => start.mutate()} loading={start.isPending} disabled={!selected.length}>
              Start sharing
            </Button>
          </div>
        </div>
      ) : null}
    </Card>
  );
}
