import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { CheckCircle2, CircleHelp, ExternalLink, FileCheck2, Landmark, Search, XCircle } from 'lucide-react';
import { apiError, get, patch, post } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Badge, Button, Card, CardHeader, Input, Modal, PageHeader, QueryState, Select, Tabs } from '@/components/ui';
import { cn, humanize, INDIAN_STATES } from '@/utils/format';

const RESULT = {
  likely_eligible: { label: 'Likely eligible', tone: 'safe' as const, icon: CheckCircle2 },
  check_details: { label: 'Check details', tone: 'warn' as const, icon: CircleHelp },
  not_eligible: { label: 'Probably not eligible', tone: 'neutral' as const, icon: XCircle },
};
const APP_STATUS: Array<[string, string]> = [
  ['interested', 'Interested'],
  ['documents_ready', 'Documents ready'],
  ['applied', 'Applied'],
  ['under_review', 'Under review'],
  ['approved', 'Approved'],
  ['rejected', 'Rejected'],
  ['benefit_received', 'Benefit received'],
];

export default function Schemes() {
  const { user } = useAuth();
  const { lang } = useI18n();
  const qc = useQueryClient();
  const [tab, setTab] = useState<'check' | 'all' | 'mine'>('check');
  const [search, setSearch] = useState('');
  const [p, setP] = useState<any>({ state: user?.state || '', age: user?.age || '', gender: 'female', annualFamilyIncome: '', maritalStatus: '', employment: '', pregnantOrLactating: false, hasGirlChildUnder10: false, wantsToStartBusiness: false, isGovtEmployee: false, paysIncomeTax: false });
  const [detail, setDetail] = useState<any>(null);
  const all = useQuery({ queryKey: ['schemes', search], queryFn: () => get<{ schemes: any[] }>('/schemes', { q: search || undefined }) });
  const mine = useQuery({ queryKey: ['scheme-apps'], queryFn: () => get<{ applications: any[] }>('/schemes/applications/mine'), enabled: !!user });

  const check = useMutation({
    mutationFn: () => {
      const body: any = { gender: p.gender };
      if (p.state) body.state = p.state;
      if (p.age !== '') body.age = Number(p.age);
      if (p.annualFamilyIncome !== '') body.annualFamilyIncome = Number(p.annualFamilyIncome);
      if (p.maritalStatus) body.maritalStatus = p.maritalStatus;
      if (p.employment) body.employment = p.employment;
      for (const k of ['pregnantOrLactating', 'hasGirlChildUnder10', 'wantsToStartBusiness', 'isGovtEmployee', 'paysIncomeTax']) body[k] = !!p[k];
      return post<{ results: any[]; disclaimer: string }>('/schemes/eligibility', body);
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const track = useMutation({
    mutationFn: (id: string) => post(`/schemes/${id}/apply`),
    onSuccess: (r) => {
      toast.success(r._message);
      qc.invalidateQueries({ queryKey: ['scheme-apps'] });
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const update = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => patch(`/schemes/applications/${id}`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['scheme-apps'] }),
  });
  const name = (s: any) => (lang === 'hi' && s.nameHi ? s.nameHi : s.name);

  return (
    <div className="px-4 py-8 sm:px-0">
      <PageHeader eyebrow="Government schemes" title="Find support you may be entitled to" subtitle="Answer a few questions. We compare them with the official criteria for each scheme and link you to the official source to apply." />
      <Tabs value={tab} onChange={setTab} tabs={[['check', 'Eligibility checker'], ['all', 'All schemes'], ...(user ? ([['mine', `My applications (${mine.data?.applications.length ?? 0})`]] as Array<['mine', string]>) : [])]} className="mb-6 w-fit" />

      {tab === 'check' && (
        <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
          <Card className="h-fit p-5">
            <div className="space-y-4">
              <Select label="State of residence" value={p.state} onChange={(e) => setP({ ...p, state: e.target.value })} options={INDIAN_STATES.map((s) => [s, s])} placeholder="Select" />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Age" type="number" value={p.age} onChange={(e) => setP({ ...p, age: e.target.value })} />
                <Select label="Gender" value={p.gender} onChange={(e) => setP({ ...p, gender: e.target.value })} options={[['female', 'Female'], ['male', 'Male'], ['other', 'Other']]} />
              </div>
              <Input label="Annual family income (₹)" type="number" value={p.annualFamilyIncome} onChange={(e) => setP({ ...p, annualFamilyIncome: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Select label="Marital status" value={p.maritalStatus} onChange={(e) => setP({ ...p, maritalStatus: e.target.value })} options={[['single', 'Single'], ['married', 'Married'], ['widowed', 'Widowed'], ['divorced', 'Divorced'], ['separated', 'Separated / abandoned']]} placeholder="Select" />
                <Select label="Work" value={p.employment} onChange={(e) => setP({ ...p, employment: e.target.value })} options={[['unemployed', 'Not working'], ['homemaker', 'Homemaker'], ['self_employed', 'Self-employed'], ['salaried', 'Salaried'], ['student', 'Student'], ['other', 'Other']]} placeholder="Select" />
              </div>
              <fieldset className="space-y-2 rounded-xl border border-sand-200 p-3 text-sm">
                <legend className="px-1 text-sm font-medium text-ink-soft">Family</legend>
                {[
                  ['pregnantOrLactating', 'I am pregnant or a nursing mother'],
                  ['hasGirlChildUnder10', 'I have a daughter under 10'],
                  ['wantsToStartBusiness', 'I want to start a business'],
                  ['isGovtEmployee', 'I am in regular government employment'],
                  ['paysIncomeTax', 'Someone in my family pays income tax'],
                ].map(([k, l]) => (
                  <label key={k} className="flex items-center gap-2">
                    <input type="checkbox" className="accent-rk-600" checked={!!p[k]} onChange={(e) => setP({ ...p, [k]: e.target.checked })} /> {l}
                  </label>
                ))}
              </fieldset>
              <Button className="w-full" onClick={() => check.mutate()} loading={check.isPending} icon={<Search className="h-4 w-4" />}>
                Check schemes
              </Button>
            </div>
          </Card>
          <div className="space-y-4">
            {!check.data ? (
              <Card className="p-8 text-center text-ink-mute">
                <Landmark className="mx-auto h-8 w-8 text-rk-400" />
                <p className="mt-3">Your results will appear here. We never invent rules — anything we cannot check is marked "check details".</p>
              </Card>
            ) : (
              <>
                <p className="rounded-xl bg-sand-100 p-3 text-sm text-ink-soft">{check.data.disclaimer}</p>
                {check.data.results.map((r) => {
                  const R = RESULT[r.result as keyof typeof RESULT];
                  return (
                    <Card key={r.scheme._id} className="p-5">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="text-lg font-semibold">{name(r.scheme)}</p>
                          <p className="text-sm text-ink-mute">{r.scheme.level === 'state' ? r.scheme.states.join(', ') : 'All India'} · {humanize(r.scheme.category)}</p>
                        </div>
                        <Badge tone={R.tone} icon={<R.icon className="h-3.5 w-3.5" />}>{R.label}</Badge>
                      </div>
                      <div className="mt-3 grid gap-3 text-sm sm:grid-cols-3">
                        {r.pass.length > 0 && <ul className="space-y-1 text-safe-700">{r.pass.map((x: string) => <li key={x}>✓ {x}</li>)}</ul>}
                        {r.fail.length > 0 && <ul className="space-y-1 text-rk-700">{r.fail.map((x: string) => <li key={x}>✕ {x}</li>)}</ul>}
                        {r.unknown.length > 0 && <ul className="space-y-1 text-warn-700">{r.unknown.map((x: string) => <li key={x}>? {x}</li>)}</ul>}
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button size="sm" variant="outline" onClick={() => setDetail(r.scheme)}>Details</Button>
                        {user && r.result !== 'not_eligible' && <Button size="sm" onClick={() => track.mutate(r.scheme._id)}>Track application</Button>}
                      </div>
                    </Card>
                  );
                })}
              </>
            )}
          </div>
        </div>
      )}

      {tab === 'all' && (
        <div>
          <div className="relative mb-4">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input className="input pl-10" placeholder="Search schemes" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <QueryState q={all}>
            <div className="grid gap-4 md:grid-cols-2">
              {(all.data?.schemes || []).map((s) => (
                <button key={s._id} onClick={() => setDetail(s)} className="card p-5 text-left transition hover:shadow-lift">
                  <div className="flex items-center gap-2">
                    <Badge tone="rk">{humanize(s.category)}</Badge>
                    <Badge>{s.level === 'state' ? s.states.join(', ') : 'Central'}</Badge>
                  </div>
                  <p className="mt-3 text-lg font-semibold">{name(s)}</p>
                  <p className="mt-1 line-clamp-2 text-sm text-ink-mute">{lang === 'hi' && s.descriptionHi ? s.descriptionHi : s.description}</p>
                </button>
              ))}
            </div>
          </QueryState>
        </div>
      )}

      {tab === 'mine' && (
        <QueryState q={mine} isEmpty={!mine.data?.applications.length} empty={<Card className="p-8 text-center text-ink-mute">You are not tracking any schemes yet.</Card>}>
          <div className="space-y-4">
            {(mine.data?.applications || []).map((a) => (
              <Card key={a._id}>
                <CardHeader title={a.scheme?.name} subtitle={a.applicationRef ? `Ref ${a.applicationRef}` : undefined} icon={<FileCheck2 className="h-4 w-4" />} action={<Select aria-label="Status" value={a.status} onChange={(e) => update.mutate({ id: a._id, body: { status: e.target.value } })} options={APP_STATUS} className="w-auto py-1.5 text-sm" />} />
                <div className="grid gap-4 p-5 md:grid-cols-2">
                  <div>
                    <p className="mb-2 text-sm font-semibold">Document checklist</p>
                    <ul className="space-y-1.5">
                      {(a.checklist || []).map((c: any, i: number) => (
                        <li key={i}>
                          <label className="flex items-start gap-2 text-sm">
                            <input type="checkbox" className="mt-0.5 accent-rk-600" checked={c.done} onChange={() => update.mutate({ id: a._id, body: { checklist: a.checklist.map((x: any, j: number) => ({ item: x.item, done: j === i ? !x.done : x.done })) } })} />
                            <span className={cn(c.done && 'text-ink-mute line-through')}>{c.item}</span>
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="space-y-3">
                    <Input label="Application reference" defaultValue={a.applicationRef || ''} onBlur={(e) => e.target.value !== (a.applicationRef || '') && update.mutate({ id: a._id, body: { applicationRef: e.target.value } })} />
                    {a.scheme?.officialUrl && (
                      <a href={a.scheme.officialUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm font-semibold text-rk-700 underline">
                        Official website <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </QueryState>
      )}

      <Modal open={!!detail} onClose={() => setDetail(null)} title={detail ? name(detail) : ''} size="lg" footer={detail && <><a href={detail.officialUrl} target="_blank" rel="noreferrer"><Button variant="outline" icon={<ExternalLink className="h-4 w-4" />}>Official source</Button></a>{user && <Button onClick={() => { track.mutate(detail._id); setDetail(null); }}>Track application</Button>}</>}>
        {detail && (
          <div className="space-y-5 text-[15px]">
            <p className="text-ink-soft">{lang === 'hi' && detail.descriptionHi ? detail.descriptionHi : detail.description}</p>
            {[
              ['Eligibility', detail.eligibility],
              ['Benefits', detail.benefits],
              ['Documents required', detail.documents],
            ].map(([t, list]: any) => (
              <div key={t}>
                <p className="font-semibold">{t}</p>
                <ul className="mt-1.5 list-disc space-y-1 pl-5 text-ink-soft">{(list || []).map((x: string) => <li key={x}>{x}</li>)}</ul>
              </div>
            ))}
            <div>
              <p className="font-semibold">How to apply</p>
              <p className="mt-1 text-ink-soft">{detail.applicationMethod}</p>
            </div>
            {detail.helpline && <p className="text-sm">Helpline: <a href={`tel:${detail.helpline}`} className="font-semibold text-rk-700">{detail.helpline}</a></p>}
            <p className="text-xs text-ink-mute">{detail.ministry} · {detail.sourceNote} {detail.lastVerifiedAt && `· Information last reviewed ${new Date(detail.lastVerifiedAt).toLocaleDateString('en-IN')}`}</p>
          </div>
        )}
      </Modal>
    </div>
  );
}
