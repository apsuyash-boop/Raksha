import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Download, Eye, KeyRound, Laptop, Lock, LogOut, ShieldCheck, Trash2, User as UserIcon } from 'lucide-react';
import { api, apiError, del, get, patch, post, put } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n, UI_LANGUAGES } from '@/contexts/I18nContext';
import { Badge, Button, Card, CardHeader, Input, Modal, PageHeader, Select, Switch } from '@/components/ui';
import { fmtDate, humanize, INDIAN_STATES, LANGS } from '@/utils/format';

export default function Settings() {
  const { user, refreshMe, hasSafetyPin, logout } = useAuth();
  const { lang, setLang } = useI18n();
  const nav = useNavigate();
  const qc = useQueryClient();
  const isWoman = user?.role === 'user';
  const [profile, setProfile] = useState({ name: user?.name || '', city: user?.city || '', state: user?.state || '', language: user?.language || 'en', age: user?.age ? String(user.age) : '' });
  const [pin, setPin] = useState({ pin: '', currentPassword: '' });
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '' });
  const [verify, setVerify] = useState<{ channel: 'email' | 'phone'; code: string } | null>(null);
  const [del1, setDel1] = useState(false);
  const [delForm, setDelForm] = useState({ password: '', confirm: '' });
  const medical = useQuery({ queryKey: ['medical'], queryFn: () => get<{ medical: any }>('/users/me/medical'), enabled: isWoman });
  const [med, setMed] = useState<any>({});
  useEffect(() => setMed(medical.data?.medical || {}), [medical.data]);
  const sessions = useQuery({ queryKey: ['sessions'], queryFn: () => get<{ sessions: any[] }>('/auth/sessions') });
  const access = useQuery({ queryKey: ['access-history'], queryFn: () => get<{ logs: any[] }>('/users/me/access-history') });

  const run = useMutation({
    mutationFn: (fn: () => Promise<any>) => fn(),
    onSuccess: async (r: any) => {
      toast.success(r?._message || 'Saved');
      await refreshMe();
      qc.invalidateQueries();
    },
    onError: (e) => toast.error(apiError(e).message),
  });

  useEffect(() => {
    if (window.location.hash) document.querySelector(window.location.hash)?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const privacy = user?.privacy;
  const setPrivacy = (k: string, v: any) => run.mutate(() => patch('/users/me/privacy', { [k]: v }));
  const setNotif = (k: string, v: boolean) => run.mutate(() => patch('/users/me/privacy', { notificationPrefs: { [k]: v } }));

  const exportData = async () => {
    try {
      const r = await api.get('/users/me/export');
      const blob = new Blob([JSON.stringify(r.data.data, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `raksha-data-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
    } catch (e) {
      toast.error(apiError(e).message);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title="Settings" subtitle="Your profile, safety, privacy and data." />

      <Card id="account">
        <CardHeader title="Profile" icon={<UserIcon className="h-4 w-4" />} />
        <div className="space-y-4 p-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Name" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
            {isWoman && <Input label="Age" type="number" value={profile.age} onChange={(e) => setProfile({ ...profile, age: e.target.value })} />}
            <Select label="State" value={profile.state} onChange={(e) => setProfile({ ...profile, state: e.target.value })} options={INDIAN_STATES.map((s) => [s, s])} placeholder="Select" />
            <Input label="City" value={profile.city} onChange={(e) => setProfile({ ...profile, city: e.target.value })} />
            <Select label="Preferred language" value={profile.language} onChange={(e) => setProfile({ ...profile, language: e.target.value })} options={LANGS} />
            <Select label="App display language" value={lang} onChange={(e) => setLang(e.target.value)} options={UI_LANGUAGES} />
          </div>
          <Button onClick={() => run.mutate(() => patch('/users/me', { ...profile, age: profile.age ? Number(profile.age) : undefined, state: profile.state || undefined }))} loading={run.isPending}>Save profile</Button>
          <div className="flex flex-wrap gap-3 border-t border-sand-200 pt-4 text-sm">
            {user?.email && <span className="flex items-center gap-2">{user.email} {user.emailVerified ? <Badge tone="safe">Verified</Badge> : <button className="font-semibold text-rk-700 underline" onClick={async () => { const r = await post<any>('/auth/verify/request', { channel: 'email' }).catch((e) => toast.error(apiError(e).message)); if (r) { setVerify({ channel: 'email', code: '' }); if (r.devCode) toast.info(`Development code: ${r.devCode}`); } }}>Verify</button>}</span>}
            {user?.phone && <span className="flex items-center gap-2">{user.phone} {user.phoneVerified ? <Badge tone="safe">Verified</Badge> : <button className="font-semibold text-rk-700 underline" onClick={async () => { const r = await post<any>('/auth/verify/request', { channel: 'phone' }).catch((e) => toast.error(apiError(e).message)); if (r) { setVerify({ channel: 'phone', code: '' }); if (r.devCode) toast.info(`Development code: ${r.devCode}`); } }}>Verify</button>}</span>}
          </div>
        </div>
      </Card>

      {isWoman && (
        <Card id="safety">
          <CardHeader title="Safety" icon={<ShieldCheck className="h-4 w-4" />} subtitle={hasSafetyPin ? 'Safety PIN is set' : 'Set a PIN so only you can cancel an SOS'} />
          <div className="space-y-5 p-5">
            <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
              <Input label={hasSafetyPin ? 'New safety PIN' : 'Safety PIN'} type="password" inputMode="numeric" maxLength={6} value={pin.pin} onChange={(e) => setPin({ ...pin, pin: e.target.value })} />
              <Input label="Your password" type="password" value={pin.currentPassword} onChange={(e) => setPin({ ...pin, currentPassword: e.target.value })} />
              <Button onClick={() => run.mutate(async () => { const r = await put('/users/me/safety-pin', pin); setPin({ pin: '', currentPassword: '' }); return r; })} icon={<KeyRound className="h-4 w-4" />}>Save PIN</Button>
            </div>
            <div className="divide-y divide-sand-200 rounded-xl border border-sand-200 px-4">
              <Switch checked={!!privacy?.autoRecordEvidenceOnSOS} onChange={(v) => setPrivacy('autoRecordEvidenceOnSOS', v)} label="Start audio recording automatically on SOS" />
              <Switch checked={!!privacy?.allowNearbyResponders} onChange={(v) => setPrivacy('allowNearbyResponders', v)} label="Alert verified responders near me" description="They see an approximate area until they accept to help." />
              <Switch checked={!!privacy?.shareLocationWithContacts} onChange={(v) => setPrivacy('shareLocationWithContacts', v)} label="Let linked contacts see my live location during SOS" />
              <Switch checked={!!privacy?.shareMedicalInfoInSOS} onChange={(v) => setPrivacy('shareMedicalInfoInSOS', v)} label="Share medical info with contacts during SOS" />
            </div>
            <div>
              <p className="label">Medical & safety information (encrypted)</p>
              <div className="grid gap-3 sm:grid-cols-2">
                {[['bloodGroup', 'Blood group'], ['allergies', 'Allergies'], ['conditions', 'Conditions'], ['medications', 'Medications']].map(([k, l]) => (
                  <Input key={k} label={l} value={med[k] || ''} onChange={(e) => setMed({ ...med, [k]: e.target.value })} />
                ))}
              </div>
              <Button variant="secondary" className="mt-3" onClick={() => run.mutate(() => put('/users/me/medical', med))}>Save medical info</Button>
            </div>
          </div>
        </Card>
      )}

      <Card id="privacy">
        <CardHeader title="Privacy & notifications" icon={<Lock className="h-4 w-4" />} />
        <div className="divide-y divide-sand-200 px-5">
          <div className="py-3">
            <Select label="Show me in the community as" value={privacy?.showInCommunityAs || 'first_name'} onChange={(e) => setPrivacy('showInCommunityAs', e.target.value)} options={[['first_name', 'First name only'], ['name', 'Full name'], ['anonymous', 'Always anonymous']]} />
          </div>
          {(['inApp', 'email', 'sms', 'whatsapp'] as const).map((k) => (
            <Switch key={k} checked={!!user?.notificationPrefs?.[k]} onChange={(v) => setNotif(k, v)} label={`${k === 'inApp' ? 'In-app' : humanize(k)} notifications`} description={k === 'sms' ? 'Used for important updates only (hearings, SOS).' : undefined} />
          ))}
        </div>
      </Card>

      <Card>
        <CardHeader title="Who accessed my information" icon={<Eye className="h-4 w-4" />} subtitle="Every time someone else views your evidence, case, SOS or location, it is logged here." />
        <ul className="max-h-80 divide-y divide-sand-200 overflow-y-auto">
          {(access.data?.logs || []).map((l) => (
            <li key={l._id} className="flex flex-wrap justify-between gap-2 px-5 py-3 text-sm">
              <span><span className="font-semibold">{l.actor?.name || (l.actorRole === 'public_link' ? 'Tracking link viewer' : 'System')}</span> <span className="text-ink-mute">({humanize(l.actor?.role || l.actorRole)})</span> — {humanize(l.action.replace('.', ' '))}</span>
              <span className="text-ink-mute">{fmtDate(l.createdAt, true)}</span>
            </li>
          ))}
          {!access.isLoading && !access.data?.logs.length && <li className="px-5 py-6 text-sm text-ink-mute">No one else has accessed your information.</li>}
        </ul>
      </Card>

      <Card>
        <CardHeader title="Security" icon={<Laptop className="h-4 w-4" />} />
        <div className="space-y-5 p-5">
          <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
            <Input label="Current password" type="password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />
            <Input label="New password" type="password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
            <Button variant="secondary" onClick={() => run.mutate(async () => { const r = await put('/users/me/password', pw); setPw({ currentPassword: '', newPassword: '' }); return r; })}>Change</Button>
          </div>
          <div>
            <p className="label">Active sessions</p>
            <ul className="space-y-2">
              {(sessions.data?.sessions || []).map((s) => (
                <li key={s._id} className="flex items-center justify-between gap-3 rounded-xl bg-sand-50 px-3 py-2 text-sm">
                  <span className="min-w-0 truncate">{(s.userAgent || 'Unknown device').slice(0, 70)} <span className="text-ink-mute">· {fmtDate(s.createdAt, true)}</span></span>
                  <button className="text-xs font-semibold text-rk-700" onClick={() => run.mutate(() => del(`/auth/sessions/${s._id}`))}>Revoke</button>
                </li>
              ))}
            </ul>
            <Button variant="ghost" className="mt-2" icon={<LogOut className="h-4 w-4" />} onClick={async () => { await post('/auth/sessions/revoke-all'); await logout(); nav('/login'); }}>Sign out of all devices</Button>
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader title="Your data" icon={<Download className="h-4 w-4" />} />
        <div className="flex flex-wrap gap-3 p-5">
          <Button variant="outline" icon={<Download className="h-4 w-4" />} onClick={exportData}>Export my data (JSON)</Button>
          <Button variant="ghost" className="text-rk-700" icon={<Trash2 className="h-4 w-4" />} onClick={() => setDel1(true)}>Delete my account</Button>
        </div>
      </Card>

      <Modal open={!!verify} onClose={() => setVerify(null)} title={`Verify your ${verify?.channel}`} size="sm" footer={<Button onClick={() => run.mutate(async () => { const r = await post('/auth/verify/confirm', verify); setVerify(null); return r; })}>Verify</Button>}>
        <Input label="6-digit code" inputMode="numeric" maxLength={6} value={verify?.code || ''} onChange={(e) => setVerify(verify && { ...verify, code: e.target.value.replace(/\D/g, '') })} />
      </Modal>
      <Modal open={del1} onClose={() => setDel1(false)} title="Delete account permanently" size="sm" footer={<Button variant="danger" disabled={delForm.confirm !== 'DELETE'} onClick={async () => { try { await del('/users/me', delForm); toast.success('Your account was deleted'); await logout(); nav('/'); } catch (e) { toast.error(apiError(e).message); } }}>Delete everything</Button>}>
        <div className="space-y-4">
          <p className="text-sm text-ink-soft">This deletes your profile, contacts, evidence files, location history, messages and scheme tracking. Community posts are anonymised. Financial records required by law are kept without your identity. This cannot be undone — consider exporting your data first.</p>
          <Input label="Password" type="password" value={delForm.password} onChange={(e) => setDelForm({ ...delForm, password: e.target.value })} />
          <Input label='Type "DELETE" to confirm' value={delForm.confirm} onChange={(e) => setDelForm({ ...delForm, confirm: e.target.value })} />
        </div>
      </Modal>
    </div>
  );
}
