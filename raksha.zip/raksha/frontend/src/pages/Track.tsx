import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Battery, ExternalLink, MapPin, Phone, ShieldCheck, Siren } from 'lucide-react';
import { get } from '@/api/client';
import { Logo } from '@/components/Brand';
import { MapView } from '@/components/MapView';
import { Badge, Button, Card, ErrorState, Spinner } from '@/components/ui';
import { fmtDate, timeAgo } from '@/utils/format';

/** Public live-tracking page for emergency contacts who don't have a Raksha account. Token-gated, expires automatically. */
export default function Track() {
  const { token } = useParams();
  const q = useQuery({ queryKey: ['track', token], queryFn: () => get<any>(`/location/track/${token}`), refetchInterval: (s) => (s.state.data?.active ? 10000 : false), retry: false });
  const d = q.data;
  return (
    <div className="min-h-screen bg-sand-50">
      <header className="border-b border-sand-200 bg-white px-4 py-3"><div className="mx-auto max-w-3xl"><Logo /></div></header>
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-6">
        {q.isLoading ? <Spinner /> : q.isError ? (
          <Card><ErrorState message="This tracking link is invalid or has been removed." /></Card>
        ) : !d.active ? (
          <Card className="p-8 text-center">
            <ShieldCheck className="mx-auto h-10 w-10 text-safe-500" />
            <p className="mt-3 text-xl font-semibold">Live sharing has ended</p>
            <p className="mt-1 text-ink-mute">{d.name} stopped sharing {timeAgo(d.endedAt)}. Location is no longer visible.</p>
          </Card>
        ) : (
          <>
            <div className={d.sos?.status === 'active' ? 'rounded-3xl bg-gradient-to-br from-rk-600 to-rk-800 p-5 text-white' : 'rounded-3xl bg-white p-5 ring-1 ring-sand-200'}>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  {d.sos?.status === 'active' ? (
                    <p className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-white/80"><Siren className="h-4 w-4 animate-pulse" /> {d.sos.isDemo ? 'Demo SOS — not real' : 'SOS active'}</p>
                  ) : (
                    <Badge tone="warn">Live location shared</Badge>
                  )}
                  <p className="mt-1 font-display text-2xl font-semibold" style={d.sos?.status === 'active' ? { color: 'white' } : undefined}>{d.name} {d.sos?.status === 'active' ? 'needs help' : 'is sharing her location with you'}</p>
                  <p className={d.sos?.status === 'active' ? 'text-sm text-white/80' : 'text-sm text-ink-mute'}>Sharing until {fmtDate(d.expiresAt, true)}</p>
                </div>
                {d.sos?.status === 'active' && !d.sos.isDemo && (
                  <a href="tel:112"><Button className="bg-white text-rk-800 hover:bg-rk-50" icon={<Phone className="h-4 w-4" />}>Call 112</Button></a>
                )}
              </div>
            </div>
            {d.location ? (
              <Card className="p-3">
                <MapView points={[{ lat: d.location.lat, lng: d.location.lng, accuracy: d.location.accuracy, label: d.name }]} height={380} />
                <div className="flex flex-wrap items-center justify-between gap-2 px-2 pb-1 pt-3 text-sm">
                  <span className="flex items-center gap-1.5 text-ink-mute"><MapPin className="h-4 w-4" /> Updated {timeAgo(d.location.at)}{d.location.accuracy ? ` · ±${Math.round(d.location.accuracy)} m` : ''}</span>
                  {d.location.battery != null && <span className="flex items-center gap-1 text-ink-mute"><Battery className="h-4 w-4" /> {d.location.battery}%</span>}
                  <a href={d.location.mapsUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-rk-700">Open in Maps <ExternalLink className="h-3.5 w-3.5" /></a>
                </div>
              </Card>
            ) : (
              <Card className="p-6 text-center text-ink-mute">Waiting for her first location update…</Card>
            )}
            <p className="text-center text-xs text-ink-mute">This page refreshes every 10 seconds. Only people with this private link can see it, and it stops working when sharing ends. Views are logged for her safety.</p>
          </>
        )}
      </main>
    </div>
  );
}
