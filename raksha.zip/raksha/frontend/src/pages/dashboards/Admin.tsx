import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Activity, BadgeCheck, Briefcase, CheckCircle2, Clock, Eye, FileLock2, Flag, HandCoins, Landmark, Plug, Search, ShieldCheck, Siren, Users, XCircle } from 'lucide-react';
import { apiError, get, patch, post, put } from '@/api/client';
import { Badge, Button, Card, CardHeader, EmptyState, Input, Modal, PageHeader, QueryState, Select, Stat, Tabs, Textarea } from '@/components/ui';
import { fmtDate, humanize, inr, ROLE_LABEL, timeAgo } from '@/utils/format';

type Tab = 'overview' | 'verifications' | 'users' | 'sos' | 'moderation' | 'schemes' | 'finance' | 'audit' | 'settings';
const PIE = ['#B4233C', '#DC3D5A', '#7A1328', '#2F7D5B', '#B7791F', '#6D28D9', '#0E7490', '#4A4245', '#F17489', '#1C523B'];

export default function Admin() {
  const [tab, setTab] = useState<Tab>('overview');
  const stats = useQuery({ queryKey: ['admin-stats'], queryFn: () => get<any>('/admin/stats'), refetchInterval: 30000 });
  const s = stats.data;
  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Administration" title="Raksha control centre" subtitle="Verification, safety operations, moderation and finance. Admins see approximate locations only, and evidence access requires a written justification." />
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          ['overview', 'Overview'],
          ['verifications', `Verifications${s?.pendingVerifications ? ` (${s.pendingVerifications})` : ''}`],
          ['users', 'Users'],
          ['sos', `SOS${s?.activeSos ? ` (${s.activeSos} active)` : ''}`],
          ['moderation', `Moderation${s ? ` (${s.pendingPosts + s.openReports})` : ''}`],
          ['schemes', 'Schemes'],
          ['finance', 'Finance'],
          ['audit', 'Audit & evidence'],
          ['settings', 'Settings'],
        ]}
      />
      {tab === 'overview' && <Overview q={stats} />}
      {tab === 'verifications' && <Verifications />}
      {tab === 'users' && <UsersTab />}
      {tab === 'sos' && <SosTab />}
      {tab === 'moderation' && <Moderation />}
      {tab === 'schemes' && <SchemesTab />}
      {tab === 'finance' && <FinanceTab />}
      {tab === 'audit' && <AuditTab />}
      {tab === 'settings' && <SettingsTab />}
    </div>
  );
}

function Overview({ q }: { q: any }) {
  const s = q.data;
  return (
    <QueryState q={q}>
      {s && (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Registered users" value={s.users} icon={<Users className="h-4 w-4" />} />
            <Stat label="Active SOS events" value={s.activeSos} hint={`${s.sosTotal} total`} icon={<Siren className="h-4 w-4" />} />
            <Stat label="Avg. SOS → contacts alerted" value={s.avgContactAlertSeconds != null ? `${s.avgContactAlertSeconds}s` : '—'} hint={`${s.responseSamples} live samples · target < 60s`} icon={<Clock className="h-4 w-4" />} tone="safe" />
            <Stat label="Cases" value={s.cases} hint={`${s.successfulAssistance} resolved with a professional`} icon={<Briefcase className="h-4 w-4" />} tone="ink" />
            <Stat label="Active verified professionals" value={s.activeProfessionals} icon={<BadgeCheck className="h-4 w-4" />} tone="safe" />
            <Stat label="Donations (live)" value={inr(s.donations.live.total)} hint={`${s.donations.live.count} payments · demo ${inr(s.donations.demo.total)}`} icon={<HandCoins className="h-4 w-4" />} />
            <Stat label="Scheme applications" value={s.schemeApplications} icon={<Landmark className="h-4 w-4" />} tone="ink" />
            <Stat label="Pending verifications" value={s.pendingVerifications} hint={`${s.openReports} open reports`} icon={<ShieldCheck className="h-4 w-4" />} />
          </div>
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader title="SOS events — last 30 days" />
              <div className="h-64 p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={s.sosDaily}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EEE6E0" vertical={false} />
                    <XAxis dataKey="_id" tick={{ fontSize: 11 }} tickFormatter={(d) => d.slice(5)} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="total" name="Total" fill="#B4233C" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="demo" name="Demo" fill="#F17489" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
            <Card>
              <CardHeader title="Users by role" />
              <div className="flex h-64 items-center p-4">
                <ResponsiveContainer width="55%" height="100%">
                  <PieChart>
                    <Pie data={s.byRole} dataKey="count" nameKey="_id" innerRadius={50} outerRadius={90} paddingAngle={2}>
                      {s.byRole.map((_: any, i: number) => <Cell key={i} fill={PIE[i % PIE.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v: any, n: any) => [v, ROLE_LABEL[String(n)] || n]} />
                  </PieChart>
                </ResponsiveContainer>
                <ul className="flex-1 space-y-1 text-sm">
                  {s.byRole.map((r: any, i: number) => <li key={r._id} className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: PIE[i % PIE.length] }} /> {ROLE_LABEL[r._id] || r._id} <span className="ml-auto font-semibold">{r.count}</span></li>)}
                </ul>
              </div>
            </Card>
          </div>
          <Card>
            <CardHeader title="Cases by status" />
            <div className="flex flex-wrap gap-2 p-5">{s.casesByStatus.map((c: any) => <Badge key={c._id} tone="blue">{humanize(c._id)}: {c.count}</Badge>)}</div>
          </Card>
          <Integrations i={s.integrations} />
        </div>
      )}
    </QueryState>
  );
}

function Integrations({ i }: { i: any }) {
  const rows: Array<[string, any]> = [
    ['SMS provider', i.sms],
    ['WhatsApp API', i.whatsapp],
    ['Email (SMTP)', i.email],
    ['Emergency services (112) integration', i.emergency],
    ['Police complaint integration', i.policeComplaints],
    ['Razorpay payments', i.payments],
    ['Malware scanning (ClamAV)', i.malwareScan],
    ['Live streaming server', i.streaming],
  ];
  return (
    <Card>
      <CardHeader title="Integrations" icon={<Plug className="h-4 w-4" />} subtitle={`Storage: ${i.storage} · Maps: ${i.maps} · Demo mode: ${i.demoMode ? 'ON' : 'off'}`} />
      <ul className="grid gap-x-6 p-5 sm:grid-cols-2">
        {rows.map(([l, ok]) => <li key={l} className="flex items-center justify-between border-b border-sand-100 py-2 text-sm">{l} {ok ? <Badge tone="safe" icon={<CheckCircle2 className="h-3 w-3" />}>Configured</Badge> : <Badge icon={<XCircle className="h-3 w-3" />}>Not configured</Badge>}</li>)}
      </ul>
    </Card>
  );
}

function Verifications() {
  const qc = useQueryClient();
  const [status, setStatus] = useState('');
  const q = useQuery({ queryKey: ['admin-ver', status], queryFn: () => get<{ items: any[] }>('/admin/verifications', { status: status || undefined }) });
  const [decide, setDecide] = useState<any>(null);
  const [note, setNote] = useState('');
  const m = useMutation({
    mutationFn: (decision: string) => post(`/admin/verifications/${decide._id}/decision`, { decision, note: note || undefined }),
    onSuccess: (r) => { toast.success(r._message); setDecide(null); qc.invalidateQueries({ queryKey: ['admin-ver'] }); qc.invalidateQueries({ queryKey: ['admin-stats'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <>
      <Select aria-label="Filter" value={status} onChange={(e) => setStatus(e.target.value)} options={[['approved', 'Approved'], ['rejected', 'Rejected']]} placeholder="Pending & more info" className="w-auto" />
      <QueryState q={q} isEmpty={!q.data?.items.length} empty={<Card><EmptyState icon={<BadgeCheck className="h-6 w-6" />} title="Nothing to review" /></Card>}>
        <div className="grid gap-4 md:grid-cols-2">
          {(q.data?.items || []).map((v) => (
            <Card key={v._id} className="p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{v.user?.name}</p>
                  <p className="text-sm text-ink-mute">{humanize(v.role)} · {v.user?.email || v.user?.phone} · {v.user?.city}</p>
                </div>
                <Badge tone={v.status === 'approved' ? 'safe' : v.status === 'rejected' ? 'rk' : 'warn'}>{humanize(v.status)}</Badge>
              </div>
              {v.campaign && <p className="mt-2 text-sm">Campaign: <strong>{v.campaign.title}</strong> · goal {inr(v.campaign.goalAmount)}</p>}
              <dl className="mt-3 space-y-1 text-sm">
                {Object.entries({ ...(v.details || {}), ...(v.profile ? { 'Profile ID': v.profile.barCouncilId || v.profile.registrationNumber || v.profile.licenseNumber } : {}) }).filter(([, x]) => x).map(([k, x]) => <div key={k} className="flex gap-2"><dt className="text-ink-mute">{humanize(k)}:</dt><dd className="font-medium">{String(x)}</dd></div>)}
              </dl>
              {(v.documents || []).length > 0 && <p className="mt-2 text-xs text-ink-mute">{v.documents.length} encrypted document(s) attached — open via Evidence access with justification.</p>}
              <p className="mt-2 text-xs text-ink-mute">Submitted {timeAgo(v.createdAt)}</p>
              {['pending', 'more_info'].includes(v.status) && <Button size="sm" className="mt-4" onClick={() => { setNote(''); setDecide(v); }}>Review</Button>}
            </Card>
          ))}
        </div>
      </QueryState>
      <Modal open={!!decide} onClose={() => setDecide(null)} title={`Review ${decide?.user?.name}`} footer={<><Button variant="ghost" onClick={() => m.mutate('more_info')}>Ask for more info</Button><Button variant="outline" onClick={() => m.mutate('rejected')}>Reject</Button><Button variant="safe" loading={m.isPending} onClick={() => m.mutate('approved')}>Approve</Button></>}>
        <Textarea label="Note to applicant" value={note} onChange={(e) => setNote(e.target.value)} />
      </Modal>
    </>
  );
}

function UsersTab() {
  const qc = useQueryClient();
  const [q, setQ] = useState('');
  const [role, setRole] = useState('');
  const users = useQuery({ queryKey: ['admin-users', q, role], queryFn: () => get<{ items: any[]; total: number }>('/admin/users', { q: q || undefined, role: role || undefined }) });
  const setStatus = async (id: string, status: string) => {
    try {
      await patch(`/admin/users/${id}`, { status });
      toast.success(`User ${status}`);
      qc.invalidateQueries({ queryKey: ['admin-users'] });
    } catch (e) {
      toast.error(apiError(e).message);
    }
  };
  return (
    <Card>
      <div className="flex flex-col gap-3 border-b border-sand-200 p-4 sm:flex-row">
        <div className="relative flex-1"><Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" /><input className="input pl-10" placeholder="Search name, email, phone" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <Select aria-label="Role" value={role} onChange={(e) => setRole(e.target.value)} options={Object.entries(ROLE_LABEL) as any} placeholder="All roles" className="sm:w-56" />
      </div>
      <QueryState q={users}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-sand-50 text-left text-ink-mute"><tr><th className="px-4 py-2 font-medium">Name</th><th className="px-4 py-2 font-medium">Role</th><th className="px-4 py-2 font-medium">Contact</th><th className="px-4 py-2 font-medium">Joined</th><th className="px-4 py-2 font-medium">Status</th><th /></tr></thead>
            <tbody className="divide-y divide-sand-100">
              {(users.data?.items || []).map((u) => (
                <tr key={u._id}>
                  <td className="px-4 py-2.5 font-medium">{u.name} {u.isDemo && <Badge tone="warn">Demo</Badge>}</td>
                  <td className="px-4 py-2.5">{ROLE_LABEL[u.role]} {['lawyer', 'ngo', 'counsellor', 'responder', 'police', 'lender'].includes(u.role) && (u.verified ? <BadgeCheck className="inline h-3.5 w-3.5 text-safe-600" /> : <Badge>unverified</Badge>)}</td>
                  <td className="px-4 py-2.5 text-ink-mute">{u.email || u.phone}</td>
                  <td className="px-4 py-2.5 text-ink-mute">{fmtDate(u.createdAt)}</td>
                  <td className="px-4 py-2.5"><Badge tone={u.status === 'active' ? 'safe' : 'rk'}>{u.status}</Badge></td>
                  <td className="px-4 py-2.5 text-right">{u.role !== 'admin' && <button className="text-xs font-semibold text-rk-700" onClick={() => setStatus(u._id, u.status === 'active' ? 'suspended' : 'active')}>{u.status === 'active' ? 'Suspend' : 'Reactivate'}</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="px-4 py-3 text-xs text-ink-mute">{users.data?.total} users</p>
      </QueryState>
    </Card>
  );
}

function SosTab() {
  const q = useQuery({ queryKey: ['admin-sos'], queryFn: () => get<{ items: any[] }>('/admin/sos'), refetchInterval: 15000 });
  return (
    <Card>
      <CardHeader title="SOS events" subtitle="Approximate locations only (~1 km). Precise location is visible only to the woman's contacts and accepted responders." icon={<Siren className="h-4 w-4" />} />
      <QueryState q={q} isEmpty={!q.data?.items.length} empty={<EmptyState title="No SOS events" />}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-sand-50 text-left text-ink-mute"><tr><th className="px-4 py-2 font-medium">When</th><th className="px-4 py-2 font-medium">User</th><th className="px-4 py-2 font-medium">Status</th><th className="px-4 py-2 font-medium">Contacts alerted in</th><th className="px-4 py-2 font-medium">Responders</th><th className="px-4 py-2 font-medium">112 integration</th><th className="px-4 py-2 font-medium">Area</th></tr></thead>
            <tbody className="divide-y divide-sand-100">
              {(q.data?.items || []).map((a) => (
                <tr key={a._id}>
                  <td className="px-4 py-2.5">{fmtDate(a.createdAt, true)}</td>
                  <td className="px-4 py-2.5">{a.user?.name} {a.isDemo && <Badge tone="warn">Demo</Badge>}</td>
                  <td className="px-4 py-2.5"><Badge tone={a.status === 'active' ? 'rk' : a.status === 'resolved' ? 'safe' : 'neutral'}>{a.status}</Badge></td>
                  <td className="px-4 py-2.5">{a.alertSeconds != null ? `${a.alertSeconds}s` : '—'}</td>
                  <td className="px-4 py-2.5">{a.respondersAccepted}/{a.respondersNotified}</td>
                  <td className="px-4 py-2.5">{humanize(a.emergencyService)}</td>
                  <td className="px-4 py-2.5 font-mono text-xs">{a.location ? `${a.location.lat}, ${a.location.lng}` : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </QueryState>
    </Card>
  );
}

function Moderation() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['admin-mod'], queryFn: () => get<{ posts: any[]; comments: any[]; reports: any[] }>('/admin/moderation') });
  const act = useMutation({
    mutationFn: ({ url, body }: { url: string; body: any }) => post(url, body),
    onSuccess: (r) => { toast.success(r._message || 'Done'); qc.invalidateQueries({ queryKey: ['admin-mod'] }); qc.invalidateQueries({ queryKey: ['admin-stats'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });
  const d = q.data;
  return (
    <QueryState q={q}>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title={`Posts awaiting review (${d?.posts.length || 0})`} icon={<Eye className="h-4 w-4" />} />
          <ul className="divide-y divide-sand-200">
            {(d?.posts || []).map((p) => (
              <li key={p._id} className="space-y-2 px-5 py-4">
                <p className="font-semibold">{p.title}</p>
                <p className="line-clamp-3 text-sm text-ink-soft">{p.body}</p>
                <div className="flex flex-wrap gap-1">{(p.moderation?.autoFlags || []).map((f: string) => <Badge key={f} tone="warn">{humanize(f)}</Badge>)}{p.anonymous && <Badge>Anonymous</Badge>}</div>
                <div className="flex gap-2"><Button size="sm" variant="safe" onClick={() => act.mutate({ url: `/admin/moderation/posts/${p._id}`, body: { action: 'publish' } })}>Publish</Button><Button size="sm" variant="outline" onClick={() => act.mutate({ url: `/admin/moderation/posts/${p._id}`, body: { action: 'remove', reason: 'Violates community guidelines' } })}>Remove</Button></div>
              </li>
            ))}
            {!d?.posts.length && <li className="px-5 py-6 text-sm text-ink-mute">Queue is clear.</li>}
          </ul>
          {(d?.comments || []).length > 0 && (
            <>
              <p className="border-t border-sand-200 px-5 pt-4 text-sm font-semibold">Comments</p>
              <ul className="divide-y divide-sand-200">
                {d!.comments.map((c) => (
                  <li key={c._id} className="space-y-2 px-5 py-3">
                    <p className="text-sm">{c.body}</p>
                    <div className="flex gap-2"><Button size="sm" variant="safe" onClick={() => act.mutate({ url: `/admin/moderation/comments/${c._id}`, body: { action: 'publish' } })}>Publish</Button><Button size="sm" variant="outline" onClick={() => act.mutate({ url: `/admin/moderation/comments/${c._id}`, body: { action: 'remove' } })}>Remove</Button></div>
                  </li>
                ))}
              </ul>
            </>
          )}
        </Card>
        <Card>
          <CardHeader title={`Open reports (${d?.reports.length || 0})`} icon={<Flag className="h-4 w-4" />} />
          <ul className="divide-y divide-sand-200">
            {(d?.reports || []).map((r) => (
              <li key={r._id} className="space-y-2 px-5 py-4 text-sm">
                <p><Badge tone="rk">{humanize(r.reason)}</Badge> on {r.targetType} <span className="font-mono text-xs text-ink-mute">{String(r.targetId).slice(-6)}</span></p>
                {r.details && <p className="text-ink-soft">{r.details}</p>}
                <p className="text-xs text-ink-mute">by {r.reporter?.name} · {timeAgo(r.createdAt)}</p>
                <div className="flex gap-2">
                  {r.targetType === 'post' && <Button size="sm" variant="outline" onClick={() => act.mutate({ url: `/admin/moderation/posts/${r.targetId}`, body: { action: 'remove', reason: `Reported: ${r.reason}` } })}>Remove post</Button>}
                  <Button size="sm" variant="secondary" onClick={() => act.mutate({ url: `/admin/reports/${r._id}`, body: { status: 'actioned' } })}>Mark actioned</Button>
                  <Button size="sm" variant="ghost" onClick={() => act.mutate({ url: `/admin/reports/${r._id}`, body: { status: 'dismissed' } })}>Dismiss</Button>
                </div>
              </li>
            ))}
            {!d?.reports.length && <li className="px-5 py-6 text-sm text-ink-mute">No open reports.</li>}
          </ul>
        </Card>
      </div>
    </QueryState>
  );
}

function SchemesTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['admin-schemes'], queryFn: () => get<{ schemes: any[] }>('/admin/schemes') });
  const [edit, setEdit] = useState<any>(null);
  const [json, setJson] = useState('');
  const save = useMutation({
    mutationFn: () => {
      const body = JSON.parse(json);
      delete body._id;
      delete body.__v;
      delete body.createdAt;
      delete body.updatedAt;
      delete body.updatedBy;
      delete body.lastVerifiedAt;
      return edit._id ? put(`/admin/schemes/${edit._id}`, body) : post('/admin/schemes', body);
    },
    onSuccess: (r) => { toast.success(r._message || 'Saved'); setEdit(null); qc.invalidateQueries({ queryKey: ['admin-schemes'] }); },
    onError: (e: any) => toast.error(e instanceof SyntaxError ? 'Invalid JSON' : apiError(e).message),
  });
  const open = (s: any) => {
    setEdit(s);
    setJson(JSON.stringify(s._id ? s : { slug: '', name: '', level: 'central', states: [], category: 'financial_aid', description: '', eligibility: [], benefits: [], documents: [], applicationMethod: '', officialUrl: 'https://', criteria: {}, tags: [], active: true, sourceNote: '' }, null, 2));
  };
  return (
    <>
      <div className="flex justify-end"><Button onClick={() => open({})}>Add scheme</Button></div>
      <p className="text-sm text-ink-mute">Only add machine-checkable criteria that appear in the official source. Anything not in "criteria" is shown to users as "check details".</p>
      <QueryState q={q}>
        <Card>
          <ul className="divide-y divide-sand-200">
            {(q.data?.schemes || []).map((s) => (
              <li key={s._id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3">
                <div><p className="font-semibold">{s.name}</p><p className="text-xs text-ink-mute">{s.level === 'state' ? s.states.join(', ') : 'Central'} · last reviewed {fmtDate(s.lastVerifiedAt)}</p></div>
                <div className="flex items-center gap-2"><Badge tone={s.active ? 'safe' : 'neutral'}>{s.active ? 'Active' : 'Hidden'}</Badge><Button size="sm" variant="outline" onClick={() => open(s)}>Edit</Button></div>
              </li>
            ))}
          </ul>
        </Card>
      </QueryState>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?._id ? `Edit ${edit.name}` : 'New scheme'} size="lg" footer={<Button loading={save.isPending} onClick={() => save.mutate()}>Save</Button>}>
        <textarea className="input min-h-[420px] font-mono text-xs" value={json} onChange={(e) => setJson(e.target.value)} aria-label="Scheme JSON" spellCheck={false} />
      </Modal>
    </>
  );
}

function FinanceTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['admin-finance'], queryFn: () => get<{ transactions: any[]; campaigns: any[]; donations: any[] }>('/admin/finance') });
  const [disb, setDisb] = useState<any>(null);
  const [f, setF] = useState({ amount: '', purpose: '', paidTo: '' });
  const m = useMutation({
    mutationFn: () => post(`/campaigns/${disb._id}/utilization`, { amount: Number(f.amount), purpose: f.purpose, paidTo: f.paidTo }),
    onSuccess: (r) => { toast.success(r._message); setDisb(null); qc.invalidateQueries({ queryKey: ['admin-finance'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });
  return (
    <QueryState q={q}>
      <div className="space-y-6">
        <Card>
          <CardHeader title="Campaigns" icon={<HandCoins className="h-4 w-4" />} />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-sand-50 text-left text-ink-mute"><tr><th className="px-4 py-2 font-medium">Campaign</th><th className="px-4 py-2 font-medium">Status</th><th className="px-4 py-2 font-medium">Raised</th><th className="px-4 py-2 font-medium">Disbursed</th><th /></tr></thead>
              <tbody className="divide-y divide-sand-100">
                {(q.data?.campaigns || []).map((c) => (
                  <tr key={c._id}>
                    <td className="px-4 py-2.5">{c.title} <span className="text-ink-mute">· {c.beneficiary?.name}</span> {c.isDemo && <Badge tone="warn">Demo</Badge>}</td>
                    <td className="px-4 py-2.5"><Badge>{humanize(c.status)}</Badge></td>
                    <td className="px-4 py-2.5">{inr(c.raisedAmount)} / {inr(c.goalAmount)}</td>
                    <td className="px-4 py-2.5">{inr(c.disbursedAmount)}</td>
                    <td className="px-4 py-2.5 text-right">{c.raisedAmount > c.disbursedAmount && <button className="text-xs font-semibold text-rk-700" onClick={() => { setF({ amount: '', purpose: '', paidTo: c.payee?.name || '' }); setDisb(c); }}>Record disbursement</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Transactions" icon={<Activity className="h-4 w-4" />} />
          <div className="max-h-96 overflow-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-sand-50 text-left text-ink-mute"><tr><th className="px-4 py-2 font-medium">Date</th><th className="px-4 py-2 font-medium">Type</th><th className="px-4 py-2 font-medium">Provider</th><th className="px-4 py-2 font-medium">Amount</th><th className="px-4 py-2 font-medium">Status</th><th className="px-4 py-2 font-medium">Signature</th></tr></thead>
              <tbody className="divide-y divide-sand-100">
                {(q.data?.transactions || []).map((t) => (
                  <tr key={t._id}>
                    <td className="px-4 py-2">{fmtDate(t.createdAt, true)}</td>
                    <td className="px-4 py-2">{humanize(t.type)}</td>
                    <td className="px-4 py-2">{t.provider} {t.isDemo && <Badge tone="warn">Demo</Badge>}</td>
                    <td className="px-4 py-2">{inr(t.amount)}</td>
                    <td className="px-4 py-2"><Badge tone={['captured', 'completed'].includes(t.status) ? 'safe' : t.status === 'failed' ? 'rk' : 'neutral'}>{t.status}</Badge></td>
                    <td className="px-4 py-2">{t.type === 'donation' ? (t.signatureVerified ? '✓ verified' : '—') : ''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
      <Modal open={!!disb} onClose={() => setDisb(null)} title="Record disbursement" footer={<Button loading={m.isPending} onClick={() => m.mutate()}>Save</Button>}>
        <div className="space-y-4">
          <Input label="Amount (₹)" type="number" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
          <Input label="Purpose" value={f.purpose} onChange={(e) => setF({ ...f, purpose: e.target.value })} />
          <Input label="Paid to" value={f.paidTo} onChange={(e) => setF({ ...f, paidTo: e.target.value })} />
        </div>
      </Modal>
    </QueryState>
  );
}

function AuditTab() {
  const [prefix, setPrefix] = useState('');
  const q = useQuery({ queryKey: ['admin-audit', prefix], queryFn: () => get<{ items: any[]; total: number }>('/admin/audit', { action: prefix || undefined, limit: 100 }) });
  const ev = useQuery({ queryKey: ['admin-ev-stats'], queryFn: () => get<{ byKind: any[]; scan: any[] }>('/admin/evidence/stats') });
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader title="Evidence vault" icon={<FileLock2 className="h-4 w-4" />} />
        <div className="flex flex-wrap gap-2 p-5">
          {(ev.data?.byKind || []).map((k) => <Badge key={k._id} tone="blue">{k._id}: {k.count}</Badge>)}
          {(ev.data?.scan || []).map((k) => <Badge key={k._id}>scan {humanize(k._id)}: {k.count}</Badge>)}
        </div>
      </Card>
      <Card>
        <div className="flex flex-wrap items-center gap-2 border-b border-sand-200 p-4">
          {[['', 'All'], ['evidence', 'Evidence'], ['sos', 'SOS'], ['case', 'Cases'], ['auth', 'Auth'], ['admin', 'Admin'], ['location', 'Location'], ['payment', 'Payments']].map(([v, l]) => (
            <button key={v} className={`chip py-1 text-xs ${prefix === v ? 'chip-active' : ''}`} onClick={() => setPrefix(v)}>{l}</button>
          ))}
        </div>
        <QueryState q={q}>
          <ul className="max-h-[560px] divide-y divide-sand-100 overflow-y-auto">
            {(q.data?.items || []).map((l) => (
              <li key={l._id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-2.5 text-sm">
                <span><span className="font-mono text-xs text-rk-700">{l.action}</span> · {l.actor?.name || l.actorRole || 'system'} {l.meta?.reason && <span className="text-ink-mute">— {String(l.meta.reason)}</span>}</span>
                <span className="text-xs text-ink-mute">{fmtDate(l.createdAt, true)} · {l.ip}</span>
              </li>
            ))}
          </ul>
        </QueryState>
      </Card>
    </div>
  );
}

function SettingsTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['admin-settings'], queryFn: () => get<{ settings: any[]; integrations: any }>('/admin/settings') });
  const [kw, setKw] = useState<string | null>(null);
  const keywords = q.data?.settings.find((s) => s.key === 'moderation.keywords')?.value || [];
  const save = useMutation({
    mutationFn: () => put('/admin/settings/moderation.keywords', { value: (kw ?? keywords.join(', ')).split(',').map((s: string) => s.trim()).filter(Boolean) }),
    onSuccess: (r) => { toast.success(r._message); qc.invalidateQueries({ queryKey: ['admin-settings'] }); },
  });
  return (
    <QueryState q={q}>
      <div className="space-y-6">
        <Card>
          <CardHeader title="Moderation keywords" subtitle="Comma-separated. Posts containing them are held for review (a built-in list is always applied)." />
          <div className="space-y-3 p-5">
            <Textarea value={kw ?? keywords.join(', ')} onChange={(e) => setKw(e.target.value)} aria-label="Keywords" />
            <Button onClick={() => save.mutate()} loading={save.isPending}>Save</Button>
          </div>
        </Card>
        {q.data && <Integrations i={q.data.integrations} />}
        <Card className="p-5 text-sm text-ink-soft">Provider credentials (SMS, WhatsApp, email, payments, storage, emergency integrations) are configured through server environment variables and are never stored in the database or shown in the UI.</Card>
      </div>
    </QueryState>
  );
}
