import { Link } from 'react-router-dom';
import { ArrowRight, Building2, Gavel, HandCoins, HeartHandshake, Landmark, Radar, ShieldCheck, Users } from 'lucide-react';
import { Button } from '@/components/ui';

const PARTNERS = [
  { role: 'lawyer', icon: Gavel, title: 'Lawyers', body: 'Receive matched cases by specialisation, location and language. Offer pro bono or low-fee help and manage cases, documents and hearings in one place.' },
  { role: 'ngo', icon: Building2, title: 'NGOs & shelters', body: 'Reach women who need shelter, rescue, legal aid or rehabilitation. Coordinate cases and share notes securely.' },
  { role: 'counsellor', icon: HeartHandshake, title: 'Counsellors', body: 'Offer emotional, legal-advice or career sessions by chat, call or video — paid or free.' },
  { role: 'responder', icon: Radar, title: 'Verified responders', body: 'Trained volunteers who can reach a woman nearby in an emergency. Background-checked; approximate location until you accept.' },
  { role: 'police', icon: ShieldCheck, title: 'Police & officials', body: 'Receive complaints women choose to share with you, confirm registration and keep them updated.' },
  { role: 'lender', icon: Landmark, title: 'Registered lenders', body: 'Make interest-free or low-interest micro-loan offers to women rebuilding their independence.' },
  { role: 'donor', icon: HandCoins, title: 'Donors & CSR', body: 'Fund verified campaigns and programmes with full transparency on how every rupee is used.' },
  { role: 'emergency_contact', icon: Users, title: 'Families & friends', body: 'Be the person she can count on. Get instant alerts and follow her live location during an SOS.' },
];

export default function Partners() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <p className="text-xs font-semibold uppercase tracking-[.16em] text-rk-600">Partner with Raksha</p>
      <h1 className="mt-2 max-w-3xl text-4xl font-semibold">Those who give help, connected to those who need it</h1>
      <p className="mt-3 max-w-2xl text-ink-mute">Every partner is verified before receiving cases or sensitive information. Choose how you would like to help.</p>
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {PARTNERS.map(({ role, icon: I, title, body }) => (
          <div key={role} className="card flex flex-col p-6">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-rk-50 text-rk-600"><I className="h-5 w-5" /></span>
            <h2 className="mt-4 font-sans text-lg font-semibold">{title}</h2>
            <p className="mt-1.5 flex-1 text-sm text-ink-mute">{body}</p>
            <Link to={`/register?role=${role}`} className="mt-5"><Button variant="outline" size="sm" className="w-full" icon={<ArrowRight className="h-4 w-4" />}>Join as {title.toLowerCase().replace(/s$/, '')}</Button></Link>
          </div>
        ))}
      </div>
      <div className="mt-12 rounded-3xl bg-ink p-8 text-white sm:p-10">
        <h2 className="text-2xl font-semibold text-white">CSR, government & institutional partnerships</h2>
        <p className="mt-2 max-w-2xl text-white/70">Fund safety programmes, run POSH and safety workshops for colleges and companies, or integrate Raksha with emergency and police systems. Core safety features stay free for every woman.</p>
        <a href="mailto:partners@raksha.app" className="mt-6 inline-block"><Button className="bg-white text-ink hover:bg-sand-100">Contact the partnerships team</Button></a>
      </div>
    </div>
  );
}
