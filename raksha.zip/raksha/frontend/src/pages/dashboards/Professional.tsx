import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { BadgeCheck, Briefcase, CalendarClock, CheckCircle2, Clock, FileText, Inbox, Landmark, ShieldAlert, Upload, UserCog } from 'lucide-react';
import { api, apiError, get, post, put } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { Badge, Button, Card, CardHeader, EmptyState, Input, Modal, PageHeader, QueryState, Select, Stat, Switch, Tabs, Textarea } from '@/components/ui';
import { CASE_TYPES, fmtDate, humanize, inr, LANGS, timeAgo } from '@/utils/format';

type Kind = 'lawyer' | 'ngo' | 'counsellor' | 'police' | 'lender';
const API: Record<string, string> = { lawyer: '/lawyers', ngo: '/ngos', counsellor: '/counsellors' };

export default function Professional({ kind }: { kind: Kind }) {
  const { user } = useAuth();
  const title = { lawyer: 'Lawyer dashboard', ngo: 'NGO dashboard', counsellor: 'Counsellor dashboard', police: 'Police / official dashboard', lender: 'Lending partner dashboard' }[kind];
  return (
    <div className="space-y-6">
      <PageHeader eyebrow={user?.verified ? 'Verified partner' : 'Awaiting verification'} title={title} subtitle={`Welcome, ${user?.name}.`} />
      {!user?.verified && <VerificationPanel kind={kind} />}
      {kind === 'lawyer' || kind === 'ngo' ? <CaseWork kind={kind} /> : kind === 'counsellor' ? <CounsellorWork /> : kind === 'police' ? <PoliceWork /> : <LenderWork />}
    </div>
  );
}

/* ----------------------------- verification ----------------------------- */
function VerificationPanel({ kind }: { kind: Kind }) {
  const qc = useQueryClient();
  const mine = useQuery({ queryKey: ['my-verification', kind], queryFn: () => (API[kind] ? get<any>(`${API[kind]}/me/profile`) : Promise.resolve({ verification: null })) });
  const [details, setDetails] = useState<Record<string, string>>({});
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const fields: Record<Kind, Array<[string, string]>> = {
    lawyer: [['barCouncilId', 'Bar Council enrolment number'], ['state', 'State Bar Council']],
    ngo: [['registrationNumber', 'Registration number'], ['darpanId', 'NGO Darpan ID']],
    counsellor: [['licenseNumber', 'License / RCI number'], ['qualification', 'Qualification']],
    police: [['badgeNumber', 'Official ID / badge number'], ['station', 'Police station / unit']],
    lender: [['regulatoryId', 'RBI / regulator registration number'], ['entityName', 'Legal entity name']],
  };
  const submit = async () => {
    setBusy(true);
    try {
      let evidenceIds: string[] = [];
      if (files.length) {
        const fd = new FormData();
        files.forEach((f) => fd.append('files', f));
        fd.append('category', 'document');
        fd.append('title', 'Verification document');
        const r = await api.post('/evidence', fd);
        evidenceIds = r.data.data.items.map((i: any) => i._id);
      }
      const url = API[kind] ? `${API[kind]}/me/verification` : `/verification/${kind}`;
      const r = await post(url, { details, evidenceIds });
      toast.success(r._message);
      qc.invalidateQueries({ queryKey: ['my-verification', kind] });
    } catch (e) {
      toast.error(apiError(e).message);
    } finally {
      setBusy(false);
    }
  };
  const v = mine.data?.verification;
  return (
    <Card className="border-warn-500/30 bg-warn-50/60">
      <CardHeader title="Get verified to start receiving cases" icon={<ShieldAlert className="h-4 w-4" />} subtitle="Raksha administrators check every professional before they appear to women or receive sensitive information." action={v && <Badge tone={v.status === 'rejected' ? 'rk' : 'warn'}>{humanize(v.status)}</Badge>} />
      <div className="space-y-4 p-5">
        {v?.reviewNote && <p className="rounded-xl bg-white p-3 text-sm">Reviewer note: {v.reviewNote}</p>}
        <div className="grid gap-3 sm:grid-cols-2">
          {fields[kind].map(([k, l]) => <Input key={k} label={l} value={details[k] || ''} onChange={(e) => setDetails({ ...details, [k]: e.target.value })} />)}
        </div>
        <div>
          <label className="label">Supporting documents (stored encrypted)</label>
          <input type="file" multiple accept="image/*,application/pdf" onChange={(e) => setFiles(Array.from(e.target.files || []))} className="text-sm" />
        </div>
        <Button onClick={submit} loading={busy} icon={<Upload className="h-4 w-4" />}>{v ? 'Update submission' : 'Submit for verification'}</Button>
        {API[kind] && <p className="text-xs text-ink-mute">Also complete your public profile below so women can find you once verified.</p>}
      </div>
    </Card>
  );
}

/* ----------------------------- lawyer / NGO ----------------------------- */
function CaseWork({ kind }: { kind: 'lawyer' | 'ngo' }) {
  const [tab, setTab] = useState<'requests' | 'cases' | 'profile'>('requests');
  const q = useQuery({ queryKey: ['cases'], queryFn: () => get<{ assigned: any[]; requests: any[] }>('/cases') });
  const assigned = q.data?.assigned || [];
  const requests = q.data?.requests || [];
  const upcoming = assigned.flatMap((c) => (c.hearings || []).filter((h: any) => new Date(h.date) > new Date()).map((h: any) => ({ ...h, c }))).sort((a, b) => +new Date(a.date) - +new Date(b.date));
  return (
    <>
      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="New requests" value={requests.length} icon={<Inbox className="h-4 w-4" />} />
        <Stat label="Active cases" value={assigned.filter((c) => !['resolved', 'closed'].includes(c.status)).length} icon={<Briefcase className="h-4 w-4" />} tone="ink" />
        <Stat label="Upcoming hearings" value={upcoming.length} hint={upcoming[0] ? `Next: ${fmtDate(upcoming[0].date)}` : undefined} icon={<CalendarClock className="h-4 w-4" />} tone="safe" />
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[['requests', `Requests (${requests.length})`], ['cases', `My cases (${assigned.length})`], ['profile', 'Profile']]} className="w-fit" />
      {tab === 'requests' && (
        <QueryState q={q} isEmpty={!requests.length} empty={<Card><EmptyState icon={<Inbox className="h-6 w-6" />} title="No pending requests" body="When a woman requests your help, it appears here." /></Card>}>
          <div className="grid gap-4 md:grid-cols-2">
            {requests.map((c) => (
              <Card key={c._id} className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-ink-mute">{c.caseNumber} · {timeAgo(c.createdAt)}</p>
                    <p className="mt-1 font-semibold">{humanize(c.type)}</p>
                  </div>
                  <Badge tone={c.urgency === 'emergency' || c.urgency === 'high' ? 'rk' : 'neutral'}>{humanize(c.urgency)}</Badge>
                </div>
                <p className="mt-2 line-clamp-3 text-sm text-ink-soft">{c.description || 'No description shared.'}</p>
                <p className="mt-2 text-xs text-ink-mute">{c.location?.city} · {c.language?.toUpperCase()} · budget {c.budget}</p>
                <Link to={`/cases/${c._id}`}><Button size="sm" className="mt-4">Review request</Button></Link>
              </Card>
            ))}
          </div>
        </QueryState>
      )}
      {tab === 'cases' && (
        <QueryState q={q} isEmpty={!assigned.length} empty={<Card><EmptyState title="No cases yet" /></Card>}>
          <Card>
            <ul className="divide-y divide-sand-200">
              {assigned.map((c) => (
                <li key={c._id}>
                  <Link to={`/cases/${c._id}`} className="flex flex-wrap items-center justify-between gap-2 px-5 py-4 hover:bg-sand-50">
                    <div>
                      <p className="font-semibold">{c.title}</p>
                      <p className="text-sm text-ink-mute">{c.caseNumber} · {c.user?.name} · {humanize(c.type)}</p>
                    </div>
                    <Badge tone="blue">{humanize(c.status)}</Badge>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        </QueryState>
      )}
      {tab === 'profile' && <ProfileForm kind={kind} />}
    </>
  );
}

/* ------------------------------- profile -------------------------------- */
function ProfileForm({ kind }: { kind: 'lawyer' | 'ngo' | 'counsellor' }) {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['my-profile', kind], queryFn: () => get<{ profile: any }>(`${API[kind]}/me/profile`) });
  const [f, setF] = useState<any>({});
  useEffect(() => {
    const p = q.data?.profile || {};
    setF({ ...p, languages: p.languages || [], specializations: p.specializations || [], focusAreas: p.focusAreas || [], services: p.services || [], modes: p.modes || [] });
  }, [q.data]);
  const save = useMutation({
    mutationFn: () => {
      const pick = (keys: string[]) => Object.fromEntries(keys.filter((k) => f[k] !== undefined && f[k] !== '').map((k) => [k, f[k]]));
      const common = ['languages', 'city', 'state', 'availability'];
      const body =
        kind === 'lawyer'
          ? pick([...common, 'displayName', 'barCouncilId', 'bio', 'specializations', 'services', 'feeType', 'consultationFee', 'proBono', 'freeFirstConsultation'])
          : kind === 'ngo'
            ? pick([...common, 'name', 'registrationNumber', 'darpanId', 'about', 'services', 'focusAreas', 'shelterCapacity', 'shelterAvailable', 'helpline', 'is24x7', 'isOneStopCentre'])
            : pick([...common, 'displayName', 'qualification', 'licenseNumber', 'bio', 'specializations', 'category', 'modes', 'price', 'freeSessions', 'meetingUrl']);
      for (const k of ['consultationFee', 'shelterCapacity', 'shelterAvailable', 'price']) if (body[k] !== undefined) body[k] = Number(body[k]);
      if (typeof body.specializations === 'string') body.specializations = [];
      return put(`${API[kind]}/me/profile`, body);
    },
    onSuccess: (r) => {
      toast.success(r._message);
      qc.invalidateQueries({ queryKey: ['my-profile', kind] });
    },
    onError: (e) => toast.error(apiError(e).message),
  });
  const toggle = (k: string, v: string) => setF({ ...f, [k]: (f[k] || []).includes(v) ? f[k].filter((x: string) => x !== v) : [...(f[k] || []), v] });
  const Chips = ({ k, opts }: { k: string; opts: Array<[string, string]> }) => (
    <div className="flex flex-wrap gap-1.5">{opts.map(([v, l]) => <button type="button" key={v} onClick={() => toggle(k, v)} className={`chip py-1 text-xs ${(f[k] || []).includes(v) ? 'chip-active' : ''}`}>{l}</button>)}</div>
  );
  return (
    <QueryState q={q}>
      <Card>
        <CardHeader title="Public profile" icon={<UserCog className="h-4 w-4" />} subtitle="Shown to women only after you are verified. Registration numbers stay private." />
        <div className="space-y-4 p-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label={kind === 'ngo' ? 'Organisation name' : 'Display name'} value={f.displayName || f.name || ''} onChange={(e) => setF({ ...f, [kind === 'ngo' ? 'name' : 'displayName']: e.target.value })} />
            <Select label="Availability" value={f.availability || 'available'} onChange={(e) => setF({ ...f, availability: e.target.value })} options={[['available', 'Taking new cases'], ['limited', 'Limited'], ['unavailable', 'Not available']]} />
            <Input label="City" value={f.city || ''} onChange={(e) => setF({ ...f, city: e.target.value })} />
            <Input label="State" value={f.state || ''} onChange={(e) => setF({ ...f, state: e.target.value })} />
          </div>
          <Textarea label="About" value={f.bio || f.about || ''} onChange={(e) => setF({ ...f, [kind === 'ngo' ? 'about' : 'bio']: e.target.value })} />
          <div><p className="label">Languages</p><Chips k="languages" opts={LANGS} /></div>
          {kind !== 'counsellor' && <div><p className="label">{kind === 'ngo' ? 'Focus areas' : 'Specialisations'}</p><Chips k={kind === 'ngo' ? 'focusAreas' : 'specializations'} opts={CASE_TYPES as any} /></div>}
          {kind === 'lawyer' && (
            <>
              <div><p className="label">Services</p><Chips k="services" opts={[['consultation', 'Consultation'], ['drafting', 'Drafting'], ['court_representation', 'Court representation'], ['mediation', 'Mediation']]} /></div>
              <div className="grid gap-4 sm:grid-cols-3">
                <Select label="Fee type" value={f.feeType || 'standard'} onChange={(e) => setF({ ...f, feeType: e.target.value })} options={[['pro_bono', 'Pro bono'], ['low_fee', 'Low fee'], ['standard', 'Standard']]} />
                <Input label="Consultation fee (₹)" type="number" value={f.consultationFee ?? ''} onChange={(e) => setF({ ...f, consultationFee: e.target.value })} />
                <Input label="Bar Council ID (private)" value={f.barCouncilId || ''} onChange={(e) => setF({ ...f, barCouncilId: e.target.value })} />
              </div>
              <Switch checked={!!f.proBono} onChange={(v) => setF({ ...f, proBono: v })} label="I take pro bono cases" />
              <Switch checked={f.freeFirstConsultation !== false} onChange={(v) => setF({ ...f, freeFirstConsultation: v })} label="First consultation free" />
            </>
          )}
          {kind === 'ngo' && (
            <>
              <div><p className="label">Services</p><Chips k="services" opts={[['shelter', 'Shelter'], ['rescue', 'Rescue'], ['legal_aid', 'Legal aid'], ['counselling', 'Counselling'], ['medical', 'Medical'], ['rehabilitation', 'Rehabilitation'], ['skills_training', 'Skills training']]} /></div>
              <div className="grid gap-4 sm:grid-cols-3">
                <Input label="Shelter capacity" type="number" value={f.shelterCapacity ?? ''} onChange={(e) => setF({ ...f, shelterCapacity: e.target.value })} />
                <Input label="Places available now" type="number" value={f.shelterAvailable ?? ''} onChange={(e) => setF({ ...f, shelterAvailable: e.target.value })} />
                <Input label="Helpline" value={f.helpline || ''} onChange={(e) => setF({ ...f, helpline: e.target.value })} />
              </div>
              <Switch checked={!!f.is24x7} onChange={(v) => setF({ ...f, is24x7: v })} label="Available 24×7" />
            </>
          )}
          {kind === 'counsellor' && (
            <>
              <div className="grid gap-4 sm:grid-cols-3">
                <Select label="Category" value={f.category || 'emotional'} onChange={(e) => setF({ ...f, category: e.target.value })} options={[['emotional', 'Emotional'], ['legal', 'Legal advice'], ['career_money', 'Career & money']]} />
                <Input label="Price per session (₹)" type="number" value={f.price ?? ''} onChange={(e) => setF({ ...f, price: e.target.value })} />
                <Input label="Qualification" value={f.qualification || ''} onChange={(e) => setF({ ...f, qualification: e.target.value })} />
              </div>
              <div><p className="label">Modes</p><Chips k="modes" opts={[['chat', 'Chat'], ['call', 'Call'], ['video', 'Video']]} /></div>
              <Input label="Secure video room link" value={f.meetingUrl || ''} onChange={(e) => setF({ ...f, meetingUrl: e.target.value })} hint="e.g. your self-hosted Jitsi room. Shared only with confirmed clients." />
              <Switch checked={!!f.freeSessions} onChange={(v) => setF({ ...f, freeSessions: v })} label="Offer free sessions" />
            </>
          )}
          <Button onClick={() => save.mutate()} loading={save.isPending}>Save profile</Button>
        </div>
      </Card>
    </QueryState>
  );
}

/* ------------------------------ counsellor ------------------------------ */
function CounsellorWork() {
  const qc = useQueryClient();
  const [tab, setTab] = useState<'sessions' | 'profile'>('sessions');
  const q = useQuery({ queryKey: ['appointments'], queryFn: () => get<{ appointments: any[] }>('/appointments') });
  const [complete, setComplete] = useState<any>(null);
  const [notes, setNotes] = useState('');
  const act = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => post(`/appointments/${id}/status`, body),
    onSuccess: (r) => { toast.success(r._message); setComplete(null); qc.invalidateQueries({ queryKey: ['appointments'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });
  const appts = q.data?.appointments || [];
  const pending = appts.filter((a) => a.status === 'requested');
  const upcoming = appts.filter((a) => a.status === 'confirmed');
  return (
    <>
      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="New requests" value={pending.length} icon={<Inbox className="h-4 w-4" />} />
        <Stat label="Upcoming sessions" value={upcoming.length} icon={<CalendarClock className="h-4 w-4" />} tone="safe" />
        <Stat label="Completed" value={appts.filter((a) => a.status === 'completed').length} icon={<CheckCircle2 className="h-4 w-4" />} tone="ink" />
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[['sessions', 'Sessions'], ['profile', 'Profile']]} className="w-fit" />
      {tab === 'sessions' ? (
        <QueryState q={q} isEmpty={!appts.length} empty={<Card><EmptyState title="No sessions yet" /></Card>}>
          <Card>
            <ul className="divide-y divide-sand-200">
              {appts.map((a) => (
                <li key={a._id} className="flex flex-wrap items-center gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{a.user?.name} <span className="text-sm font-normal text-ink-mute">· {a.mode} · {a.user?.language?.toUpperCase()}</span></p>
                    <p className="text-sm text-ink-mute">{fmtDate(a.scheduledAt, true)}{a.topic ? ` · ${a.topic}` : ''}</p>
                  </div>
                  <Badge tone={a.status === 'confirmed' ? 'safe' : a.status === 'requested' ? 'warn' : 'neutral'}>{a.status}</Badge>
                  {a.status === 'requested' && (
                    <>
                      <Button size="sm" onClick={() => act.mutate({ id: a._id, body: { action: 'confirm' } })}>Confirm</Button>
                      <Button size="sm" variant="ghost" onClick={() => act.mutate({ id: a._id, body: { action: 'decline' } })}>Decline</Button>
                    </>
                  )}
                  {a.status === 'confirmed' && (
                    <>
                      <Link to={`/messages?with=${a.user?._id}`}><Button size="sm" variant="secondary">Chat</Button></Link>
                      <Button size="sm" variant="outline" onClick={() => { setNotes(''); setComplete(a); }}>Mark complete</Button>
                    </>
                  )}
                </li>
              ))}
            </ul>
          </Card>
        </QueryState>
      ) : (
        <ProfileForm kind="counsellor" />
      )}
      <Modal open={!!complete} onClose={() => setComplete(null)} title="Complete session" footer={<Button loading={act.isPending} onClick={() => act.mutate({ id: complete._id, body: { action: 'complete', notes: notes || undefined } })}>Complete</Button>}>
        <Textarea label="Private session notes (only visible to you)" value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Modal>
    </>
  );
}

/* -------------------------------- police -------------------------------- */
function PoliceWork() {
  const q = useQuery({ queryKey: ['police-inbox'], queryFn: () => get<{ complaints: any[] }>('/complaints/police/inbox') });
  return (
    <Card>
      <CardHeader title="Complaints shared with you" icon={<FileText className="h-4 w-4" />} subtitle="Women can share a complaint with a verified official. Your status updates are shown to them as confirmed by police." />
      <QueryState q={q} isEmpty={!q.data?.complaints.length} empty={<EmptyState title="No complaints shared with you yet" />}>
        <ul className="divide-y divide-sand-200">
          {(q.data?.complaints || []).map((c) => (
            <li key={c._id}>
              <Link to={`/complaints/${c._id}`} className="flex flex-wrap items-center justify-between gap-2 px-5 py-4 hover:bg-sand-50">
                <div>
                  <p className="font-semibold">{c.complaintNumber} · {humanize(c.incident?.type)}</p>
                  <p className="text-sm text-ink-mute">{c.user?.name} · {c.user?.city} · updated {timeAgo(c.updatedAt)}</p>
                </div>
                <div className="flex gap-1.5">
                  {c.isDemo && <Badge tone="warn">Demo</Badge>}
                  <Badge tone="blue">{humanize(c.status)}</Badge>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </QueryState>
    </Card>
  );
}

/* -------------------------------- lender -------------------------------- */
function LenderWork() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const q = useQuery({ queryKey: ['loan-market'], queryFn: () => get<{ loans: any[] }>('/loans/market'), enabled: !!user?.verified });
  const [offerFor, setOfferFor] = useState<any>(null);
  const [o, setO] = useState<any>({ annualInterestRate: 0, processingFee: 0, tenureMonths: 12, terms: '', regulatoryId: '' });
  const m = useMutation({
    mutationFn: () => post(`/loans/${offerFor._id}/offers`, { ...o, annualInterestRate: Number(o.annualInterestRate), processingFee: Number(o.processingFee), tenureMonths: Number(o.tenureMonths) }),
    onSuccess: (r) => { toast.success(r._message); setOfferFor(null); qc.invalidateQueries({ queryKey: ['loan-market'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });
  if (!user?.verified) return null;
  return (
    <>
      <p className="rounded-xl bg-sand-100 p-4 text-sm text-ink-soft"><Landmark className="mr-1 inline h-4 w-4" /> Requests are anonymised. Borrower identity is shared only after she accepts your offer. Offers must comply with your regulator's fair-practices code; interest is capped at 36% p.a. on Raksha and interest-free offers are highlighted.</p>
      <QueryState q={q} isEmpty={!q.data?.loans.length} empty={<Card><EmptyState title="No open requests" /></Card>}>
        <div className="grid gap-4 md:grid-cols-2">
          {(q.data?.loans || []).map((l) => (
            <Card key={l._id} className="p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-display text-2xl font-semibold">{inr(l.amount)}</p>
                  <p className="text-sm text-ink-mute">{humanize(l.purpose)} · {l.tenureMonths} months · {l.city}</p>
                </div>
                <Badge tone={l.myOffer?.status === 'accepted' ? 'safe' : 'blue'}>{l.myOffer ? `Your offer: ${l.myOffer.status}` : humanize(l.status)}</Badge>
              </div>
              {l.description && <p className="mt-2 text-sm text-ink-soft">{l.description}</p>}
              <p className="mt-2 text-xs text-ink-mute">{l.monthlyIncome ? `Monthly income ${inr(l.monthlyIncome)} · ` : ''}{l.offersCount} offer(s) · <Clock className="inline h-3 w-3" /> {timeAgo(l.createdAt)}</p>
              {l.borrower && <div className="mt-3 rounded-xl bg-safe-50 p-3 text-sm text-safe-700"><BadgeCheck className="mr-1 inline h-4 w-4" /> Accepted — contact {l.borrower.name} · {l.borrower.phone} · {l.borrower.email}</div>}
              {!l.myOffer && ['submitted', 'offers_received'].includes(l.status) && <Button size="sm" className="mt-4" onClick={() => setOfferFor(l)}>Make an offer</Button>}
            </Card>
          ))}
        </div>
      </QueryState>
      <Modal open={!!offerFor} onClose={() => setOfferFor(null)} title={`Offer for ${offerFor ? inr(offerFor.amount) : ''}`} footer={<Button loading={m.isPending} onClick={() => m.mutate()}>Send offer</Button>}>
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-3">
            <Input label="Interest % p.a." type="number" min={0} max={36} value={o.annualInterestRate} onChange={(e) => setO({ ...o, annualInterestRate: e.target.value })} />
            <Input label="Processing fee (₹)" type="number" value={o.processingFee} onChange={(e) => setO({ ...o, processingFee: e.target.value })} />
            <Input label="Tenure (months)" type="number" value={o.tenureMonths} onChange={(e) => setO({ ...o, tenureMonths: e.target.value })} />
          </div>
          <Input label="Regulatory registration number" value={o.regulatoryId} onChange={(e) => setO({ ...o, regulatoryId: e.target.value })} />
          <Textarea label="Key terms (EMI, penalties, repayment)" value={o.terms} onChange={(e) => setO({ ...o, terms: e.target.value })} />
        </div>
      </Modal>
    </>
  );
}
