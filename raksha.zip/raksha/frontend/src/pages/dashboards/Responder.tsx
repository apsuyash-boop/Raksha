import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Navigation, Radar, ShieldCheck, Siren } from 'lucide-react';
import { apiError, get, post, put } from '@/api/client';
import { useAuth } from '@/contexts/AuthContext';
import { useSocket } from '@/contexts/SocketContext';
import { getCurrentPosition, useGeolocation } from '@/hooks/useGeolocation';
import { MapView } from '@/components/MapView';
import { Badge, Button, Card, CardHeader, EmptyState, Modal, PageHeader, QueryState, Stat, Switch, Textarea } from '@/components/ui';
import { timeAgo } from '@/utils/format';

export default function Responder() {
  const { user } = useAuth();
  const socket = useSocket();
  const qc = useQueryClient();
  const profile = useQuery({ queryKey: ['responder-profile'], queryFn: () => get<{ profile: any; verification: any }>('/responders/me') });
  const inbox = useQuery({ queryKey: ['responder-inbox'], queryFn: () => get<{ alerts: any[] }>('/sos/responder/inbox'), enabled: !!user?.verified, refetchInterval: 15000 });
  const p = profile.data?.profile;
  const [report, setReport] = useState<any>(null);
  const [text, setText] = useState('');

  const toggle = useMutation({
    mutationFn: async (active: boolean) => {
      const pos = active ? await getCurrentPosition() : null;
      return put('/responders/me', { active, availabilityMode: active ? 'always' : 'off', lat: pos?.lat, lng: pos?.lng });
    },
    onSuccess: (r) => { toast.success(r._message); qc.invalidateQueries({ queryKey: ['responder-profile'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });
  // Keep position fresh while responder mode is on (used only for nearby matching).
  useGeolocation(!!p?.active, (pos) => socket?.emit('responder:location', { lat: pos.lat, lng: pos.lng }));

  const respond = useMutation({
    mutationFn: ({ id, action, report }: { id: string; action: string; report?: string }) => post(`/sos/${id}/respond`, { action, report }),
    onSuccess: (r) => { toast.success(r._message); setReport(null); qc.invalidateQueries({ queryKey: ['responder-inbox'] }); },
    onError: (e) => toast.error(apiError(e).message),
  });

  const verify = useMutation({ mutationFn: () => post('/responders/me/verification', { details: { note: 'Requesting responder verification' } }), onSuccess: (r) => { toast.success(r._message); qc.invalidateQueries({ queryKey: ['responder-profile'] }); } });
  const alerts = inbox.data?.alerts || [];

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Verified responder" title="Responder dashboard" subtitle="When a woman nearby presses SOS, you may be asked to help. You see an approximate area first; her exact location is shared only after you accept." />
      {!user?.verified ? (
        <Card className="p-6">
          <p className="font-semibold">Your responder account is awaiting verification.</p>
          <p className="mt-1 text-sm text-ink-mute">Raksha verifies identity and conducts background checks before anyone can receive emergency requests.</p>
          <Button className="mt-4" onClick={() => verify.mutate()} loading={verify.isPending} disabled={profile.data?.verification?.status === 'pending'}>{profile.data?.verification?.status === 'pending' ? 'Verification pending' : 'Request verification'}</Button>
        </Card>
      ) : (
        <>
          <Card className="p-5">
            <Switch checked={!!p?.active} onChange={(v) => toggle.mutate(v)} label={<span className="flex items-center gap-2"><Radar className="h-4 w-4 text-rk-600" /> Responder mode {p?.active ? 'ON' : 'OFF'}</span>} description="While on, your location is used only to decide whether you are near an emergency. Turn it off any time." />
          </Card>
          <div className="grid gap-4 sm:grid-cols-3">
            <Stat label="Requests received" value={p?.stats?.requestsReceived || 0} icon={<Siren className="h-4 w-4" />} />
            <Stat label="Accepted" value={p?.stats?.accepted || 0} icon={<ShieldCheck className="h-4 w-4" />} tone="safe" />
            <Stat label="Completed" value={p?.stats?.completed || 0} icon={<Navigation className="h-4 w-4" />} tone="ink" />
          </div>
          <QueryState q={inbox} isEmpty={!alerts.length} empty={<Card><EmptyState icon={<Radar className="h-6 w-6" />} title="No emergency requests" body="Requests near you will appear here instantly." /></Card>}>
            <div className="grid gap-4 lg:grid-cols-2">
              {alerts.map((a) => (
                <Card key={a.id} className={a.status === 'active' && a.myStatus === 'notified' ? 'ring-2 ring-rk-500' : ''}>
                  <CardHeader
                    title={a.status === 'active' ? 'Someone nearby needs help' : `SOS ${a.status}`}
                    subtitle={`${timeAgo(a.createdAt)} · ~${a.distanceKm ?? '?'} km away`}
                    icon={<Siren className="h-4 w-4" />}
                    action={<div className="flex gap-1.5">{a.isDemo && <Badge tone="warn">Demo</Badge>}<Badge tone={a.myStatus === 'accepted' || a.myStatus === 'arrived' ? 'safe' : 'neutral'}>{a.myStatus}</Badge></div>}
                  />
                  <div className="space-y-3 p-4">
                    {a.location && <MapView points={[{ lat: a.location.lat, lng: a.location.lng, approximate: !a.location.precise, label: a.location.precise ? a.person?.firstName : undefined, accuracy: a.location.precise ? 30 : undefined }]} height={220} zoom={a.location.precise ? 16 : 13} />}
                    {!a.location?.precise && <p className="text-xs text-ink-mute">Approximate area (~1 km). Exact location is shared after you accept.</p>}
                    {a.message && <p className="rounded-lg bg-sand-100 p-2 text-sm">"{a.message}"</p>}
                    {a.status === 'active' && (
                      <div className="flex flex-wrap gap-2">
                        {a.myStatus === 'notified' && (
                          <>
                            <Button onClick={() => respond.mutate({ id: a.id, action: 'accept' })} loading={respond.isPending}>I can help</Button>
                            <Button variant="ghost" onClick={() => respond.mutate({ id: a.id, action: 'decline' })}>Can't help now</Button>
                          </>
                        )}
                        {a.myStatus === 'accepted' && (
                          <>
                            {a.location?.precise && <a href={`https://www.google.com/maps/dir/?api=1&destination=${a.location.lat},${a.location.lng}`} target="_blank" rel="noreferrer"><Button icon={<Navigation className="h-4 w-4" />}>Navigate</Button></a>}
                            <Button variant="secondary" onClick={() => respond.mutate({ id: a.id, action: 'arrived' })}>I've arrived</Button>
                          </>
                        )}
                        {['accepted', 'arrived'].includes(a.myStatus) && <Button variant="outline" onClick={() => { setText(''); setReport(a); }}>Report completion</Button>}
                      </div>
                    )}
                    <p className="text-xs text-ink-mute">Your safety matters too: meet in a public, well-lit place and call 112 if there is violence.</p>
                  </div>
                </Card>
              ))}
            </div>
          </QueryState>
        </>
      )}
      <Modal open={!!report} onClose={() => setReport(null)} title="Report completion" footer={<Button loading={respond.isPending} onClick={() => respond.mutate({ id: report.id, action: 'complete', report: text })}>Submit</Button>}>
        <Textarea label="What happened? (shared with Raksha, not public)" value={text} onChange={(e) => setText(e.target.value)} />
      </Modal>
    </div>
  );
}
