export type Role = 'user' | 'emergency_contact' | 'responder' | 'lawyer' | 'ngo' | 'counsellor' | 'police' | 'donor' | 'lender' | 'admin';

export interface User {
  _id: string;
  id?: string;
  name: string;
  email?: string;
  phone?: string;
  role: Role;
  verified: boolean;
  emailVerified?: boolean;
  phoneVerified?: boolean;
  age?: number;
  state?: string;
  city?: string;
  language: string;
  avatarColor?: string;
  isDemo?: boolean;
  privacy?: {
    shareLocationWithContacts: boolean;
    allowNearbyResponders: boolean;
    shareMedicalInfoInSOS: boolean;
    autoRecordEvidenceOnSOS: boolean;
    showInCommunityAs: 'name' | 'first_name' | 'anonymous';
  };
  notificationPrefs?: { email: boolean; sms: boolean; whatsapp: boolean; inApp: boolean };
  createdAt?: string;
}

export interface TimelineItem {
  step: string;
  label: string;
  at: string;
  meta?: any;
}

export interface SOSAlert {
  _id: string;
  status: 'active' | 'cancelled' | 'resolved';
  isDemo: boolean;
  createdAt: string;
  location?: { type: 'Point'; coordinates: [number, number] };
  accuracy?: number;
  message?: string;
  timeline: TimelineItem[];
  contactDeliveries?: Array<{ name: string; channel: string; status: string; error?: string }>;
  responders?: Array<{ status: string; distanceKm?: number }>;
  emergencyService?: { status: string; message: string; reference?: string };
  evidence?: string[];
  contactsAlertedAt?: string;
  cancelledAt?: string;
  resolvedAt?: string;
}

export interface Contact {
  _id: string;
  name: string;
  relation?: string;
  phone?: string;
  email?: string;
  channels: { sms: boolean; whatsapp: boolean; email: boolean; app: boolean };
  linkedUser?: { _id: string; name: string } | null;
  priority: number;
  canViewLiveLocation: boolean;
}

export interface Evidence {
  _id: string;
  evidenceId: string;
  title: string;
  description?: string;
  category: string;
  kind: 'image' | 'video' | 'audio' | 'document';
  mimeType: string;
  size: number;
  sha256: string;
  capturedAt?: string;
  uploadedAt: string;
  gps?: { lat: number; lng: number; accuracy?: number };
  sos?: string;
  cases?: string[];
  verificationStatus: string;
  scanStatus: string;
  accessLog?: Array<{ user?: { name: string; role: string }; role: string; action: string; reason?: string; at: string }>;
  sharedWith?: Array<{ user?: { _id: string; name: string; role: string }; grantedAt: string }>;
}

export interface CaseItem {
  _id: string;
  caseNumber: string;
  type: string;
  title: string;
  description?: string;
  status: string;
  urgency: string;
  lawyer?: any;
  ngo?: any;
  user?: any;
  evidence?: any[];
  complaints?: any[];
  hearings?: Array<{ _id: string; date: string; court?: string; purpose?: string }>;
  importantDates?: Array<{ _id: string; date: string; label: string }>;
  notes?: Array<{ _id: string; author?: { name: string; role: string }; text: string; visibility: string; at: string }>;
  documents?: Array<{ _id: string; title: string; body?: string; at: string }>;
  timeline?: Array<{ _id: string; label: string; detail?: string; at: string; by?: { name: string; role: string } }>;
  requests?: Array<{ _id: string; providerType: string; status: string; at: string; message?: string; service?: string }>;
  consent?: { shareEvidenceWithAssigned: boolean; shareContactWithAssigned: boolean };
  location?: { city?: string; state?: string };
  language?: string;
  budget?: string;
  access?: string;
  createdAt: string;
  updatedAt: string;
}
