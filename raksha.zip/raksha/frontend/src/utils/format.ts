import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export const cn = (...c: ClassValue[]) => twMerge(clsx(c));

export const humanize = (s?: string) => (s ? s.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase()) : '');

export function fmtDate(d?: string | Date, withTime = false) {
  if (!d) return '';
  const date = new Date(d);
  return date.toLocaleString('en-IN', withTime ? { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' } : { day: 'numeric', month: 'short', year: 'numeric' });
}

export function fmtTime(d?: string | Date) {
  if (!d) return '';
  return new Date(d).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', second: '2-digit' });
}

export function timeAgo(d?: string | Date) {
  if (!d) return '';
  const s = Math.round((Date.now() - new Date(d).getTime()) / 1000);
  if (s < 0) {
    const f = -s;
    if (f < 3600) return `in ${Math.round(f / 60)} min`;
    if (f < 86400) return `in ${Math.round(f / 3600)} h`;
    return `in ${Math.round(f / 86400)} days`;
  }
  if (s < 45) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  if (s < 86400 * 30) return `${Math.round(s / 86400)} days ago`;
  return fmtDate(d);
}

export const inr = (n?: number) => `₹${Math.round(n || 0).toLocaleString('en-IN')}`;

export function bytes(n?: number) {
  if (!n) return '0 B';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export const initials = (name?: string) =>
  (name || '?')
    .replace(/\(.*?\)/g, '')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0])
    .join('')
    .toUpperCase();

export const CASE_TYPES = [
  ['domestic_violence', 'Domestic violence'],
  ['dowry', 'Dowry'],
  ['harassment', 'Harassment / stalking'],
  ['workplace_harassment', 'Workplace harassment'],
  ['divorce', 'Divorce'],
  ['maintenance', 'Maintenance'],
  ['child_custody', 'Child custody'],
  ['sexual_assault', 'Sexual assault'],
  ['cyber_crime', 'Online harassment'],
  ['other', 'Other'],
] as const;

export const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala',
  'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Jammu and Kashmir',
  'Ladakh', 'Lakshadweep', 'Puducherry',
];

export const LANGS: Array<[string, string]> = [
  ['en', 'English'],
  ['hi', 'हिन्दी'],
  ['mr', 'मराठी'],
  ['bn', 'বাংলা'],
  ['ta', 'தமிழ்'],
  ['te', 'తెలుగు'],
  ['kn', 'ಕನ್ನಡ'],
  ['ml', 'മലയാളം'],
  ['gu', 'ગુજરાતી'],
  ['pa', 'ਪੰਜਾਬੀ'],
  ['or', 'ଓଡ଼ିଆ'],
  ['ur', 'اردو'],
];

export const ROLE_HOME: Record<string, string> = {
  user: '/dashboard',
  emergency_contact: '/guardian',
  responder: '/responder/dashboard',
  lawyer: '/lawyer/dashboard',
  ngo: '/ngo/dashboard',
  counsellor: '/counsellor/dashboard',
  police: '/police/dashboard',
  donor: '/donate',
  lender: '/lender/dashboard',
  admin: '/admin/dashboard',
};

export const ROLE_LABEL: Record<string, string> = {
  user: 'Woman / User',
  emergency_contact: 'Emergency contact',
  responder: 'Verified responder',
  lawyer: 'Lawyer',
  ngo: 'NGO',
  counsellor: 'Counsellor',
  police: 'Police / official',
  donor: 'Donor',
  lender: 'Lending partner',
  admin: 'Administrator',
};
