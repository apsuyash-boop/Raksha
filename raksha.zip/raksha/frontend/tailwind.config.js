/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        rk: {
          50: '#FFF5F5',
          100: '#FFE4E6',
          200: '#FECDD3',
          300: '#FDA4AF',
          400: '#F17489',
          500: '#DC3D5A',
          600: '#B4233C',
          700: '#951B32',
          800: '#7A1328',
          900: '#5C0E1F',
        },
        ink: { DEFAULT: '#1F1A1C', soft: '#4A4245', mute: '#6F6669' },
        sand: { 50: '#FCFAF8', 100: '#F7F2EE', 200: '#EEE6E0', 300: '#DED3CB' },
        safe: { 50: '#EEF8F2', 100: '#D3EEDD', 500: '#2F7D5B', 600: '#24664A', 700: '#1C523B' },
        warn: { 50: '#FFF8EB', 500: '#B7791F', 700: '#8A5A12' },
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        sans: ['"Plus Jakarta Sans"', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        deva: ['"Noto Sans Devanagari"', '"Plus Jakarta Sans"', 'sans-serif'],
      },
      borderRadius: { '4xl': '2rem' },
      boxShadow: {
        card: '0 1px 2px rgba(31,26,28,.04), 0 4px 16px -4px rgba(31,26,28,.06)',
        lift: '0 2px 4px rgba(31,26,28,.05), 0 12px 32px -8px rgba(31,26,28,.12)',
        sos: '0 0 0 10px rgba(180,35,60,.10), 0 0 0 22px rgba(180,35,60,.05), 0 18px 40px -10px rgba(180,35,60,.55)',
      },
      keyframes: {
        pulseRing: { '0%': { transform: 'scale(.9)', opacity: '.55' }, '100%': { transform: 'scale(1.6)', opacity: '0' } },
        fadeUp: { '0%': { opacity: '0', transform: 'translateY(10px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
      },
      animation: {
        'pulse-ring': 'pulseRing 2.2s cubic-bezier(.2,.6,.3,1) infinite',
        'fade-up': 'fadeUp .5s ease-out both',
      },
    },
  },
  plugins: [],
};
